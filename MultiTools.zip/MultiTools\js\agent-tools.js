/**
 * agent-tools.js — MODO AGENTE (Fase 1 MVP)
 *
 * Transforma a IA em um agente que chama FERRAMENTAS uma a uma no AE
 * em vez de gerar 1 script gigante. Workflow:
 *
 *   1. user prompt -> chama Ollama com tools definidas
 *   2. Ollama responde com tool_calls (ex: create_comp(1080, 1920))
 *   3. cada tool_call roda no AE via MT_tool_dispatch (ExtendScript)
 *   4. resultado JSON volta como role:"tool" message
 *   5. chama Ollama de novo com o historico
 *   6. repete ate Ollama nao pedir mais tools (fim)
 *
 * UI: cada tool call vira um card na bolha do chat com status live
 */

(function() {
    'use strict';

    // ═══════════════════════════════════════════════════
    // DEFINICAO DAS TOOLS (formato OpenAI/Ollama)
    // ═══════════════════════════════════════════════════
    var AGENT_TOOLS = [
        {
            type: 'function',
            function: {
                name: 'create_comp',
                description: 'Cria uma nova composicao no After Effects e define como ativa. Chame isso PRIMEIRO antes de adicionar qualquer layer. Retorna comp_id que voce pode usar (opcional) nas proximas tools.',
                parameters: {
                    type: 'object',
                    properties: {
                        width:    { type: 'integer', description: 'Largura em pixels. Ex: 1080 (quadrado/reels), 1920 (horizontal)' },
                        height:   { type: 'integer', description: 'Altura em pixels. Ex: 1080 (quadrado), 1920 (reels vertical)' },
                        duration: { type: 'number',  description: 'Duracao total em segundos. Ex: 6, 10, 15' },
                        fps:      { type: 'integer', description: 'Frames por segundo. Default: 30' },
                        name:     { type: 'string',  description: 'Nome da comp. Ex: "PicPay_Motion"' }
                    },
                    required: ['width', 'height', 'duration', 'name']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'add_text',
                description: 'Adiciona uma text layer na comp ativa. Use pra titulos, subtitulos, body text. Retorna layer_id pra usar em set_keyframe e apply_helper depois.',
                parameters: {
                    type: 'object',
                    properties: {
                        text:      { type: 'string',  description: 'Conteudo do texto' },
                        font_size: { type: 'integer', description: 'Tamanho da fonte em px. Title=86, subtitle=48, body=30 (pra comp 1080)' },
                        color:     { type: 'string',  description: 'Cor HEX com #. Ex: "#FFFFFF", "#FF3B30"' },
                        font:      { type: 'string',  description: 'Nome da fonte. Default: "Arial-BoldMT"' },
                        align:     { type: 'string',  enum: ['c','l','r'], description: 'Alinhamento: c=center, l=left, r=right' },
                        x:         { type: 'number',  description: 'Position X (pixels). Centro da comp = comp.width/2' },
                        y:         { type: 'number',  description: 'Position Y (pixels). Centro = comp.height/2' },
                        anchor:    { type: 'string',  enum: ['TL','TC','TR','ML','MC','MR','BL','BC','BR'], description: 'Atalho de posicao (em vez de x/y). TC=top-center, MC=middle-center, etc' },
                        name:      { type: 'string',  description: 'Nome da layer. Ex: "Title", "Subtitle_Scene1"' },
                        in_point:  { type: 'number',  description: 'Tempo (seg) em que a layer aparece' },
                        out_point: { type: 'number',  description: 'Tempo (seg) em que a layer some' }
                    },
                    required: ['text']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'add_shape_rect',
                description: 'Adiciona um retangulo/shape layer na comp. Use pra cards, buttons, BGs decorativos. Se is_bg=true, cria um Solid full-comp (para background). Retorna layer_id.',
                parameters: {
                    type: 'object',
                    properties: {
                        width:        { type: 'integer', description: 'Largura do retangulo em px (ignored se is_bg=true)' },
                        height:       { type: 'integer', description: 'Altura do retangulo em px (ignored se is_bg=true)' },
                        color:        { type: 'string',  description: 'Cor de fill HEX' },
                        stroke_color: { type: 'string',  description: 'Cor da borda HEX. Opcional.' },
                        stroke_width: { type: 'number',  description: 'Espessura da borda. Default: 2' },
                        roundness:    { type: 'number',  description: 'Arredondamento das pontas (0 = reto). Ex: 20, 40' },
                        x:            { type: 'number',  description: 'Position X' },
                        y:            { type: 'number',  description: 'Position Y' },
                        anchor:       { type: 'string',  enum: ['TL','TC','TR','ML','MC','MR','BL','BC','BR'], description: 'Atalho de posicao' },
                        name:         { type: 'string',  description: 'Nome da layer' },
                        in_point:     { type: 'number' },
                        out_point:    { type: 'number' },
                        is_bg:        { type: 'boolean', description: 'Se true, cria um Solid full-comp (ignora width/height/x/y). Use pra BG principal.' }
                    },
                    required: ['color']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'set_keyframe',
                description: 'Cria um keyframe numa propriedade de uma layer (position, scale, opacity, rotation, anchor). Use multiplos set_keyframe na mesma propriedade pra criar animacao entre valores.',
                parameters: {
                    type: 'object',
                    properties: {
                        layer_id: { type: 'integer', description: 'ID da layer (retornado por add_text/add_shape_rect)' },
                        property: { type: 'string',  enum: ['position','scale','opacity','rotation','anchor'], description: 'Propriedade animada' },
                        time:     { type: 'number',  description: 'Tempo do keyframe em segundos (tempo absoluto da comp)' },
                        value:    { description: 'Valor. position/scale/anchor = [x,y] (array). opacity/rotation = numero' }
                    },
                    required: ['layer_id', 'property', 'time', 'value']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'apply_helper',
                description: 'Aplica um helper de animacao pre-feito na layer. Mais rapido que criar keyframes um por um. Helpers: pop_in, bounce_pop, fade_in, fade_out, slide_in_up, slide_in_left, drop_shadow, glow.',
                parameters: {
                    type: 'object',
                    properties: {
                        layer_id:   { description: 'ID da layer (numero, "last", ou name string)' },
                        helper:     { type: 'string',  enum: ['pop_in','bounce_pop','fade_in','fade_out','slide_in_up','slide_in_left','drop_shadow','glow'], description: 'Helper a aplicar' },
                        time_start: { type: 'number',  description: 'Tempo em que o helper comeca (seg). Default: layer.inPoint' },
                        duration:   { type: 'number',  description: 'Duracao do helper em seg. Default: 0.4' },
                        params:     { type: 'object',  description: 'Params extras do helper. Ex: {opacity:60, distance:10} pro drop_shadow' }
                    },
                    required: ['layer_id', 'helper']
                }
            }
        },

        // ═══════ FASE 3 — TOOLS AVANCADAS ═══════
        {
            type: 'function',
            function: {
                name: 'set_parent',
                description: 'Faz uma layer ser filha de outra (parenting). Essencial pra null controllers, cascata de animacoes, grupos 3D. Passar parent_id:null remove o parent.',
                parameters: {
                    type: 'object',
                    properties: {
                        child_id:  { description: 'ID da layer filha' },
                        parent_id: { description: 'ID da layer pai (ou null/vazio pra remover parent)' }
                    },
                    required: ['child_id']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'set_expression',
                description: 'Aplica uma expressao AE numa propriedade. Use pra efeitos procedurais: wiggle(3,20) = shake, loopOut("cycle") = repetir keyframes, time*30 = rotacao continua, random()*100 = variacao. Expressao vazia "" remove.',
                parameters: {
                    type: 'object',
                    properties: {
                        layer_id:   { description: 'ID da layer' },
                        property:   { type: 'string', enum: ['position','scale','opacity','rotation','anchor'], description: 'Propriedade' },
                        expression: { type: 'string', description: 'Codigo da expressao AE. Ex: "wiggle(3, 20)", "time*30", "loopOut()"' }
                    },
                    required: ['layer_id', 'property', 'expression']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'apply_effect',
                description: 'Aplica qualquer efeito do AE. Use display name comum (Gaussian Blur, Drop Shadow, Glow, Tint, Levels, Fill, Hue/Saturation, Brightness & Contrast, 4-Color Gradient, Noise, Ramp, Bevel & Emboss) ou matchName (ex: "ADBE Gaussian Blur 2"). params aplica parametros por nome.',
                parameters: {
                    type: 'object',
                    properties: {
                        layer_id: { description: 'ID da layer' },
                        effect:   { type: 'string', description: 'Nome do efeito. Ex: "Gaussian Blur", "Drop Shadow", "Glow", "Tint", "Levels"' },
                        params:   { type: 'object', description: 'Parametros do efeito por nome. Ex: {"Blurriness": 20} pro Gaussian Blur' }
                    },
                    required: ['layer_id', 'effect']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'add_null',
                description: 'Cria uma Null Object layer (controlador invisivel). Use como parent pra grupos de layers, cameras, ou animar algo sem ser renderizado. Retorna layer_id.',
                parameters: {
                    type: 'object',
                    properties: {
                        name:      { type: 'string',  description: 'Nome do null' },
                        x:         { type: 'number',  description: 'Position X' },
                        y:         { type: 'number',  description: 'Position Y' },
                        in_point:  { type: 'number' },
                        out_point: { type: 'number' },
                        threeD:    { type: 'boolean', description: 'Se true, null fica 3D pra controllers de camera' }
                    }
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'duplicate_layer',
                description: 'Duplica uma layer existente. Util pra fazer stagger de muitos elementos iguais com timing diferente. Mantem animacoes, parent, expressoes — muda so nome e timing.',
                parameters: {
                    type: 'object',
                    properties: {
                        layer_id:    { description: 'ID da layer original' },
                        new_name:    { type: 'string', description: 'Nome da copia' },
                        time_offset: { type: 'number', description: 'Deslocamento em seg no in/outPoint. Ex: 0.1 pra stagger.' },
                        in_point:    { type: 'number', description: 'inPoint absoluto (override)' },
                        out_point:   { type: 'number', description: 'outPoint absoluto (override)' }
                    },
                    required: ['layer_id']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'set_3d_layer',
                description: 'Habilita/desabilita 3D numa layer. Permite rotateX/Y, position Z. Precisa de camera na comp pra visualizar.',
                parameters: {
                    type: 'object',
                    properties: {
                        layer_id: { description: 'ID da layer' },
                        enabled:  { type: 'boolean', description: 'true ativa 3D, false desativa' }
                    },
                    required: ['layer_id']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'set_blend_mode',
                description: 'Muda blend mode da layer. Use pra efeitos como neon (Add, Screen), color tint (Multiply, Color), contraste (Overlay). Modes: Normal, Add, Screen, Multiply, Overlay, Darken, Lighten, Difference, Soft Light, Hard Light, Color Dodge, Color Burn, Hue, Saturation, Color, Luminosity.',
                parameters: {
                    type: 'object',
                    properties: {
                        layer_id: { description: 'ID da layer' },
                        mode:     { type: 'string', description: 'Blend mode. Ex: "Screen", "Add", "Multiply", "Overlay"' }
                    },
                    required: ['layer_id', 'mode']
                }
            }
        },

        // ═══════ FASE 4 — TOOLS DE INSPECAO + BATCH + UNDO GRANULAR ═══════
        {
            type: 'function',
            function: {
                name: 'query_state',
                description: 'INSPECAO — retorna o estado atual: comp ativa (nome, dimensoes, duracao) + lista de TODAS as layers criadas (id, name, type, in_point, out_point, position, parent). Use pra verificar o que ja existe antes de criar algo novo. NAO modifica nada.',
                parameters: { type: 'object', properties: {} }
            }
        },
        {
            type: 'function',
            function: {
                name: 'set_keyframes',
                description: 'BATCH: cria MULTIPLOS keyframes numa chamada (mais eficiente que chamar set_keyframe varias vezes). Tipico pra animacoes customizadas tipo bounce manual ou morphing complexo.',
                parameters: {
                    type: 'object',
                    properties: {
                        layer_id:  { description: 'ID da layer' },
                        property:  { type: 'string', enum: ['position','scale','opacity','rotation','anchor'], description: 'Propriedade' },
                        keyframes: {
                            type: 'array',
                            description: 'Array de keyframes: [{time, value}, ...]. Ex: [{time:0,value:[0,0]},{time:0.3,value:[100,100]}]',
                            items: { type: 'object', properties: { time: { type: 'number' }, value: {} } }
                        }
                    },
                    required: ['layer_id', 'property', 'keyframes']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'set_transform',
                description: 'BATCH: seta multiplas propriedades de transform numa chamada (position + scale + rotation + anchor + opacity). Use pra posicionar/configurar rapido sem fazer multiplas tool calls.',
                parameters: {
                    type: 'object',
                    properties: {
                        layer_id: { description: 'ID da layer' },
                        position: { description: 'Array [x,y]. Opcional.' },
                        scale:    { description: 'Array [sx,sy] ou numero unico. Opcional.' },
                        rotation: { type: 'number', description: 'Graus. Opcional.' },
                        anchor:   { description: 'Array [x,y]. Opcional.' },
                        opacity:  { type: 'number', description: '0-100. Opcional.' }
                    },
                    required: ['layer_id']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'delete_layer',
                description: 'Remove uma layer criada. Use pra UNDO GRANULAR se voce errou (ex: criou layer errada com set_transform). NAO use pra remover layer que pretende usar em outra coisa.',
                parameters: {
                    type: 'object',
                    properties: {
                        layer_id: { description: 'ID da layer a remover' }
                    },
                    required: ['layer_id']
                }
            }
        },

        // ═══════ FASE 5 — WEB SEARCH + PLANNING ═══════
        {
            type: 'function',
            function: {
                name: 'search_web',
                description: 'Busca na web pra encontrar referencias: cores de marca (ex: "Nubank brand colors hex"), tendencias de motion ("viral reel motion 2024"), paletas tematicas ("cyberpunk color palette"), fontes, conceitos. Retorna snippets de DuckDuckGo + Wikipedia. Use NO INICIO do motion, antes de create_comp, pra pesquisar a estetica/cores certas.',
                parameters: {
                    type: 'object',
                    properties: {
                        query:       { type: 'string',  description: 'Query de busca. Ex: "Nubank roxo hex color", "cyberpunk motion graphics 2024", "minimalist ad palette"' },
                        max_results: { type: 'integer', description: 'Max resultados. Default: 5' }
                    },
                    required: ['query']
                }
            }
        },

        // ═══════ FASE 6 — AUTOMATION TOOLS (trabalha com layers/comps EXISTENTES) ═══════
        {
            type: 'function',
            function: {
                name: 'get_selected_layers',
                description: 'Retorna info das layers que o USUARIO selecionou na timeline. Use ANTES de aplicar operacoes em selecao (stagger, batch_rename, align, etc). Retorna lista com index, name, type, in_point, out_point.',
                parameters: { type: 'object', properties: {} }
            }
        },
        {
            type: 'function',
            function: {
                name: 'list_comps',
                description: 'Lista TODAS as composicoes existentes no projeto AE. Use pra descobrir o que existe antes de criar comp nova ou pra mudar pra outra comp.',
                parameters: { type: 'object', properties: {} }
            }
        },
        {
            type: 'function',
            function: {
                name: 'open_comp',
                description: 'Abre uma composicao existente no viewer (ativa ela). Use pra mudar de comp antes de modificar/adicionar layers nela.',
                parameters: {
                    type: 'object',
                    properties: {
                        name:  { type: 'string',  description: 'Nome exato da comp' },
                        index: { type: 'integer', description: 'Index do item no project (1-based) — alternativa ao name' }
                    }
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'pre_compose_selected',
                description: 'Pre-compoe (encapsula) as layers SELECIONADAS em uma nova composicao filha. Operacao classica de organizacao no AE. Use quando o usuario pedir "pre-comp essas layers" ou pra agrupar elementos.',
                parameters: {
                    type: 'object',
                    properties: {
                        name:            { type: 'string',  description: 'Nome da pre-comp criada' },
                        move_attributes: { type: 'boolean', description: 'true = move atributos pra pre-comp (padrao). false = mantem atributos na layer container.' }
                    }
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'batch_rename_selected',
                description: 'Renomeia TODAS as layers selecionadas com um pattern. Use {N} pra numero (1, 2, 3) ou {n} pra numero zero-padded (01, 02). Ex: pattern="Card_{N}" gera "Card_1", "Card_2", "Card_3".',
                parameters: {
                    type: 'object',
                    properties: {
                        pattern: { type: 'string',  description: 'Pattern com {N} ou {n}. Ex: "Card_{N}", "Item_{n}", "Bg_layer"' },
                        start:   { type: 'integer', description: 'Numero inicial. Default: 1' }
                    },
                    required: ['pattern']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'align_selected',
                description: 'Alinha as layers SELECIONADAS no centro horizontal/vertical da comp (ou ao redor da primeira/ultima layer).',
                parameters: {
                    type: 'object',
                    properties: {
                        axis:   { type: 'string', enum: ['h','v','both'], description: 'h=horizontal (X), v=vertical (Y), both=ambos' },
                        anchor: { type: 'string', enum: ['comp','first','last'], description: 'comp=centro da comp, first=primeira layer, last=ultima' }
                    }
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'stagger_selected',
                description: 'Cascade — Offset em sequencia o startTime das layers SELECIONADAS. Cria efeito de cascata visual. Ex: offset=0.1 com 5 layers cria delays 0, 0.1, 0.2, 0.3, 0.4s.',
                parameters: {
                    type: 'object',
                    properties: {
                        offset: { type: 'number', description: 'Delta em segundos entre cada layer. Ex: 0.1, 0.05, 0.2' },
                        from:   { type: 'string', enum: ['first','last'], description: 'first=primeira nao desloca, ultima desloca mais. last=inverso.' }
                    },
                    required: ['offset']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'trim_selected',
                description: 'Define inPoint/outPoint das layers SELECIONADAS. Use pra cortar/extender duracao de varias layers de uma vez.',
                parameters: {
                    type: 'object',
                    properties: {
                        in_point:  { type: 'number', description: 'Tempo de entrada (s). Opcional.' },
                        out_point: { type: 'number', description: 'Tempo de saida (s). Opcional.' }
                    }
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'toggle_layer_flag',
                description: 'Liga/desliga flags da layer (solo, enabled/visible, locked, shy, threeD). Se layer_id for omitido, aplica em selectedLayers.',
                parameters: {
                    type: 'object',
                    properties: {
                        layer_id: { description: 'ID da layer especifica (opcional — sem isso aplica nas selecionadas)' },
                        flag:     { type: 'string', enum: ['solo','enabled','locked','shy','threeD'], description: 'Flag a togglar' },
                        value:    { type: 'boolean', description: 'true/false. Omitido = inverte estado atual.' }
                    },
                    required: ['flag']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'apply_to_selected',
                description: 'BATCH: aplica apply_helper OU apply_effect em TODAS as layers SELECIONADAS de uma vez. Economiza chamadas se o usuario quiser "drop shadow em todos selecionados" ou "fade in em tudo".',
                parameters: {
                    type: 'object',
                    properties: {
                        tool:   { type: 'string', enum: ['apply_helper','apply_effect'], description: 'Qual tool replicar' },
                        params: { type: 'object', description: 'Params da tool (sem layer_id — vai aplicar em cada selected). Ex: {helper:"fade_in", time_start:0, duration:0.4}' }
                    },
                    required: ['tool', 'params']
                }
            }
        },
        {
            type: 'function',
            function: {
                name: 'save_project',
                description: 'Salva o projeto AE atual (Ctrl+S programatico). Falha se o projeto ainda nao foi salvo (precisa ter feito Save As antes).',
                parameters: { type: 'object', properties: {} }
            }
        },
        {
            type: 'function',
            function: {
                name: 'set_work_area',
                description: 'Define a work area da comp ativa (regiao de loop/preview/render). Use quando o usuario pedir "renderiza so de 2 a 5 segundos" ou "loop dessa parte".',
                parameters: {
                    type: 'object',
                    properties: {
                        'in':  { type: 'number', description: 'Tempo inicial em segundos' },
                        out:   { type: 'number', description: 'Tempo final em segundos' }
                    }
                }
            }
        },

        {
            type: 'function',
            function: {
                name: 'plan_motion',
                description: 'PLANEJAMENTO — registra o plano do motion antes de executar. Use como SEGUNDA tool (depois de search_web se precisar). Forca voce a pensar em TODAS as cenas, timings, estilos e transicoes ANTES de construir. Depois disso execute scene por scene seguindo o plano.',
                parameters: {
                    type: 'object',
                    properties: {
                        title: { type: 'string', description: 'Titulo curto do motion' },
                        total_duration: { type: 'number', description: 'Duracao total em segundos' },
                        dimensions: { type: 'string', enum: ['1080x1080','1080x1920','1920x1080','1920x1920'], description: 'Formato' },
                        palette: {
                            type: 'array',
                            description: 'Paleta de 3-5 cores HEX coesas',
                            items: { type: 'string' }
                        },
                        style: { type: 'string', description: 'Estilo geral: kinetic_typo, cards_ui, hypnotic_loop, reel_structure, neon_glow, null_cascade, custom' },
                        scenes: {
                            type: 'array',
                            description: 'Lista de cenas com proposito, timing, elementos e animacoes',
                            items: {
                                type: 'object',
                                properties: {
                                    name: { type: 'string' },
                                    start: { type: 'number' },
                                    end: { type: 'number' },
                                    purpose: { type: 'string', description: 'Objetivo narrativo: hook, problema, solucao, cta, etc' },
                                    elements: { type: 'array', items: { type: 'string' }, description: 'Lista de elementos (ex: "texto BIG", "card 800x200", "null_ctrl")' },
                                    animations: { type: 'array', items: { type: 'string' }, description: 'Animacoes previstas (ex: "bounce_pop", "slide_in_up", "wiggle rotation")' }
                                }
                            }
                        }
                    },
                    required: ['title', 'total_duration', 'scenes']
                }
            }
        }
    ];

    // ═══════════════════════════════════════════════════
    // JS TOOLS — rodam no painel (nao no ExtendScript)
    // ═══════════════════════════════════════════════════
    var JS_TOOLS = {
        // plan_motion — registra plano estruturado do motion (nao executa nada no AE)
        // Serve pra forcar a IA a pensar antes de construir. O plano eh ecoado de volta
        // pra servir de "check" durante a execucao das cenas.
        plan_motion: function(args, callback) {
            try {
                var plan = {
                    title: args.title || 'Motion',
                    total_duration: args.total_duration || 6,
                    dimensions: args.dimensions || '1080x1920',
                    palette: args.palette || [],
                    style: args.style || 'custom',
                    scenes: args.scenes || []
                };
                // Valida que os tempos das cenas cobrem a duracao total
                var lastEnd = 0;
                for (var i = 0; i < plan.scenes.length; i++) {
                    if (plan.scenes[i].end > lastEnd) lastEnd = plan.scenes[i].end;
                }
                plan._coverage_ok = Math.abs(lastEnd - plan.total_duration) < 0.5;
                plan._scene_count = plan.scenes.length;
                callback({ ok: true, data: plan });
            } catch(e) {
                callback({ ok: false, error: 'plan_motion invalido: ' + e.message });
            }
        },

        // search_web — busca na web via DuckDuckGo Instant Answer + Wikipedia fallback
        search_web: function(args, callback) {
            var query = String(args.query || '').trim();
            if (!query) { callback({ ok: false, error: 'query vazio' }); return; }

            var maxResults = args.max_results || 5;
            var results = [];

            // 1) DuckDuckGo Instant Answer (JSON, free, no key)
            var ddgUrl = 'https://api.duckduckgo.com/?q=' + encodeURIComponent(query) + '&format=json&no_html=1&skip_disambig=1';

            fetch(ddgUrl)
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    // Abstract (resumo do tema)
                    if (data.AbstractText) {
                        results.push({
                            title: data.Heading || query,
                            snippet: data.AbstractText.substring(0, 400),
                            source: data.AbstractSource || 'DuckDuckGo',
                            url: data.AbstractURL || ''
                        });
                    }
                    // Related topics (topicos relacionados)
                    if (data.RelatedTopics && data.RelatedTopics.length) {
                        for (var i = 0; i < Math.min(maxResults - results.length, data.RelatedTopics.length); i++) {
                            var rt = data.RelatedTopics[i];
                            if (rt.Text) {
                                results.push({
                                    title: (rt.Text.split(' - ')[0] || '').substring(0, 80),
                                    snippet: rt.Text.substring(0, 400),
                                    source: 'DuckDuckGo',
                                    url: rt.FirstURL || ''
                                });
                            }
                        }
                    }
                    // Se DuckDuckGo deu pouco, busca na Wikipedia pra completar
                    if (results.length < 2) {
                        var wikiUrl = 'https://en.wikipedia.org/api/rest_v1/page/summary/' + encodeURIComponent(query.replace(/ /g, '_'));
                        fetch(wikiUrl)
                            .then(function(wr) { return wr.ok ? wr.json() : null; })
                            .then(function(wd) {
                                if (wd && wd.extract) {
                                    results.push({
                                        title: wd.title || query,
                                        snippet: wd.extract.substring(0, 400),
                                        source: 'Wikipedia',
                                        url: (wd.content_urls && wd.content_urls.desktop && wd.content_urls.desktop.page) || ''
                                    });
                                }
                                callback({ ok: true, data: { query: query, results: results, count: results.length } });
                            })
                            .catch(function() {
                                callback({ ok: true, data: { query: query, results: results, count: results.length } });
                            });
                    } else {
                        callback({ ok: true, data: { query: query, results: results, count: results.length } });
                    }
                })
                .catch(function(err) {
                    callback({ ok: false, error: 'search_web falhou: ' + err.message });
                });
        }
    };

    // ═══════════════════════════════════════════════════
    // DISPATCHER — executa tool call (JS ou ExtendScript)
    // ═══════════════════════════════════════════════════
    function dispatchTool(csInterface, tool_name, args, callback) {
        var startTime = Date.now();

        // Se eh uma JS tool, executa no browser
        if (JS_TOOLS[tool_name]) {
            JS_TOOLS[tool_name](args || {}, function(result) {
                result._elapsed_ms = Date.now() - startTime;
                callback(result);
            });
            return;
        }

        // Senao, vai pro ExtendScript no AE
        var argsJSON;
        try {
            argsJSON = JSON.stringify(args || {});
        } catch(e) {
            callback({ ok: false, error: 'args JSON invalido: ' + e.message });
            return;
        }
        var escaped = argsJSON.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
        var script = 'MT_tool_dispatch("' + tool_name + '", "' + escaped + '")';
        csInterface.evalScript(script, function(result) {
            var elapsed = Date.now() - startTime;
            try {
                var data = JSON.parse(result);
                data._elapsed_ms = elapsed;
                callback(data);
            } catch(e) {
                callback({ ok: false, error: 'parse erro: ' + e.message + ' | raw: ' + result, _elapsed_ms: elapsed });
            }
        });
    }

    // ═══════════════════════════════════════════════════
    // AGENT LOOP — chama Ollama, executa tools, repete
    // ═══════════════════════════════════════════════════
    function runAgent(options) {
        // options = {
        //   provider: {endpoint, key, model},
        //   systemPrompt: '...',
        //   userPrompt: '...',
        //   maxSteps: 30,
        //   csInterface: <CSInterface>,
        //   onToolCall: function(name, args, index) {...},      // antes de executar
        //   onToolResult: function(name, result, index) {...},  // depois de executar
        //   onAssistant: function(text) {...},                   // mensagem final da IA
        //   onError: function(err) {...},
        //   onStatus: function(msg) {...}
        // }
        options = options || {};
        var maxSteps = options.maxSteps || 30;
        var messages = [
            { role: 'system', content: options.systemPrompt || '' },
            { role: 'user',   content: options.userPrompt   || '' }
        ];
        var step = 0;
        var toolCallIndex = 0;
        var aborted = false;
        // Same-error loop detection: guarda hash das ultimas tool calls + resultado
        var recentErrors = {};

        function log(msg) { if (options.onStatus) options.onStatus(msg); }

        // Hash simples de tool call pra detectar loop (nome + args JSON)
        function callHash(name, args) {
            try { return name + '::' + JSON.stringify(args); }
            catch(e) { return name + '::<unstringifiable>'; }
        }

        // Provider unico: Ollama Cloud (qwen3-coder:480b-cloud, 1M via Yarn)
        function callLLM(provider, systemPrompt, historyMsgs, callback) {
            callOllama(provider, systemPrompt, historyMsgs, callback);
        }

        function callOllama(provider, systemPrompt, historyMsgs, callback) {
            // historyMsgs ja vem no formato Ollama: [{role, content, tool_calls?}]
            var msgsOut = [{ role: 'system', content: systemPrompt }].concat(historyMsgs);
            var reqBody = {
                model: provider.model,
                messages: msgsOut,
                tools: AGENT_TOOLS,
                stream: false,
                options: {
                    temperature: 0.3,
                    num_predict: 8000,
                    num_ctx: 1048576,        // 1M ctx (Yarn extrapolation no qwen3-coder)
                    rope_scaling: { type: 'yarn', factor: 4.0, original_max_position_embeddings: 262144 }
                }
            };
            fetch(provider.endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + provider.key },
                body: JSON.stringify(reqBody)
            })
            .then(function(r) {
                if (!r.ok) return r.text().then(function(err) {
                    throw new Error('Ollama ' + r.status + ': ' + err.substring(0, 300));
                });
                return r.json();
            })
            .then(function(data) {
                if (data.error) throw new Error('Ollama erro: ' + data.error);
                var msg = data.message || {};
                var content = msg.content || '';
                var toolCallsRaw = msg.tool_calls || [];
                var toolCalls = [];
                for (var i = 0; i < toolCallsRaw.length; i++) {
                    var tc = toolCallsRaw[i];
                    var fn = tc.function || {};
                    var args = fn.arguments;
                    if (typeof args === 'string') {
                        try { args = JSON.parse(args); } catch(e) { args = {}; }
                    }
                    toolCalls.push({ name: fn.name, args: args || {} });
                }
                callback({ content: content, toolCalls: toolCalls, raw: data });
            })
            .catch(function(err) { callback({ error: err }); });
        }

        // ═══════════════════════════════════════════════════
        // STEP LOOP
        // ═══════════════════════════════════════════════════
        function step_call() {
            if (aborted) return;
            if (step >= maxSteps) {
                log('⚠ Limite de ' + maxSteps + ' steps atingido');
                if (options.onAssistant) options.onAssistant('[Limite de steps atingido]');
                return;
            }
            step++;
            if (options.onStep) options.onStep(step, maxSteps);

            // historyMsgs = tudo de messages EXCETO o system (que vai inline no callLLM)
            var history = messages.slice(1);
            var systemPrompt = (messages[0] && messages[0].content) || '';

            log('Step ' + step + ' — chamando ' + options.provider.name + '...');

            callLLM(options.provider, systemPrompt, history, function(res) {
                if (aborted) return;
                if (res.error) { log('✗ ' + res.error.message); if (options.onError) options.onError(res.error); return; }

                var content = res.content || '';
                var toolCalls = res.toolCalls || [];

                // Adiciona resposta assistant ao historico universal (formato Ollama-like)
                // Preserva o _id de cada tool_call (vindo do Groq) pra linkar com tool result depois
                var assistantMsg = {
                    role: 'assistant',
                    content: content
                };
                if (toolCalls.length > 0) {
                    assistantMsg.tool_calls = toolCalls.map(function(tc, idx) {
                        return {
                            id: 'call_' + step + '_' + idx,
                            function: { name: tc.name, arguments: tc.args }
                        };
                    });
                }
                messages.push(assistantMsg);

                if (toolCalls.length === 0) {
                    log('✓ Agente finalizou');
                    if (options.onAssistant) options.onAssistant(content);
                    return;
                }

                // Executa tool calls sequencialmente
                var executeOne = function(i) {
                    if (aborted || i >= toolCalls.length) { step_call(); return; }
                    var tc = toolCalls[i];
                    var name = tc.name;
                    var args = tc.args;

                    var idx = toolCallIndex++;
                    var hash = callHash(name, args);

                    // Pega o id do tool_call correspondente no assistant message (pra Groq/OpenAI)
                    var thisToolId = (assistantMsg.tool_calls && assistantMsg.tool_calls[i] && assistantMsg.tool_calls[i].id) || ('call_' + step + '_' + i);

                    // LOOP DETECTION
                    if (recentErrors[hash] && recentErrors[hash] >= 2) {
                        log('🛑 Loop detectado: ' + name + ' falhou 2x com mesmos args');
                        if (options.onToolCall) options.onToolCall(name, args, idx, step);
                        var loopErr = {
                            ok: false,
                            error: 'LOOP DETECTADO: esta mesma chamada falhou ' + recentErrors[hash] + 'x. MUDE A ESTRATEGIA.',
                            _elapsed_ms: 0
                        };
                        if (options.onToolResult) options.onToolResult(name, loopErr, idx, step);
                        messages.push({ role: 'tool', tool_name: name, tool_call_id: thisToolId, content: JSON.stringify(loopErr) });
                        executeOne(i + 1);
                        return;
                    }

                    if (options.onToolCall) options.onToolCall(name, args, idx, step);

                    dispatchTool(options.csInterface, name, args, function(result) {
                        if (!result.ok) {
                            recentErrors[hash] = (recentErrors[hash] || 0) + 1;
                        } else {
                            delete recentErrors[hash];
                        }
                        if (options.onToolResult) options.onToolResult(name, result, idx, step);

                        var toolContent;
                        try { toolContent = JSON.stringify(result); }
                        catch(e) { toolContent = String(result); }
                        messages.push({ role: 'tool', tool_name: name, tool_call_id: thisToolId, content: toolContent });

                        executeOne(i + 1);
                    });
                };
                executeOne(0);
            });
        }

        step_call();

        // Retorna handler pra abortar
        return {
            abort: function() { aborted = true; log('Agente abortado pelo usuario'); }
        };
    }

    // ═══════════════════════════════════════════════════
    // EXPORT
    // ═══════════════════════════════════════════════════
    window.MT_AGENT = {
        TOOLS: AGENT_TOOLS,
        runAgent: runAgent,
        dispatchTool: dispatchTool
    };

})();
