# ADDON — LOGICA DE CENAS COMPLEXAS MULTI-PARTE

Este addon ensina como criar animacoes com MULTIPLAS CENAS que trocam de contexto visual (chat > UI de app > mapa > outro). Baseado em scripts que funcionaram 100% sem bugs.

---

## 1. REGRA DE OURO: CRIAR CENAS DE TRAS PRA FRENTE

O segredo pra layers ficarem na ordem certa: criar as cenas NA ORDEM INVERSA. A ultima cena primeiro, a primeira cena por ultimo.

```javascript
// ❌ ERRADO — cria na ordem cronologica
// Cena 1 (0-7s) -> Cena 2 (7-14s) -> Cena 3 (14-18s) -> Cena 4 (18-25s)
// Resultado: layers da Cena 1 ficam ATRAS de tudo

// ✅ CORRETO — cria na ordem inversa
// Cena 4 (18-25s) -> Cena 3 (14-18s) -> Cena 2 (7-14s) -> Cena 1 (0-7s)
// Resultado: layers da Cena 1 ficam NA FRENTE (aparecem primeiro)
```

POR QUE: No AE, cada layer novo vai pro TOPO da timeline. Se voce cria Cena 1 primeiro, ela vai pro topo. Depois cria Cena 2 que vai pro topo acima da Cena 1. No final, a Cena 4 (que deveria aparecer por ultimo) esta no topo cobrindo tudo.

Criando de tras pra frente, a Cena 1 (criada por ultimo) fica naturalmente no topo, aparecendo primeiro.

---

## 2. FUNDOS POR CENA — inPoint/outPoint OBRIGATORIOS

Cada cena que tem fundo diferente precisa de um solido proprio com inPoint e outPoint.

```javascript
// Cena 1: fundo preto (0-7s)
var bgChat = mkSolid(comp, [0,0,0], "BG_Chat");
if (bgChat) { bgChat.outPoint = 7.0; }

// Cena 2: fundo branco (7-14s)
var bgUI = mkSolid(comp, [1,1,1], "BG_UI");
if (bgUI) { bgUI.inPoint = 7.0; bgUI.outPoint = 14.0; fade(bgUI, 7.0, null); }

// Cena 3: fundo verde mapa (14-18s)
var bgMap = mkSolid(comp, AE.hex("#B2EBC8"), "BG_Map");
if (bgMap) { bgMap.inPoint = 14.0; bgMap.outPoint = 18.0; }

// Cena 4: fundo preto outro (18-25s)
var bgOutro = mkSolid(comp, [0,0,0], "BG_Outro");
if (bgOutro) { bgOutro.inPoint = 18.0; }
```

---

## 3. ANIMACAO DE CHAT/iMESSAGE

### 3.1 Estrutura de dados do chat
```javascript
var mensagens = [
    {t: "yo, wanna hang out tonight?", isMe: false, y: 500, w: 550, time: 0.5},
    {t: "Yea, let's do it.", isMe: true, y: 650, w: 350, time: 2.0},
    {t: "Can you pick me up?", isMe: true, y: 800, w: 450, time: 3.5},
    {t: "Just go Uber.", isMe: false, y: 1100, w: 320, time: 5.5}
];
```

### 3.2 Bolha de digitando ("..." pulsante)
```javascript
// Aparece ANTES da resposta, some quando a resposta chega
var typingBubble = mkRect(comp, [280, 950], [150, 80], 40, corCinza, null, 0, "Typing");
if (typingBubble) {
    typingBubble.inPoint = 4.2;     // aparece antes da msg
    typingBubble.outPoint = 5.4;    // some quando a msg aparece
    springScale(typingBubble, 4.2, 5.2);
}
var typingDots = mkText(comp, "...", [280, 960], 60, [1,1,1], "Arial-BoldMT", "c", "TypingDots");
if (typingDots) {
    typingDots.inPoint = 4.3;
    typingDots.outPoint = 5.4;
    fade(typingDots, 4.3, 5.3);
}
```

### 3.3 Loop de criacao de bolhas
```javascript
for (var i = 0; i < mensagens.length; i++) {
    var msg = mensagens[i];
    var posX = msg.isMe ? 800 : 350;           // direita se eu, esquerda se outro
    var cor = msg.isMe ? corAzul : corCinza;    // azul se eu, cinza se outro
    var tFimCena = 7.0;                          // quando a cena do chat acaba

    // Bolha
    var bolha = mkRect(comp, [posX, msg.y], [msg.w, 100], 50, cor, null, 0, "Bolha_" + i);
    if (bolha) {
        bolha.inPoint = msg.time;
        bolha.outPoint = tFimCena;
        springScale(bolha, msg.time, tFimCena - 0.5);
    }

    // Texto dentro da bolha
    var txt = mkText(comp, msg.t, [posX, msg.y + 10], 35, [1,1,1], "ArialMT", "c", "MsgTxt_" + i);
    if (txt) {
        txt.inPoint = msg.time + 0.1;
        txt.outPoint = tFimCena;
        fade(txt, msg.time + 0.1, tFimCena - 0.5);
    }
}
```

### 3.4 Timestamp e watermark
```javascript
// "Now 9:32" — aparece junto com a primeira msg
var timestamp = mkText(comp, "Now 9:32", [380, 400], 22, AE.hex("#888888"), "ArialMT", "c", "Timestamp");
if (timestamp) { timestamp.inPoint = 0.8; timestamp.outPoint = 7.0; fade(timestamp, 0.8, null); }

// Watermark Instagram (canto superior direito) — presente o video todo
var igHandle = mkText(comp, "@SEUARROBA", [870, 135], 28, [1,1,1], "Arial-BoldMT", "l", "IG_Handle");
// NAO definir inPoint/outPoint = fica o video todo
```

---

## 4. ANIMACAO DE UI DE APP (Uber, Rappi, iFood, etc)

### 4.1 Search bar
```javascript
var searchBox = mkRect(comp, [540, 500], [800, 120], 30, corCinzaClaro, null, 0, "SearchBox");
if (searchBox) {
    searchBox.inPoint = 7.5;
    searchBox.outPoint = 14.0;
    springScale(searchBox, 7.5, 13.8);
}
var searchTxt = mkText(comp, "Where to?", [200, 515], 40, [0,0,0], "Arial-BoldMT", "l", "SearchTxt");
if (searchTxt) {
    searchTxt.inPoint = 7.6;
    searchTxt.outPoint = 14.0;
    fade(searchTxt, 7.6, 13.8);
}
```

### 4.2 Cards de opcao (resultado de busca)
```javascript
var optionBox = mkRect(comp, [540, 700], [800, 180], 40, [1,1,1], corCinza, 4, "OptionBox");
if (optionBox) {
    optionBox.inPoint = 8.5;
    optionBox.outPoint = 14.0;
    springScale(optionBox, 8.5, 13.7);
}
var optTxt1 = mkText(comp, "Birch Coffee", [300, 680], 45, [0,0,0], "Arial-BoldMT", "l", "OptTxt1");
if (optTxt1) { optTxt1.inPoint = 8.6; optTxt1.outPoint = 14.0; fade(optTxt1, 8.6, 13.7); }

var optTxt2 = mkText(comp, "21 E 27th St, New York", [300, 730], 30, AE.hex("#888888"), "ArialMT", "l", "OptTxt2");
if (optTxt2) { optTxt2.inPoint = 8.7; optTxt2.outPoint = 14.0; fade(optTxt2, 8.7, 13.7); }
```

### 4.3 Botao CTA preto
```javascript
var btn = mkRect(comp, [540, 1600], [800, 120], 60, [0,0,0], null, 0, "CTA_Btn");
if (btn) { btn.inPoint = 10.0; btn.outPoint = 14.0; springScale(btn, 10.0, 13.6); }

var btnTxt = mkText(comp, "Choose UberX", [540, 1615], 40, [1,1,1], "Arial-BoldMT", "c", "CTA_Txt");
if (btnTxt) { btnTxt.inPoint = 10.1; btnTxt.outPoint = 14.0; fade(btnTxt, 10.1, 13.6); }
```

### 4.4 Status que muda (loading -> found -> arriving)
```javascript
// Container do status
var statusBox = mkRect(comp, [540, 1000], [700, 200], 20, corCinzaClaro, null, 0, "StatusBox");
if (statusBox) { statusBox.inPoint = 11.5; statusBox.outPoint = 14.0; springScale(statusBox, 11.5, 13.5); }

// Status 1: "Ride requested" + barra azul
var s1Txt = mkText(comp, "Ride requested\nFinding drivers nearby", [540, 970], 35, [0,0,0], "Arial-BoldMT", "c", "Status1");
if (s1Txt) { s1Txt.inPoint = 11.6; s1Txt.outPoint = 12.3; fade(s1Txt, 11.6, 12.2); }
var s1Bar = mkRect(comp, [540, 1060], [600, 10], 5, corAzul, null, 0, "Bar1");
if (s1Bar) { s1Bar.inPoint = 11.6; s1Bar.outPoint = 12.3; springScale(s1Bar, 11.6, null); }

// Status 2: "Driver Found!" + barra verde
var s2Txt = mkText(comp, "Driver Found!\nMeet at current location", [540, 970], 35, [0,0,0], "Arial-BoldMT", "c", "Status2");
if (s2Txt) { s2Txt.inPoint = 12.3; s2Txt.outPoint = 13.0; fade(s2Txt, 12.3, 12.9); }
var s2Bar = mkRect(comp, [540, 1060], [600, 10], 5, corVerde, null, 0, "Bar2");
if (s2Bar) { s2Bar.inPoint = 12.3; s2Bar.outPoint = 13.0; springScale(s2Bar, 12.3, null); }

// Status 3: "Driver is arriving now!"
var s3Txt = mkText(comp, "Driver is arriving now!", [540, 1000], 40, [0,0,0], "Arial-BoldMT", "c", "Status3");
if (s3Txt) { s3Txt.inPoint = 13.0; s3Txt.outPoint = 14.0; fade(s3Txt, 13.0, 13.8); }
```

---

## 5. ANIMACAO DE MAPA

### 5.1 Fundo verde (grama) + estrada cinza + linha amarela
```javascript
// Fundo verde
var bgMap = mkSolid(comp, AE.hex("#B2EBC8"), "BG_Map");
if (bgMap) { bgMap.inPoint = 14.0; bgMap.outPoint = 18.0; }

// Estrada (retangulo cinza vertical)
var road = mkRect(comp, [400, 960], [300, 1920], 0, AE.hex("#B3C0D1"), null, 0, "Road");
if (road) { road.inPoint = 14.0; road.outPoint = 18.0; }

// Linha central amarela
var roadLine = mkRect(comp, [400, 960], [10, 1920], 0, AE.hex("#FFD700"), null, 0, "RoadLine");
if (roadLine) { roadLine.inPoint = 14.0; roadLine.outPoint = 18.0; }
```

### 5.2 Ponto do usuario (bolinha azul com sombra)
```javascript
var userDot = mkEllipse(comp, [500, 960], 30, corAzul, "UserDot");
if (userDot) {
    userDot.inPoint = 14.2;
    userDot.outPoint = 18.0;
    springScale(userDot, 14.2, null);
    // Sombra forte (glow do ponto no mapa)
    var dotSh = AE.fx(userDot, "ADBE Drop Shadow");
    if (dotSh) {
        AE.sv(AE.gc(dotSh, ["ADBE Drop Shadow-0002"]), 100);  // opacity alta
        AE.sv(AE.gc(dotSh, ["ADBE Drop Shadow-0005"]), 15);   // distance
    }
}
```

### 5.3 Carro se movendo (posicao animada)
```javascript
var car = mkRect(comp, [400, 2100], [100, 180], 30, [1,1,1], null, 0, "Car");
if (car) {
    car.inPoint = 14.5;
    car.outPoint = 18.0;
    // Carro vem de baixo da tela e sobe ate perto do usuario
    var carPos = AE.pos(car);
    AE.sa(carPos, 14.5, [400, 2100]);   // comeca fora da tela
    AE.sa(carPos, 16.0, [400, 1050]);   // chega perto do ponto
    AE.ease(carPos, 60);
    // Sombra
    var carSh = AE.fx(car, "ADBE Drop Shadow");
    if (carSh) {
        AE.sv(AE.gc(carSh, ["ADBE Drop Shadow-0002"]), 50);
        AE.sv(AE.gc(carSh, ["ADBE Drop Shadow-0006"]), 20);
    }
}
```

### 5.4 Notificacao push (slide de cima)
```javascript
var notif = mkRect(comp, [540, -200], [900, 200], 40, [1,1,1], null, 0, "Notif");
if (notif) {
    notif.inPoint = 16.2;
    notif.outPoint = 18.0;
    // Desliza do topo
    var nPos = AE.pos(notif);
    AE.sa(nPos, 16.2, [540, -200]);    // fora da tela, acima
    AE.sa(nPos, 16.5, [540, 250]);     // posicao final
    AE.ease(nPos, 70);
    // Sombra
    var nSh = AE.fx(notif, "ADBE Drop Shadow");
    if (nSh) {
        AE.sv(AE.gc(nSh, ["ADBE Drop Shadow-0002"]), 20);
        AE.sv(AE.gc(nSh, ["ADBE Drop Shadow-0006"]), 40);
    }
}
var nTitle = mkText(comp, "Uber", [150, 210], 35, [0,0,0], "Arial-BoldMT", "l", "NotifTitle");
if (nTitle) { nTitle.inPoint = 16.3; nTitle.outPoint = 18.0; fade(nTitle, 16.3, null); }
var nMsg = mkText(comp, "Message from Driver\nI have arrived", [150, 270], 30, [0,0,0], "ArialMT", "l", "NotifMsg");
if (nMsg) { nMsg.inPoint = 16.4; nMsg.outPoint = 18.0; fade(nMsg, 16.4, null); }
```

---

## 6. OUTRO/ENCERRAMENTO

### 6.1 Texto fade in > fade out sequencial
```javascript
// Nome da marca
var brand = mkText(comp, "Uber", [540, 960], 80, [1,1,1], "Arial-BoldMT", "c", "Brand");
if (brand) { brand.inPoint = 18.5; fade(brand, 18.5, 20.5); }

// Nome do criador
var creator = mkText(comp, "Abdullah", [540, 960], 50, [1,1,1], "ArialMT", "c", "Creator");
if (creator) { creator.inPoint = 21.0; fade(creator, 21.0, 23.0); }

// Icone Instagram (quadrado arredondado + circulo + ponto)
var igBox = mkRect(comp, [540, 800], [150, 150], 40, null, [1,1,1], 10, "IG_Box");
if (igBox) { igBox.inPoint = 23.5; fade(igBox, 23.5, null); }

var igHandle = mkText(comp, "@ABDALLAHRAFATT", [540, 1000], 40, [1,1,1], "Arial-BoldMT", "c", "IG_Handle");
if (igHandle) { igHandle.inPoint = 23.5; fade(igHandle, 23.5, null); }
```

---

## 7. FUNCOES AUXILIARES OBRIGATORIAS

Estas funcoes DEVEM estar em todo script que usa este padrao.

```javascript
// springScale — pop in com bounce + saida opcional
function springScale(layer, tStart, tOut) {
    var sc = AE.scl(layer);
    if (!sc) return;
    AE.sa(sc, tStart, [0, 0]);
    AE.sa(sc, tStart + 0.1, [110, 110]);
    AE.sa(sc, tStart + 0.2, [95, 95]);
    AE.sa(sc, tStart + 0.3, [100, 100]);
    AE.ease(sc, 70);
    if (tOut) {
        AE.sa(sc, tOut, [100, 100]);
        AE.sa(sc, tOut + 0.2, [0, 0]);
        AE.ease(sc, 80);
    }
}

// fade — fade in e/ou fade out
function fade(layer, tIn, tOut, dur) {
    var op = AE.opa(layer);
    if (!op) return;
    dur = dur || 0.2;
    if (tIn !== null) {
        AE.sa(op, tIn, 0);
        AE.sa(op, tIn + dur, 100);
    }
    if (tOut !== null) {
        AE.sa(op, tOut, 100);
        AE.sa(op, tOut + dur, 0);
    }
    AE.ease(op, 60);
}
```

### Diferenca entre springScale e fade:
- **springScale** = pra elementos visuais (cards, botoes, bolhas, icones). Aparece com bounce.
- **fade** = pra textos dentro de containers. Aparece suavemente sem bounce.
- **springScale com tOut** = o elemento encolhe e some na saida. Usar quando o container inteiro some.
- **fade com tOut** = o texto some suavemente. Usar pra textos que saem antes do container.

---

## 8. TEMPLATE PARA VIDEOS COM MULTIPLAS CENAS

```javascript
(function() {
    // [BIBLIOTECA + CRIADORES + springScale + fade]

    app.beginUndoGroup("[Nome]");
    try {
        var comp = app.project.items.addComp("[Nome]", 1080, 1920, 1, [duracao], 30);
        if (!comp) { alert("Erro."); return; }

        // CRIAR NA ORDEM INVERSA:

        // ── CENA [ULTIMA]: Outro ([tempo]s - [fim]s) ──
        var bgOutro = mkSolid(comp, [0,0,0], "BG_Outro");
        if (bgOutro) { bgOutro.inPoint = [tempo]; }
        // ... elementos do outro ...

        // ── CENA [N-1]: [Nome] ([tempo]s - [tempo]s) ──
        var bgCenaN = mkSolid(comp, [cor], "BG_CenaN");
        if (bgCenaN) { bgCenaN.inPoint = [tempo]; bgCenaN.outPoint = [tempo]; }
        // ... elementos ...

        // ── CENA 2: [Nome] ([tempo]s - [tempo]s) ──
        var bgCena2 = mkSolid(comp, [cor], "BG_Cena2");
        if (bgCena2) { bgCena2.inPoint = [tempo]; bgCena2.outPoint = [tempo]; }
        // ... elementos ...

        // ── CENA 1: [Nome] (0s - [tempo]s) ──
        var bgCena1 = mkSolid(comp, [cor], "BG_Cena1");
        if (bgCena1) { bgCena1.outPoint = [tempo]; }
        // ... elementos ...

        alert("Criado!");
    } catch(e) {
        alert("Erro: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();
```

---

## 9. TIPOS DE CENA DISPONIVEIS

| Tipo | Fundo | Elementos Principais |
|------|-------|---------------------|
| Chat/iMessage | Preto | Bolhas cinza (outro) + azul (eu) + typing dots + timestamp |
| UI de App | Branco/Cinza | Search bar + cards + botao CTA + status box |
| Mapa | Verde + estrada cinza | Ponto azul + carro animado + notificacao push |
| Outro | Preto | Texto marca + texto criador + icone Instagram |
| Landing Page | Branco | Hero text + botao + features list |
| Dashboard | Cinza claro | Cards com numeros + graficos (barras) + header |
| E-commerce | Branco | Cards de produto + preco + botao comprar |

---

## 10. ERROS QUE ESTE PADRAO EVITA

1. **Layers na ordem errada** — criando de tras pra frente, a cena 1 sempre fica visivel primeiro
2. **Fundos se sobrepondo** — cada fundo tem inPoint/outPoint exatos
3. **Elementos aparecendo no tempo errado** — todo elemento tem inPoint E outPoint
4. **Textos sem container** — texto sempre acompanha o inPoint/outPoint do card pai
5. **Saida brusca** — springScale com tOut faz saida suave, fade com tOut faz fade out
6. **Typing bubble ficando visivel** — outPoint garante que some antes da msg real
