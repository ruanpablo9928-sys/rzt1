(function() {
    // ══════════════════════════════════════════════════════════════════════
    // ║  EMAIL STORY — RECRIACAO COMPLETA (1920x1080 @ 30fps — 27.5s)     ║
    // ║  14 cenas: opener > 3 bolhas > mail counter > inbox > phone >     ║
    // ║  workspace > channels > transicao > keep all > logo > outro       ║
    // ══════════════════════════════════════════════════════════════════════

    // === BIBLIOTECA ===
    var AE={};
    AE.gc=function(p,ns){var c=p;for(var i=0;i<ns.length;i++){try{c=c.property(ns[i])}catch(e){return null}if(!c)return null}return c};
    AE.pos=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Position"]):null};
    AE.scl=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Scale"]):null};
    AE.opa=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Opacity"]):null};
    AE.rot=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Rotate Z"]):null};
    AE.anc=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Anchor Point"]):null};
    AE.sv=function(p,v){if(!p)return;try{p.setValue(v)}catch(e){}};
    AE.sa=function(p,t,v){if(!p)return;try{p.setValueAtTime(t,v)}catch(e){}};
    AE.gv=function(p){if(!p)return null;try{return p.value}catch(e){return null}};
    AE.hex=function(h){h=h.replace("#","");return[parseInt(h.substr(0,2),16)/255,parseInt(h.substr(2,2),16)/255,parseInt(h.substr(4,2),16)/255]};
    AE.ease=function(p,inf){if(!p||p.numKeys===0)return;inf=inf||80;try{var d=1,v=p.propertyValueType;if(v===PropertyValueType.TwoD||v===PropertyValueType.TwoD_SPATIAL)d=2;if(v===PropertyValueType.ThreeD||v===PropertyValueType.ThreeD_SPATIAL)d=3;for(var k=1;k<=p.numKeys;k++){var ei=[],eo=[];for(var j=0;j<d;j++){ei.push(new KeyframeEase(0,inf));eo.push(new KeyframeEase(0,inf))}p.setTemporalEaseAtKey(k,ei,eo)}}catch(e){}};
    AE.fx=function(l,mn){if(!l)return null;try{return l.property("ADBE Effect Parade").addProperty(mn)}catch(e){return null}};

    // === CRIADORES ===
    function SH(comp,n){try{var s=comp.layers.addShape();if(s&&n)s.name=n;return s}catch(e){return null}}

    function EL(comp,cfg){
        cfg=cfg||{};var s=SH(comp,cfg.n||"E");if(!s)return null;
        try{var v=s.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group").property("ADBE Vectors Group");
        var el=v.addProperty("ADBE Vector Shape - Ellipse");var r=cfg.r||50;el.property("ADBE Vector Ellipse Size").setValue([r*2,r*2]);
        if(cfg.fc!==false){var f=v.addProperty("ADBE Vector Graphic - Fill");var c=cfg.fc||[1,1,1];f.property("ADBE Vector Fill Color").setValue([c[0],c[1],c[2],1])}
        if(cfg.sc){var st=v.addProperty("ADBE Vector Graphic - Stroke");st.property("ADBE Vector Stroke Color").setValue([cfg.sc[0],cfg.sc[1],cfg.sc[2],1]);st.property("ADBE Vector Stroke Width").setValue(cfg.sw||2)}
        if(cfg.p)AE.sv(AE.pos(s),cfg.p);return s}catch(e){return null}
    }

    function RC(comp,cfg){
        cfg=cfg||{};var s=SH(comp,cfg.n||"R");if(!s)return null;
        try{var v=s.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group").property("ADBE Vectors Group");
        var r=v.addProperty("ADBE Vector Shape - Rect");r.property("ADBE Vector Rect Size").setValue(cfg.sz||[200,200]);
        r.property("ADBE Vector Rect Roundness").setValue(cfg.rn||0);
        if(cfg.fc!==false){var f=v.addProperty("ADBE Vector Graphic - Fill");var c=cfg.fc||[1,1,1];f.property("ADBE Vector Fill Color").setValue([c[0],c[1],c[2],1])}
        if(cfg.sc){var st=v.addProperty("ADBE Vector Graphic - Stroke");st.property("ADBE Vector Stroke Color").setValue([cfg.sc[0],cfg.sc[1],cfg.sc[2],1]);st.property("ADBE Vector Stroke Width").setValue(cfg.sw||2)}
        if(cfg.p)AE.sv(AE.pos(s),cfg.p);return s}catch(e){return null}
    }

    function TX(comp,t,cfg){
        if(!comp)return null;try{cfg=cfg||{};var l=comp.layers.addText(t||"");if(!l)return null;
        l.name=cfg.n||"T";var tp=AE.gc(l,["ADBE Text Properties","ADBE Text Document"]);
        if(tp){var d=tp.value;d.font=cfg.f||"Arial-BoldMT";d.fontSize=cfg.s||30;d.fillColor=cfg.c||[0,0,0];
        d.tracking=cfg.tr!==undefined?cfg.tr:0;
        if(cfg.al==="c")d.justification=ParagraphJustification.CENTER_JUSTIFY;
        if(cfg.al==="l")d.justification=ParagraphJustification.LEFT_JUSTIFY;
        if(cfg.al==="r")d.justification=ParagraphJustification.RIGHT_JUSTIFY;
        tp.setValue(d)}if(cfg.p)AE.sv(AE.pos(l),cfg.p);return l}catch(e){return null}
    }

    function SLD(comp,cor,n,w,h){try{return comp.layers.addSolid(cor||[0,0,0],n||"S",w||comp.width,h||comp.height,1)}catch(e){return null}}

    // === HELPERS DE ANIMACAO ===
    function popIn(layer, tIn, over) {
        if (!layer) return;
        var s = AE.scl(layer);
        if (!s) return;
        var o = over || 112;
        AE.sa(s, tIn, [0,0]);
        AE.sa(s, tIn + 0.15, [o,o]);
        AE.sa(s, tIn + 0.25, [95,95]);
        AE.sa(s, tIn + 0.35, [100,100]);
        AE.ease(s, 75);
    }

    function fadeIn(layer, tIn, dur) {
        if (!layer) return;
        var o = AE.opa(layer);
        if (!o) return;
        dur = dur || 0.25;
        AE.sa(o, tIn, 0);
        AE.sa(o, tIn + dur, 100);
        AE.ease(o, 60);
    }

    function fadeOut(layer, tOut, dur) {
        if (!layer) return;
        var o = AE.opa(layer);
        if (!o) return;
        dur = dur || 0.25;
        AE.sa(o, tOut, 100);
        AE.sa(o, tOut + dur, 0);
        AE.ease(o, 60);
    }

    function tilt(layer, tStart, startAng, tEnd, endAng) {
        if (!layer) return;
        var r = AE.rot(layer);
        if (!r) return;
        AE.sa(r, tStart, startAng);
        AE.sa(r, tEnd, endAng);
        AE.ease(r, 65);
    }

    function addShadow(layer, opac, dist, soft) {
        if (!layer) return;
        var sh = AE.fx(layer, "ADBE Drop Shadow");
        if (sh) {
            AE.sv(AE.gc(sh, ["ADBE Drop Shadow-0002"]), opac || 18);
            AE.sv(AE.gc(sh, ["ADBE Drop Shadow-0005"]), dist || 6);
            AE.sv(AE.gc(sh, ["ADBE Drop Shadow-0006"]), soft || 25);
        }
    }

    function addGlow(layer, opac, soft) {
        if (!layer) return;
        var sh = AE.fx(layer, "ADBE Drop Shadow");
        if (sh) {
            AE.sv(AE.gc(sh, ["ADBE Drop Shadow-0001"]), [1,1,1,1]);
            AE.sv(AE.gc(sh, ["ADBE Drop Shadow-0002"]), opac || 80);
            AE.sv(AE.gc(sh, ["ADBE Drop Shadow-0005"]), 0);
            AE.sv(AE.gc(sh, ["ADBE Drop Shadow-0006"]), soft || 60);
        }
    }

    function addBlur(layer, amount) {
        if (!layer) return;
        var gb = AE.fx(layer, "ADBE Gaussian Blur 2");
        if (gb) AE.sv(AE.gc(gb, ["ADBE Gaussian Blur 2-0001"]), amount || 20);
    }

    function exitBlur(layer, tStart, tEnd) {
        if (!layer) return;
        var s = AE.scl(layer);
        if (!s) return;
        AE.sa(s, tStart, [100, 100]);
        AE.sa(s, tEnd, [140, 140]);
        AE.ease(s, 80);
        fadeOut(layer, tStart + 0.05, (tEnd - tStart) - 0.05);
    }

    // === INICIO ===
    app.beginUndoGroup("Email_Story_Recreation");
    try {
        var W = 1920, H = 1080;
        var comp = app.project.items.addComp("Email_Story_Slack_Recreation", W, H, 1, 27.5, 30);
        if (!comp) { alert("Erro ao criar comp."); return; }
        comp.motionBlur = true;
        var CX = W/2, CY = H/2;

        // === CORES ===
        var cBgLight = AE.hex("#F2F2F4");
        var cWhite = [1,1,1];
        var cBlack = [0,0,0];
        var cText = AE.hex("#111114");
        var cMuted = AE.hex("#8A8A92");
        var cGrayBub = AE.hex("#E5E5EA");
        var cGrayTxt = AE.hex("#2A2A2E");
        var cBlue = AE.hex("#1A86FF");
        var cBlueLt = AE.hex("#4A9FFF");
        var cMailTop = AE.hex("#66A8FF");
        var cMailBot = AE.hex("#0A5CE6");
        var cRed = AE.hex("#FF3B30");
        var cPink = AE.hex("#E91E63");
        var cYellowBull = AE.hex("#FFC400");
        var cTeal = AE.hex("#26C6DA");
        var cGreen = AE.hex("#22C06B");
        var cAmber = AE.hex("#F4B400");
        var cCyan = AE.hex("#1AA1FF");
        var cLogoPink = AE.hex("#E01E5A");
        var cLogoYellow = AE.hex("#ECB22E");
        var cLogoGreen = AE.hex("#2EB67D");
        var cLogoBlue = AE.hex("#36C5F0");
        var cStroke = AE.hex("#C8C8D0");

        var fBold = "Arial-BoldMT";
        var fReg = "ArialMT";

        var typeExpr = "var str=value.toString();var spd=17;var t=Math.max(0,time-inPoint);var chars=Math.floor(t*spd);str.substring(0,chars)";

        // ═══════════════════════════════════════════════════
        // FUNDO BASE (sempre atras de tudo, cria PRIMEIRO)
        // ═══════════════════════════════════════════════════
        var bgBase = SLD(comp, cBgLight, "BG_Base");

        var glow1 = EL(comp, {p:[CX-560, CY-280], r:520, fc:AE.hex("#FFFAEF"), n:"Glow_TL"});
        if (glow1) { AE.sv(AE.opa(glow1), 55); addBlur(glow1, 280); }
        var glow2 = EL(comp, {p:[CX+560, CY+280], r:560, fc:AE.hex("#EAF0FF"), n:"Glow_BR"});
        if (glow2) { AE.sv(AE.opa(glow2), 65); addBlur(glow2, 300); }

        // ═══════════════════════════════════════════════════
        // CENA 14: OUTRO "dnyxstudios" (23.0s - 27.5s)
        // ═══════════════════════════════════════════════════
        var bgOutro = SLD(comp, cBlack, "BG_Outro");
        bgOutro.inPoint = 23.0;
        bgOutro.outPoint = 27.5;
        fadeIn(bgOutro, 23.0, 0.35);

        var outroGlow = EL(comp, {p:[CX, CY], r:420, fc:cWhite, n:"Outro_Glow"});
        if (outroGlow) {
            outroGlow.inPoint = 23.2;
            outroGlow.outPoint = 27.5;
            AE.sv(AE.opa(outroGlow), 22);
            addBlur(outroGlow, 320);
            fadeIn(outroGlow, 23.2, 0.5);
            fadeOut(outroGlow, 26.4, 0.6);
        }

        var outroText = TX(comp, "dnyxstudios", {p:[CX, CY+20], s:140, c:cWhite, f:fBold, al:"c", n:"Outro_Text"});
        if (outroText) {
            outroText.inPoint = 23.35;
            outroText.outPoint = 27.5;
            popIn(outroText, 23.35, 108);
            fadeIn(outroText, 23.35, 0.45);
            fadeOut(outroText, 26.2, 0.6);
            addGlow(outroText, 90, 70);
        }

        // ═══════════════════════════════════════════════════
        // CENA 13: LOGO + "Where teams get things done" (19.5s - 23.0s)
        // ═══════════════════════════════════════════════════
        var logoNull = comp.layers.addNull();
        logoNull.name = "Logo_Controller";
        logoNull.inPoint = 19.5;
        logoNull.outPoint = 23.0;
        AE.sv(AE.pos(logoNull), [CX, CY]);
        var lPos = AE.pos(logoNull);
        AE.sa(lPos, 19.5, [CX, CY]);
        AE.sa(lPos, 20.3, [CX, CY]);
        AE.sa(lPos, 20.95, [CX-440, CY]);
        AE.ease(lPos, 85);

        var pillDefs = [
            {off:[-30, -85], sz:[110, 38], c:cLogoGreen,  n:"Pill_TL"},
            {off:[ 85, -30], sz:[38, 110], c:cLogoYellow, n:"Pill_TR"},
            {off:[ 30,  85], sz:[110, 38], c:cLogoPink,   n:"Pill_BR"},
            {off:[-85,  30], sz:[38, 110], c:cLogoBlue,   n:"Pill_BL"}
        ];
        for (var pi = 0; pi < pillDefs.length; pi++) {
            var pd = pillDefs[pi];
            var pill = RC(comp, {p:[CX + pd.off[0], CY + pd.off[1]], sz:pd.sz, rn:19, fc:pd.c, n:pd.n});
            if (pill) {
                pill.inPoint = 19.5;
                pill.outPoint = 23.0;
                pill.parent = logoNull;
                popIn(pill, 19.55 + pi*0.06, 118);
                addShadow(pill, 12, 3, 14);
                fadeOut(pill, 22.75, 0.2);
            }
        }

        var taglineTxt = TX(comp, "Where teams get things done", {p:[CX-300, CY+15], s:62, c:cText, f:fBold, al:"l", n:"Tagline_Txt"});
        if (taglineTxt) {
            taglineTxt.inPoint = 20.95;
            taglineTxt.outPoint = 23.0;
            var ttp = AE.gc(taglineTxt, ["ADBE Text Properties", "ADBE Text Document"]);
            if (ttp) ttp.expression = typeExpr;
            fadeIn(taglineTxt, 20.95, 0.15);
            fadeOut(taglineTxt, 22.75, 0.2);
        }

        // ═══════════════════════════════════════════════════
        // CENA 12: "Keep all your X in one place" (16.5s - 19.5s)
        // ═══════════════════════════════════════════════════
        var keepTxt = TX(comp, "Keep all your ", {p:[CX-150, CY+15], s:78, c:cText, f:fBold, al:"r", n:"Keep_Static"});
        if (keepTxt) {
            keepTxt.inPoint = 16.5;
            keepTxt.outPoint = 18.8;
            popIn(keepTxt, 16.5, 110);
            fadeOut(keepTxt, 18.55, 0.2);
        }

        var word1 = TX(comp, "conversations", {p:[CX-135, CY+15], s:78, c:cGreen, f:fBold, al:"l", n:"Word_Conv"});
        if (word1) {
            word1.inPoint = 16.6;
            word1.outPoint = 17.35;
            popIn(word1, 16.6, 115);
            fadeOut(word1, 17.2, 0.12);
        }

        var word2 = TX(comp, "files", {p:[CX-135, CY+15], s:78, c:cAmber, f:fBold, al:"l", n:"Word_Files"});
        if (word2) {
            word2.inPoint = 17.35;
            word2.outPoint = 18.05;
            popIn(word2, 17.35, 115);
            fadeOut(word2, 17.9, 0.12);
        }

        var word3 = TX(comp, "updates", {p:[CX-135, CY+15], s:78, c:cCyan, f:fBold, al:"l", n:"Word_Updates"});
        if (word3) {
            word3.inPoint = 18.05;
            word3.outPoint = 18.8;
            popIn(word3, 18.05, 115);
            fadeOut(word3, 18.65, 0.12);
        }

        var inOnePlace = TX(comp, "in one place", {p:[CX, CY+15], s:92, c:cText, f:fBold, al:"c", n:"InOnePlace"});
        if (inOnePlace) {
            inOnePlace.inPoint = 18.8;
            inOnePlace.outPoint = 19.5;
            popIn(inOnePlace, 18.8, 112);
            fadeOut(inOnePlace, 19.3, 0.18);
        }

        // ═══════════════════════════════════════════════════
        // CENA 11: MOTION BLUR TRANSITION (16.0s - 16.5s)
        // ═══════════════════════════════════════════════════
        for (var si = 0; si < 14; si++) {
            var sy = 120 + si * 70;
            var sw = 220 + (si % 5) * 150;
            var streak = RC(comp, {p:[-sw, sy], sz:[sw, 5], rn:2, fc:AE.hex("#A8A8B2"), n:"Streak_"+si});
            if (streak) {
                var tStart = 15.95 + si * 0.012;
                streak.inPoint = tStart;
                streak.outPoint = 16.55;
                var stP = AE.pos(streak);
                AE.sa(stP, tStart, [-sw, sy]);
                AE.sa(stP, tStart + 0.3, [W + sw, sy]);
                AE.ease(stP, 75);
                fadeIn(streak, tStart, 0.05);
                fadeOut(streak, tStart + 0.22, 0.1);
            }
        }

        // ═══════════════════════════════════════════════════
        // CENA 10: CHANNELS LIST (14.0s - 16.0s)
        // ═══════════════════════════════════════════════════
        var chHeader = TX(comp, "Channels", {p:[CX-120, CY-230], s:82, c:cText, f:fBold, al:"l", n:"CH_Header"});
        if (chHeader) {
            chHeader.inPoint = 14.0;
            chHeader.outPoint = 16.0;
            popIn(chHeader, 14.0, 110);
            fadeOut(chHeader, 15.75, 0.2);
        }
        var chArrow = TX(comp, "v", {p:[CX+160, CY-220], s:50, c:cMuted, f:fBold, al:"l", n:"CH_Arrow"});
        if (chArrow) {
            chArrow.inPoint = 14.08;
            chArrow.outPoint = 16.0;
            popIn(chArrow, 14.08, 110);
            fadeOut(chArrow, 15.75, 0.2);
        }

        var chItems = ["general", "marketing", "product", "sales", "operations"];
        for (var ci = 0; ci < chItems.length; ci++) {
            var chY = CY - 115 + ci * 75;
            var chDelay = 14.15 + ci * 0.09;

            var chHash = TX(comp, "#", {p:[CX-170, chY+12], s:58, c:cMuted, f:fReg, al:"l", n:"CH_Hash_"+ci});
            if (chHash) {
                chHash.inPoint = chDelay;
                chHash.outPoint = 16.0;
                popIn(chHash, chDelay, 112);
                fadeOut(chHash, 15.75, 0.2);
            }

            var chName = TX(comp, chItems[ci], {p:[CX-80, chY+12], s:58, c:cText, f:fBold, al:"l", n:"CH_Name_"+ci});
            if (chName) {
                chName.inPoint = chDelay + 0.03;
                chName.outPoint = 16.0;
                popIn(chName, chDelay + 0.03, 110);
                fadeOut(chName, 15.75, 0.2);
            }
        }

        var addPlus = TX(comp, "+", {p:[CX-170, CY-115+5*75+18], s:58, c:cMuted, f:fReg, al:"l", n:"CH_AddPlus"});
        if (addPlus) {
            addPlus.inPoint = 14.62;
            addPlus.outPoint = 16.0;
            popIn(addPlus, 14.62, 110);
            fadeOut(addPlus, 15.75, 0.2);
        }
        var addTxt = TX(comp, "Add channels", {p:[CX-80, CY-115+5*75+18], s:58, c:cMuted, f:fReg, al:"l", n:"CH_AddTxt"});
        if (addTxt) {
            addTxt.inPoint = 14.66;
            addTxt.outPoint = 16.0;
            popIn(addTxt, 14.66, 110);
            fadeOut(addTxt, 15.75, 0.2);
        }

        // ═══════════════════════════════════════════════════
        // CENA 9: "Your Workspace" UI (12.0s - 14.0s)
        // ═══════════════════════════════════════════════════
        var wsCard = RC(comp, {p:[CX, CY+20], sz:[1120, 820], rn:26, fc:cWhite, n:"WS_Card"});
        if (wsCard) {
            wsCard.inPoint = 12.0;
            wsCard.outPoint = 14.0;
            popIn(wsCard, 12.0, 106);
            fadeOut(wsCard, 13.75, 0.25);
            addShadow(wsCard, 22, 12, 42);
            tilt(wsCard, 12.0, -2.5, 13.8, 1.5);
        }

        var wsTitle = TX(comp, "Your Workspace", {p:[CX-200, CY-270], s:66, c:cText, f:fBold, al:"l", n:"WS_Title"});
        if (wsTitle) {
            wsTitle.inPoint = 12.12;
            wsTitle.outPoint = 14.0;
            fadeIn(wsTitle, 12.12, 0.2);
            fadeOut(wsTitle, 13.75, 0.2);
            tilt(wsTitle, 12.12, -2.5, 13.8, 1.5);
        }

        var wsHelp = EL(comp, {p:[CX+270, CY-255], r:24, fc:false, sc:cMuted, sw:3, n:"WS_HelpC"});
        if (wsHelp) { wsHelp.inPoint = 12.18; wsHelp.outPoint = 14.0; fadeIn(wsHelp, 12.18, 0.2); fadeOut(wsHelp, 13.75, 0.2); }
        var wsHelpQ = TX(comp, "?", {p:[CX+270, CY-238], s:38, c:cMuted, f:fBold, al:"c", n:"WS_HelpQ"});
        if (wsHelpQ) { wsHelpQ.inPoint = 12.18; wsHelpQ.outPoint = 14.0; fadeIn(wsHelpQ, 12.18, 0.2); fadeOut(wsHelpQ, 13.75, 0.2); }

        var wsGear = EL(comp, {p:[CX+340, CY-255], r:24, fc:false, sc:cMuted, sw:3, n:"WS_Gear"});
        if (wsGear) { wsGear.inPoint = 12.22; wsGear.outPoint = 14.0; fadeIn(wsGear, 12.22, 0.2); fadeOut(wsGear, 13.75, 0.2); }
        var wsGearDot = EL(comp, {p:[CX+340, CY-255], r:6, fc:cMuted, n:"WS_GearDot"});
        if (wsGearDot) { wsGearDot.inPoint = 12.22; wsGearDot.outPoint = 14.0; fadeIn(wsGearDot, 12.22, 0.2); fadeOut(wsGearDot, 13.75, 0.2); }

        var wsInput = RC(comp, {p:[CX, CY-150], sz:[920, 94], rn:16, fc:cWhite, sc:cStroke, sw:2, n:"WS_Input"});
        if (wsInput) {
            wsInput.inPoint = 12.2;
            wsInput.outPoint = 14.0;
            fadeIn(wsInput, 12.2, 0.2);
            fadeOut(wsInput, 13.75, 0.2);
            tilt(wsInput, 12.2, -2.5, 13.8, 1.5);
        }
        var wsInLbl = TX(comp, "Add people, groups, spaces, and more", {p:[CX-440, CY-168], s:28, c:cText, f:fReg, al:"l", n:"WS_InLbl"});
        if (wsInLbl) { wsInLbl.inPoint = 12.25; wsInLbl.outPoint = 14.0; fadeIn(wsInLbl, 12.25, 0.2); fadeOut(wsInLbl, 13.75, 0.2); }
        var wsInPH = TX(comp, "e.g. elonmusk@gmail.com", {p:[CX-440, CY-132], s:28, c:cMuted, f:fReg, al:"l", n:"WS_InPH"});
        if (wsInPH) { wsInPH.inPoint = 12.3; wsInPH.outPoint = 14.0; fadeIn(wsInPH, 12.3, 0.2); fadeOut(wsInPH, 13.75, 0.2); }

        var wsPeopleH = TX(comp, "People with access", {p:[CX-440, CY-50], s:36, c:cText, f:fBold, al:"l", n:"WS_PeopleH"});
        if (wsPeopleH) { wsPeopleH.inPoint = 12.32; wsPeopleH.outPoint = 14.0; fadeIn(wsPeopleH, 12.32, 0.2); fadeOut(wsPeopleH, 13.75, 0.2); }

        var avatars = [
            {c:AE.hex("#4FC3F7"), t:"E"},
            {c:AE.hex("#9C27B0"), t:"D"},
            {c:AE.hex("#C2185B"), t:"M"},
            {c:AE.hex("#43A047"), t:"V"}
        ];
        for (var ai = 0; ai < avatars.length; ai++) {
            var aX = CX - 395 + ai * 60;
            var av = EL(comp, {p:[aX, CY+30], r:34, fc:avatars[ai].c, n:"WS_Av_"+ai});
            if (av) {
                av.inPoint = 12.38 + ai * 0.03;
                av.outPoint = 14.0;
                popIn(av, 12.38 + ai * 0.03, 118);
                fadeOut(av, 13.75, 0.2);
            }
            var avT = TX(comp, avatars[ai].t, {p:[aX, CY+44], s:34, c:cWhite, f:fBold, al:"c", n:"WS_AvT_"+ai});
            if (avT) {
                avT.inPoint = 12.43 + ai * 0.03;
                avT.outPoint = 14.0;
                fadeIn(avT, 12.43 + ai * 0.03, 0.2);
                fadeOut(avT, 13.75, 0.2);
            }
        }

        var wsShared = TX(comp, "Shared with 4 others", {p:[CX-155, CY+18], s:34, c:cText, f:fBold, al:"l", n:"WS_Shared"});
        if (wsShared) { wsShared.inPoint = 12.52; wsShared.outPoint = 14.0; fadeIn(wsShared, 12.52, 0.2); fadeOut(wsShared, 13.75, 0.2); }
        var wsEmail = TX(comp, "markzuch@gmail.com", {p:[CX-155, CY+54], s:28, c:cMuted, f:fReg, al:"l", n:"WS_Email"});
        if (wsEmail) { wsEmail.inPoint = 12.56; wsEmail.outPoint = 14.0; fadeIn(wsEmail, 12.56, 0.2); fadeOut(wsEmail, 13.75, 0.2); }
        var wsTeam = TX(comp, "Team", {p:[CX+410, CY+38], s:32, c:cText, f:fBold, al:"l", n:"WS_Team"});
        if (wsTeam) { wsTeam.inPoint = 12.6; wsTeam.outPoint = 14.0; fadeIn(wsTeam, 12.6, 0.2); fadeOut(wsTeam, 13.75, 0.2); }

        var wsGenH = TX(comp, "General access", {p:[CX-440, CY+130], s:36, c:cText, f:fBold, al:"l", n:"WS_GenH"});
        if (wsGenH) { wsGenH.inPoint = 12.7; wsGenH.outPoint = 14.0; fadeIn(wsGenH, 12.7, 0.2); fadeOut(wsGenH, 13.75, 0.2); }

        var wsLockBody = RC(comp, {p:[CX-395, CY+205], sz:[44, 34], rn:6, fc:cText, n:"WS_LockBody"});
        if (wsLockBody) { wsLockBody.inPoint = 12.75; wsLockBody.outPoint = 14.0; fadeIn(wsLockBody, 12.75, 0.2); fadeOut(wsLockBody, 13.75, 0.2); }
        var wsLockArc = EL(comp, {p:[CX-395, CY+182], r:16, fc:false, sc:cText, sw:5, n:"WS_LockArc"});
        if (wsLockArc) { wsLockArc.inPoint = 12.75; wsLockArc.outPoint = 14.0; fadeIn(wsLockArc, 12.75, 0.2); fadeOut(wsLockArc, 13.75, 0.2); }

        var wsRestr = TX(comp, "Restricted", {p:[CX-340, CY+195], s:36, c:cText, f:fBold, al:"l", n:"WS_Restr"});
        if (wsRestr) { wsRestr.inPoint = 12.8; wsRestr.outPoint = 14.0; fadeIn(wsRestr, 12.8, 0.2); fadeOut(wsRestr, 13.75, 0.2); }
        var wsSub = TX(comp, "Only people with access can open with the link", {p:[CX-340, CY+235], s:26, c:cMuted, f:fReg, al:"l", n:"WS_Sub"});
        if (wsSub) { wsSub.inPoint = 12.85; wsSub.outPoint = 14.0; fadeIn(wsSub, 12.85, 0.2); fadeOut(wsSub, 13.75, 0.2); }

        var wsCopyBtn = RC(comp, {p:[CX-320, CY+325], sz:[210, 78], rn:39, fc:cWhite, sc:cStroke, sw:2, n:"WS_CopyBtn"});
        if (wsCopyBtn) {
            wsCopyBtn.inPoint = 12.95;
            wsCopyBtn.outPoint = 14.0;
            popIn(wsCopyBtn, 12.95, 112);
            fadeOut(wsCopyBtn, 13.75, 0.2);
            addShadow(wsCopyBtn, 10, 2, 10);
        }
        var wsCopyTxt = TX(comp, "Copy link", {p:[CX-320, CY+340], s:32, c:cText, f:fBold, al:"c", n:"WS_CopyTxt"});
        if (wsCopyTxt) {
            wsCopyTxt.inPoint = 13.0;
            wsCopyTxt.outPoint = 14.0;
            fadeIn(wsCopyTxt, 13.0, 0.15);
            fadeOut(wsCopyTxt, 13.75, 0.2);
        }

        var wsDoneBtn = RC(comp, {p:[CX+380, CY+325], sz:[190, 78], rn:39, fc:cBlue, n:"WS_DoneBtn"});
        if (wsDoneBtn) {
            wsDoneBtn.inPoint = 13.0;
            wsDoneBtn.outPoint = 14.0;
            popIn(wsDoneBtn, 13.0, 115);
            fadeOut(wsDoneBtn, 13.75, 0.2);
            addShadow(wsDoneBtn, 18, 4, 14);
        }
        var wsDoneTxt = TX(comp, "Done", {p:[CX+380, CY+340], s:32, c:cWhite, f:fBold, al:"c", n:"WS_DoneTxt"});
        if (wsDoneTxt) {
            wsDoneTxt.inPoint = 13.05;
            wsDoneTxt.outPoint = 14.0;
            fadeIn(wsDoneTxt, 13.05, 0.15);
            fadeOut(wsDoneTxt, 13.75, 0.2);
        }

        // ═══════════════════════════════════════════════════
        // CENA 8: PHONE + BULLSEYE (10.5s - 12.0s)
        // ═══════════════════════════════════════════════════
        var bullPink = EL(comp, {p:[CX, CY+30], r:400, fc:cPink, n:"Bull_Pink"});
        if (bullPink) {
            bullPink.inPoint = 10.5;
            bullPink.outPoint = 12.0;
            popIn(bullPink, 10.5, 110);
            fadeOut(bullPink, 11.8, 0.2);
            addShadow(bullPink, 30, 10, 45);
        }
        var bullYell = EL(comp, {p:[CX, CY+30], r:305, fc:cYellowBull, n:"Bull_Yellow"});
        if (bullYell) {
            bullYell.inPoint = 10.55;
            bullYell.outPoint = 12.0;
            popIn(bullYell, 10.55, 110);
            fadeOut(bullYell, 11.8, 0.2);
        }
        var bullTeal = EL(comp, {p:[CX, CY+30], r:210, fc:cTeal, n:"Bull_Teal"});
        if (bullTeal) {
            bullTeal.inPoint = 10.6;
            bullTeal.outPoint = 12.0;
            popIn(bullTeal, 10.6, 110);
            fadeOut(bullTeal, 11.8, 0.2);
        }

        var phoneFrame = RC(comp, {p:[CX, CY+30], sz:[380, 770], rn:62, fc:AE.hex("#141418"), n:"Phone_Frame"});
        if (phoneFrame) {
            phoneFrame.inPoint = 10.65;
            phoneFrame.outPoint = 12.0;
            popIn(phoneFrame, 10.65, 108);
            fadeOut(phoneFrame, 11.8, 0.2);
            addShadow(phoneFrame, 45, 18, 55);
            tilt(phoneFrame, 10.65, -7, 11.85, 3);
        }
        var phoneScreen = RC(comp, {p:[CX, CY+30], sz:[340, 720], rn:52, fc:cWhite, n:"Phone_Screen"});
        if (phoneScreen) {
            phoneScreen.inPoint = 10.7;
            phoneScreen.outPoint = 12.0;
            popIn(phoneScreen, 10.7, 105);
            fadeOut(phoneScreen, 11.8, 0.2);
            tilt(phoneScreen, 10.7, -7, 11.85, 3);
        }
        var phoneNotch = RC(comp, {p:[CX, CY-310], sz:[80, 10], rn:5, fc:AE.hex("#141418"), n:"Phone_Notch"});
        if (phoneNotch) {
            phoneNotch.inPoint = 10.75;
            phoneNotch.outPoint = 12.0;
            fadeIn(phoneNotch, 10.75, 0.2);
            fadeOut(phoneNotch, 11.8, 0.2);
            tilt(phoneNotch, 10.75, -7, 11.85, 3);
        }

        var phoneLogoPills = [
            {p:[CX - 20, CY - 52], sz:[62, 22], c:cLogoGreen,  n:"PhPill_TL"},
            {p:[CX + 52, CY - 20], sz:[22, 62], c:cLogoYellow, n:"PhPill_TR"},
            {p:[CX + 20, CY + 52], sz:[62, 22], c:cLogoPink,   n:"PhPill_BR"},
            {p:[CX - 52, CY + 20], sz:[22, 62], c:cLogoBlue,   n:"PhPill_BL"}
        ];
        for (var phi = 0; phi < phoneLogoPills.length; phi++) {
            var php = phoneLogoPills[phi];
            var phpill = RC(comp, {p:php.p, sz:php.sz, rn:11, fc:php.c, n:php.n});
            if (phpill) {
                phpill.inPoint = 10.82 + phi * 0.035;
                phpill.outPoint = 12.0;
                popIn(phpill, 10.82 + phi * 0.035, 118);
                fadeOut(phpill, 11.8, 0.2);
                tilt(phpill, 10.82 + phi * 0.035, -7, 11.85, 3);
            }
        }

        var slackLbl = TX(comp, "slack", {p:[CX, CY+130], s:66, c:cText, f:fBold, al:"c", n:"Phone_SlackLbl"});
        if (slackLbl) {
            slackLbl.inPoint = 10.95;
            slackLbl.outPoint = 12.0;
            popIn(slackLbl, 10.95, 110);
            fadeOut(slackLbl, 11.8, 0.2);
            tilt(slackLbl, 10.95, -7, 11.85, 3);
        }

        // ═══════════════════════════════════════════════════
        // CENA 7: "Your inbox is empty!" CARD (8.5s - 10.5s)
        // ═══════════════════════════════════════════════════
        var ibCard = RC(comp, {p:[CX, CY], sz:[920, 600], rn:32, fc:cWhite, n:"IB_Card"});
        if (ibCard) {
            ibCard.inPoint = 8.5;
            ibCard.outPoint = 10.5;
            popIn(ibCard, 8.5, 106);
            fadeOut(ibCard, 10.25, 0.25);
            addShadow(ibCard, 28, 14, 48);
            tilt(ibCard, 8.5, -3.5, 10.3, 2.5);
        }

        var trayBody = RC(comp, {p:[CX, CY-140], sz:[180, 130], rn:22, fc:false, sc:cBlue, sw:8, n:"IB_Tray"});
        if (trayBody) {
            trayBody.inPoint = 8.65;
            trayBody.outPoint = 10.5;
            popIn(trayBody, 8.65, 112);
            fadeOut(trayBody, 10.25, 0.2);
            tilt(trayBody, 8.65, -3.5, 10.3, 2.5);
        }
        var trayLid = RC(comp, {p:[CX, CY-175], sz:[96, 18], rn:9, fc:false, sc:cBlue, sw:8, n:"IB_TrayLid"});
        if (trayLid) {
            trayLid.inPoint = 8.7;
            trayLid.outPoint = 10.5;
            popIn(trayLid, 8.7, 112);
            fadeOut(trayLid, 10.25, 0.2);
            tilt(trayLid, 8.7, -3.5, 10.3, 2.5);
        }

        var ibBadge = EL(comp, {p:[CX+90, CY-195], r:30, fc:cBgLight, n:"IB_Badge"});
        if (ibBadge) {
            ibBadge.inPoint = 8.78;
            ibBadge.outPoint = 10.5;
            popIn(ibBadge, 8.78, 120);
            fadeOut(ibBadge, 10.25, 0.2);
            addShadow(ibBadge, 18, 3, 12);
            tilt(ibBadge, 8.78, -3.5, 10.3, 2.5);
        }
        var ibBadgeTxt = TX(comp, "!!", {p:[CX+90, CY-178], s:36, c:cBlue, f:fBold, al:"c", n:"IB_BadgeTxt"});
        if (ibBadgeTxt) {
            ibBadgeTxt.inPoint = 8.82;
            ibBadgeTxt.outPoint = 10.5;
            fadeIn(ibBadgeTxt, 8.82, 0.15);
            fadeOut(ibBadgeTxt, 10.25, 0.2);
            tilt(ibBadgeTxt, 8.82, -3.5, 10.3, 2.5);
        }

        var ibTitle = TX(comp, "Your inbox is empty!", {p:[CX, CY-40], s:52, c:cText, f:fBold, al:"c", n:"IB_Title"});
        if (ibTitle) {
            ibTitle.inPoint = 8.9;
            ibTitle.outPoint = 10.5;
            fadeIn(ibTitle, 8.9, 0.2);
            fadeOut(ibTitle, 10.25, 0.2);
            tilt(ibTitle, 8.9, -3.5, 10.3, 2.5);
        }
        var ibSub1 = TX(comp, "Your inbox has nothing you're looking for!", {p:[CX, CY+25], s:30, c:cMuted, f:fReg, al:"c", n:"IB_Sub1"});
        if (ibSub1) { ibSub1.inPoint = 8.95; ibSub1.outPoint = 10.5; fadeIn(ibSub1, 8.95, 0.2); fadeOut(ibSub1, 10.25, 0.2); tilt(ibSub1, 8.95, -3.5, 10.3, 2.5); }
        var ibSub2 = TX(comp, "Consider signing up to slack or upgrading.", {p:[CX, CY+65], s:30, c:cMuted, f:fReg, al:"c", n:"IB_Sub2"});
        if (ibSub2) { ibSub2.inPoint = 9.0; ibSub2.outPoint = 10.5; fadeIn(ibSub2, 9.0, 0.2); fadeOut(ibSub2, 10.25, 0.2); tilt(ibSub2, 9.0, -3.5, 10.3, 2.5); }

        var ibUpBtn = RC(comp, {p:[CX-160, CY+190], sz:[290, 74], rn:37, fc:cWhite, sc:cBlue, sw:3, n:"IB_UpBtn"});
        if (ibUpBtn) {
            ibUpBtn.inPoint = 9.1;
            ibUpBtn.outPoint = 10.5;
            popIn(ibUpBtn, 9.1, 112);
            fadeOut(ibUpBtn, 10.25, 0.2);
            tilt(ibUpBtn, 9.1, -3.5, 10.3, 2.5);
        }
        var ibUpTxt = TX(comp, "Upgrade Mail", {p:[CX-160, CY+205], s:32, c:cBlue, f:fBold, al:"c", n:"IB_UpTxt"});
        if (ibUpTxt) {
            ibUpTxt.inPoint = 9.15;
            ibUpTxt.outPoint = 10.5;
            fadeIn(ibUpTxt, 9.15, 0.2);
            fadeOut(ibUpTxt, 10.25, 0.2);
            tilt(ibUpTxt, 9.15, -3.5, 10.3, 2.5);
        }

        var ibClBtn = RC(comp, {p:[CX+160, CY+190], sz:[270, 74], rn:37, fc:cWhite, sc:cMuted, sw:3, n:"IB_ClBtn"});
        if (ibClBtn) {
            ibClBtn.inPoint = 9.15;
            ibClBtn.outPoint = 10.5;
            popIn(ibClBtn, 9.15, 112);
            fadeOut(ibClBtn, 10.25, 0.2);
            tilt(ibClBtn, 9.15, -3.5, 10.3, 2.5);
        }
        var ibClTxt = TX(comp, "Clear Space", {p:[CX+160, CY+205], s:32, c:cText, f:fBold, al:"c", n:"IB_ClTxt"});
        if (ibClTxt) {
            ibClTxt.inPoint = 9.2;
            ibClTxt.outPoint = 10.5;
            fadeIn(ibClTxt, 9.2, 0.2);
            fadeOut(ibClTxt, 10.25, 0.2);
            tilt(ibClTxt, 9.2, -3.5, 10.3, 2.5);
        }

        for (var sl = 0; sl < 36; sl++) {
            var slY = 60 + sl * 28;
            var sline = RC(comp, {p:[CX, slY], sz:[W, 1.5], rn:0, fc:AE.hex("#B8B8C2"), n:"IB_Scan_"+sl});
            if (sline) {
                sline.inPoint = 8.5;
                sline.outPoint = 10.5;
                AE.sv(AE.opa(sline), 10);
                fadeOut(sline, 10.25, 0.2);
            }
        }

        // ═══════════════════════════════════════════════════
        // CENA 6: MAIL ICON WITH COUNTER (7.0s - 8.5s)
        // ═══════════════════════════════════════════════════
        var mailGlow = EL(comp, {p:[CX, CY+30], r:330, fc:AE.hex("#B3D4FF"), n:"Mail_Glow"});
        if (mailGlow) {
            mailGlow.inPoint = 7.0;
            mailGlow.outPoint = 8.5;
            AE.sv(AE.opa(mailGlow), 45);
            addBlur(mailGlow, 200);
            fadeIn(mailGlow, 7.0, 0.3);
            fadeOut(mailGlow, 8.25, 0.25);
        }

        var mailIconTop = RC(comp, {p:[CX, CY], sz:[320, 320], rn:72, fc:cMailTop, n:"Mail_Icon_Top"});
        if (mailIconTop) {
            mailIconTop.inPoint = 7.0;
            mailIconTop.outPoint = 8.5;
            popIn(mailIconTop, 7.0, 114);
            fadeOut(mailIconTop, 8.25, 0.25);
            addShadow(mailIconTop, 38, 12, 38);
        }
        var mailIconBot = RC(comp, {p:[CX, CY+80], sz:[320, 160], rn:72, fc:cMailBot, n:"Mail_Icon_Bot"});
        if (mailIconBot) {
            mailIconBot.inPoint = 7.02;
            mailIconBot.outPoint = 8.5;
            AE.sv(AE.opa(mailIconBot), 55);
            popIn(mailIconBot, 7.02, 112);
            fadeOut(mailIconBot, 8.25, 0.25);
        }

        var envFlap = RC(comp, {p:[CX, CY-30], sz:[210, 60], rn:8, fc:AE.hex("#E6F0FF"), n:"Env_Flap"});
        if (envFlap) {
            envFlap.inPoint = 7.12;
            envFlap.outPoint = 8.5;
            popIn(envFlap, 7.12, 112);
            fadeOut(envFlap, 8.25, 0.25);
        }
        var envBody = RC(comp, {p:[CX, CY+15], sz:[210, 150], rn:14, fc:cWhite, n:"Env_Body"});
        if (envBody) {
            envBody.inPoint = 7.1;
            envBody.outPoint = 8.5;
            popIn(envBody, 7.1, 112);
            fadeOut(envBody, 8.25, 0.25);
            addShadow(envBody, 25, 5, 15);
        }

        var badgeBg = EL(comp, {p:[CX+130, CY-130], r:50, fc:cRed, n:"Badge_BG"});
        if (badgeBg) {
            badgeBg.inPoint = 7.3;
            badgeBg.outPoint = 8.5;
            popIn(badgeBg, 7.3, 125);
            fadeOut(badgeBg, 8.25, 0.25);
            addShadow(badgeBg, 45, 5, 14);
        }
        var badgeNum = TX(comp, "0", {p:[CX+130, CY-110], s:54, c:cWhite, f:fBold, al:"c", n:"Badge_Num"});
        if (badgeNum) {
            badgeNum.inPoint = 7.32;
            badgeNum.outPoint = 8.5;
            var bnP = AE.gc(badgeNum, ["ADBE Text Properties", "ADBE Text Document"]);
            if (bnP) {
                bnP.expression = "var i=7.32;var d=0.85;var t=(time-i)/d;t=Math.max(0,Math.min(1,t));t=1-Math.pow(1-t,3);Math.round(47*t)+''";
            }
            fadeIn(badgeNum, 7.32, 0.1);
            fadeOut(badgeNum, 8.25, 0.25);
        }

        // ═══════════════════════════════════════════════════
        // CENA 5: "And all of a sudden" (6.0s - 7.0s)
        // ═══════════════════════════════════════════════════
        var suddenTxt = TX(comp, "And all of a sudden", {p:[CX, CY+15], s:94, c:cText, f:fBold, al:"c", n:"Sudden_Txt"});
        if (suddenTxt) {
            suddenTxt.inPoint = 6.0;
            suddenTxt.outPoint = 7.0;
            popIn(suddenTxt, 6.0, 114);
            fadeOut(suddenTxt, 6.78, 0.2);
        }

        // ═══════════════════════════════════════════════════
        // CENA 4: BUBBLE 3 "When's this due?" (5.0s - 6.0s)
        // ═══════════════════════════════════════════════════
        var b3Rect = RC(comp, {p:[CX-290, CY+200], sz:[550, 135], rn:67, fc:cGrayBub, n:"B3_Rect"});
        if (b3Rect) {
            b3Rect.inPoint = 5.0;
            b3Rect.outPoint = 6.0;
            popIn(b3Rect, 5.0, 118);
            addShadow(b3Rect, 20, 6, 25);
            tilt(b3Rect, 5.0, -4, 5.8, 2);
            exitBlur(b3Rect, 5.82, 6.0);
        }
        var b3Txt = TX(comp, "When's this due?", {p:[CX-290, CY+220], s:54, c:cGrayTxt, f:fBold, al:"c", n:"B3_Txt"});
        if (b3Txt) {
            b3Txt.inPoint = 5.06;
            b3Txt.outPoint = 6.0;
            fadeIn(b3Txt, 5.06, 0.15);
            tilt(b3Txt, 5.06, -4, 5.8, 2);
            fadeOut(b3Txt, 5.82, 0.15);
        }

        // ═══════════════════════════════════════════════════
        // CENA 3: BUBBLE 2 "Check the doc" (4.0s - 6.0s)
        // ═══════════════════════════════════════════════════
        var b2Rect = RC(comp, {p:[CX+250, CY-40], sz:[480, 210], rn:42, fc:cBlue, n:"B2_Rect"});
        if (b2Rect) {
            b2Rect.inPoint = 4.0;
            b2Rect.outPoint = 6.0;
            popIn(b2Rect, 4.0, 118);
            addShadow(b2Rect, 25, 7, 28);
            tilt(b2Rect, 4.0, 5, 5.8, -3);
            exitBlur(b2Rect, 5.82, 6.0);
        }
        var b2Txt = TX(comp, "Check the doc", {p:[CX+250, CY-90], s:56, c:cWhite, f:fBold, al:"c", n:"B2_Txt"});
        if (b2Txt) {
            b2Txt.inPoint = 4.1;
            b2Txt.outPoint = 6.0;
            fadeIn(b2Txt, 4.1, 0.15);
            tilt(b2Txt, 4.1, 5, 5.8, -3);
            fadeOut(b2Txt, 5.82, 0.15);
        }
        var b2Att = RC(comp, {p:[CX+250, CY+0], sz:[340, 66], rn:14, fc:cBlueLt, n:"B2_Att"});
        if (b2Att) {
            b2Att.inPoint = 4.2;
            b2Att.outPoint = 6.0;
            popIn(b2Att, 4.2, 112);
            tilt(b2Att, 4.2, 5, 5.8, -3);
            exitBlur(b2Att, 5.82, 6.0);
        }
        var b2ClipC = EL(comp, {p:[CX+110, CY+18], r:12, fc:false, sc:cWhite, sw:4, n:"B2_ClipArc"});
        if (b2ClipC) {
            b2ClipC.inPoint = 4.25;
            b2ClipC.outPoint = 6.0;
            fadeIn(b2ClipC, 4.25, 0.15);
            tilt(b2ClipC, 4.25, 5, 5.8, -3);
            fadeOut(b2ClipC, 5.82, 0.15);
        }
        var b2ClipR = RC(comp, {p:[CX+110, CY+3], sz:[5, 22], rn:2, fc:cWhite, n:"B2_ClipBar"});
        if (b2ClipR) {
            b2ClipR.inPoint = 4.25;
            b2ClipR.outPoint = 6.0;
            fadeIn(b2ClipR, 4.25, 0.15);
            tilt(b2ClipR, 4.25, 5, 5.8, -3);
            fadeOut(b2ClipR, 5.82, 0.15);
        }
        var b2AttTxt = TX(comp, "meeting.doc", {p:[CX+270, CY+5], s:38, c:cWhite, f:fBold, al:"c", n:"B2_AttTxt"});
        if (b2AttTxt) {
            b2AttTxt.inPoint = 4.3;
            b2AttTxt.outPoint = 6.0;
            fadeIn(b2AttTxt, 4.3, 0.15);
            tilt(b2AttTxt, 4.3, 5, 5.8, -3);
            fadeOut(b2AttTxt, 5.82, 0.15);
        }

        // ═══════════════════════════════════════════════════
        // CENA 2: BUBBLE 1 "Did you see my email?" (2.5s - 6.0s)
        // ═══════════════════════════════════════════════════
        var b1Rect = RC(comp, {p:[CX-200, CY-140], sz:[620, 135], rn:67, fc:cGrayBub, n:"B1_Rect"});
        if (b1Rect) {
            b1Rect.inPoint = 2.5;
            b1Rect.outPoint = 6.0;
            popIn(b1Rect, 2.5, 118);
            addShadow(b1Rect, 20, 6, 25);
            tilt(b1Rect, 2.5, -3, 5.8, 4);
            exitBlur(b1Rect, 5.82, 6.0);
        }
        var b1Txt = TX(comp, "Did you see my email?", {p:[CX-200, CY-120], s:54, c:cGrayTxt, f:fBold, al:"c", n:"B1_Txt"});
        if (b1Txt) {
            b1Txt.inPoint = 2.6;
            b1Txt.outPoint = 6.0;
            fadeIn(b1Txt, 2.6, 0.2);
            tilt(b1Txt, 2.6, -3, 5.8, 4);
            fadeOut(b1Txt, 5.82, 0.15);
        }

        // ═══════════════════════════════════════════════════
        // CENA 1: "We've all been there..." (0.0s - 2.5s)
        // ═══════════════════════════════════════════════════
        var scene1Words = [
            {t:"We've",    off:-400, delay:0.08},
            {t:"all",      off:-160, delay:0.24},
            {t:"been",     off:40,   delay:0.40},
            {t:"there...", off:285,  delay:0.56}
        ];
        for (var w = 0; w < scene1Words.length; w++) {
            var sw1 = scene1Words[w];
            var wTxt = TX(comp, sw1.t, {p:[CX + sw1.off, CY + 15], s:105, c:cText, f:fBold, al:"c", n:"S1_Word_"+w});
            if (wTxt) {
                wTxt.inPoint = sw1.delay;
                wTxt.outPoint = 2.5;
                popIn(wTxt, sw1.delay, 120);
                fadeOut(wTxt, 2.25, 0.2);
            }
        }

        alert("Email Story Slack recriado com sucesso!\n\nResolucao: 1920x1080\nDuracao: 27.5s\nCenas: 14\n\nCopie o audio original por baixo para sincronia.");
    } catch(e) {
        alert("Erro: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();
