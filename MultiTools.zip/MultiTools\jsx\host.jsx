/**
 * MultiTools — After Effects ExtendScript Host
 *
 * One-click tool functions called via csInterface.evalScript().
 * All functions wrapped in undo groups for clean Ctrl+Z behavior.
 */

// ═══════════════════════════════════════════════════════════════════
// AGENT TOOLS — carrega tools.jsx NO ESCOPO GLOBAL
// (NAO pode estar dentro de IIFE/function — senao as funcoes MT_tool_*
// ficam em escopo local e nao sao visiveis pros evalScript() seguintes)
// ═══════════════════════════════════════════════════════════════════
$.writeln('[MT Host] host.jsx carregado, tentando carregar tools.jsx...');
try {
    // Tenta multiplos caminhos pra achar tools.jsx (CEP pode ter comportamento variado)
    var _mtPaths = [];
    try { _mtPaths.push((new File($.fileName)).path + '/tools.jsx'); } catch(e) {}
    // Caminho fixo da extensao (Windows)
    _mtPaths.push('C:/Program Files (x86)/Common Files/Adobe/CEP/extensions/MultiTools/jsx/tools.jsx');
    _mtPaths.push('/Library/Application Support/Adobe/CEP/extensions/MultiTools/jsx/tools.jsx');

    var _mtLoaded = false;
    for (var _mtI = 0; _mtI < _mtPaths.length; _mtI++) {
        try {
            var _mtF = new File(_mtPaths[_mtI]);
            if (_mtF.exists) {
                $.writeln('[MT Host] carregando tools.jsx de: ' + _mtPaths[_mtI]);
                $.evalFile(_mtF);
                _mtLoaded = true;
                break;
            }
        } catch(_mtE) { $.writeln('[MT Host] path falhou: ' + _mtPaths[_mtI] + ' -> ' + _mtE); }
    }
    if (!_mtLoaded) {
        $.writeln('[MT Host] ❌ tools.jsx NAO encontrado em nenhum path');
    } else {
        $.writeln('[MT Host] ✓ tools.jsx carregado, typeof MT_tool_dispatch = ' + (typeof MT_tool_dispatch));
    }
} catch(_mtE) {
    $.writeln('[MT Host] erro ao carregar tools.jsx: ' + _mtE);
}

// ═══════════════════════════════════════════════════════════════════
// ANCHOR POINT
// ═══════════════════════════════════════════════════════════════════

/**
 * Move o ponto de âncora da(s) camada(s) selecionada(s) para uma posição do grid 3x3.
 * Compensa a posição da camada para que ela não se mova visualmente.
 * @param {string} pos - TL, TC, TR, ML, MC, MR, BL, BC, BR
 */
function moveAnchorPoint(pos) {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";

        app.beginUndoGroup("MT: Mover Âncora → " + pos);

        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];

            // Pegar dimensões da camada (source)
            var w, h;
            if (layer.source) {
                w = layer.source.width;
                h = layer.source.height;
            } else {
                w = comp.width;
                h = comp.height;
            }

            // Calcular nova posição do anchor point
            var newAnchor = [0, 0];
            switch (pos) {
                case "TL": newAnchor = [0, 0]; break;
                case "TC": newAnchor = [w / 2, 0]; break;
                case "TR": newAnchor = [w, 0]; break;
                case "ML": newAnchor = [0, h / 2]; break;
                case "MC": newAnchor = [w / 2, h / 2]; break;
                case "MR": newAnchor = [w, h / 2]; break;
                case "BL": newAnchor = [0, h]; break;
                case "BC": newAnchor = [w / 2, h]; break;
                case "BR": newAnchor = [w, h]; break;
            }

            // Compensar posição para manter camada no lugar
            var oldAnchor = layer.anchorPoint.value;
            var diff = [newAnchor[0] - oldAnchor[0], newAnchor[1] - oldAnchor[1]];

            layer.anchorPoint.setValue(newAnchor);

            var oldPos = layer.position.value;
            if (oldPos.length === 3) {
                layer.position.setValue([oldPos[0] + diff[0], oldPos[1] + diff[1], oldPos[2]]);
            } else {
                layer.position.setValue([oldPos[0] + diff[0], oldPos[1] + diff[1]]);
            }
        }

        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

// ═══════════════════════════════════════════════════════════════════
// LAYER CREATION
// ═══════════════════════════════════════════════════════════════════

function createNullLayer() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        app.beginUndoGroup("MT: Add Null");
        comp.layers.addNull();
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function createSolidLayer() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        app.beginUndoGroup("MT: Add Solid");
        comp.layers.addSolid([0.5, 0.5, 0.5], "Solid", comp.width, comp.height, 1, comp.duration);
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function createAdjustmentLayer() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        app.beginUndoGroup("MT: Add Adjustment");
        var layer = comp.layers.addSolid([1, 1, 1], "Adjustment Layer", comp.width, comp.height, 1, comp.duration);
        layer.adjustmentLayer = true;
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function createShapeLayer() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        app.beginUndoGroup("MT: Add Shape");
        comp.layers.addShape();
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function createCameraLayer() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        app.beginUndoGroup("MT: Add Camera");
        comp.layers.addCamera("Camera", [comp.width / 2, comp.height / 2]);
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function createLightLayer() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        app.beginUndoGroup("MT: Add Light");
        comp.layers.addLight("Light", [comp.width / 2, comp.height / 2]);
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

// ═══════════════════════════════════════════════════════════════════
// TRANSFORM
// ═══════════════════════════════════════════════════════════════════

function centerSelectedLayer() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";
        app.beginUndoGroup("MT: Center Layer");
        for (var i = 0; i < layers.length; i++) {
            layers[i].property("Position").setValue([comp.width / 2, comp.height / 2]);
        }
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function fitLayerToComp() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";
        app.beginUndoGroup("MT: Fit to Comp");
        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];
            if (layer.source) {
                var sw = layer.source.width;
                var sh = layer.source.height;
                var scaleX = (comp.width / sw) * 100;
                var scaleY = (comp.height / sh) * 100;
                layer.property("Scale").setValue([scaleX, scaleY]);
                layer.property("Position").setValue([comp.width / 2, comp.height / 2]);
            }
        }
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function mirrorLayerH() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";
        app.beginUndoGroup("MT: Mirror H");
        for (var i = 0; i < layers.length; i++) {
            var s = layers[i].property("Scale").value;
            layers[i].property("Scale").setValue([s[0] * -1, s[1]]);
        }
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function mirrorLayerV() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";
        app.beginUndoGroup("MT: Mirror V");
        for (var i = 0; i < layers.length; i++) {
            var s = layers[i].property("Scale").value;
            layers[i].property("Scale").setValue([s[0], s[1] * -1]);
        }
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function selectAllLayers() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        for (var i = 1; i <= comp.numLayers; i++) {
            comp.layer(i).selected = true;
        }
        return "true";
    } catch (e) { return "false"; }
}

function deselectAllLayers() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        for (var i = 1; i <= comp.numLayers; i++) {
            comp.layer(i).selected = false;
        }
        return "true";
    } catch (e) { return "false"; }
}

// ═══════════════════════════════════════════════════════════════════
// COMPOSITION
// ═══════════════════════════════════════════════════════════════════

function duplicateActiveComp() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        app.beginUndoGroup("MT: Duplicate Comp");
        comp.duplicate();
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function preCompSelected() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";

        app.beginUndoGroup("MT: Pre-Comp");
        var indices = [];
        for (var i = 0; i < layers.length; i++) {
            indices.push(layers[i].index);
        }
        comp.layers.precompose(indices, "Pre-comp", true);
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function freezeCurrentFrame() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";

        app.beginUndoGroup("MT: Freeze Frame");
        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];
            layer.timeRemapEnabled = true;
            var tr = layer.property("Time Remap");
            // Remove the last keyframe added by AE, set constant at current time
            tr.setValueAtTime(comp.time, comp.time);
            // Remove all other keyframes
            while (tr.numKeys > 1) {
                if (tr.keyTime(tr.numKeys) !== comp.time) {
                    tr.removeKey(tr.numKeys);
                } else if (tr.numKeys > 1) {
                    tr.removeKey(1);
                } else {
                    break;
                }
            }
        }
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function saveCurrentFrame() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";

        var desktopPath = new Folder("~/Desktop").fsName;
        var fileName = comp.name.replace(/[^a-zA-Z0-9]/g, "_") + "_frame_" + Math.round(comp.time * comp.frameRate) + ".png";
        var filePath = desktopPath + "/" + fileName;

        // Add comp to render queue with PNG output
        var rqi = app.project.renderQueue.items.add(comp);
        var om = rqi.outputModule(1);

        // Set to PNG Sequence
        om.applyTemplate("_HIDDEN X-Factor 8 Premul");
        om.file = new File(filePath);

        // Set time span to current frame only
        rqi.timeSpanStart = comp.time;
        rqi.timeSpanDuration = 1 / comp.frameRate;

        app.project.renderQueue.render();
        return "true";
    } catch (e) { return "false"; }
}

// ═══════════════════════════════════════════════════════════════════
// EFFECTS
// ═══════════════════════════════════════════════════════════════════

function applyGaussianBlur() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";

        app.beginUndoGroup("MT: Gaussian Blur");
        for (var i = 0; i < layers.length; i++) {
            var fx = layers[i].property("Effects").addProperty("ADBE Gaussian Blur 2");
            fx.property("Blurriness").setValue(20);
        }
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function applyCameraLensBlur() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";

        app.beginUndoGroup("MT: Camera Lens Blur");
        for (var i = 0; i < layers.length; i++) {
            var fx = layers[i].property("Effects").addProperty("ADBE Camera Lens Blur");
            fx.property("Blur Radius").setValue(15);
        }
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function applyFill() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";

        app.beginUndoGroup("MT: Fill");
        for (var i = 0; i < layers.length; i++) {
            layers[i].property("Effects").addProperty("ADBE Fill");
        }
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function applyGlow() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";

        app.beginUndoGroup("MT: Glow");
        for (var i = 0; i < layers.length; i++) {
            layers[i].property("Effects").addProperty("ADBE Glo2");
        }
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

// ═══════════════════════════════════════════════════════════════════
// PROJECT
// ═══════════════════════════════════════════════════════════════════

function purgeAllMemory() {
    try {
        app.purge(PurgeTarget.ALL_CACHES);
        return "true";
    } catch (e) { return "false"; }
}

function saveCurrentProject() {
    try {
        var proj = app.project;
        if (!proj.file) { proj.save(); }
        else { proj.save(proj.file); }
        return "true";
    } catch (e) { return "false"; }
}

function collectProjectFiles() {
    try {
        var proj = app.project;
        if (!proj.file) return "false";
        app.beginUndoGroup("MT: Collect Files");
        proj.save(proj.file);
        proj.consolidateFootage();
        proj.removeUnusedFootage();
        app.endUndoGroup();
        return "true";
    } catch (e) { return "false"; }
}

function getProjectInfo() {
    try {
        var proj = app.project;
        var pName = proj.file ? proj.file.name.replace(/"/g, '\\"') : "(Unsaved)";
        var cName = "";
        var dur = "";
        var fps = "";
        var res = "";
        var lc = 0;
        var comp = proj.activeItem;
        if (comp && comp instanceof CompItem) {
            cName = comp.name.replace(/"/g, '\\"');
            dur = formatTime(comp.duration, comp.frameRate);
            fps = comp.frameRate.toFixed(2) + " fps";
            res = comp.width + " \u00D7 " + comp.height;
            lc = comp.numLayers;
        }
        return '{"projectName":"' + pName + '","compName":"' + cName + '","duration":"' + dur + '","fps":"' + fps + '","resolution":"' + res + '","layerCount":' + lc + '}';
    } catch (e) { return '{"error":"' + e.toString().replace(/"/g, '\\"') + '"}'; }
}

// ═══════════════════════════════════════════════════════════════════
// EXPRESSÕES
// ═══════════════════════════════════════════════════════════════════

/**
 * Aplica bounce em TODAS as propriedades com keyframes das camadas selecionadas.
 * Usa a expressão fornecida pelo usuário com amp=0.06, freq=1.8, decay=5.
 */
function applyBounceToAll() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";

        var bounceExp =
            "n = 0;\n" +
            "if (numKeys > 0) {\n" +
            "  n = nearestKey(time).index;\n" +
            "  if (key(n).time > time) { n--; }\n" +
            "}\n" +
            "t = (n == 0) ? 0 : time - key(n).time;\n" +
            "if (n > 0) {\n" +
            "  v = velocityAtTime(key(n).time - thisComp.frameDuration / 10);\n" +
            "  amp = 0.06; freq = 1.8; decay = 5;\n" +
            "  value + v * amp * Math.sin(freq * t * 2 * Math.PI) / Math.exp(decay * t);\n" +
            "} else { value; }";

        var count = 0;
        app.beginUndoGroup("MT: Bounce em Todas as Propriedades");

        for (var i = 0; i < layers.length; i++) {
            count += addBounceToProps(layers[i], bounceExp);
        }

        app.endUndoGroup();
        return count > 0 ? "true" : "false";
    } catch (e) { return "false"; }
}

/**
 * Aplica bounce com parâmetros customizados do modal de configuração.
 * @param {number} amp - Amplitude
 * @param {number} freq - Frequência
 * @param {number} decay - Decaimento
 */
function applyBounceWithParams(amp, freq, decay) {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";

        app.beginUndoGroup("MT: Elastic (amp=" + amp + " freq=" + freq + " decay=" + decay + ")");

        // Expressao 100% relativa (nearestKey/velocityAtTime): continua correta
        // mesmo se keyframes/camadas forem movidos, duplicados ou afastados.
        var bounceExp =
            "n = 0;\n" +
            "if (numKeys > 0) {\n" +
            "  n = nearestKey(time).index;\n" +
            "  if (key(n).time > time) { n--; }\n" +
            "}\n" +
            "t = (n == 0) ? 0 : time - key(n).time;\n" +
            "if (n > 0) {\n" +
            "  v = velocityAtTime(key(n).time - thisComp.frameDuration / 10);\n" +
            "  amp = " + amp + "; freq = " + freq + "; decay = " + decay + ";\n" +
            "  value + v * amp * Math.sin(freq * t * 2 * Math.PI) / Math.exp(decay * t);\n" +
            "} else { value; }";

        var count = 0;
        for (var i = 0; i < layers.length; i++) {
            count += addBounceToProps(layers[i], bounceExp);
        }

        app.endUndoGroup();
        return count > 0 ? "true" : "false";
    } catch (e) { return "false"; }
}

/**
 * Percorre recursivamente todas as propriedades de um grupo
 * e aplica a expressão bounce nas que têm keyframes.
 */
function addBounceToProps(propGroup, expr) {
    var count = 0;
    for (var i = 1; i <= propGroup.numProperties; i++) {
        var prop = propGroup.property(i);

        // Se é um grupo, recursar
        if (prop.propertyType === PropertyType.INDEXED_GROUP ||
            prop.propertyType === PropertyType.NAMED_GROUP) {
            count += addBounceToProps(prop, expr);
        }
        // Se é uma propriedade com keyframes
        else if (prop.propertyType === PropertyType.PROPERTY) {
            if (prop.numKeys > 0 && prop.canSetExpression) {
                try {
                    prop.expression = expr;
                    count++;
                } catch (e) {
                    // Algumas propriedades não suportam expressão, ignorar
                }
            }
        }
    }
    return count;
}

// ═══════════════════════════════════════════════════════════════════
// TEXT BOUNCE — Animator Scale por caractere
// ═══════════════════════════════════════════════════════════════════

/**
 * Aplica um Text Animator com expressão de bounce na propriedade Amount.
 * Configura Position e Opacity para entrada e aplica expressão baseada em palavras.
 * @param {number} delay - Frames de delay entre palavras
 * @param {number} freq  - Frequência da oscilação
 * @param {number} amp   - Amplitude do bounce
 * @param {number} decay - Taxa de decaimento
 * @param {number} speed - Multiplicador de velocidade (tempo)
 * @param {number} mode  - Modo de animação (1=Letras, 3=Palavras)
 */
function applyTextBounceWithParams(delay, freq, amp, decay, speed, mode) {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";

        var count = 0;
        var modeStr = (mode === 3) ? "Palavras" : "Letras";
        app.beginUndoGroup("MT: TextBounce (" + modeStr + ")");

        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];

            // Verificar se é camada de texto
            if (!(layer instanceof TextLayer)) continue;

            var textProp = layer.property("ADBE Text Properties");
            var animators = textProp.property("ADBE Text Animators");

            // 1. Criar novo animator
            var animator = animators.addProperty("ADBE Text Animator");
            animator.name = "MT: TextBounce";

            // 2. Adicionar Position e Opacity ao animator
            var animProps = animator.property("ADBE Text Animator Properties");
            var posProp = animProps.addProperty("ADBE Text Position 3D");
            posProp.setValue([0, -50, 0]);

            var opacProp = animProps.addProperty("ADBE Text Opacity");
            opacProp.setValue(0);

            // 3. Remover TODOS os seletores existentes para garantir limpeza
            var selectors = animator.property("ADBE Text Selectors");
            for (var k = selectors.numProperties; k >= 1; k--) {
                selectors.property(k).remove();
            }

            // 4. Adicionar Expression Selector
            var exprSelector = selectors.addProperty("ADBE Text Expressible Selector");
            exprSelector.name = "Selector Bounce";

            // 5. Definir "Based On" (1=Chars, 3=Words) usando MatchName
            var basedOnProp = exprSelector.property("ADBE Text Expressible Based On");
            if (basedOnProp) {
                basedOnProp.setValue(mode);
            } else {
                if (exprSelector.numProperties >= 1) exprSelector.property(1).setValue(mode);
            }

            // 6. Montar expressão e aplicar no Amount
            // speed multiplica o tempo: t = (...) * speed
            // textIndex é 1-based, subtrair 1 para começar do 0
            // delay vem em "frames" do slider
            var expr =
                "pDelay = " + delay + " * thisComp.frameDuration;\n" +
                "pSpeed = " + speed + ";\n" +
                "d = pDelay * (textIndex - 1);\n" +
                "t = (time - thisLayer.inPoint) * pSpeed - d;\n" +
                "if (t >= 0) {\n" +
                "  freq = " + freq + ";\n" +
                "  amplitude = " + amp + ";\n" +
                "  decay = " + decay + ";\n" +
                "  s = amplitude * Math.cos(freq * t * 2 * Math.PI) / Math.exp(decay * t);\n" +
                "  [s, s, s];\n" +
                "} else {\n" +
                "  value;\n" +
                "}";

            var amountProp = exprSelector.property("ADBE Text Expressible Amount");
            if (amountProp) {
                amountProp.expression = expr;
            }

            count++;
        }

        app.endUndoGroup();
        return count > 0 ? "true" : "false";
    } catch (e) { return "false"; }
}

// ===================================================================
// TEXT EXPLODER - aplica preset .ffx de explosao no playhead
// ===================================================================
/**
 * Aplica um preset de animacao (.ffx) de explosao de texto na(s) camada(s)
 * de texto selecionada(s), alinhando o inicio da animacao ao indicador de
 * tempo (playhead). Robusto: mede onde os keyframes do preset caem e desloca
 * pelo delta (playhead - primeiroKeyframe) -> funciona tenha o applyPreset
 * respeitado o CTI ou nao (sem risco de deslocar duas vezes).
 *
 * @param {string} presetPath caminho completo do arquivo .ffx
 * @return {string} numero de camadas afetadas ("ERR:..." em caso de erro)
 */
function applyTextExploder(presetPath) {
    try {
        var comp = getActiveComp(); if (!comp) return "ERR:Nenhuma composicao ativa";
        var sel = comp.selectedLayers;
        if (!sel || sel.length === 0) return "ERR:Nenhuma camada selecionada";

        var file = new File(presetPath);
        if (!file.exists) return "ERR:Preset nao encontrado";

        var textLayers = [];
        for (var s = 0; s < sel.length; s++) {
            if (sel[s] instanceof TextLayer) textLayers.push(sel[s]);
        }
        if (textLayers.length === 0) return "ERR:Selecione uma camada de texto";

        var t0 = comp.time;
        app.beginUndoGroup("MT: Text Exploder");

        var count = 0;
        for (var i = 0; i < textLayers.length; i++) {
            var layer = textLayers[i];

            // Isola a selecao nesta camada (applyPreset pode agir na selecao)
            _mtDeselectAll(comp);
            layer.selected = true;

            var animGroup = layer.property("ADBE Text Properties").property("ADBE Text Animators");
            var beforeCount = animGroup.numProperties;

            layer.applyPreset(file);

            var afterCount = animGroup.numProperties;

            // Coleta as propriedades com keyframes dos NOVOS animators
            var newProps = [];
            for (var a = beforeCount + 1; a <= afterCount; a++) {
                _mtCollectKeyedProps(animGroup.property(a), newProps);
            }

            // Alinha o primeiro keyframe do preset ao playhead
            if (newProps.length > 0) {
                var minT = null;
                for (var p = 0; p < newProps.length; p++) {
                    var kt = newProps[p].keyTime(1);
                    if (minT === null || kt < minT) minT = kt;
                }
                var dt = t0 - minT;
                if (Math.abs(dt) > 0.0005) {
                    for (var q = 0; q < newProps.length; q++) _mtOffsetKeys(newProps[q], dt);
                }
            }
            count++;
        }

        // Restaura a selecao original
        _mtDeselectAll(comp);
        for (var rr = 0; rr < sel.length; rr++) { try { sel[rr].selected = true; } catch (eSelR) {} }

        app.endUndoGroup();
        return "" + count;
    } catch (err) {
        try { app.endUndoGroup(); } catch (e2) {}
        return "ERR:" + err.toString();
    }
}

/** Deseleciona todas as camadas da comp. */
function _mtDeselectAll(comp) {
    for (var i = 1; i <= comp.numLayers; i++) {
        try { comp.layer(i).selected = false; } catch (e) {}
    }
}

/** Coleta recursivamente propriedades com keyframes de um grupo. */
function _mtCollectKeyedProps(group, out) {
    for (var i = 1; i <= group.numProperties; i++) {
        var pr = group.property(i);
        if (pr.propertyType === PropertyType.INDEXED_GROUP || pr.propertyType === PropertyType.NAMED_GROUP) {
            _mtCollectKeyedProps(pr, out);
        } else if (pr.propertyType === PropertyType.PROPERTY && pr.numKeys > 0) {
            out.push(pr);
        }
    }
}

/**
 * Desloca TODOS os keyframes de uma propriedade em dt segundos,
 * preservando interpolacao, ease temporal e tangentes espaciais.
 */
function _mtOffsetKeys(prop, dt) {
    var nk = prop.numKeys;
    if (nk < 1) return;
    var isSpatial = false;
    try { isSpatial = prop.isSpatial; } catch (e0) {}

    var t = [], v = [], inT = [], outT = [], inE = [], outE = [], cont = [], autoB = [], inS = [], outS = [], rove = [];
    for (var k = 1; k <= nk; k++) {
        t.push(prop.keyTime(k));
        v.push(prop.keyValue(k));
        inT.push(prop.keyInInterpolationType(k));
        outT.push(prop.keyOutInterpolationType(k));
        try { inE.push(prop.keyInTemporalEase(k)); } catch (e1) { inE.push(null); }
        try { outE.push(prop.keyOutTemporalEase(k)); } catch (e2) { outE.push(null); }
        try { cont.push(prop.keyTemporalContinuous(k)); } catch (e3) { cont.push(false); }
        try { autoB.push(prop.keyTemporalAutoBezier(k)); } catch (e4) { autoB.push(false); }
        if (isSpatial) {
            try { inS.push(prop.keyInSpatialTangent(k)); } catch (e5) { inS.push(null); }
            try { outS.push(prop.keyOutSpatialTangent(k)); } catch (e6) { outS.push(null); }
            try { rove.push(prop.keyRoving(k)); } catch (e7) { rove.push(false); }
        }
    }

    for (var r = nk; r >= 1; r--) prop.removeKey(r);

    for (var a = 0; a < t.length; a++) {
        prop.setValueAtTime(t[a] + dt, v[a]);
    }

    for (var b = 0; b < t.length; b++) {
        var idx = b + 1;
        try { prop.setInterpolationTypeAtKey(idx, inT[b], outT[b]); } catch (eA) {}
        if (isSpatial) {
            try { if (inS[b] && outS[b]) prop.setSpatialTangentsAtKey(idx, inS[b], outS[b]); } catch (eB) {}
            try { prop.setRovingAtKey(idx, rove[b]); } catch (eC) {}
        }
        try { if (inE[b] && outE[b]) prop.setTemporalEaseAtKey(idx, inE[b], outE[b]); } catch (eD) {}
        try { prop.setTemporalContinuousAtKey(idx, cont[b]); } catch (eE) {}
        try { prop.setTemporalAutoBezierAtKey(idx, autoB[b]); } catch (eF) {}
    }
}

// ===================================================================
// ICONES - cria shape layer vetorial a partir de caminhos convertidos
// ===================================================================
/**
 * Cria uma shape layer com o icone escolhido no painel. O painel converte
 * o SVG (biblioteca Feather, MIT) em caminhos bezier e envia como JSON:
 * [{ closed: bool, v: [[x,y]...], i: [[x,y]...], o: [[x,y]...] }, ...]
 * (coordenadas ja centradas na origem e escaladas pro tamanho final).
 *
 * @param {string} name     nome do icone (vira o nome da camada)
 * @param {string} jsonStr  caminhos em JSON
 * @param {number} strokeW  espessura do traco (px) — icones de traco
 * @param {number} r,g,b    cor (0-1)
 * @param {boolean} filled  true = icone preenchido (Fill em vez de Stroke)
 * @param {number} fillRule 1 = non-zero, 2 = even-odd (buracos)
 * @param {string} animType "none" | "draw" (trim paths) | "pop" (escala) | "spin" (rotacao loop)
 * @param {number} animDur  duracao da animacao em segundos
 * @return {string} "1" ou "ERR:..."
 */
function createIconFromJSON(name, jsonStr, strokeW, r, g, b, filled, fillRule, animType, animDur, split) {
    try {
        var comp = getActiveComp(); if (!comp) return "ERR:Nenhuma composicao ativa";

        var paths;
        try { paths = eval("(" + jsonStr + ")"); } catch (eP) { return "ERR:JSON invalido"; }
        if (!paths || !paths.length) return "ERR:Icone vazio";

        animType = animType || "none";
        animDur = Math.max(0.15, animDur || 0.8);
        var t0 = comp.time; // animacao comeca no playhead

        app.beginUndoGroup("MT: Icone " + name);

        // SEPARADO: uma shape layer por caminho, pivo no centro de cada parte,
        // animacao em cascata (facil de animar cada pedaco independente)
        if (split && paths.length > 1) {
            var stag = Math.min(0.07, 0.5 / paths.length);
            for (var sp2 = 0; sp2 < paths.length; sp2++) {
                var one = [paths[sp2]];
                var ctr = _mtPathsCenter(one);
                _mtShiftPaths(one, ctr[0], ctr[1]);

                var ly = comp.layers.addShape();
                ly.name = "icone " + name + " " + (sp2 + 1);
                var cont = ly.property("ADBE Root Vectors Group");
                _mtAddIconShapes(cont, one);
                if (animType === "draw") _mtIconDraw(cont, false, t0 + sp2 * stag, animDur);
                if (filled) {
                    var fl2 = cont.addProperty("ADBE Vector Graphic - Fill");
                    fl2.property("ADBE Vector Fill Color").setValue([r, g, b, 1]);
                    try { fl2.property("ADBE Vector Fill Rule").setValue(fillRule === 2 ? 2 : 1); } catch (eF2) {}
                } else {
                    var st2 = cont.addProperty("ADBE Vector Graphic - Stroke");
                    st2.property("ADBE Vector Stroke Color").setValue([r, g, b, 1]);
                    st2.property("ADBE Vector Stroke Width").setValue(strokeW);
                    try { st2.property("ADBE Vector Stroke Line Cap").setValue(2); } catch (eC2) {}
                    try { st2.property("ADBE Vector Stroke Line Join").setValue(2); } catch (eJ2) {}
                }
                ly.property("ADBE Transform Group").property("ADBE Position")
                    .setValue([comp.width / 2 + ctr[0], comp.height / 2 + ctr[1]]);
                _mtIconAnim(ly, animType, animDur, t0 + sp2 * stag);
            }
            app.endUndoGroup();
            return "1";
        }

        var layer = comp.layers.addShape();
        layer.name = "icone " + name;
        var contents = layer.property("ADBE Root Vectors Group");

        _mtAddIconShapes(contents, paths);

        // DESENHAR: Trim Paths keyframado ANTES do paint (afeta os caminhos acima)
        if (animType === "draw") _mtIconDraw(contents, paths.length > 1, t0, animDur);

        // um paint no nivel raiz pinta todos os caminhos acima dele
        if (filled) {
            var fl = contents.addProperty("ADBE Vector Graphic - Fill");
            fl.property("ADBE Vector Fill Color").setValue([r, g, b, 1]);
            try { fl.property("ADBE Vector Fill Rule").setValue(fillRule === 2 ? 2 : 1); } catch (eFR) {}
        } else {
            var st = contents.addProperty("ADBE Vector Graphic - Stroke");
            st.property("ADBE Vector Stroke Color").setValue([r, g, b, 1]);
            st.property("ADBE Vector Stroke Width").setValue(strokeW);
            try { st.property("ADBE Vector Stroke Line Cap").setValue(2); } catch (eC) {}
            try { st.property("ADBE Vector Stroke Line Join").setValue(2); } catch (eJ) {}
        }

        layer.property("ADBE Transform Group").property("ADBE Position")
            .setValue([comp.width / 2, comp.height / 2]);

        _mtIconAnim(layer, animType, animDur, t0);

        app.endUndoGroup();
        _mtIconCleanup(paths); paths = null;
        return "1";
    } catch (err) {
        try { app.endUndoGroup(); } catch (e2) {}
        return "ERR:" + err.toString();
    }
}

/**
 * Libera a memoria do motor de script depois de avaliar JSONs grandes de
 * icones (o ExtendScript quase nao coleta sozinho -> AE ia acumulando e
 * travando com o uso).
 */
function _mtIconCleanup(big) {
    try { if (big) big.length = 0; } catch (e1) {}
    try { $.gc(); } catch (e2) {}
}

/**
 * Cria uma shape layer de icone COLORIDO: cada elemento do SVG vira um
 * grupo com seus proprios Fill/Stroke (cor + opacidade originais).
 * O painel envia os elementos ja na ordem de empilhamento do AE.
 * JSON: [{ paths:[{closed,v,i,o}], fill:[r,g,b]|null, fillOp, stroke, strokeOp, sw, rule }]
 */
function createColorIconFromJSON(name, jsonStr, animType, animDur, split) {
    try {
        var comp = getActiveComp(); if (!comp) return "ERR:Nenhuma composicao ativa";

        var els;
        try { els = eval("(" + jsonStr + ")"); } catch (eP) { return "ERR:JSON invalido"; }
        if (!els || !els.length) return "ERR:Icone vazio";

        animType = animType || "none";
        animDur = Math.max(0.15, animDur || 0.8);
        var t0 = comp.time;

        app.beginUndoGroup("MT: Icone " + name);

        // SEPARADO: uma shape layer por parte, pivo proprio, cascata.
        // Cria do fundo pra frente: a ultima criada fica no topo da timeline.
        if (split && els.length > 1) {
            var stagC = Math.min(0.07, 0.5 / els.length);
            var made = 0;
            for (var ee = els.length - 1; ee >= 0; ee--) {
                var elS = els[ee];
                var ctrC = _mtPathsCenter(elS.paths);
                _mtShiftPaths(elS.paths, ctrC[0], ctrC[1]);

                var lyC = comp.layers.addShape();
                lyC.name = "icone " + name + " " + (ee + 1);
                _mtAddColorElement(lyC.property("ADBE Root Vectors Group"), elS);
                lyC.property("ADBE Transform Group").property("ADBE Position")
                    .setValue([comp.width / 2 + ctrC[0], comp.height / 2 + ctrC[1]]);
                _mtIconAnim(lyC, animType, animDur, t0 + made * stagC);
                made++;
            }
            app.endUndoGroup();
            _mtIconCleanup(els); els = null;
            return "1";
        }

        var layer = comp.layers.addShape();
        layer.name = "icone " + name;
        var contents = layer.property("ADBE Root Vectors Group");

        for (var e = 0; e < els.length; e++) {
            var grp = contents.addProperty("ADBE Vector Group");
            try { grp.name = "parte " + (e + 1); } catch (eN) {}
            _mtAddColorElement(grp.property("ADBE Vectors Group"), els[e]);
        }

        layer.property("ADBE Transform Group").property("ADBE Position")
            .setValue([comp.width / 2, comp.height / 2]);

        _mtIconAnim(layer, animType, animDur, t0);

        app.endUndoGroup();
        _mtIconCleanup(els); els = null;
        return "1";
    } catch (err) {
        try { app.endUndoGroup(); } catch (e2) {}
        return "ERR:" + err.toString();
    }
}

/** Animacoes pop/spin dos icones (compartilhada mono/colorido). */
function _mtIconAnim(layer, animType, animDur, t0) {
    var tg = layer.property("ADBE Transform Group");
    // POP: escala com overshoot + fade rapido, no playhead
    if (animType === "pop") {
        var sc = tg.property("ADBE Scale");
        sc.setValueAtTime(t0, [0, 0]);
        sc.setValueAtTime(t0 + animDur * 0.7, [108, 108]);
        sc.setValueAtTime(t0 + animDur, [100, 100]);
        try {
            var pKE = new KeyframeEase(0, 66);
            for (var kk = 1; kk <= 3; kk++) sc.setTemporalEaseAtKey(kk, [pKE], [pKE]);
        } catch (ePE) {}
        var op = tg.property("ADBE Opacity");
        op.setValueAtTime(t0, 0);
        op.setValueAtTime(t0 + Math.min(animDur * 0.35, 0.25), 100);
    }
    // GIRAR: rotacao continua em loop (expressao editavel/removivel)
    else if (animType === "spin") {
        var rotSpeed = 360 / Math.max(0.1, animDur);
        tg.property("ADBE Rotate Z").expression =
            "(time - inPoint) * " + rotSpeed.toFixed(2) + ";";
    }
}

/** Adiciona os caminhos como Shape Groups num container. */
function _mtAddIconShapes(container, paths) {
    for (var p = 0; p < paths.length; p++) {
        var pd = paths[p];
        var sg = container.addProperty("ADBE Vector Shape - Group");
        var shp = new Shape();
        shp.vertices = pd.v;
        shp.inTangents = pd.i;
        shp.outTangents = pd.o;
        shp.closed = !!pd.closed;
        sg.property("ADBE Vector Shape").setValue(shp);
    }
}

/** Shapes + Fill/Stroke de UM elemento colorido num container. */
function _mtAddColorElement(container, el) {
    _mtAddIconShapes(container, el.paths);
    if (el.fill) {
        var fl = container.addProperty("ADBE Vector Graphic - Fill");
        fl.property("ADBE Vector Fill Color").setValue([el.fill[0], el.fill[1], el.fill[2], 1]);
        try { fl.property("ADBE Vector Fill Rule").setValue(el.rule === 2 ? 2 : 1); } catch (eR) {}
        try { if (el.fillOp < 1) fl.property("ADBE Vector Fill Opacity").setValue(Math.round(el.fillOp * 100)); } catch (eO) {}
    }
    if (el.stroke) {
        var st = container.addProperty("ADBE Vector Graphic - Stroke");
        st.property("ADBE Vector Stroke Color").setValue([el.stroke[0], el.stroke[1], el.stroke[2], 1]);
        st.property("ADBE Vector Stroke Width").setValue(Math.max(0.1, el.sw || 1));
        try { st.property("ADBE Vector Stroke Line Cap").setValue(2); } catch (eC) {}
        try { st.property("ADBE Vector Stroke Line Join").setValue(2); } catch (eJ) {}
        try { if (el.strokeOp < 1) st.property("ADBE Vector Stroke Opacity").setValue(Math.round(el.strokeOp * 100)); } catch (eO2) {}
    }
}

/** Trim Paths de "desenhar" (0 -> 100) num container, a partir de t0. */
function _mtIconDraw(container, multiPath, t0, dur) {
    var trim = container.addProperty("ADBE Vector Filter - Trim");
    // varios caminhos -> desenha um depois do outro (estilo line-md)
    try { if (multiPath) trim.property("ADBE Vector Trim Type").setValue(2); } catch (eTT) {}
    var te = trim.property("ADBE Vector Trim End");
    te.setValueAtTime(t0, 0);
    te.setValueAtTime(t0 + dur, 100);
    try {
        var eKE = new KeyframeEase(0, 66);
        te.setTemporalEaseAtKey(1, [eKE], [eKE]);
        te.setTemporalEaseAtKey(2, [eKE], [eKE]);
    } catch (eTE) {}
}

// ===================================================================
// ELEMENTOS - UIs prontas construidas como shape layers nativas
// ===================================================================
/**
 * Constroi um template de UI (chat, celular, navegador...) como um
 * conjunto de shape layers parentadas a um NULL de controle, no centro
 * da comp. Tudo vetorial, por partes, 100% editavel.
 *
 * @param {string}  kind    chat | aichat | phone | browser | card | player | terminal
 * @param {boolean} animate entrada em cascata (pop) a partir do playhead
 * @return {string} numero de camadas criadas ("ERR:...")
 */
function createUITemplate(kind, animate) {
    try {
        var comp = getActiveComp(); if (!comp) return "ERR:Nenhuma composicao ativa";
        var u = comp.height / 1080; // escala relativa a comp
        var t0 = comp.time;

        // paleta
        var BG1 = [0.086, 0.086, 0.125];  // painel escuro
        var BG2 = [0.125, 0.125, 0.180];  // barra/painel 2
        var BG3 = [0.165, 0.165, 0.235];  // bolha neutra
        var ACC = [0.306, 0.549, 1.0];    // azul
        var GRN = [0.180, 0.490, 0.310];  // verde (bolha user)
        var W60 = [0.85, 0.85, 0.88];
        var W25 = [0.42, 0.42, 0.48];
        var MAG = [0.78, 0.22, 0.93];     // magenta/roxo
        var RED = [1.0, 0.30, 0.20];      // glow vermelho
        var BLU = [0.22, 0.42, 1.0];      // glow azul
        var GRN2 = [0.25, 0.90, 0.50];    // verde vivo
        var LGT = [0.86, 0.86, 0.90];     // cinza claro
        var DRK = [0.05, 0.05, 0.08];     // quase preto

        app.beginUndoGroup("MT: UI " + kind);

        var ctrl = comp.layers.addNull(comp.duration);
        ctrl.name = "UI " + kind;
        try { ctrl.label = 14; } catch (eL) {}
        ctrl.property("ADBE Transform Group").property("ADBE Position")
            .setValue([comp.width / 2, comp.height / 2]);

        // cada item: [tipoShape, params..., fill, x, y] via closures utilitarias
        var made = [];
        function rect(name, w, h, r, fill, x, y, rot) {
            made.push(_mtUIShape(comp, name, _mtUIRoundRect(w * u, h * u, r * u), fill, x * u, y * u, ctrl, rot));
        }
        function circ(name, rr, fill, x, y) {
            made.push(_mtUIShape(comp, name, _mtUICircle(rr * u), fill, x * u, y * u, ctrl));
        }
        function tri(name, s, fill, x, y) {
            made.push(_mtUIShape(comp, name, _mtUITriangle(s * u), fill, x * u, y * u, ctrl));
        }
        function ring(name, r, sw, color, pct, x, y) {
            made.push(_mtUIRing(comp, name, r * u, sw * u, color, pct, x * u, y * u, ctrl));
        }
        function txt(name, str, size, color, x, y) {
            made.push(_mtUIText(comp, name, str, size * u, color, x * u, y * u, ctrl));
        }
        function blurLast(amount) { _mtUIBlur(made[made.length - 1], amount * u); }

        if (kind === "chat") {
            rect("painel", 620, 900, 36, BG1, 0, 0);
            rect("header", 620, 90, 24, BG2, 0, -405);
            circ("avatar", 26, ACC, -250, -405);
            rect("nome", 160, 16, 8, W60, -130, -412);
            rect("status", 100, 10, 5, W25, -160, -388);
            rect("bolha 1", 320, 90, 24, BG3, -120, -270);
            rect("linha 1", 240, 12, 6, W25, -120, -270);
            rect("bolha 2", 320, 90, 24, GRN, 120, -150);
            rect("linha 2", 240, 12, 6, W60, 120, -150);
            rect("bolha 3", 360, 120, 24, BG3, -100, -5);
            rect("linha 3a", 280, 12, 6, W25, -100, -25);
            rect("linha 3b", 200, 12, 6, W25, -140, 15);
            rect("bolha 4", 300, 90, 24, GRN, 130, 130);
            rect("linha 4", 220, 12, 6, W60, 130, 130);
            rect("input", 480, 70, 35, BG2, -40, 395);
            circ("enviar", 32, ACC, 260, 395);
        } else if (kind === "aichat") {
            rect("janela", 940, 660, 24, BG1, 0, 0);
            rect("header", 940, 64, 16, BG2, 0, -298);
            circ("logo", 14, ACC, -430, -298);
            rect("titulo", 180, 14, 7, W60, -310, -298);
            rect("msg user", 480, 70, 22, BG3, 190, -190);
            rect("linha u", 400, 12, 6, W60, 190, -190);
            circ("avatar ia", 22, ACC, -420, -80);
            rect("resp 1", 700, 14, 7, W60, -30, -100);
            rect("resp 2", 760, 14, 7, W25, 0, -60);
            rect("resp 3", 640, 14, 7, W25, -60, -20);
            rect("resp 4", 500, 14, 7, W25, -130, 20);
            rect("input", 800, 76, 38, BG2, -30, 250);
            circ("enviar", 30, ACC, 400, 250);
        } else if (kind === "phone") {
            rect("aro", 440, 920, 64, BG2, 0, 0);
            rect("tela", 400, 860, 48, BG1, 0, 0);
            rect("notch", 140, 30, 15, BG2, 0, -400);
            rect("home", 130, 10, 5, W25, 0, 405);
        } else if (kind === "browser") {
            rect("janela", 1000, 660, 20, BG1, 0, 0);
            rect("topo", 1000, 70, 16, BG2, 0, -295);
            circ("btn 1", 8, [1.0, 0.373, 0.341], -460, -295);
            circ("btn 2", 8, [0.996, 0.737, 0.180], -430, -295);
            circ("btn 3", 8, [0.157, 0.784, 0.251], -400, -295);
            rect("url", 640, 40, 20, BG1, 40, -295);
            rect("midia", 620, 300, 12, BG3, 0, -80);
            rect("texto 1", 800, 14, 7, W25, 0, 120);
            rect("texto 2", 720, 14, 7, W25, -40, 160);
            rect("texto 3", 560, 14, 7, W25, -120, 200);
        } else if (kind === "card") {
            rect("card", 560, 150, 28, BG2, 0, 0);
            rect("icone app", 90, 90, 22, ACC, -205, 0);
            rect("titulo", 240, 20, 10, W60, -20, -25);
            rect("texto", 320, 14, 7, W25, 20, 10);
            rect("hora", 50, 12, 6, W25, 230, -40);
        } else if (kind === "player") {
            rect("video", 800, 450, 20, BG1, 0, 0);
            circ("play fundo", 55, ACC, 0, -20);
            tri("play", 40, [1, 1, 1], 6, -20);
            rect("trilha", 700, 10, 5, BG3, 0, 175);
            rect("progresso", 260, 10, 5, ACC, -220, 175);
            circ("cursor", 11, [1, 1, 1], -90, 175);
        } else if (kind === "terminal") {
            rect("janela", 760, 480, 16, BG1, 0, 0);
            rect("topo", 760, 54, 12, BG2, 0, -213);
            circ("btn 1", 7, [1.0, 0.373, 0.341], -345, -213);
            circ("btn 2", 7, [0.996, 0.737, 0.180], -320, -213);
            circ("btn 3", 7, [0.157, 0.784, 0.251], -295, -213);
            rect("linha 1", 300, 12, 6, ACC, -190, -140);
            rect("linha 2", 460, 12, 6, W25, -110, -100);
            rect("linha 3", 380, 12, 6, GRN, -130, -60);
            rect("linha 4", 520, 12, 6, W25, -80, -20);
            rect("linha 5", 260, 12, 6, W25, -210, 20);
            rect("cursor", 16, 22, 2, W60, -60, 60);
        } else if (kind === "prompt") {
            // barra de prompt IA com glow colorido (blur) atras
            rect("brilho vermelho", 520, 240, 120, RED, -330, 20); blurLast(130);
            rect("brilho azul", 520, 240, 120, BLU, 330, 20); blurLast(130);
            rect("barra", 1100, 300, 60, DRK, 0, 0);
            rect("cursor", 5, 44, 2, W60, -470, -60);
            rect("texto", 380, 16, 8, W25, -265, -60);
            circ("mais", 26, BG3, -465, 65);
            rect("chip 1", 150, 52, 26, BG3, -345, 65);
            rect("chip 2", 130, 52, 26, BG3, -190, 65);
            rect("chip voz", 130, 52, 26, BG3, 330, 65);
            circ("enviar", 34, MAG, 465, 65);
            tri("seta", 26, [1, 1, 1], 464, 65);
        } else if (kind === "gauge") {
            // medidor circular com boneco e numero editavel
            ring("anel fundo", 170, 30, LGT, 100, 0, -40);
            ring("anel progresso", 170, 30, MAG, 60, 0, -40);
            txt("numero", "60", 130, MAG, 0, -75);
            circ("cabeca", 16, W60, 0, 30);
            rect("corpo", 14, 52, 7, W60, 0, 70, 0);
            rect("perna 1", 12, 46, 6, W60, -14, 110, 25);
            rect("perna 2", 12, 46, 6, W60, 14, 110, -25);
            txt("rotulo", "walking", 36, [0.72, 0.72, 0.78], 0, 155);
        } else if (kind === "stats") {
            // pills de estatistica com anel de progresso e valor editavel
            rect("pill 1", 620, 190, 95, [0.13, 0.13, 0.17], 0, -115);
            ring("anel 1", 52, 16, GRN2, 67, -200, -115);
            txt("valor 1", "67%", 60, [1, 1, 1], 30, -150);
            rect("rotulo 1", 170, 14, 7, W25, 25, -75);
            rect("pill 2", 620, 190, 95, [0.13, 0.13, 0.17], 0, 115);
            ring("anel 2", 52, 16, MAG, 45, -200, 115);
            txt("valor 2", "$ 234", 60, [1, 1, 1], 40, 80);
            rect("rotulo 2", 170, 14, 7, W25, 25, 155);
        } else {
            app.endUndoGroup();
            return "ERR:Template desconhecido";
        }

        // entrada em cascata (pop) a partir do playhead
        if (animate) {
            for (var a = 0; a < made.length; a++) {
                _mtIconAnim(made[a], "pop", 0.5, t0 + a * 0.05);
            }
        }

        app.endUndoGroup();
        return "" + (made.length + 1);
    } catch (err) {
        try { app.endUndoGroup(); } catch (e2) {}
        return "ERR:" + err.toString();
    }
}

/** Cria uma shape layer com um Shape pronto, fill, posicao e rotacao opcional. */
function _mtUIShape(comp, name, shape, fill, x, y, parent, rot) {
    var ly = comp.layers.addShape();
    ly.name = name;
    var cont = ly.property("ADBE Root Vectors Group");
    var sg = cont.addProperty("ADBE Vector Shape - Group");
    sg.property("ADBE Vector Shape").setValue(shape);
    var fl = cont.addProperty("ADBE Vector Graphic - Fill");
    fl.property("ADBE Vector Fill Color").setValue([fill[0], fill[1], fill[2], 1]);
    var tg = ly.property("ADBE Transform Group");
    tg.property("ADBE Position").setValue([comp.width / 2 + x, comp.height / 2 + y]);
    if (rot) { try { tg.property("ADBE Rotate Z").setValue(rot); } catch (eR) {} }
    ly.parent = parent;
    return ly;
}

/** Shape layer de anel/arco de progresso: circulo + Trim + Stroke (comeca no topo). */
function _mtUIRing(comp, name, r, sw, color, pct, x, y, parent) {
    var ly = comp.layers.addShape();
    ly.name = name;
    var cont = ly.property("ADBE Root Vectors Group");
    var sg = cont.addProperty("ADBE Vector Shape - Group");
    sg.property("ADBE Vector Shape").setValue(_mtUICircle(r));
    var trim = cont.addProperty("ADBE Vector Filter - Trim");
    trim.property("ADBE Vector Trim End").setValue(Math.max(0, Math.min(100, pct)));
    try { trim.property("ADBE Vector Trim Offset").setValue(-90); } catch (eO) {}
    var st = cont.addProperty("ADBE Vector Graphic - Stroke");
    st.property("ADBE Vector Stroke Color").setValue([color[0], color[1], color[2], 1]);
    st.property("ADBE Vector Stroke Width").setValue(sw);
    try { st.property("ADBE Vector Stroke Line Cap").setValue(2); } catch (eC) {}
    ly.property("ADBE Transform Group").property("ADBE Position")
        .setValue([comp.width / 2 + x, comp.height / 2 + y]);
    ly.parent = parent;
    return ly;
}

/** Camada de TEXTO editavel, centralizada GEOMETRICAMENTE na posicao. */
function _mtUIText(comp, name, str, size, color, x, y, parent) {
    var ly = comp.layers.addText(str);
    ly.name = name;
    try {
        var tp = ly.property("ADBE Text Properties").property("ADBE Text Document");
        var doc = tp.value;
        doc.fontSize = size;
        doc.fillColor = [color[0], color[1], color[2]];
        try { doc.applyStroke = false; } catch (eS) {}
        tp.setValue(doc);
    } catch (eD) {}
    // centraliza pela medida REAL do texto (independe de justificacao/baseline)
    try {
        var r2 = ly.sourceRectAtTime(comp.time, false);
        ly.property("ADBE Transform Group").property("ADBE Anchor Point")
            .setValue([r2.left + r2.width / 2, r2.top + r2.height / 2]);
    } catch (eR) {}
    ly.property("ADBE Transform Group").property("ADBE Position")
        .setValue([comp.width / 2 + x, comp.height / 2 + y]);
    ly.parent = parent;
    return ly;
}

/** Gaussian Blur numa camada (usado pra glow suave atras de paineis). */
function _mtUIBlur(layer, amount) {
    try {
        var fx = layer.property("ADBE Effect Parade").addProperty("ADBE Gaussian Blur 2");
        fx.property(1).setValue(amount);
    } catch (e) {}
}

/** Shape de retangulo arredondado centrado na origem. */
function _mtUIRoundRect(w, h, r) {
    var hw = w / 2, hh = h / 2;
    r = Math.min(r, hw, hh);
    var K = 0.5522847498, kr = r * K;
    var s = new Shape();
    if (r <= 0) {
        s.vertices = [[-hw, -hh], [hw, -hh], [hw, hh], [-hw, hh]];
        s.inTangents = [[0, 0], [0, 0], [0, 0], [0, 0]];
        s.outTangents = [[0, 0], [0, 0], [0, 0], [0, 0]];
    } else {
        s.vertices = [
            [-hw + r, -hh], [hw - r, -hh],
            [hw, -hh + r], [hw, hh - r],
            [hw - r, hh], [-hw + r, hh],
            [-hw, hh - r], [-hw, -hh + r]
        ];
        s.inTangents = [[-kr, 0], [0, 0], [0, -kr], [0, 0], [kr, 0], [0, 0], [0, kr], [0, 0]];
        s.outTangents = [[0, 0], [kr, 0], [0, 0], [0, kr], [0, 0], [-kr, 0], [0, 0], [0, -kr]];
    }
    s.closed = true;
    return s;
}

/** Shape de circulo centrado na origem. */
function _mtUICircle(r) {
    var K = 0.5522847498, kr = r * K;
    var s = new Shape();
    s.vertices = [[r, 0], [0, r], [-r, 0], [0, -r]];
    s.inTangents = [[0, -kr], [kr, 0], [0, kr], [-kr, 0]];
    s.outTangents = [[0, kr], [-kr, 0], [0, -kr], [kr, 0]];
    s.closed = true;
    return s;
}

/** Shape de triangulo "play" centrado na origem. */
function _mtUITriangle(sz) {
    var s = new Shape();
    s.vertices = [[-sz * 0.4, -sz * 0.5], [sz * 0.6, 0], [-sz * 0.4, sz * 0.5]];
    s.inTangents = [[0, 0], [0, 0], [0, 0]];
    s.outTangents = [[0, 0], [0, 0], [0, 0]];
    s.closed = true;
    return s;
}

/** Centro do bounding box dos vertices dos caminhos. */
function _mtPathsCenter(paths) {
    var minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
    for (var p = 0; p < paths.length; p++) {
        for (var j = 0; j < paths[p].v.length; j++) {
            var x = paths[p].v[j][0], y = paths[p].v[j][1];
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        }
    }
    if (minX > maxX) return [0, 0];
    return [(minX + maxX) / 2, (minY + maxY) / 2];
}

/** Desloca os vertices dos caminhos (tangentes sao relativas, nao mudam). */
function _mtShiftPaths(paths, cx, cy) {
    for (var p = 0; p < paths.length; p++) {
        for (var j = 0; j < paths[p].v.length; j++) {
            paths[p].v[j][0] -= cx;
            paths[p].v[j][1] -= cy;
        }
    }
}

// ===================================================================
// QUEBRAR PALAVRAS - divide um texto em varias camadas editaveis
// ===================================================================
/**
 * Quebra a(s) camada(s) de texto selecionada(s) em varias camadas,
 * uma por palavra / letra / linha, mantendo posicao, estilo e (via
 * duplicacao) a animacao de cada trecho. Cada camada resultante e
 * 100% editavel individualmente na timeline.
 *
 * @param {string}  mode         "words" | "chars" | "lines"
 * @param {boolean} keepOriginal manter a camada original (senao, remove)
 * @return {string} numero de camadas criadas ("false" em caso de erro)
 */
var _MT_probeTick = 0;

function breakTextIntoWords(mode, keepOriginal, addControls) {
    try {
        var comp = getActiveComp(); if (!comp) return "ERR:Nenhuma composicao ativa";
        var sel = comp.selectedLayers;
        if (!sel || sel.length === 0) return "ERR:Nenhuma camada selecionada";

        // Filtra apenas camadas de texto
        var textLayers = [];
        for (var s = 0; s < sel.length; s++) {
            if (sel[s] instanceof TextLayer) textLayers.push(sel[s]);
        }
        if (textLayers.length === 0) return "ERR:A camada selecionada nao e de texto";

        mode = mode || "words";
        var mt = comp.time; // tempo base de medicao

        app.beginUndoGroup("MT: Quebrar Palavras");

        var totalCreated = 0;
        for (var li = 0; li < textLayers.length; li++) {
            var made = splitOneTextLayer(comp, textLayers[li], mode, mt, addControls);
            totalCreated += made;
            // Remove o original apenas se gerou trechos e o usuario nao pediu para manter
            if (made > 0 && !keepOriginal) {
                try { textLayers[li].remove(); } catch (eRm) {}
            }
        }

        app.endUndoGroup();
        return "" + totalCreated;
    } catch (err) {
        try { app.endUndoGroup(); } catch (e2) {}
        return "ERR:" + err.toString();
    }
}

/**
 * Retorna a propriedade Source Text de uma camada de forma robusta
 * (matchName completo, independente de idioma do AE).
 */
function _mtSourceText(layer) {
    var tp = null;
    try { tp = layer.property("ADBE Text Properties").property("ADBE Text Document"); } catch (e1) {}
    if (!tp) { try { tp = layer.property("Source Text"); } catch (e2) {} }
    if (!tp) { try { tp = layer.property("ADBE Text Document"); } catch (e3) {} }
    return tp;
}

/**
 * Quebra UMA camada de texto. Retorna o numero de camadas criadas.
 */
function splitOneTextLayer(comp, layer, mode, baseT, addControls) {
    var srcTextProp = _mtSourceText(layer);
    if (!srcTextProp) return 0;
    var srcDoc = srcTextProp.value;
    var fullText = srcDoc.text;
    if (fullText === null || fullText === undefined || fullText === "") return 0;

    var just = srcDoc.justification;

    // Leading (altura de linha) para textos multi-linha
    var fontSize = srcDoc.fontSize || 50;
    var leading;
    try { leading = (srcDoc.autoLeading ? fontSize * 1.2 : srcDoc.leading); }
    catch (eLead) { leading = fontSize * 1.2; }
    if (!leading || leading <= 0) leading = fontSize * 1.2;

    // Camada-sonda para medir larguras (duplicata, sem animadores, texto estatico).
    // Removida antes do fim do undo group -> nao aparece na comp.
    var probe = layer.duplicate();
    probe.name = "__MT_probe__";
    _mtStripAnimators(probe);
    var probeTextProp = _mtSourceText(probe);
    while (probeTextProp.numKeys > 0) { probeTextProp.removeKey(1); }

    var lines = fullText.split(/\r\n|\r|\n/);
    var created = 0;

    for (var lineIdx = 0; lineIdx < lines.length; lineIdx++) {
        var lineText = lines[lineIdx];
        var tokens = _mtTokenize(lineText, mode);
        if (tokens.length === 0) continue;

        var FW = _mtMeasureWidth(probeTextProp, probe, lineText, baseT);

        for (var ti = 0; ti < tokens.length; ti++) {
            var tok = tokens[ti];
            var endStr = lineText.substring(0, tok.start + tok.len);
            var prefixEndW = _mtMeasureWidth(probeTextProp, probe, endStr, baseT);
            var wordW = _mtMeasureWidth(probeTextProp, probe, tok.str, baseT);
            var leftEdge = prefixEndW - wordW;

            var shiftX;
            if (just === ParagraphJustification.CENTER_JUSTIFY) {
                shiftX = leftEdge + wordW / 2 - FW / 2;
            } else if (just === ParagraphJustification.RIGHT_JUSTIFY) {
                shiftX = leftEdge + wordW - FW;
            } else {
                shiftX = leftEdge;
            }
            var shiftY = lineIdx * leading;

            // Duplica a original (preserva estilo + animacao) e vira 1 trecho
            var rSingle = _mtMeasureRectJust(probeTextProp, probe, tok.str, just, baseT);
            var wl = layer.duplicate();
            _mtSetText(wl, tok.str);
            wl.name = _mtSanitizeName(tok.str);
            // ancora SEMPRE no centro da palavra: bounce/escala pivota nela
            // mesma, e animacao de posicao vem "de baixo dela" (trajetoria
            // inteira deslocada pro slot da palavra)
            var centered = _mtCenterWord(wl, rSingle, shiftX, shiftY, baseT);
            if (!centered) _mtOffsetAnchor(wl, shiftX, shiftY); // fallback antigo
            if (addControls) _mtAddControlNull(comp, wl, centered ? 0 : shiftX, centered ? 0 : shiftY, baseT);
            created++;
        }
    }

    try { probe.remove(); } catch (ePr) {}
    return created;
}

/**
 * Mede o retangulo (espaco da camada) de uma string na sonda, com a
 * justificacao REAL da camada original — da o centro exato da palavra
 * no espaco da camada, imune a animators (a sonda nao tem nenhum).
 */
function _mtMeasureRectJust(textProp, probe, str, just, baseT) {
    var td = textProp.value;
    td.text = (str && str.length) ? str : " ";
    try { td.justification = just; } catch (eJ) {}
    textProp.setValue(td);
    var tt = baseT + (_MT_probeTick++) * 0.00001;
    var r = probe.sourceRectAtTime(tt, false);
    return { left: r.left, top: r.top, width: r.width, height: r.height };
}

/** Valor "assentado" de uma propriedade: ultimo keyframe, ou valor base (pre-expressao). */
function _mtSettledValue(prop, t) {
    try {
        if (prop.numKeys > 0) return prop.keyValue(prop.numKeys);
        return prop.valueAtTime(t, true);
    } catch (e) { try { return prop.value; } catch (e2) { return null; } }
}

/**
 * Centraliza a ANCORA da palavra no proprio centro dela e recalcula a
 * Position (valor, TODOS os keyframes, ou a base da expressao aditiva)
 * pra palavra continuar exatamente no mesmo lugar da frase.
 *
 * Resultado: bounce/escala pivota no CENTRO DA PALAVRA (nao no centro
 * da comp) e animacao de posicao vem "de baixo DELA", porque cada
 * palavra carrega a propria trajetoria deslocada pro seu slot.
 *
 * @return {boolean} true se centralizou (false -> usar fallback antigo)
 */
function _mtCenterWord(wl, rect, shiftX, shiftY, baseT) {
    try {
        var tg = wl.property("ADBE Transform Group");
        var ap = tg.property("ADBE Anchor Point");
        var pos = tg.property("ADBE Position");
        if (ap.expressionEnabled || ap.numKeys > 0) return false;

        // centro da palavra no espaco da camada (texto ja e so a palavra)
        var wcx = rect.left + rect.width / 2;
        var wcy = rect.top + rect.height / 2;

        // delta em espaco da camada: da ancora antiga ate o slot da palavra
        var A0 = ap.value;
        var dlx = wcx + shiftX - A0[0];
        var dly = wcy + shiftY - A0[1];

        // converte pro espaco da comp usando escala/rotacao ASSENTADAS
        var sx = 1, sy = 1;
        try {
            var sv = _mtSettledValue(tg.property("ADBE Scale"), baseT);
            if (sv) { sx = sv[0] / 100; sy = sv[1] / 100; }
        } catch (eS) {}
        var dx = dlx * sx, dy = dly * sy;
        try {
            var rotV = _mtSettledValue(tg.property("ADBE Rotate Z"), baseT);
            var th = (rotV || 0) * Math.PI / 180;
            if (th) {
                var rx = dx * Math.cos(th) - dy * Math.sin(th);
                var ry = dx * Math.sin(th) + dy * Math.cos(th);
                dx = rx; dy = ry;
            }
        } catch (eR) {}

        ap.setValue(A0.length > 2 ? [wcx, wcy, A0[2]] : [wcx, wcy]);

        if (pos.numKeys > 0) {
            // desloca a trajetoria INTEIRA pro slot da palavra
            for (var k = 1; k <= pos.numKeys; k++) {
                var v = pos.keyValue(k);
                var nv = (v.length > 2) ? [v[0] + dx, v[1] + dy, v[2]] : [v[0] + dx, v[1] + dy];
                pos.setValueAtTime(pos.keyTime(k), nv);
            }
        } else {
            var pv = pos.valueAtTime(baseT, true); // base pre-expressao
            pos.setValue(pv.length > 2 ? [pv[0] + dx, pv[1] + dy, pv[2]] : [pv[0] + dx, pv[1] + dy]);
        }
        return true;
    } catch (e) { return false; }
}

/**
 * Mede a largura (px, espaco da camada) de uma string usando a sonda.
 * A sonda e sempre esquerda-justificada para medir largura pura.
 * Usa um tempo unico por medicao para invalidar o cache de sourceRectAtTime.
 */
function _mtMeasureWidth(textProp, probe, str, baseT) {
    var hasText = (str && str.length > 0);
    var td = textProp.value;
    td.text = hasText ? str : " ";
    td.justification = ParagraphJustification.LEFT_JUSTIFY;
    textProp.setValue(td);
    var tt = baseT + (_MT_probeTick++) * 0.00001;
    var r = probe.sourceRectAtTime(tt, false);
    return hasText ? r.width : 0;
}

/**
 * Divide uma linha em tokens {str, start, len} conforme o modo.
 */
function _mtTokenize(lineText, mode) {
    var tokens = [];
    if (mode === "lines") {
        if (lineText.replace(/^\s+|\s+$/g, "").length > 0) {
            tokens.push({ str: lineText, start: 0, len: lineText.length });
        }
        return tokens;
    }
    if (mode === "chars") {
        for (var i = 0; i < lineText.length; i++) {
            var ch = lineText.charAt(i);
            if (ch === " " || ch === "\t") continue;
            tokens.push({ str: ch, start: i, len: 1 });
        }
        return tokens;
    }
    // "words" (padrao)
    var re = /\S+/g;
    var m;
    while ((m = re.exec(lineText)) !== null) {
        tokens.push({ str: m[0], start: m.index, len: m[0].length });
    }
    return tokens;
}

/**
 * Define o texto de uma camada preservando o estilo (e keyframes se houver).
 */
function _mtSetText(layer, str) {
    var tp = _mtSourceText(layer);
    if (!tp) return;
    if (tp.numKeys > 0) {
        for (var k = 1; k <= tp.numKeys; k++) {
            var d = tp.keyValue(k);
            d.text = str;
            tp.setValueAtTime(tp.keyTime(k), d);
        }
    } else {
        var d2 = tp.value;
        d2.text = str;
        tp.setValue(d2);
    }
}

/**
 * Desloca o Ponto de Ancora (espaco da camada) para reposicionar o trecho
 * sem alterar Position -> preserva keyframes/expressoes de posicao/animacao.
 */
function _mtOffsetAnchor(layer, shiftX, shiftY) {
    if ((!shiftX || shiftX === 0) && (!shiftY || shiftY === 0)) return;
    var ap = layer.property("ADBE Transform Group").property("ADBE Anchor Point");
    if (ap.expressionEnabled) { _mtOffsetPosition(layer, shiftX, shiftY); return; }
    if (ap.numKeys > 0) {
        for (var k = 1; k <= ap.numKeys; k++) {
            var v = ap.keyValue(k);
            v[0] -= shiftX; v[1] -= shiftY;
            ap.setValueAtTime(ap.keyTime(k), v);
        }
    } else {
        var v2 = ap.value;
        v2[0] -= shiftX; v2[1] -= shiftY;
        ap.setValue(v2);
    }
}

/**
 * Fallback: desloca a Position (compensando escala uniforme) quando o
 * Ponto de Ancora tem expressao.
 */
function _mtOffsetPosition(layer, shiftX, shiftY) {
    var pos = layer.property("ADBE Transform Group").property("ADBE Position");
    if (pos.expressionEnabled) return;
    var f = 1;
    try { f = layer.property("ADBE Transform Group").property("ADBE Scale").value[0] / 100; } catch (e) {}
    var dx = shiftX * f, dy = shiftY * f;
    if (pos.numKeys > 0) {
        for (var k = 1; k <= pos.numKeys; k++) {
            var v = pos.keyValue(k);
            v[0] += dx; v[1] += dy;
            pos.setValueAtTime(pos.keyTime(k), v);
        }
    } else {
        var v2 = pos.value;
        v2[0] += dx; v2[1] += dy;
        pos.setValue(v2);
    }
}

/** Remove todos os animadores de texto de uma camada. */
function _mtStripAnimators(layer) {
    try {
        var animators = layer.property("ADBE Text Properties").property("ADBE Text Animators");
        for (var k = animators.numProperties; k >= 1; k--) {
            try { animators.property(k).remove(); } catch (e) {}
        }
    } catch (e2) {}
}

/** Nome amigavel e curto para a camada. */
function _mtSanitizeName(str) {
    var s = ("" + str).replace(/[\r\n\t]+/g, " ");
    if (s.length > 32) s = s.substring(0, 32);
    return s.length ? s : "palavra";
}

/**
 * Cria um NULL de controle na posicao visivel da palavra e torna a palavra
 * filha dele. Assim o usuario move/afasta a palavra arrastando o NULL, mesmo
 * quando a Position esta "travada" por expressao/keyframes (ex: elastico).
 *
 * So cria quando a Position esta animada (expressao ou keyframes) — senao a
 * palavra ja e arrastavel direto e nao precisa de null.
 *
 * O null e IDENTIDADE (anchor == position), entao nao altera o visual da
 * palavra; a animacao/elastico continua 100% na palavra e "monta" por cima.
 */
function _mtAddControlNull(comp, wl, offX, offY, t) {
    try {
        var tg = wl.property("ADBE Transform Group");
        var posProp = tg.property("ADBE Position");
        // Position livre (sem expressao e sem keyframes) ja e arrastavel -> nao cria null
        if (!posProp.expressionEnabled && posProp.numKeys === 0) return null;

        // Base da posicao (antes da expressao/bounce)
        var base;
        try { base = posProp.valueAtTime(t, true); } catch (eV) { base = posProp.value; }

        // Fator de escala p/ converter o offset (espaco da camada) -> comp
        var sf = 1;
        try { sf = tg.property("ADBE Scale").value[0] / 100; } catch (eS) {}

        var is3D = false;
        try { is3D = wl.threeDLayer; } catch (eD) {}

        // Q = local visivel da palavra (base + offset) -> alca do null fica na palavra
        var qx = base[0] + offX * sf;
        var qy = base[1] + offY * sf;
        var q = is3D ? [qx, qy, (base.length > 2 ? base[2] : 0)] : [qx, qy];

        var op = null;
        try { op = wl.parent; } catch (eP) {}

        var nul = comp.layers.addNull();
        nul.name = "CTRL " + wl.name;
        try { nul.label = 9; } catch (eL) {}
        nul.moveBefore(wl);
        if (is3D) { try { nul.threeDLayer = true; } catch (e3) {} }
        if (op) { try { nul.parent = op; } catch (eOp) {} }

        var nTg = nul.property("ADBE Transform Group");
        // anchor == position => parent identidade (nao move a palavra ao parentar)
        nTg.property("ADBE Anchor Point").setValue(q);
        nTg.property("ADBE Position").setValue(q);

        wl.parent = nul;
        return nul;
    } catch (e) { return null; }
}

// ═══════════════════════════════════════════════════════════════════
// SPREAD / APROXIMAÇÃO — Afasta layers do centro da comp
// ═══════════════════════════════════════════════════════════════════

/**
 * Aplica uma expressão de aproximação/spread nas layers selecionadas.
 * Cada layer se afasta do centro da composição ao longo do tempo,
 * proporcionalmente à sua distância original do centro.
 * @param {number} intensity - Intensidade do afastamento (0.05 a 3.0)
 * @param {number} speed - Velocidade da animação (0.3 a 5.0)
 * @param {number} easing - Suavização da curva (0.5 a 8.0)
 */
function applySpreadEffect(intensity, speed, easing) {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers;
        if (layers.length === 0) return "false";

        var spreadExp =
            "var center = [thisComp.width/2, thisComp.height/2];\n" +
            "var offset = value - center;\n" +
            "var t = time - inPoint;\n" +
            "var spd = " + speed + ";\n" +
            "var intensity = " + intensity + ";\n" +
            "var easing = " + easing + ";\n" +
            "var raw = 1 - Math.exp(-spd * t);\n" +
            "var progress = Math.pow(raw, 1 / Math.max(easing * 0.5, 0.3));\n" +
            "center + offset * (1 + intensity * progress);";

        var count = 0;
        app.beginUndoGroup("MT: Aproximação (int=" + intensity + " spd=" + speed + " ease=" + easing + ")");

        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];
            var posProp = layer.property("ADBE Transform Group").property("ADBE Position");
            if (posProp && posProp.canSetExpression) {
                try {
                    posProp.expression = spreadExp;
                    count++;
                } catch (e) {
                    // Ignorar se não suportar expressão
                }
            }
        }

        app.endUndoGroup();
        return count > 0 ? "true" : "false";
    } catch (e) { return "false"; }
}



// ═══════════════════════════════════════════════════════════════════
// COPILOTO — Execução segura de scripts gerados pela IA
// ═══════════════════════════════════════════════════════════════════

function getActiveCompInfo() {
    try {
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) return '{"error":"Nenhuma comp ativa"}';
        var n = comp.name.replace(/"/g, '\\"');
        return '{"name":"' + n + '","width":' + comp.width + ',"height":' + comp.height + ',"fps":' + comp.frameRate + ',"duration":' + comp.duration.toFixed(2) + ',"numLayers":' + comp.numLayers + '}';
    } catch (e) {
        return '{"error":"' + e.toString().replace(/"/g, '\\"') + '"}';
    }
}

function getLayersList() {
    try {
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) return '[]';
        var r = '[';
        for (var i = 1; i <= comp.numLayers; i++) {
            var l = comp.layer(i);
            if (i > 1) r += ',';
            r += '{"index":' + i + ',"name":"' + l.name.replace(/"/g, '\\"') + '","type":"' + l.matchName + '","enabled":' + l.enabled + '}';
        }
        return r + ']';
    } catch (e) { return '[]'; }
}

// Retorna descricao DETALHADA da timeline (cada layer com tempo de entrada/saida, tipo, dimensoes)
// Usado pela IA para compor video na timeline ja decupada
function getTimelineComposition() {
    try {
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) return '{"error":"Nenhuma comp ativa"}';

        function esc(s) { return String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"'); }

        var r = '{';
        r += '"name":"' + esc(comp.name) + '",';
        r += '"width":' + comp.width + ',';
        r += '"height":' + comp.height + ',';
        r += '"fps":' + comp.frameRate + ',';
        r += '"duration":' + comp.duration.toFixed(3) + ',';
        r += '"numLayers":' + comp.numLayers + ',';
        r += '"layers":[';

        for (var i = 1; i <= comp.numLayers; i++) {
            var l = comp.layer(i);
            if (i > 1) r += ',';

            // Categoria amigavel pra IA (sem referenciar FootageSource que nao e global)
            var cat = "other";
            var hasVideo = false, hasAudio = false;
            try { hasVideo = !!l.hasVideo; } catch(eV) {}
            try { hasAudio = !!l.hasAudio; } catch(eA) {}

            if (l instanceof TextLayer) {
                cat = "text";
            } else if (l instanceof ShapeLayer) {
                cat = "shape";
            } else if (l instanceof AVLayer) {
                if (l.nullLayer) {
                    cat = "null";
                } else if (l.source) {
                    if (l.source instanceof CompItem) {
                        cat = "precomp";
                    } else {
                        // FootageItem: detectar still/video/audio via mainSource
                        var isStill = false;
                        try { isStill = !!l.source.mainSource.isStill; } catch(eS) {}
                        var isSolid = false;
                        try { isSolid = !!l.source.mainSource.color; } catch(eC) {}
                        if (isSolid) cat = "solid";
                        else if (isStill) cat = "image";
                        else if (hasVideo && hasAudio) cat = "video";
                        else if (hasVideo) cat = "footage";
                        else if (hasAudio) cat = "audio";
                    }
                }
            }

            var srcW = 0, srcH = 0, srcDur = 0;
            try { if (l.source) { srcW = l.source.width || 0; srcH = l.source.height || 0; srcDur = l.source.duration || 0; } } catch(e1) {}

            r += '{';
            r += '"index":' + i + ',';
            r += '"name":"' + esc(l.name) + '",';
            r += '"category":"' + cat + '",';
            r += '"matchName":"' + esc(l.matchName) + '",';
            r += '"inPoint":' + l.inPoint.toFixed(3) + ',';
            r += '"outPoint":' + l.outPoint.toFixed(3) + ',';
            r += '"startTime":' + l.startTime.toFixed(3) + ',';
            r += '"duration":' + (l.outPoint - l.inPoint).toFixed(3) + ',';
            r += '"enabled":' + l.enabled + ',';
            r += '"hasVideo":' + hasVideo + ',';
            r += '"hasAudio":' + hasAudio + ',';
            r += '"srcWidth":' + srcW + ',';
            r += '"srcHeight":' + srcH + ',';
            r += '"srcDuration":' + srcDur.toFixed(3);
            r += '}';
        }

        r += ']}';
        return r;
    } catch (e) {
        return '{"error":"' + e.toString().replace(/"/g, '\\"') + '"}';
    }
}

function importImageToComp(filePath) {
    try {
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) return "Selecione uma composição";

        var imgFile = new File(filePath);
        if (!imgFile.exists) return "Arquivo não encontrado";

        app.beginUndoGroup("MT: Importar Imagem AI");

        // Import the file
        var importOptions = new ImportOptions(imgFile);
        var item = app.project.importFile(importOptions);

        // Add to comp
        var layer = comp.layers.add(item);
        layer.name = "AI Image";

        // Fit to comp
        var scaleX = (comp.width / item.width) * 100;
        var scaleY = (comp.height / item.height) * 100;
        var s = Math.max(scaleX, scaleY);
        layer.transform.scale.setValue([s, s]);
        layer.transform.position.setValue([comp.width / 2, comp.height / 2]);

        // Move to bottom
        layer.moveToEnd();

        app.endUndoGroup();
        return "true";
    } catch (e) {
        return "Erro: " + e.toString();
    }
}

function safeExecuteFile(filePath) {
    try {
        // Tentar múltiplos formatos de path
        var f = null;
        var paths = [
            filePath,
            decodeURI(filePath),
            filePath.replace(/\//g, "\\"),
            filePath.replace("file:///", ""),
            decodeURI(filePath.replace("file:///", ""))
        ];
        for (var p = 0; p < paths.length; p++) {
            var test = new File(paths[p]);
            if (test.exists) { f = test; break; }
        }
        if (!f) return "ERRO: Arquivo não encontrado";
        var result = $.evalFile(f);
        try { f.remove(); } catch(e2) {}
        if (result !== undefined && result !== null) return String(result);
        return "OK";
    } catch (e) {
        return "ERRO: " + e.toString() + " | Linha: " + e.line;
    }
}

function safeExecute(code) {
    try {
        code = code.replace(/\\n/g, "\n").replace(/\\"/g, '"').replace(/\\\\/g, "\\");
        code = code.replace(/^```(?:javascript|jsx|js)?\s*\n?/gm, "");
        code = code.replace(/```\s*$/gm, "");
        code = code.replace(/^\s+|\s+$/g, "");

        var tempFile = new File(Folder.temp.fsName + "/mt_copilot_exec.jsx");
        tempFile.open("w");
        tempFile.encoding = "UTF-8";
        tempFile.write(code);
        tempFile.close();

        var result = $.evalFile(tempFile);
        tempFile.remove();

        if (result !== undefined && result !== null) return String(result);
        return "OK";
    } catch (e) {
        return "ERRO: " + e.toString() + " | Linha: " + e.line;
    }
}

// ═══════════════════════════════════════════════════════════════════
// UTILIDADES
// ═══════════════════════════════════════════════════════════════════

function getActiveComp() {
    var item = app.project.activeItem;
    if (item && item instanceof CompItem) return item;
    return null;
}

function formatTime(seconds, frameRate) {
    if (!seconds || !frameRate) return "00:00:00";
    var totalFrames = Math.round(seconds * frameRate);
    var frames = totalFrames % Math.round(frameRate);
    var secs = Math.floor(seconds) % 60;
    var mins = Math.floor(seconds / 60);
    return pad(mins) + ":" + pad(secs) + ":" + pad(frames);
}

function pad(n) {
    return (n < 10 ? "0" : "") + n;
}

// ═══════════════════════════════════════════════════════════════════
// CAPTIONS
// ═══════════════════════════════════════════════════════════════════

/**
 * Cria uma camada de texto com keyframes baseados no JSON de legendas.
 * @param {string} jsonStr - String JSON contendo array de objetos {start, end, text}
 * @param {string} mode - "single" (padrão) ou "separate"
 */
function createCaptionsFromJSON(jsonStr, mode) {
    var comp = getActiveComp(); if (!comp) return "false";

    // Parse JSON safely (ExtendScript não tem JSON nativo)
    var data;
    try {
        data = eval("(" + jsonStr + ")");
    } catch (e) {
        return "false";
    }

    if (!data || data.length === 0) return "false";

    app.beginUndoGroup("MT: Criar Legendas (AI)");

    if (mode === 'separate') {
        // MODO SEPARADO: Uma layer por palavra
        // Melhor performance para edição individual, mas gera muitas layers
        // Criar do fim para o início para manter ordem visual correta (ou o contrário?)
        // Se criar em loop normal (0..N), o N fica no topo.

        for (var i = 0; i < data.length; i++) {
            var cap = data[i];
            var layer = comp.layers.addText(cap.text);

            // Configurar texto
            var textProp = layer.property("Source Text");
            var textDoc = textProp.value;
            textDoc.fontSize = 50;
            textDoc.fillColor = [1, 1, 1];
            textDoc.justification = ParagraphJustification.CENTER_JUSTIFY;
            textProp.setValue(textDoc);

            // Configurar Tempo
            layer.inPoint = cap.start;
            layer.outPoint = cap.end;

            // Configurar Posição (Centralizado, Base)
            var b = layer.sourceRectAtTime(cap.start, false); // ou 0
            layer.property("Position").setValue([comp.width / 2, comp.height * 0.9]);
            layer.property("Anchor Point").setValue([0, 0]);
        }

    } else {
        // MODO ÚNICO: Uma layer animada (Source Text)
        // Padrão anterior

        var layer = comp.layers.addText("Legendas");
        var textProp = layer.property("Source Text");

        // Configuração inicial
        var textDoc = textProp.value;
        textDoc.fontSize = 50;
        textDoc.fillColor = [1, 1, 1];
        textDoc.justification = ParagraphJustification.CENTER_JUSTIFY;
        textProp.setValue(textDoc);

        // Posição
        layer.property("Position").setValue([comp.width / 2, comp.height * 0.9]);
        layer.property("Anchor Point").setValue([0, 0]);

        // Keyframes
        for (var i = 0; i < data.length; i++) {
            var cap = data[i];

            // Keyframe de entrada
            textProp.setValueAtTime(cap.start, new TextDocument(cap.text));

            // Verificar próximo
            var nextStart = (i < data.length - 1) ? data[i + 1].start : (cap.end + 100);

            // Limpar se houver gap.
            // No modo 'palavra por palavra' interpolado, gaps são raros dentro da frase, mas existem entre frases.
            if (nextStart - cap.end > 0.05) {
                textProp.setValueAtTime(cap.end, new TextDocument(""));
            }
        }
    }

    app.endUndoGroup();
    return "true";
}

/**
 * Renderiza apenas o áudio da composição ativa para um arquivo temporário WAV.
 * Retorna o caminho do arquivo renderizado ou "false".
 */
function renderAudioOnly() {
    try {
        var comp = getActiveComp(); if (!comp) return "false";

        // Caminho do arquivo temporário
        var tempFolder = Folder.temp;
        var fileName = "temp_audio_" + Math.floor(Math.random() * 10000) + ".wav";
        var file = new File(tempFolder.fsName + "/" + fileName);

        // Adicionar à Render Queue
        var rq = app.project.renderQueue;
        var rqItem = rq.items.add(comp);

        // Desabilitar outros itens da fila para não renderizar o mundo todo
        for (var i = 1; i < rq.numItems; i++) { // items is 1-based, but we just added one so it's the last one
            if (rq.item(i) !== rqItem) {
                rq.item(i).render = false;
            }
        }

        // Configurar Output Module
        var om = rqItem.outputModule(1);
        try {
            om.applyTemplate("WAV"); // Tenta usar o template "WAV"
        } catch (e) {
            // Se falhar, tenta "Lossless" e muda para WAV se possível via scripting?
            // Scripting output module settings is hard. Assuming "WAV" exists or user has a template for audio.
            // Or try "AIFF" ?
            // Let's assume WAV exists as per request requirement.
            return "Error: Template WAV not found";
        }

        om.file = file;

        // Renderizar
        rq.render();

        // Verificar se arquivo existe
        if (file.exists) {
            // Remover item da fila (limpeza)
            rqItem.remove();
            return file.fsName; // Retorna caminho absoluto
        } else {
            return "false";
        }

    } catch (e) {
        return "Error: " + e.toString();
    }
}

// ═══════════════════════════════════════════════════════════════════
// DESENHAR CAMINHO — Creates AE animations from drawn paths
// ═══════════════════════════════════════════════════════════════════

function createDrawnPath(jsonStr) {
    try {
        var data = eval("(" + jsonStr + ")");
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) return "Selecione uma composição";
        if (!data.strokes || data.strokes.length === 0) return "Nenhum traço";

        _mtDrawPressure = !!data.pressure;

        app.beginUndoGroup("MT: Desenho " + data.mode);

        var startTime = data.atPlayhead ? comp.time : 0;
        var result = "false";

        switch (data.mode) {
            case "reveal":   result = _drawReveal(comp, data, startTime); break;
            case "motion":   result = _drawMotion(comp, data, startTime); break;
            case "stroke":   result = _drawStroke(comp, data, startTime); break;
            case "loop":     result = _drawLoop(comp, data, startTime); break;
            case "multi":    result = _drawMulti(comp, data, startTime); break;
            default:         result = _drawReveal(comp, data, startTime);
        }

        app.endUndoGroup();
        return result;
    } catch (e) {
        return "Erro: " + e.toString();
    }
}

// Convert canvas coords to comp coords
function _drawToComp(pts, canvasW, canvasH, comp) {
    var scaleX = comp.width / canvasW;
    var scaleY = comp.height / canvasH;
    var result = [];
    for (var i = 0; i < pts.length; i++) {
        result.push({
            x: pts[i].x * scaleX,
            y: pts[i].y * scaleY,
            t: pts[i].t || 0,
            p: (pts[i].p != null) ? pts[i].p : 1
        });
    }
    return result;
}

// Taper best-effort — pressão → afinamento do traço (AE 2020+). Falha silenciosa em versões antigas.
function _drawTryTaper(stroke, startPct, endPct) {
    try {
        var groupNames = ["ADBE Vector Stroke Taper", "ADBE Vector Taper"];
        var taper = null;
        for (var i = 0; i < groupNames.length; i++) {
            try { var g = stroke.property(groupNames[i]); if (g) { taper = g; break; } } catch (e) {}
        }
        if (!taper) return;
        var swNames = ["ADBE Vector Taper Start Width", "ADBE Vector Stroke Taper Start Width"];
        var ewNames = ["ADBE Vector Taper End Width", "ADBE Vector Stroke Taper End Width"];
        for (var j = 0; j < swNames.length; j++) { try { var sp = taper.property(swNames[j]); if (sp) { sp.setValue(startPct); break; } } catch (e) {} }
        for (var k = 0; k < ewNames.length; k++) { try { var ep = taper.property(ewNames[k]); if (ep) { ep.setValue(endPct); break; } } catch (e) {} }
    } catch (e) {}
}

// Build Shape object from points — honors vertexType ("smooth" | "corner") and tangentStrength (0-1)
// Uses Catmull-Rom → Bezier tangent math (EXATAMENTE igual ao preview do canvas no main.js)
function _drawBuildShape(pts, vertexType, tangentStrength) {
    var verts = [];
    var inT = [];
    var outT = [];
    for (var i = 0; i < pts.length; i++) {
        verts.push([pts[i].x, pts[i].y]);
        inT.push([0, 0]);
        outT.push([0, 0]);
    }

    if (vertexType !== "corner" && pts.length >= 3) {
        // Uniform Catmull-Rom: tangent at vertex j = (P[j+1] - P[j-1]) * k
        // AE stores inTangent/outTangent as vectors RELATIVE to the vertex
        var k = (typeof tangentStrength === "number") ? tangentStrength * 0.5 : 0.25;
        for (var j = 0; j < pts.length; j++) {
            var prev = pts[j === 0 ? 0 : j - 1];
            var next = pts[j + 1 >= pts.length ? pts.length - 1 : j + 1];
            var dx = (next.x - prev.x) * k;
            var dy = (next.y - prev.y) * k;
            inT[j] = [-dx, -dy];
            outT[j] = [dx, dy];
        }
    }
    // Se vertexType === "corner", todos os tangents ficam [0,0] = vertices retos

    var shape = new Shape();
    shape.vertices = verts;
    shape.inTangents = inT;
    shape.outTangents = outT;
    shape.closed = false;
    return shape;
}

// Create shape layer with path
function _drawCreateShapeLayer(comp, pts, color, strokeWidth, name, vertexType, tangentStrength) {
    var layer = comp.layers.addShape();
    layer.name = name || "Drawn Path";
    var contents = layer.property("ADBE Root Vectors Group");
    var group = contents.addProperty("ADBE Vector Group");
    group.name = "Path";
    var gc = group.property("ADBE Vectors Group");

    // Path
    var pathProp = gc.addProperty("ADBE Vector Shape - Group");
    var shapePath = pathProp.property("ADBE Vector Shape");
    shapePath.setValue(_drawBuildShape(pts, vertexType, tangentStrength));

    // Stroke
    var stroke = gc.addProperty("ADBE Vector Graphic - Stroke");
    var hex = color.replace("#", "");
    var r = parseInt(hex.substring(0, 2), 16) / 255;
    var g = parseInt(hex.substring(2, 4), 16) / 255;
    var b = parseInt(hex.substring(4, 6), 16) / 255;
    stroke.property("ADBE Vector Stroke Color").setValue([r, g, b, 1]);
    stroke.property("ADBE Vector Stroke Width").setValue(strokeWidth || 4);
    stroke.property("ADBE Vector Stroke Line Cap").setValue(2); // Round cap

    // Pressão (caneta/tablet) → taper nas pontas do traço
    if (typeof _mtDrawPressure !== "undefined" && _mtDrawPressure && pts.length > 1) {
        var sPct = Math.round(((pts[0].p != null) ? pts[0].p : 1) * 100);
        var ePct = Math.round(((pts[pts.length - 1].p != null) ? pts[pts.length - 1].p : 1) * 100);
        _drawTryTaper(stroke, sPct, ePct);
    }

    // Reset position to 0,0 (shape coords are absolute)
    layer.transform.position.setValue([0, 0]);
    layer.transform.anchorPoint.setValue([0, 0]);

    return { layer: layer, gc: gc, shapePath: shapePath };
}

// Apply easing to keyframes
function _drawApplyEasing(prop, easing) {
    if (!easing || easing === "none") return;
    var inf = 75;
    if (easing === "easeIn") inf = 85;
    if (easing === "easeOut") inf = 85;
    var ease = new KeyframeEase(0, inf);
    for (var k = 1; k <= prop.numKeys; k++) {
        var dims = 1;
        try { var v = prop.keyValue(k); if (v instanceof Array) dims = v.length; } catch(e) {}
        var ea = [];
        for (var d = 0; d < dims; d++) ea.push(ease);
        try { prop.setTemporalEaseAtKey(k, ea, ea); } catch(e) {}
    }
}

// Get auto duration from stroke timing
function _drawGetDuration(stroke, override) {
    if (override && override > 0) return override;
    var pts = stroke.points;
    if (pts.length < 2) return 1;
    return Math.max(0.5, pts[pts.length - 1].t || 1);
}

// ── MODE: REVEAL ──────────────────────────────────────
function _drawReveal(comp, data, startTime) {
    var count = 0;
    for (var s = 0; s < data.strokes.length; s++) {
        var stroke = data.strokes[s];
        var pts = _drawToComp(stroke.points, data.canvasW, data.canvasH, comp);
        var dur = _drawGetDuration(stroke, data.duration);
        var res = _drawCreateShapeLayer(comp, pts, stroke.color || data.color, stroke.width || data.width, "Reveal " + (s + 1), data.vertexType, data.tangentStrength);

        // Add Trim Paths
        var trim = res.gc.addProperty("ADBE Vector Filter - Trim");
        var trimEnd = trim.property("ADBE Vector Trim End");
        trimEnd.setValueAtTime(startTime, 0);
        trimEnd.setValueAtTime(startTime + dur, 100);
        _drawApplyEasing(trimEnd, data.easing);

        count++;
    }
    return count > 0 ? "true" : "Erro ao criar";
}

// ── MODE: MOTION PATH ─────────────────────────────────
function _drawMotion(comp, data, startTime) {
    var layers = comp.selectedLayers;
    if (layers.length === 0) return "Selecione uma layer para mover";

    var stroke = data.strokes[0]; // Use first stroke
    var pts = _drawToComp(stroke.points, data.canvasW, data.canvasH, comp);
    var dur = _drawGetDuration(stroke, data.duration);

    for (var i = 0; i < layers.length; i++) {
        var layer = layers[i];
        var pos = layer.transform.position;

        // Create keyframes following the path with real timing
        for (var p = 0; p < pts.length; p++) {
            var t = startTime + (pts[p].t / pts[pts.length - 1].t) * dur;
            pos.setValueAtTime(t, [pts[p].x, pts[p].y]);
        }

        _drawApplyEasing(pos, data.easing);
    }

    return "true";
}

// ── MODE: STROKE ANIMATE ──────────────────────────────
function _drawStroke(comp, data, startTime) {
    var stroke = data.strokes[0];
    var pts = _drawToComp(stroke.points, data.canvasW, data.canvasH, comp);
    var dur = _drawGetDuration(stroke, data.duration);
    var res = _drawCreateShapeLayer(comp, pts, stroke.color || data.color, stroke.width || data.width, "Stroke Animate", data.vertexType, data.tangentStrength);

    // Add Trim Paths with moving segment
    var trim = res.gc.addProperty("ADBE Vector Filter - Trim");
    var segSize = 15; // 15% segment

    var trimStart = trim.property("ADBE Vector Trim Start");
    var trimEnd = trim.property("ADBE Vector Trim End");

    trimStart.setValueAtTime(startTime, 0);
    trimStart.setValueAtTime(startTime + dur, 100 - segSize);
    trimEnd.setValueAtTime(startTime, segSize);
    trimEnd.setValueAtTime(startTime + dur, 100);

    _drawApplyEasing(trimStart, data.easing);
    _drawApplyEasing(trimEnd, data.easing);

    // Add Glow
    try {
        var fx = res.layer.property("ADBE Effect Parade");
        var glow = fx.addProperty("ADBE Glo2");
        glow.property(1).setValue(50); // threshold
        glow.property(2).setValue(1.5); // radius
        glow.property(3).setValue(0.8); // intensity
    } catch(e) {}

    return "true";
}

// ── MODE: LOOP ────────────────────────────────────────
function _drawLoop(comp, data, startTime) {
    var stroke = data.strokes[0];
    var pts = _drawToComp(stroke.points, data.canvasW, data.canvasH, comp);
    var dur = _drawGetDuration(stroke, data.duration);
    var res = _drawCreateShapeLayer(comp, pts, stroke.color || data.color, stroke.width || data.width, "Loop Path", data.vertexType, data.tangentStrength);

    // Add Trim Paths with looping offset expression
    var trim = res.gc.addProperty("ADBE Vector Filter - Trim");
    var segSize = 20;
    trim.property("ADBE Vector Trim Start").setValue(0);
    trim.property("ADBE Vector Trim End").setValue(segSize);

    // Animate offset with expression for infinite loop
    var offset = trim.property("ADBE Vector Trim Offset");
    var speed = dur > 0 ? (360 / dur) : 180;
    offset.expression = "time * " + speed.toFixed(1);

    return "true";
}

// ── MODE: MULTI-STROKE ────────────────────────────────
function _drawMulti(comp, data, startTime) {
    var count = 0;
    var timeOffset = 0;

    for (var s = 0; s < data.strokes.length; s++) {
        var stroke = data.strokes[s];
        var pts = _drawToComp(stroke.points, data.canvasW, data.canvasH, comp);
        var dur = _drawGetDuration(stroke, data.duration);
        var sTime = startTime + timeOffset;

        var res = _drawCreateShapeLayer(comp, pts, stroke.color || data.color, stroke.width || data.width, "Stroke " + (s + 1), data.vertexType, data.tangentStrength);

        // Trim Paths reveal
        var trim = res.gc.addProperty("ADBE Vector Filter - Trim");
        var trimEnd = trim.property("ADBE Vector Trim End");
        trimEnd.setValueAtTime(sTime, 0);
        trimEnd.setValueAtTime(sTime + dur, 100);
        _drawApplyEasing(trimEnd, data.easing);

        // Set layer timing
        res.layer.inPoint = sTime;

        timeOffset += dur + 0.1; // Small gap between strokes
        count++;
    }

    return count > 0 ? "true" : "Erro ao criar";
}


// ═══════════════════════════════════════════════════════════════════
// NOVAS ANIMAÇÕES — Wiggle / Fade / Pop / Slide
// ═══════════════════════════════════════════════════════════════════

function _mtEaseKeys(prop) {
    try {
        var dim = 1;
        try { var v = prop.valueAtTime(0, false); if (v instanceof Array) dim = v.length; } catch (e) {}
        for (var k = 1; k <= prop.numKeys; k++) {
            var ein = [], eout = [];
            for (var d = 0; d < dim; d++) { ein.push(new KeyframeEase(0, 33)); eout.push(new KeyframeEase(0, 33)); }
            prop.setInterpolationTypeAtKey(k, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER);
            prop.setTemporalEaseAtKey(k, ein, eout);
        }
    } catch (e) {}
}

// WIGGLE — expressão wiggle() em Position (+ Rotation opcional)
function applyWiggleEffect(freq, amp, rot) {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers; if (layers.length === 0) return "false";
        app.beginUndoGroup("MT: Wiggle");
        var count = 0;
        for (var i = 0; i < layers.length; i++) {
            var L = layers[i];
            var pos = L.property("ADBE Transform Group").property("ADBE Position");
            if (pos && pos.canSetExpression) {
                try { pos.expression = "wiggle(" + freq + ", " + amp + ")"; count++; } catch (e) {}
            }
            if (rot > 0) {
                var rz = L.property("ADBE Transform Group").property("ADBE Rotate Z");
                if (rz && rz.canSetExpression) { try { rz.expression = "wiggle(" + freq + ", " + rot + ")"; } catch (e) {} }
            }
        }
        app.endUndoGroup();
        return count > 0 ? "true" : "false";
    } catch (e) { return "false"; }
}

// FADE — keyframes de Opacity no playhead (mode: in / out / inout)
function applyFadeIn(dur, mode) {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers; if (layers.length === 0) return "false";
        app.beginUndoGroup("MT: Fade (" + mode + ")");
        var t0 = comp.time, count = 0;
        for (var i = 0; i < layers.length; i++) {
            var op = layers[i].property("ADBE Transform Group").property("ADBE Opacity");
            if (!op) continue;
            if (mode === "in") {
                op.setValueAtTime(t0, 0); op.setValueAtTime(t0 + dur, 100);
            } else if (mode === "out") {
                op.setValueAtTime(t0, 100); op.setValueAtTime(t0 + dur, 0);
            } else { // inout
                op.setValueAtTime(t0, 0);
                op.setValueAtTime(t0 + dur, 100);
                op.setValueAtTime(t0 + dur * 2, 100);
                op.setValueAtTime(t0 + dur * 3, 0);
            }
            _mtEaseKeys(op);
            count++;
        }
        app.endUndoGroup();
        return count > 0 ? "true" : "false";
    } catch (e) { return "false"; }
}

// POP — Scale 0 → overshoot → 100 no playhead
function applyPopIn(dur, overshoot) {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers; if (layers.length === 0) return "false";
        app.beginUndoGroup("MT: Pop In");
        var t0 = comp.time, count = 0, os = 1 + (overshoot / 100);
        for (var i = 0; i < layers.length; i++) {
            var sc = layers[i].property("ADBE Transform Group").property("ADBE Scale");
            if (!sc) continue;
            var base = sc.valueAtTime(t0, false);
            var bx = base[0], by = base[1];
            sc.setValueAtTime(t0, [0, 0]);
            sc.setValueAtTime(t0 + dur * 0.6, [bx * os, by * os]);
            sc.setValueAtTime(t0 + dur, [bx, by]);
            _mtEaseKeys(sc);
            count++;
        }
        app.endUndoGroup();
        return count > 0 ? "true" : "false";
    } catch (e) { return "false"; }
}

// SLIDE — Position de fora da tela → posição final (dir: left/right/top/bottom)
function applySlideIn(dur, dist, dir) {
    try {
        var comp = getActiveComp(); if (!comp) return "false";
        var layers = comp.selectedLayers; if (layers.length === 0) return "false";
        app.beginUndoGroup("MT: Slide In (" + dir + ")");
        var t0 = comp.time, count = 0;
        for (var i = 0; i < layers.length; i++) {
            var pos = layers[i].property("ADBE Transform Group").property("ADBE Position");
            if (!pos) continue;
            var p = pos.valueAtTime(t0, false);
            var fx = p[0], fy = p[1];
            var sx = fx, sy = fy;
            if (dir === "left") sx = fx - dist;
            else if (dir === "right") sx = fx + dist;
            else if (dir === "top") sy = fy - dist;
            else if (dir === "bottom") sy = fy + dist;
            var start = (p.length === 3) ? [sx, sy, p[2]] : [sx, sy];
            var fin = (p.length === 3) ? [fx, fy, p[2]] : [fx, fy];
            pos.setValueAtTime(t0, start);
            pos.setValueAtTime(t0 + dur, fin);
            _mtEaseKeys(pos);
            count++;
        }
        app.endUndoGroup();
        return count > 0 ? "true" : "false";
    } catch (e) { return "false"; }
}


// ═══════════════════════════════════════════════════════════════════
// MOTION — Construtor de cena: cria layers de shape/texto no AE
// ═══════════════════════════════════════════════════════════════════

function _motionHexRGB(hex) {
    hex = (hex || "#cccccc").replace("#", "");
    if (hex.length === 3) hex = hex.charAt(0) + hex.charAt(0) + hex.charAt(1) + hex.charAt(1) + hex.charAt(2) + hex.charAt(2);
    return [parseInt(hex.substring(0, 2), 16) / 255, parseInt(hex.substring(2, 4), 16) / 255, parseInt(hex.substring(4, 6), 16) / 255];
}

function _motionAddFill(gc, rgb) {
    var fill = gc.addProperty("ADBE Vector Graphic - Fill");
    fill.property("ADBE Vector Fill Color").setValue([rgb[0], rgb[1], rgb[2], 1]);
    return fill;
}
function _motionAddStroke(gc, rgb, w) {
    var st = gc.addProperty("ADBE Vector Graphic - Stroke");
    st.property("ADBE Vector Stroke Color").setValue([rgb[0], rgb[1], rgb[2], 1]);
    st.property("ADBE Vector Stroke Width").setValue(w || 4);
    st.property("ADBE Vector Stroke Line Cap").setValue(2);
    return st;
}

function _motionNewShape(comp, name) {
    var layer = comp.layers.addShape();
    layer.name = name || "Shape";
    var root = layer.property("ADBE Root Vectors Group");
    var grp = root.addProperty("ADBE Vector Group");
    grp.name = "Group";
    return { layer: layer, gc: grp.property("ADBE Vectors Group") };
}

function _motionPlace(layer, cx, cy, rot, opacity) {
    layer.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0, 0]);
    layer.property("ADBE Transform Group").property("ADBE Position").setValue([cx, cy]);
    if (rot) layer.property("ADBE Transform Group").property("ADBE Rotate Z").setValue(rot);
    if (opacity != null) layer.property("ADBE Transform Group").property("ADBE Opacity").setValue(opacity);
}

function _motionGlow(layer, amount, glowHex) {
    if (!amount || amount <= 0) return;
    try {
        var fx = layer.property("ADBE Effect Parade");
        var glow = fx.addProperty("ADBE Glo2");
        try { glow.property(1).setValue(Math.max(0, 100 - amount)); } catch (e) {}
        try { glow.property(2).setValue(Math.max(4, amount * 1.4)); } catch (e) {}
        try { glow.property(3).setValue(0.5 + (amount / 100) * 1.6); } catch (e) {}
        if (glowHex) {
            var gc = _motionHexRGB(glowHex);
            try { glow.property(6).setValue(2); } catch (e) {}                       // Glow Colors = A & B
            try { glow.property(11).setValue([gc[0], gc[1], gc[2], 1]); } catch (e) {} // Color A
            try { glow.property(12).setValue([gc[0], gc[1], gc[2], 1]); } catch (e) {} // Color B
        }
    } catch (e) {}
}

function _motionApplyNeon(gc, glowRgb) {
    var f = _motionAddFill(gc, [0.04, 0.04, 0.06]);
    try { f.property("ADBE Vector Fill Opacity").setValue(45); } catch (e) {}
    try {
        var st = gc.addProperty("ADBE Vector Graphic - Stroke");
        st.property("ADBE Vector Stroke Color").setValue([glowRgb[0], glowRgb[1], glowRgb[2], 1]);
        st.property("ADBE Vector Stroke Width").setValue(3);
    } catch (e) {}
}

function _motionApplyGlass(gc, fill) {
    try { fill.property("ADBE Vector Fill Opacity").setValue(18); } catch (e) {}
    try {
        var st = gc.addProperty("ADBE Vector Graphic - Stroke");
        st.property("ADBE Vector Stroke Color").setValue([1, 1, 1, 1]);
        st.property("ADBE Vector Stroke Width").setValue(2);
        try { st.property("ADBE Vector Stroke Opacity").setValue(28); } catch (e) {}
    } catch (e) {}
}

function _motionBuildBg(comp, prim) {
    var rgb1 = _motionHexRGB(prim.c1), rgb2 = _motionHexRGB(prim.c2);
    var solid = comp.layers.addSolid(rgb2, "BG Cena", comp.width, comp.height, 1);
    try { solid.moveToEnd(); } catch (e) {}
    try {
        var fx = solid.property("ADBE Effect Parade");
        var ramp = fx.addProperty("ADBE Ramp");
        ramp.property(1).setValue([comp.width / 2, comp.height * 0.5]);
        ramp.property(2).setValue(rgb1);
        ramp.property(3).setValue([comp.width, comp.height]);
        ramp.property(4).setValue(rgb2);
        try { ramp.property(5).setValue(2); } catch (e) {}
    } catch (e) {}
}

function _motionBuildPrim(comp, prim, sx, sy) {
    var s = (sx + sy) / 2;
    var cx = prim.cx * sx, cy = prim.cy * sy;
    var w = (prim.w || 100) * sx, h = (prim.h || 100) * sy;
    var rgb = _motionHexRGB(prim.color);
    var op = (prim.opacity != null) ? prim.opacity : 100;
    var kind = prim.kind;

    if (kind === "bg") { _motionBuildBg(comp, prim); return; }

    if (kind === "text") {
        var tl = comp.layers.addText(prim.text || "Texto");
        var td = tl.property("ADBE Text Properties").property("ADBE Text Document").value;
        td.fillColor = rgb;
        td.applyFill = true;
        td.fontSize = Math.max(6, (prim.fontSize || 40) * s);
        try { td.justification = ParagraphJustification.CENTER_JUSTIFY; } catch (e) {}
        tl.property("ADBE Text Properties").property("ADBE Text Document").setValue(td);
        tl.property("ADBE Transform Group").property("ADBE Position").setValue([cx, cy]);
        if (prim.rot) tl.property("ADBE Transform Group").property("ADBE Rotate Z").setValue(prim.rot);
        if (op != null) tl.property("ADBE Transform Group").property("ADBE Opacity").setValue(op);
        _motionGlow(tl, prim.glow, prim.glowColor);
        return;
    }

    var neonRgb = prim.glowColor ? _motionHexRGB(prim.glowColor) : rgb;

    if (kind === "ellipse") {
        var e = _motionNewShape(comp, "Ellipse");
        var el = e.gc.addProperty("ADBE Vector Shape - Ellipse");
        el.property("ADBE Vector Ellipse Size").setValue([w, h]);
        if (prim.neon) { _motionApplyNeon(e.gc, neonRgb); }
        else if (prim.stroke) { _motionAddStroke(e.gc, rgb, (prim.strokeWidth || 6) * s); }
        else { var efill = _motionAddFill(e.gc, rgb); if (prim.glass) _motionApplyGlass(e.gc, efill); }
        _motionPlace(e.layer, cx, cy, prim.rot, op);
        _motionGlow(e.layer, prim.glow, prim.glowColor);
        return;
    }

    if (kind === "star") {
        var st = _motionNewShape(comp, prim.polygon ? "Polygon" : "Star");
        var star = st.gc.addProperty("ADBE Vector Shape - Star");
        try { star.property("ADBE Vector Star Type").setValue(prim.polygon ? 2 : 1); } catch (e2) {}
        try { star.property("ADBE Vector Star Points").setValue(prim.points || 5); } catch (e3) {}
        var outer = Math.min(w, h) / 2;
        try { star.property("ADBE Vector Star Outer Radius").setValue(outer); } catch (e4) {}
        if (!prim.polygon) { try { star.property("ADBE Vector Star Inner Radius").setValue(outer * 0.5); } catch (e5) {} }
        if (prim.neon) { _motionApplyNeon(st.gc, neonRgb); }
        else if (prim.stroke) { _motionAddStroke(st.gc, rgb, (prim.strokeWidth || 6) * s); }
        else { var sfill = _motionAddFill(st.gc, rgb); if (prim.glass) _motionApplyGlass(st.gc, sfill); }
        _motionPlace(st.layer, cx, cy, prim.rot, op);
        _motionGlow(st.layer, prim.glow, prim.glowColor);
        return;
    }

    if (kind === "line") {
        var ln = _motionNewShape(comp, "Line");
        var pathProp = ln.gc.addProperty("ADBE Vector Shape - Group");
        var shp = new Shape();
        shp.vertices = [[-w / 2, 0], [w / 2, 0]];
        shp.inTangents = [[0, 0], [0, 0]];
        shp.outTangents = [[0, 0], [0, 0]];
        shp.closed = false;
        pathProp.property("ADBE Vector Shape").setValue(shp);
        _motionAddStroke(ln.gc, rgb, (prim.strokeWidth || h || 6) * s);
        _motionPlace(ln.layer, cx, cy, prim.rot, op);
        _motionGlow(ln.layer, prim.glow, prim.glowColor);
        return;
    }

    // default: rect (com roundness)
    var rc = _motionNewShape(comp, "Rect");
    var rect = rc.gc.addProperty("ADBE Vector Shape - Rect");
    rect.property("ADBE Vector Rect Size").setValue([w, h]);
    var rad = (prim.radius || 0) * s;
    if (prim.radius === "pill") rad = Math.min(w, h) / 2;
    try { rect.property("ADBE Vector Rect Roundness").setValue(rad); } catch (e6) {}
    if (prim.neon) { _motionApplyNeon(rc.gc, neonRgb); }
    else if (prim.stroke) { _motionAddStroke(rc.gc, rgb, (prim.strokeWidth || 6) * s); }
    else { var rfill = _motionAddFill(rc.gc, rgb); if (prim.glass) _motionApplyGlass(rc.gc, rfill); }
    _motionPlace(rc.layer, cx, cy, prim.rot, op);
    _motionGlow(rc.layer, prim.glow, prim.glowColor);
}

function buildMotionScene(jsonStr) {
    try {
        var data = eval("(" + jsonStr + ")");
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) return "Selecione uma composição";
        if (!data.prims || data.prims.length === 0) return "Nada para criar";

        var sx = comp.width / data.canvasW;
        var sy = comp.height / data.canvasH;

        app.beginUndoGroup("MT: Motion Scene (" + data.prims.length + " elementos)");
        for (var i = 0; i < data.prims.length; i++) {
            try { _motionBuildPrim(comp, data.prims[i], sx, sy); } catch (ePrim) {}
        }
        app.endUndoGroup();
        return "true";
    } catch (e) {
        return "Erro: " + e.toString();
    }
}
