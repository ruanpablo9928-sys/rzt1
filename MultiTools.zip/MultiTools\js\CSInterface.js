/**
 * CSInterface - Adobe CEP Interface Library v11.2
 * Source: Adobe-CEP/CEP-Resources (CEP_11.x)
 * 
 * Provides communication bridge between HTML panel and host application.
 * The underlying __adobe_cep__ object is injected by CEP runtime.
 */

/* jshint -W079 */
"use strict";

// ─── Constants ────────────────────────────────────────────────────────
var EvalScript_ErrMessage = "EvalScript error.";

// ─── SystemPath ─────────────────────────────────────────────────────
var SystemPath = {
    USER_DATA: "userData",
    COMMON_FILES: "commonFiles",
    MY_DOCUMENTS: "myDocuments",
    APPLICATION: "application",
    EXTENSION: "extension",
    HOST_APPLICATION: "hostApplication"
};

// ─── ColorType ──────────────────────────────────────────────────────
var ColorType = {
    CYCLIC_TYPE_NONE: 0,
    CYCLIC_TYPE_SOLID: 1,
    CYCLIC_TYPE_LINEAR: 2,
    CYCLIC_TYPE_RADIAL: 3
};

// ─── Data Classes ───────────────────────────────────────────────────

function RGBColor(red, green, blue, alpha) {
    this.red = red || 0;
    this.green = green || 0;
    this.blue = blue || 0;
    this.alpha = alpha || 255;
}

function Direction(x, y) {
    this.x = x || 0;
    this.y = y || 0;
}

function GradientStop(offset, rgbColor) {
    this.offset = offset;
    this.rgbColor = rgbColor;
}

function GradientColor(type, direction, numStops, gradientStops) {
    this.type = type;
    this.direction = direction;
    this.numStops = numStops;
    this.gradientStops = gradientStops;
}

function UIColor(type, antialiasLevel, color) {
    this.type = type;
    this.antialiasLevel = antialiasLevel;
    this.color = color;
}

function AppSkinInfo(baseFontFamily, baseFontSize, appBarBackgroundColor,
    panelBackgroundColor, appBarBackgroundColorSRGB,
    panelBackgroundColorSRGB, systemHighlightColor) {
    this.baseFontFamily = baseFontFamily;
    this.baseFontSize = baseFontSize;
    this.appBarBackgroundColor = appBarBackgroundColor;
    this.panelBackgroundColor = panelBackgroundColor;
    this.appBarBackgroundColorSRGB = appBarBackgroundColorSRGB;
    this.panelBackgroundColorSRGB = panelBackgroundColorSRGB;
    this.systemHighlightColor = systemHighlightColor;
}

function HostEnvironment(appName, appVersion, appLocale, appUILocale,
    appId, isAppOnline, appSkinInfo) {
    this.appName = appName;
    this.appVersion = appVersion;
    this.appLocale = appLocale;
    this.appUILocale = appUILocale;
    this.appId = appId;
    this.isAppOnline = isAppOnline;
    this.appSkinInfo = appSkinInfo;
}

function HostCapabilities(EXTENDED_PANEL_MENU, EXTENDED_PANEL_ICONS,
    DELEGATE_APE_ENGINE) {
    this.EXTENDED_PANEL_MENU = EXTENDED_PANEL_MENU;
    this.EXTENDED_PANEL_ICONS = EXTENDED_PANEL_ICONS;
    this.DELEGATE_APE_ENGINE = DELEGATE_APE_ENGINE;
}

function ApiVersion(major, minor, micro) {
    this.major = major;
    this.minor = minor;
    this.micro = micro;
}

function MenuItemStatus(menuItemLabel, enabled, checked) {
    this.menuItemLabel = menuItemLabel;
    this.enabled = enabled;
    this.checked = checked;
}

function ContextMenuItemStatus(menuItemID, enabled, checked) {
    this.menuItemID = menuItemID;
    this.enabled = enabled;
    this.checked = checked;
}

// ─── CSEvent ────────────────────────────────────────────────────────

function CSEvent(type, scope, appId, extensionId) {
    this.type = type;
    this.scope = scope;
    this.appId = appId;
    this.extensionId = extensionId;
    this.data = "";
}

CSEvent.CYCLIC_EVENT_CYCLIC = "cyclic";

// ─── CSInterface ────────────────────────────────────────────────────

function CSInterface() { }

/**
 * Retrieves information about the host environment.
 * @return {HostEnvironment}
 */
CSInterface.prototype.getHostEnvironment = function () {
    var env = window.__adobe_cep__.getHostEnvironment();
    return JSON.parse(env);
};

/**
 * Closes this extension.
 */
CSInterface.prototype.closeExtension = function () {
    window.__adobe_cep__.closeExtension();
};

/**
 * Retrieves a system path.
 * @param {string} pathType - One of SystemPath constants.
 * @return {string} The path.
 */
CSInterface.prototype.getSystemPath = function (pathType) {
    var path = decodeURI(window.__adobe_cep__.getSystemPath(pathType));
    var os = this.getOSInformation();
    if (os.indexOf("Windows") >= 0) {
        path = path.replace("file:///", "");
    } else if (os.indexOf("Mac") >= 0) {
        path = path.replace("file://", "");
    }
    return path;
};

/**
 * Evaluates a JavaScript script in the host application's scripting engine.
 * @param {string} script - The ExtendScript to evaluate.
 * @param {function} [callback] - Receives the result string.
 */
CSInterface.prototype.evalScript = function (script, callback) {
    if (callback === null || callback === undefined) {
        callback = function (result) { };
    }
    window.__adobe_cep__.evalScript(script, callback);
};

/**
 * Retrieves the unique application identifier.
 * @return {string}
 */
CSInterface.prototype.getApplicationID = function () {
    var appId = this.getHostEnvironment().appId;
    return appId;
};

/**
 * Retrieves host capability information.
 * @return {HostCapabilities}
 */
CSInterface.prototype.getHostCapabilities = function () {
    var OnLine = this.getHostEnvironment().isAppOnline;
    return OnLine;
};

/**
 * Dispatches a CEP event.
 * @param {CSEvent} event
 */
CSInterface.prototype.dispatchEvent = function (event) {
    if (typeof event.data === "object") {
        event.data = JSON.stringify(event.data);
    }
    window.__adobe_cep__.dispatchEvent(event);
};

/**
 * Registers an event listener.
 * @param {string} type - The event type.
 * @param {function} listener - The event handler.
 * @param {object} [obj] - Optional listener context.
 */
CSInterface.prototype.addEventListener = function (type, listener, obj) {
    window.__adobe_cep__.addEventListener(type, listener, obj);
};

/**
 * Removes a registered event listener.
 * @param {string} type
 * @param {function} listener
 * @param {object} [obj]
 */
CSInterface.prototype.removeEventListener = function (type, listener, obj) {
    window.__adobe_cep__.removeEventListener(type, listener, obj);
};

/**
 * Launches another extension.
 * @param {string} extensionId
 * @param {string} [startUrl]
 */
CSInterface.prototype.requestOpenExtension = function (extensionId, startUrl) {
    window.__adobe_cep__.requestOpenExtension(extensionId, startUrl);
};

/**
 * Retrieves the list of loaded extensions.
 * @param {string[]} [extensionIds]
 * @return {object[]}
 */
CSInterface.prototype.getExtensions = function (extensionIds) {
    var extensionIdsStr = JSON.stringify(extensionIds);
    var extensionsStr = window.__adobe_cep__.getExtensions(extensionIdsStr);
    return JSON.parse(extensionsStr);
};

/**
 * Retrieves network preferences.
 * @return {object}
 */
CSInterface.prototype.getNetworkPreferences = function () {
    return JSON.parse(window.__adobe_cep__.getNetworkPreferences());
};

/**
 * Initializes the resource bundle for localization.
 * @return {object}
 */
CSInterface.prototype.initResourceBundle = function () {
    var resourceBundle = JSON.parse(window.__adobe_cep__.initResourceBundle());
    var resElms = document.querySelectorAll("[data-locale]");
    for (var n = 0; n < resElms.length; n++) {
        var resEl = resElms[n];
        var resKey = resEl.getAttribute("data-locale");
        if (resKey && resourceBundle[resKey]) {
            resEl.innerHTML = resourceBundle[resKey];
        }
    }
    return resourceBundle;
};

/**
 * Writes installation info to a file.
 * @return {string}
 */
CSInterface.prototype.dumpInstallationInfo = function () {
    return window.__adobe_cep__.dumpInstallationInfo();
};

/**
 * Retrieves OS information.
 * @return {string} "Windows", "Mac", or "Unknown"
 */
CSInterface.prototype.getOSInformation = function () {
    var ua = navigator.userAgent;
    if (ua.indexOf("Windows") >= 0) return "Windows";
    if (ua.indexOf("Mac") >= 0) return "Mac";
    return "Unknown";
};

/**
 * Opens a URL in the default browser.
 * @param {string} url
 */
CSInterface.prototype.openURLInDefaultBrowser = function (url) {
    cep.util.openURLInDefaultBrowser(url);
};

/**
 * Retrieves the extension ID.
 * @return {string}
 */
CSInterface.prototype.getExtensionID = function () {
    return window.__adobe_cep__.getExtensionId();
};

/**
 * Retrieves the display scale factor.
 * @return {number}
 */
CSInterface.prototype.getScaleFactor = function () {
    return window.__adobe_cep__.getScaleFactor();
};

/**
 * Sets a handler for scale factor changes.
 * @param {function} handler
 */
CSInterface.prototype.setScaleFactorChangedHandler = function (handler) {
    window.__adobe_cep__.setScaleFactorChangedHandler(handler);
};

/**
 * Retrieves current API version.
 * @return {ApiVersion}
 */
CSInterface.prototype.getCurrentApiVersion = function () {
    return JSON.parse(window.__adobe_cep__.getCurrentApiVersion());
};

/**
 * Sets the panel flyout menu.
 * @param {string} menu - XML string defining the menu.
 */
CSInterface.prototype.setPanelFlyoutMenu = function (menu) {
    if (menu) {
        window.__adobe_cep__.invokeSync("setPanelFlyoutMenu", menu);
    }
};

/**
 * Updates a flyout menu item.
 * @param {string} menuItemLabel
 * @param {boolean} enabled
 * @param {boolean} checked
 * @return {MenuItemStatus}
 */
CSInterface.prototype.updatePanelMenuItem = function (menuItemLabel, enabled, checked) {
    return new MenuItemStatus(menuItemLabel, enabled, checked);
};

/**
 * Sets a context menu.
 * @param {string} menu - XML string defining the menu.
 * @param {function} callback
 */
CSInterface.prototype.setContextMenu = function (menu, callback) {
    if (menu) {
        window.__adobe_cep__.invokeAsync("setContextMenu", menu, callback);
    }
};

/**
 * Sets a context menu by JSON string.
 * @param {string} menu
 * @param {function} callback
 */
CSInterface.prototype.setContextMenuByJSON = function (menu, callback) {
    if (menu) {
        window.__adobe_cep__.invokeAsync("setContextMenuByJSON", menu, callback);
    }
};

/**
 * Checks if the extension window is visible.
 * @return {boolean}
 */
CSInterface.prototype.isWindowVisible = function () {
    return window.__adobe_cep__.invokeSync("isWindowVisible", "");
};

/**
 * Resizes the extension content.
 * @param {number} width
 * @param {number} height
 */
CSInterface.prototype.resizeContent = function (width, height) {
    window.__adobe_cep__.resizeContent(width, height);
};

/**
 * Registers an invalid certificate callback.
 * @param {function} callback
 */
CSInterface.prototype.registerInvalidCertificateCallback = function (callback) {
    return window.__adobe_cep__.registerInvalidCertificateCallback(callback);
};

/**
 * Registers key events interest.
 * @param {string} keyEventsInterest - JSON string of key event descriptors.
 */
CSInterface.prototype.registerKeyEventsInterest = function (keyEventsInterest) {
    return window.__adobe_cep__.registerKeyEventsInterest(keyEventsInterest);
};

/**
 * Sets the extension window title.
 * @param {string} title
 */
CSInterface.prototype.setWindowTitle = function (title) {
    window.__adobe_cep__.invokeSync("setWindowTitle", title);
};

/**
 * Gets the extension window title.
 * @return {string}
 */
CSInterface.prototype.getWindowTitle = function () {
    return window.__adobe_cep__.invokeSync("getWindowTitle", "");
};

// ─── Theme Management ───────────────────────────────────────────────

/**
 * Converts a color value (0-255) to two-digit hex.
 * @param {number} d - The color value.
 * @return {string}
 */
CSInterface.prototype.toHex = function (d) {
    var hex = Math.round(d).toString(16);
    return hex.length === 1 ? "0" + hex : hex;
};

/**
 * Extracts the panel background color from AppSkinInfo as a hex string.
 * @param {AppSkinInfo} appSkinInfo
 * @return {string} "#RRGGBB" format
 */
CSInterface.prototype.getColorFromSkinInfo = function (appSkinInfo) {
    var panelBgColor = appSkinInfo.panelBackgroundColor.color;
    return "#" + this.toHex(panelBgColor.red)
        + this.toHex(panelBgColor.green)
        + this.toHex(panelBgColor.blue);
};

// ─── Thememanager ───────────────────────────────────────────────────

/**
 * Applies the host app theme to the extension panel.
 * Call this on startup and whenever the theme changes.
 */
CSInterface.prototype.updateThemeWithAppSkinInfo = function (appSkinInfo) {
    var panelBgColor = appSkinInfo.panelBackgroundColor.color;
    var darkBg = (panelBgColor.red + panelBgColor.green + panelBgColor.blue) / 3 < 128;
    var textColor = darkBg ? "#e0e0e0" : "#333333";
    var bgColor = "#" + this.toHex(panelBgColor.red)
        + this.toHex(panelBgColor.green)
        + this.toHex(panelBgColor.blue);

    document.body.style.backgroundColor = bgColor;
    document.body.style.color = textColor;
};
