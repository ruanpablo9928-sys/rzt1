(function() {
    // ╔═════════════════════════════════════════════════════════════╗
    // ║  HYPNOTIC RING LOOP — ESTILO MOSS AND FOG (BLINDADO)        ║
    // ║  1080x1920 @ 30fps — 6.0s Loop Perfeito                     ║
    // ║  Resolvido erro de Objeto Inválido na árvore de vetores     ║
    // ╚═════════════════════════════════════════════════════════════╝

    var AE = {};
    AE.gc = function(p, ns) { var c = p; for (var i=0; i<ns.length; i++) { try { c = c.property(ns[i]); } catch(e) { return null; } if (!c) return null; } return c; };
    AE.pos = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Position"]) : null; };
    AE.scl = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Scale"]) : null; };
    AE.opa = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Opacity"]) : null; };
    AE.rot = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Rotate Z"]) : null; };
    AE.sv = function(p, v) { if (!p) return; try { p.setValue(v); } catch(e) {} };
    AE.sa = function(p, t, v) { if (!p) return; try { p.setValueAtTime(t, v); } catch(e) {} };
    AE.gv = function(p) { if (!p) return null; try { return p.value; } catch(e) { return null; } };
    AE.hex = function(h) { h = h.replace("#", ""); return [parseInt(h.substr(0,2),16)/255, parseInt(h.substr(2,2),16)/255, parseInt(h.substr(4,2),16)/255]; };

    // --- CURVA MANTEIGA EXTREMA (100% INFLUÊNCIA) ---
    AE.maxEase = function(p) {
        if (!p || p.numKeys === 0) return;
        try {
            var d = 1, v = p.propertyValueType;
            if (v === PropertyValueType.TwoD || v === PropertyValueType.TwoD_SPATIAL) d = 2;
            if (v === PropertyValueType.ThreeD || v === PropertyValueType.ThreeD_SPATIAL) d = 3;
            for (var k = 1; k <= p.numKeys; k++) {
                var ei = [], eo = [];
                for (var j = 0; j < d; j++) { ei.push(new KeyframeEase(0, 100)); eo.push(new KeyframeEase(0, 100)); }
                p.setTemporalEaseAtKey(k, ei, eo);
            }
        } catch(e) {}
    };

    function mkSolid(comp, cor, nome) { try { return comp.layers.addSolid(cor, nome, comp.width, comp.height, 1); } catch(e) { return null; } }

    // --- A MÁGICA SEGURA: O ANEL REPLICADOR BLINDADO ---
    function mkSplittingRing(comp, centerPos, color, name) {
        try {
            var s = comp.layers.addShape(); s.name = name || "Ring_System";
            var rootVec = s.property("ADBE Root Vectors Group");
            
            // 1. Cria a estrutura
            var grp = rootVec.addProperty("ADBE Vector Group");
            var vec = grp.property("ADBE Vectors Group");

            var el = vec.addProperty("ADBE Vector Shape - Ellipse");
            var st = vec.addProperty("ADBE Vector Graphic - Stroke");
            st.property("ADBE Vector Stroke Color").setValue(color);
            st.property("ADBE Vector Stroke Line Cap").setValue(2); 

            var rep = rootVec.addProperty("ADBE Vector Filter - Repeater");
            rep.property("ADBE Vector Repeater Transform").property("ADBE Vector Repeater Position").setValue([0, 0]); 

            AE.sv(AE.pos(s), centerPos);

            // 2. O SEGREDO: Vamos buscar as referências DEPOIS de adicionar o Repeater.
            // Assim garantimos que o After Effects não devolve um "Objeto Inválido".
            var p_elSize = AE.gc(s, ["ADBE Root Vectors Group", "ADBE Vector Group", "ADBE Vectors Group", "ADBE Vector Shape - Ellipse", "ADBE Vector Ellipse Size"]);
            var p_elPos = AE.gc(s, ["ADBE Root Vectors Group", "ADBE Vector Group", "ADBE Vectors Group", "ADBE Vector Shape - Ellipse", "ADBE Vector Ellipse Position"]);
            var p_stW = AE.gc(s, ["ADBE Root Vectors Group", "ADBE Vector Group", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Width"]);
            var p_repCopies = AE.gc(s, ["ADBE Root Vectors Group", "ADBE Vector Filter - Repeater", "ADBE Vector Repeater Copies"]);
            var p_repRot = AE.gc(s, ["ADBE Root Vectors Group", "ADBE Vector Filter - Repeater", "ADBE Vector Repeater Transform", "ADBE Vector Repeater Rotation"]);

            return {
                layer: s,
                elSize: p_elSize,
                elPos: p_elPos,   
                stW: p_stW,       
                repCopies: p_repCopies, 
                repRot: p_repRot,       
                grpRot: AE.rot(s)     
            };
        } catch(e) { return null; }
    }

    app.beginUndoGroup("Moss and Fog Loop (Corrigido)");

    try {
        var comp = app.project.items.addComp("Hypnotic_Ring_Loop_Fix", 1080, 1920, 1, 6.0, 30);
        
        // Motion Blur Extremo Ativado
        comp.shutterAngle = 360; 
        comp.motionBlur = true;  

        var cBg = AE.hex("#F2F2F2"); 
        var cRing = AE.hex("#1A1A1A"); 

        mkSolid(comp, cBg, "Background_Cinza");

        // Cria o nosso sistema avançado de anéis usando as referências blindadas
        var ringSys = mkSplittingRing(comp, [540, 960], cRing, "Anel_Hipnotico");
        
        if (ringSys) {
            ringSys.layer.motionBlur = true;

            // ─────────────────────────────────────
            // A COREOGRAFIA (6 Segundos em Loop)
            // ─────────────────────────────────────
            
            // ETAPA 1: Estado Inicial (1 Círculo Grande)
            AE.sa(ringSys.elSize, 0.0, [300, 300]);
            AE.sa(ringSys.elPos,  0.0, [0, 0]);
            AE.sa(ringSys.stW,    0.0, 25);
            AE.sa(ringSys.repCopies, 0.0, 1);
            AE.sa(ringSys.repRot, 0.0, 360);

            // ETAPA 2: A Primeira Divisão (2 Círculos)
            AE.sa(ringSys.elSize, 0.8, [180, 180]);
            AE.sa(ringSys.elPos,  0.8, [0, -180]); 
            AE.sa(ringSys.stW,    0.8, 30);
            AE.sa(ringSys.repCopies, 0.8, 2);
            AE.sa(ringSys.repRot, 0.8, 180); 

            // ETAPA 3: A Multiplicação (8 Círculos formando o arco)
            AE.sa(ringSys.elSize, 1.8, [65, 65]);
            AE.sa(ringSys.elPos,  1.8, [0, -320]);
            AE.sa(ringSys.stW,    1.8, 35);
            AE.sa(ringSys.repCopies, 1.8, 8);
            AE.sa(ringSys.repRot, 1.8, 45); 

            // ETAPA 4: O GIRO HIPNÓTICO
            AE.sa(ringSys.grpRot, 1.8, 0);
            AE.sa(ringSys.grpRot, 4.2, 1080); 

            // ETAPA 5: A Fusão Reversa (Volta para 2 Círculos)
            AE.sa(ringSys.elSize, 4.2, [65, 65]);
            AE.sa(ringSys.elPos,  4.2, [0, -320]);
            AE.sa(ringSys.stW,    4.2, 35);
            AE.sa(ringSys.repCopies, 4.2, 8);
            AE.sa(ringSys.repRot, 4.2, 45);

            AE.sa(ringSys.elSize, 5.0, [180, 180]);
            AE.sa(ringSys.elPos,  5.0, [0, -180]);
            AE.sa(ringSys.stW,    5.0, 30);
            AE.sa(ringSys.repCopies, 5.0, 2);
            AE.sa(ringSys.repRot, 5.0, 180);

            // ETAPA 6: O Fecho Perfeito (1 Círculo Grande)
            AE.sa(ringSys.elSize, 6.0, [300, 300]);
            AE.sa(ringSys.elPos,  6.0, [0, 0]);
            AE.sa(ringSys.stW,    6.0, 25);
            AE.sa(ringSys.repCopies, 6.0, 1);
            AE.sa(ringSys.repRot, 6.0, 360);

            // Aplica a Curva Manteiga em Tudo
            AE.maxEase(ringSys.elSize);
            AE.maxEase(ringSys.elPos);
            AE.maxEase(ringSys.stW);
            AE.maxEase(ringSys.repCopies);
            AE.maxEase(ringSys.repRot);
            AE.maxEase(ringSys.grpRot);
        }

        alert("Mágica Concluída Sem Erros! 🎯\n\n- Estrutura de Repeater isolada e blindada.\n- As 8 bolinhas vão esticar-se nativamente devido ao Motion Blur e Shutter Angle.\n\nDê Play para assistir ao loop Moss and Fog perfeito!");

    } catch(e) {
        alert("Erro fatal: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();