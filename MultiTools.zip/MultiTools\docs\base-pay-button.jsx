(function() {
    // ╔══════════════════════════════════════════════════════════════════╗
    // ║  PAY BUTTON INTERACTION LOOP — After Effects 2019 (v16.x)       ║
    // ║  720x720 @ 30fps — 11.0s Loop                                   ║
    // ║  Recriação: Botão PAY → Face ID → COMPLETE → Loop               ║
    // ║  BLINDADO: Todas as refs buscadas por caminho completo           ║
    // ╚══════════════════════════════════════════════════════════════════╝

    // ===== UTILIDADES =====
    var H = {};
    H.hex = function(h) {
        h = h.replace("#", "");
        return [
            parseInt(h.substr(0, 2), 16) / 255,
            parseInt(h.substr(2, 2), 16) / 255,
            parseInt(h.substr(4, 2), 16) / 255
        ];
    };

    H.sv = function(p, v) { if (p) try { p.setValue(v); } catch(e) {} };
    H.sa = function(p, t, v) { if (p) try { p.setValueAtTime(t, v); } catch(e) {} };

    H.gc = function(parent, names) {
        var c = parent;
        for (var i = 0; i < names.length; i++) {
            try { c = c.property(names[i]); } catch(e) { return null; }
            if (!c) return null;
        }
        return c;
    };

    H.easeKeys = function(p, influence) {
        if (!p || p.numKeys === 0) return;
        var inf = influence || 75;
        try {
            var d = 1, v = p.propertyValueType;
            if (v === PropertyValueType.TwoD || v === PropertyValueType.TwoD_SPATIAL) d = 2;
            if (v === PropertyValueType.ThreeD || v === PropertyValueType.ThreeD_SPATIAL) d = 3;
            for (var k = 1; k <= p.numKeys; k++) {
                var ei = [], eo = [];
                for (var j = 0; j < d; j++) {
                    ei.push(new KeyframeEase(0, inf));
                    eo.push(new KeyframeEase(0, inf));
                }
                p.setTemporalEaseAtKey(k, ei, eo);
            }
        } catch(e) {}
    };

    H.pos = function(l) { return l ? H.gc(l, ["ADBE Transform Group", "ADBE Position"]) : null; };
    H.scl = function(l) { return l ? H.gc(l, ["ADBE Transform Group", "ADBE Scale"]) : null; };
    H.opa = function(l) { return l ? H.gc(l, ["ADBE Transform Group", "ADBE Opacity"]) : null; };
    H.rot = function(l) { return l ? H.gc(l, ["ADBE Transform Group", "ADBE Rotate Z"]) : null; };

    // ===== CORES =====
    var cBg      = H.hex("#D6EDF5");
    var cButton  = H.hex("#B8A5E6");
    var cBtnDark = H.hex("#9B8AD4");
    var cWhite   = [1, 1, 1];
    var cBlack   = [0, 0, 0];

    // ===== TIMING =====
    var T = {
        payIdle:     0.0,
        cursorUp:    1.5,
        clickStart:  2.0,
        shrinkStart: 2.2,
        shrinkEnd:   3.0,
        faceIn:      3.2,
        scanStart:   3.5,
        scanEnd:     5.5,
        expandStart: 6.0,
        expandEnd:   7.0,
        completeIn:  7.2,
        completeIdle:8.5,
        resetStart:  9.0,
        resetEnd:    10.0,
        payBack:     10.2,
        duration:    11.0
    };

    // ===== HELPER: Cria shape layer com rect arredondado (BLINDADO) =====
    function mkRoundRect(comp, color, nome) {
        var s = comp.layers.addShape();
        s.name = nome;
        var root = s.property("ADBE Root Vectors Group");
        var grp = root.addProperty("ADBE Vector Group");
        var vecs = grp.property("ADBE Vectors Group");
        // Adiciona TUDO primeiro
        vecs.addProperty("ADBE Vector Shape - Rect");
        vecs.addProperty("ADBE Vector Graphic - Fill");

        // AGORA busca as referências pelo caminho completo (BLINDADO)
        var p_size = H.gc(s, ["ADBE Root Vectors Group", "ADBE Vector Group", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Size"]);
        var p_round = H.gc(s, ["ADBE Root Vectors Group", "ADBE Vector Group", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Roundness"]);
        var p_fill = H.gc(s, ["ADBE Root Vectors Group", "ADBE Vector Group", "ADBE Vectors Group", "ADBE Vector Graphic - Fill", "ADBE Vector Fill Color"]);

        H.sv(p_fill, color);

        return { layer: s, size: p_size, round: p_round };
    }

    app.beginUndoGroup("Pay Button Animation Loop v2");

    try {
        var comp = app.project.items.addComp("PayButton_Loop", 720, 720, 1, T.duration, 30);
        var cx = 360, cy = 340;

        // ===== 1. BACKGROUND =====
        comp.layers.addSolid(cBg, "Background", 720, 720, 1);

        // ===== 2. SOMBRA DO BOTÃO =====
        var sh = mkRoundRect(comp, cBtnDark, "Button_Shadow");
        H.sv(H.pos(sh.layer), [cx, cy + 8]);
        H.sv(H.opa(sh.layer), 50);

        H.sa(sh.size, T.payIdle,     [380, 120]);
        H.sa(sh.size, T.shrinkStart, [380, 120]);
        H.sa(sh.size, T.shrinkEnd,   [130, 130]);
        H.sa(sh.size, T.expandStart, [130, 130]);
        H.sa(sh.size, T.expandEnd,   [380, 120]);
        H.sa(sh.size, T.resetEnd,    [380, 120]);

        H.sa(sh.round, T.payIdle,     60);
        H.sa(sh.round, T.shrinkStart, 60);
        H.sa(sh.round, T.shrinkEnd,   65);
        H.sa(sh.round, T.expandStart, 65);
        H.sa(sh.round, T.expandEnd,   60);

        H.easeKeys(sh.size, 80);
        H.easeKeys(sh.round, 80);

        // ===== 3. BOTÃO PRINCIPAL =====
        var btn = mkRoundRect(comp, cButton, "Button_Body");
        H.sv(H.pos(btn.layer), [cx, cy]);

        H.sa(btn.size, T.payIdle,      [380, 120]);
        H.sa(btn.size, T.shrinkStart,  [380, 120]);
        H.sa(btn.size, T.shrinkEnd,    [130, 130]);
        H.sa(btn.size, T.expandStart,  [130, 130]);
        H.sa(btn.size, T.expandEnd,    [380, 120]);
        H.sa(btn.size, T.resetEnd,     [380, 120]);

        H.sa(btn.round, T.payIdle,     60);
        H.sa(btn.round, T.shrinkStart, 60);
        H.sa(btn.round, T.shrinkEnd,   65);
        H.sa(btn.round, T.expandStart, 65);
        H.sa(btn.round, T.expandEnd,   60);

        H.easeKeys(btn.size, 80);
        H.easeKeys(btn.round, 80);

        // ===== 4. ÍCONE DO CARTÃO =====
        var cardLayer = comp.layers.addShape();
        cardLayer.name = "Card_Icon";
        var cRoot = cardLayer.property("ADBE Root Vectors Group");

        // Corpo do cartão
        var cG1 = cRoot.addProperty("ADBE Vector Group");
        cG1.name = "Card_Outline";
        var cV1 = cG1.property("ADBE Vectors Group");
        cV1.addProperty("ADBE Vector Shape - Rect");
        cV1.addProperty("ADBE Vector Graphic - Stroke");

        // BLINDADO: busca refs após adicionar tudo ao grupo
        var p_cardRectSize = H.gc(cardLayer, ["ADBE Root Vectors Group", "Card_Outline", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Size"]);
        var p_cardRectRound = H.gc(cardLayer, ["ADBE Root Vectors Group", "Card_Outline", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Roundness"]);
        var p_cardStrokeColor = H.gc(cardLayer, ["ADBE Root Vectors Group", "Card_Outline", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Color"]);
        var p_cardStrokeW = H.gc(cardLayer, ["ADBE Root Vectors Group", "Card_Outline", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Width"]);

        H.sv(p_cardRectSize, [52, 38]);
        H.sv(p_cardRectRound, 6);
        H.sv(p_cardStrokeColor, cWhite);
        H.sv(p_cardStrokeW, 2.5);

        // Tarja magnética
        var cG2 = cRoot.addProperty("ADBE Vector Group");
        cG2.name = "Card_Stripe";
        var cV2 = cG2.property("ADBE Vectors Group");
        cV2.addProperty("ADBE Vector Shape - Rect");
        cV2.addProperty("ADBE Vector Graphic - Stroke");

        var p_stripeSize = H.gc(cardLayer, ["ADBE Root Vectors Group", "Card_Stripe", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Size"]);
        var p_stripePos = H.gc(cardLayer, ["ADBE Root Vectors Group", "Card_Stripe", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Position"]);
        var p_stripeSC = H.gc(cardLayer, ["ADBE Root Vectors Group", "Card_Stripe", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Color"]);
        var p_stripeSW = H.gc(cardLayer, ["ADBE Root Vectors Group", "Card_Stripe", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Width"]);

        H.sv(p_stripeSize, [42, 8]);
        H.sv(p_stripePos, [0, -6]);
        H.sv(p_stripeSC, cWhite);
        H.sv(p_stripeSW, 2);

        // Chip
        var cG3 = cRoot.addProperty("ADBE Vector Group");
        cG3.name = "Card_Chip";
        var cV3 = cG3.property("ADBE Vectors Group");
        cV3.addProperty("ADBE Vector Shape - Rect");
        cV3.addProperty("ADBE Vector Graphic - Stroke");

        var p_chipSize = H.gc(cardLayer, ["ADBE Root Vectors Group", "Card_Chip", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Size"]);
        var p_chipPos = H.gc(cardLayer, ["ADBE Root Vectors Group", "Card_Chip", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Position"]);
        var p_chipRound = H.gc(cardLayer, ["ADBE Root Vectors Group", "Card_Chip", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Roundness"]);
        var p_chipSC = H.gc(cardLayer, ["ADBE Root Vectors Group", "Card_Chip", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Color"]);
        var p_chipSW = H.gc(cardLayer, ["ADBE Root Vectors Group", "Card_Chip", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Width"]);

        H.sv(p_chipSize, [14, 10]);
        H.sv(p_chipPos, [-12, 8]);
        H.sv(p_chipRound, 2);
        H.sv(p_chipSC, cWhite);
        H.sv(p_chipSW, 2);

        H.sv(H.pos(cardLayer), [cx - 60, cy]);

        // Opacidade do cartão
        var p_cardOpa = H.opa(cardLayer);
        H.sa(p_cardOpa, T.payIdle,             100);
        H.sa(p_cardOpa, T.shrinkStart,         100);
        H.sa(p_cardOpa, T.shrinkStart + 0.3,   0);
        H.sa(p_cardOpa, T.resetEnd - 0.3,      0);
        H.sa(p_cardOpa, T.payBack,             100);
        H.easeKeys(p_cardOpa, 70);

        // ===== 5. TEXTO "PAY" =====
        var payText = comp.layers.addText("PAY");
        payText.name = "Text_PAY";
        var payDoc = payText.property("ADBE Text Properties").property("ADBE Text Document");
        var payTD = payDoc.value;
        payTD.fontSize = 36;
        payTD.fillColor = cWhite;
        try { payTD.font = "Arial-BoldMT"; } catch(e) { try { payTD.font = "ArialMT"; } catch(e2) {} }
        payTD.justification = ParagraphJustification.CENTER_JUSTIFY;
        payTD.tracking = 200;
        payDoc.setValue(payTD);

        H.sv(H.pos(payText), [cx + 40, cy + 12]);

        var p_payOpa = H.opa(payText);
        H.sa(p_payOpa, T.payIdle,           100);
        H.sa(p_payOpa, T.shrinkStart,       100);
        H.sa(p_payOpa, T.shrinkStart + 0.3, 0);
        H.sa(p_payOpa, T.resetEnd - 0.3,    0);
        H.sa(p_payOpa, T.payBack,           100);
        H.easeKeys(p_payOpa, 70);

        // ===== 6. FACE ID ICON =====
        var faceLayer = comp.layers.addShape();
        faceLayer.name = "FaceID_Icon";
        var fRoot = faceLayer.property("ADBE Root Vectors Group");

        // Função para criar traço (path aberto) BLINDADO
        function addStrokePath(rootProp, pts, nome, inTan, outTan, closed) {
            var g = rootProp.addProperty("ADBE Vector Group");
            g.name = nome;
            var vs = g.property("ADBE Vectors Group");
            vs.addProperty("ADBE Vector Shape - Group");
            vs.addProperty("ADBE Vector Graphic - Stroke");

            // BLINDADO: busca pelo nome do grupo
            var p_shape = H.gc(faceLayer, ["ADBE Root Vectors Group", nome, "ADBE Vectors Group", "ADBE Vector Shape - Group", "ADBE Vector Shape"]);
            var p_sColor = H.gc(faceLayer, ["ADBE Root Vectors Group", nome, "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Color"]);
            var p_sWidth = H.gc(faceLayer, ["ADBE Root Vectors Group", nome, "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Width"]);
            var p_sCap = H.gc(faceLayer, ["ADBE Root Vectors Group", nome, "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Line Cap"]);

            if (p_shape) {
                var shape = new Shape();
                shape.vertices = pts;
                if (inTan) shape.inTangents = inTan;
                if (outTan) shape.outTangents = outTan;
                shape.closed = closed || false;
                p_shape.setValue(shape);
            }
            H.sv(p_sColor, cWhite);
            H.sv(p_sWidth, 3);
            H.sv(p_sCap, 2); // Round cap
        }

        var sz = 22, cn = 10;

        // 4 cantos
        addStrokePath(fRoot, [[-sz, -sz + cn], [-sz, -sz], [-sz + cn, -sz]], "Corner_TL");
        addStrokePath(fRoot, [[sz - cn, -sz], [sz, -sz], [sz, -sz + cn]], "Corner_TR");
        addStrokePath(fRoot, [[-sz, sz - cn], [-sz, sz], [-sz + cn, sz]], "Corner_BL");
        addStrokePath(fRoot, [[sz - cn, sz], [sz, sz], [sz, sz - cn]], "Corner_BR");

        // Olhos
        addStrokePath(fRoot, [[-8, -6], [-8, -2]], "Eye_L");
        addStrokePath(fRoot, [[8, -6], [8, -2]], "Eye_R");

        // Nariz
        addStrokePath(fRoot, [[0, -1], [0, 6]], "Nose");

        // Boca (com curva)
        addStrokePath(fRoot,
            [[-10, 10], [0, 16], [10, 10]],
            "Mouth",
            [[0, 0], [-5, 0], [0, 0]],
            [[0, 0], [5, 0], [0, 0]],
            false
        );

        H.sv(H.pos(faceLayer), [cx, cy]);

        // Opacidade do Face ID
        var p_faceOpa = H.opa(faceLayer);
        H.sa(p_faceOpa, T.payIdle,              0);
        H.sa(p_faceOpa, T.shrinkEnd,            0);
        H.sa(p_faceOpa, T.faceIn,               100);
        H.sa(p_faceOpa, T.expandStart - 0.3,    100);
        H.sa(p_faceOpa, T.expandStart,          0);
        H.sa(p_faceOpa, T.duration,             0);
        H.easeKeys(p_faceOpa, 70);

        // Escala pulsante (scanning)
        var p_faceScl = H.scl(faceLayer);
        H.sa(p_faceScl, T.faceIn,           [80, 80]);
        H.sa(p_faceScl, T.faceIn + 0.3,     [100, 100]);
        H.sa(p_faceScl, T.scanStart,        [100, 100]);
        H.sa(p_faceScl, T.scanStart + 0.5,  [105, 105]);
        H.sa(p_faceScl, T.scanStart + 1.0,  [100, 100]);
        H.sa(p_faceScl, T.scanStart + 1.5,  [105, 105]);
        H.sa(p_faceScl, T.scanEnd,          [100, 100]);
        H.easeKeys(p_faceScl, 60);

        // ===== 7. LINHA DE SCAN =====
        var scanLayer = comp.layers.addShape();
        scanLayer.name = "Scan_Line";
        var scRoot = scanLayer.property("ADBE Root Vectors Group");
        var scGrp = scRoot.addProperty("ADBE Vector Group");
        scGrp.name = "ScanBar";
        var scVecs = scGrp.property("ADBE Vectors Group");
        scVecs.addProperty("ADBE Vector Shape - Rect");
        scVecs.addProperty("ADBE Vector Graphic - Fill");

        // BLINDADO
        var p_scSize = H.gc(scanLayer, ["ADBE Root Vectors Group", "ScanBar", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Size"]);
        var p_scRound = H.gc(scanLayer, ["ADBE Root Vectors Group", "ScanBar", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Roundness"]);
        var p_scFillC = H.gc(scanLayer, ["ADBE Root Vectors Group", "ScanBar", "ADBE Vectors Group", "ADBE Vector Graphic - Fill", "ADBE Vector Fill Color"]);

        H.sv(p_scSize, [40, 3]);
        H.sv(p_scRound, 2);
        H.sv(p_scFillC, cWhite);

        var p_scanPos = H.pos(scanLayer);
        H.sa(p_scanPos, T.scanStart,              [cx, cy - 20]);
        H.sa(p_scanPos, T.scanStart + 1.0,        [cx, cy + 20]);
        H.sa(p_scanPos, T.scanStart + 1.0 + 0.03, [cx, cy - 20]);
        H.sa(p_scanPos, T.scanEnd,                [cx, cy + 20]);
        H.easeKeys(p_scanPos, 50);

        var p_scanOpa = H.opa(scanLayer);
        H.sa(p_scanOpa, T.payIdle,         0);
        H.sa(p_scanOpa, T.scanStart,       0);
        H.sa(p_scanOpa, T.scanStart + 0.1, 60);
        H.sa(p_scanOpa, T.scanEnd - 0.1,   60);
        H.sa(p_scanOpa, T.scanEnd,         0);
        H.easeKeys(p_scanOpa, 50);

        // ===== 8. TEXTO "COMPLETE" =====
        var compText = comp.layers.addText("COMPLETE");
        compText.name = "Text_COMPLETE";
        var compDoc = compText.property("ADBE Text Properties").property("ADBE Text Document");
        var compTD = compDoc.value;
        compTD.fontSize = 32;
        compTD.fillColor = cWhite;
        try { compTD.font = "Arial-BoldMT"; } catch(e) { try { compTD.font = "ArialMT"; } catch(e2) {} }
        compTD.justification = ParagraphJustification.CENTER_JUSTIFY;
        compTD.tracking = 150;
        compDoc.setValue(compTD);

        H.sv(H.pos(compText), [cx, cy + 12]);

        var p_compOpa = H.opa(compText);
        H.sa(p_compOpa, T.payIdle,           0);
        H.sa(p_compOpa, T.expandEnd,         0);
        H.sa(p_compOpa, T.completeIn,        100);
        H.sa(p_compOpa, T.completeIdle,      100);
        H.sa(p_compOpa, T.resetStart,        100);
        H.sa(p_compOpa, T.resetStart + 0.3,  0);
        H.sa(p_compOpa, T.duration,          0);
        H.easeKeys(p_compOpa, 70);

        // ===== 9. CURSOR =====
        var cursorLayer = comp.layers.addShape();
        cursorLayer.name = "Cursor_Hand";
        var curRoot = cursorLayer.property("ADBE Root Vectors Group");
        var curGrp = curRoot.addProperty("ADBE Vector Group");
        curGrp.name = "Arrow";
        var curVecs = curGrp.property("ADBE Vectors Group");
        curVecs.addProperty("ADBE Vector Shape - Group");
        curVecs.addProperty("ADBE Vector Graphic - Fill");
        curVecs.addProperty("ADBE Vector Graphic - Stroke");

        // BLINDADO
        var p_curShape = H.gc(cursorLayer, ["ADBE Root Vectors Group", "Arrow", "ADBE Vectors Group", "ADBE Vector Shape - Group", "ADBE Vector Shape"]);
        var p_curFillC = H.gc(cursorLayer, ["ADBE Root Vectors Group", "Arrow", "ADBE Vectors Group", "ADBE Vector Graphic - Fill", "ADBE Vector Fill Color"]);
        var p_curStrokeC = H.gc(cursorLayer, ["ADBE Root Vectors Group", "Arrow", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Color"]);
        var p_curStrokeW = H.gc(cursorLayer, ["ADBE Root Vectors Group", "Arrow", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Width"]);

        var cShape = new Shape();
        cShape.vertices = [
            [0, 0], [0, 22], [6, 17], [11, 26],
            [15, 24], [10, 15], [18, 15]
        ];
        cShape.closed = true;
        H.sv(p_curShape, cShape);
        H.sv(p_curFillC, cBlack);
        H.sv(p_curStrokeC, cWhite);
        H.sv(p_curStrokeW, 1.5);

        // Animar posição
        var p_curPos = H.pos(cursorLayer);
        H.sa(p_curPos, T.payIdle,          [cx - 5, cy + 100]);
        H.sa(p_curPos, T.cursorUp,         [cx - 5, cy + 100]);
        H.sa(p_curPos, T.clickStart,       [cx - 5, cy + 10]);
        H.sa(p_curPos, T.clickStart + 0.1, [cx - 5, cy + 15]);
        H.sa(p_curPos, T.clickStart + 0.3, [cx - 5, cy + 10]);
        H.sa(p_curPos, T.shrinkEnd,        [cx - 5, cy + 100]);
        H.sa(p_curPos, T.duration,         [cx - 5, cy + 100]);
        H.easeKeys(p_curPos, 75);

        // Click scale
        var p_curScl = H.scl(cursorLayer);
        H.sa(p_curScl, T.payIdle,           [100, 100]);
        H.sa(p_curScl, T.clickStart,        [100, 100]);
        H.sa(p_curScl, T.clickStart + 0.05, [85, 85]);
        H.sa(p_curScl, T.clickStart + 0.15, [100, 100]);
        H.easeKeys(p_curScl, 60);

        // ===== 10. CLICK RIPPLE =====
        var rippleLayer = comp.layers.addShape();
        rippleLayer.name = "Click_Ripple";
        var rRoot = rippleLayer.property("ADBE Root Vectors Group");
        var rGrp = rRoot.addProperty("ADBE Vector Group");
        rGrp.name = "Ripple";
        var rVecs = rGrp.property("ADBE Vectors Group");
        rVecs.addProperty("ADBE Vector Shape - Ellipse");
        rVecs.addProperty("ADBE Vector Graphic - Stroke");

        // BLINDADO
        var p_ripSize = H.gc(rippleLayer, ["ADBE Root Vectors Group", "Ripple", "ADBE Vectors Group", "ADBE Vector Shape - Ellipse", "ADBE Vector Ellipse Size"]);
        var p_ripSC = H.gc(rippleLayer, ["ADBE Root Vectors Group", "Ripple", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Color"]);
        var p_ripSW = H.gc(rippleLayer, ["ADBE Root Vectors Group", "Ripple", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Width"]);

        H.sv(p_ripSC, cWhite);
        H.sv(p_ripSW, 2);
        H.sv(H.pos(rippleLayer), [cx, cy]);

        H.sa(p_ripSize, T.clickStart,       [10, 10]);
        H.sa(p_ripSize, T.clickStart + 0.4, [200, 200]);

        var p_ripOpa = H.opa(rippleLayer);
        H.sa(p_ripOpa, T.payIdle,          0);
        H.sa(p_ripOpa, T.clickStart,       60);
        H.sa(p_ripOpa, T.clickStart + 0.4, 0);
        H.sa(p_ripOpa, T.duration,         0);
        H.easeKeys(p_ripSize, 70);
        H.easeKeys(p_ripOpa, 70);

        // ===== REORDENAR LAYERS =====
        try {
            cursorLayer.moveToBeginning();
            rippleLayer.moveAfter(cursorLayer);
        } catch(e) {}

        // ===== MOTION BLUR =====
        comp.motionBlur = true;
        comp.shutterAngle = 180;
        btn.layer.motionBlur = true;
        sh.layer.motionBlur = true;

        alert("Animação criada com sucesso!\n\n" +
              "Composição: PayButton_Loop (720x720, 30fps, 11s)\n\n" +
              "1. Botão PAY com cartão\n" +
              "2. Cursor clica → encolhe para círculo\n" +
              "3. Face ID scan\n" +
              "4. Expande → COMPLETE\n" +
              "5. Volta para PAY (loop)\n\n" +
              "Dê Play para assistir!");

    } catch(e) {
        alert("Erro: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();
