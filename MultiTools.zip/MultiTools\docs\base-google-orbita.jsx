(function() {
    // ╔═════════════════════════════════════════════════════════════╗
    // ║  GOOGLE MOTION COMMERCIAL — DOTS TO LOGO                    ║
    // ║  1080x1920 @ 30fps — 7.0s                                   ║
    // ║  Orbit Rotation, Alignment, Pop out to Text                 ║
    // ╚═════════════════════════════════════════════════════════════╝

    var AE = {};
    AE.gc = function(p, ns) { var c = p; for (var i=0; i<ns.length; i++) { try { c = c.property(ns[i]); } catch(e) { return null; } if (!c) return null; } return c; };
    AE.pos = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Position"]) : null; };
    AE.scl = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Scale"]) : null; };
    AE.opa = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Opacity"]) : null; };
    AE.rot = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Rotate Z"]) : null; };
    AE.sv = function(p, v) { if (!p) return; try { p.setValue(v); } catch(e) {} };
    AE.sa = function(p, t, v) { if (!p) return; try { p.setValueAtTime(t, v); } catch(e) {} };
    AE.hex = function(h) { h = h.replace("#", ""); return [parseInt(h.substr(0,2),16)/255, parseInt(h.substr(2,2),16)/255, parseInt(h.substr(4,2),16)/255]; };
    
    // Curva Suave (Butter Ease - 95%)
    AE.smoothEase = function(p) {
        if (!p || p.numKeys === 0) return;
        try {
            var d = 1, v = p.propertyValueType;
            if (v === PropertyValueType.TwoD || v === PropertyValueType.TwoD_SPATIAL) d = 2;
            if (v === PropertyValueType.ThreeD || v === PropertyValueType.ThreeD_SPATIAL) d = 3;
            for (var k = 1; k <= p.numKeys; k++) {
                var ei = [], eo = [];
                for (var j = 0; j < d; j++) {
                    ei.push(new KeyframeEase(0, 95)); eo.push(new KeyframeEase(0, 95));
                }
                p.setTemporalEaseAtKey(k, ei, eo);
            }
        } catch(e) {}
    };

    // -- Construtores --
    function mkSolid(comp, cor, nome) { try { return comp.layers.addSolid(cor, nome, comp.width, comp.height, 1); } catch(e) { return null; } }
    
    function mkEllipse(comp, pos, raio, corFill, nome) {
        try {
            var s = comp.layers.addShape(); s.name = nome || "Ell";
            var grp = s.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
            var vec = grp.property("ADBE Vectors Group");
            var el = vec.addProperty("ADBE Vector Shape - Ellipse");
            el.property("ADBE Vector Ellipse Size").setValue([raio * 2, raio * 2]);
            if (corFill) {
                var f = vec.addProperty("ADBE Vector Graphic - Fill");
                f.property("ADBE Vector Fill Color").setValue(corFill);
            }
            AE.sv(AE.pos(s), pos); return s;
        } catch(e) { return null; }
    }

    function mkText(comp, texto, pos, tamanho, cor, alinhamento, nome) {
        try {
            var l = comp.layers.addText(texto); l.name = nome || "Txt";
            var tp = AE.gc(l, ["ADBE Text Properties", "ADBE Text Document"]);
            if (tp) {
                var d = tp.value; d.font = "Arial-BoldMT"; d.fontSize = tamanho || 30; d.fillColor = cor || [0, 0, 0];
                if (alinhamento === "c") d.justification = ParagraphJustification.CENTER_JUSTIFY;
                if (alinhamento === "l") d.justification = ParagraphJustification.LEFT_JUSTIFY;
                tp.setValue(d);
            }
            AE.sv(AE.pos(l), pos); return l;
        } catch(e) { return null; }
    }

    // Animação de entrada elástica (Pop-in)
    function popIn(layer, tIn) {
        if(!layer) return;
        var s = AE.scl(layer);
        AE.sa(s, tIn, [0,0]); 
        AE.sa(s, tIn + 0.3, [110,110]); 
        AE.sa(s, tIn + 0.5, [100,100]);
        AE.smoothEase(s);
    }

    // Animação de saída (Pop-out)
    function popOut(layer, tOut) {
        if(!layer) return;
        var s = AE.scl(layer);
        AE.sa(s, tOut, [100,100]); 
        AE.sa(s, tOut + 0.2, [120,120]); 
        AE.sa(s, tOut + 0.4, [0,0]);
        AE.smoothEase(s);
    }

    app.beginUndoGroup("Google Commercial Build");

    try {
        var comp = app.project.items.addComp("Google_Dot_Animation", 1080, 1920, 1, 7.0, 30);
        
        // Cores Oficiais do Google
        var cBlue = AE.hex("#4285F4");
        var cRed = AE.hex("#EA4335");
        var cYellow = AE.hex("#FBBC05");
        var cGreen = AE.hex("#34A853");
        var cWhite = AE.hex("#FFFFFF");

        var bg = mkSolid(comp, cWhite, "Background_Branco");

        // ─────────────────────────────────────
        // 1. O CENTRO DA ÓRBITA (NULL OBJECT)
        // ─────────────────────────────────────
        var orbitCenter = comp.layers.addNull();
        orbitCenter.name = "Orbit_Controller";
        AE.sv(AE.pos(orbitCenter), [540, 960]); // Fica exatamente no meio da tela

        // ─────────────────────────────────────
        // 2. AS BOLINHAS DO GOOGLE
        // ─────────────────────────────────────
        var radius = 40; // Tamanho das bolinhas
        var balls = [
            { id: "Blue", c: cBlue, startPos: [0, -150], finalPos: [-180, 0] },
            { id: "Red", c: cRed, startPos: [150, 0], finalPos: [-60, 0] },
            { id: "Yellow", c: cYellow, startPos: [0, 150], finalPos: [60, 0] },
            { id: "Green", c: cGreen, startPos: [-150, 0], finalPos: [180, 0] }
        ];

        var ballLayers = [];

        for (var i = 0; i < balls.length; i++) {
            var bData = balls[i];
            
            // Cria a bola no centro absoluto (540, 960) primeiro
            var ball = mkEllipse(comp, [540, 960], radius, bData.c, "Dot_" + bData.id);
            
            // Parenta ao Null (a partir de agora, posições são locais baseadas no Null [0,0])
            ball.parent = orbitCenter;
            
            // Joga para a posição de início (a cruz)
            var bPos = AE.pos(ball);
            AE.sv(bPos, bData.startPos);

            // Pop-in das bolhas
            popIn(ball, 0.2 + (i * 0.1));

            // Move as bolhas para formar a linha reta a partir de 2.5s
            AE.sa(bPos, 2.5, bData.startPos);
            AE.sa(bPos, 3.2, bData.finalPos);
            AE.smoothEase(bPos);

            // Pop-out para dar espaço ao texto
            popOut(ball, 4.0);

            ballLayers.push(ball);
        }

        // ─────────────────────────────────────
        // 3. A ANIMAÇÃO DE GIRO DO NULL
        // ─────────────────────────────────────
        var orbitRot = AE.rot(orbitCenter);
        AE.sa(orbitRot, 0.8, 0);       // Começa parado
        AE.sa(orbitRot, 2.5, -360);    // Dá uma volta completa (anti-horário)
        AE.smoothEase(orbitRot);       // Acelera e freia como manteiga

        // ─────────────────────────────────────
        // 4. A REVELAÇÃO DO TEXTO "Google"
        // ─────────────────────────────────────
        // Para podermos colorir letra por letra, criamos em camadas separadas
        var gTextData = [
            { t: "G", c: cBlue, p: [330, 1000] },
            { t: "o", c: cRed, p: [430, 1000] },
            { t: "o", c: cYellow, p: [515, 1000] },
            { t: "g", c: cBlue, p: [595, 1000] },
            { t: "l", c: cGreen, p: [660, 1000] },
            { t: "e", c: cRed, p: [720, 1000] }
        ];

        for (var j = 0; j < gTextData.length; j++) {
            var letter = mkText(comp, gTextData[j].t, gTextData[j].p, 120, gTextData[j].c, "l", "Letter_" + j);
            
            // As letras começam escondidas e saltam logo após as bolinhas sumirem
            var lScl = AE.scl(letter);
            AE.sa(lScl, 0, [0,0]);
            
            // A animação de pop do texto acontece sequencialmente
            var tPop = 4.2 + (j * 0.05);
            AE.sa(lScl, tPop, [0,0]); 
            AE.sa(lScl, tPop + 0.3, [115,115]); 
            AE.sa(lScl, tPop + 0.5, [100,100]);
            AE.smoothEase(lScl);
        }

        alert("Comercial do Google criado com sucesso!\n\nDinâmica:\n1. As bolinhas nascem em formato de cruz.\n2. Orbitam em torno do centro em 360 graus.\n3. Se alinham horizontalmente no centro da tela.\n4. Encolhem para dar lugar ao logo completo e colorido da Google.\n\nTudo com 95% de easing.");

    } catch(e) {
        alert("Erro fatal: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();