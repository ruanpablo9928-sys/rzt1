(function() {
    // ╔═════════════════════════════════════════════════════════════╗
    // ║  SCROLL FOCUS LIST — ESTILO RANKYOUP / PINDOWN (PT-BR)      ║
    // ║  1080x1920 @ 30fps — 7.0s                                   ║
    // ║  Sistema Procedural (Expressões de Desfoque, Escala e Cor)  ║
    // ╚═════════════════════════════════════════════════════════════╝

    var AE = {};
    AE.gc = function(p, ns) { var c = p; for (var i=0; i<ns.length; i++) { try { c = c.property(ns[i]); } catch(e) { return null; } if (!c) return null; } return c; };
    AE.pos = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Position"]) : null; };
    AE.scl = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Scale"]) : null; };
    AE.opa = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Opacity"]) : null; };
    AE.anc = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Anchor Point"]) : null; };
    AE.sv = function(p, v) { if (!p) return; try { p.setValue(v); } catch(e) {} };
    AE.sa = function(p, t, v) { if (!p) return; try { p.setValueAtTime(t, v); } catch(e) {} };
    AE.hex = function(h) { h = h.replace("#", ""); return [parseInt(h.substr(0,2),16)/255, parseInt(h.substr(2,2),16)/255, parseInt(h.substr(4,2),16)/255]; };
    AE.fx = function(l, mn) { if (!l) return null; try { return l.property("ADBE Effect Parade").addProperty(mn); } catch(e) { return null; } };

    // --- CURVA MANTEIGA MAX (100% INFLUÊNCIA) ---
    AE.maxEase = function(p) {
        if (!p || p.numKeys === 0) return;
        try {
            var d = 1, v = p.propertyValueType;
            if (v === PropertyValueType.TwoD || v === PropertyValueType.TwoD_SPATIAL) d = 2;
            if (v === PropertyValueType.ThreeD || v === PropertyValueType.ThreeD_SPATIAL) d = 3;
            for (var k = 1; k <= p.numKeys; k++) {
                var ei = [], eo = [];
                for (var j = 0; j < d; j++) { ei.push(new KeyframeEase(0, 100)); eo.push(new KeyframeEase(0, 100)); }
                p.setTemporalEaseAtKey(k, ei, eo);
            }
        } catch(e) {}
    };

    // --- ALINHAMENTO À ESQUERDA PERFEITO ---
    function leftAnchor(layer) {
        if(!layer || !layer.sourceRectAtTime) return;
        try {
            var rect = layer.sourceRectAtTime(0, false);
            // Puxa a âncora para a esquerda absoluta, mas mantém no centro vertical
            AE.sv(AE.anc(layer), [rect.left, rect.top + rect.height / 2]);
        } catch(e) {}
    }

    // -- CONSTRUTORES --
    function mkSolid(comp, cor, nome) { try { return comp.layers.addSolid(cor, nome, comp.width, comp.height, 1); } catch(e) { return null; } }

    function mkText(comp, texto, pos, tamanho, cor, alinhamento, nome) {
        try {
            var l = comp.layers.addText(texto); l.name = nome || "Txt";
            var tp = AE.gc(l, ["ADBE Text Properties", "ADBE Text Document"]);
            if (tp) {
                var d = tp.value; 
                d.font = "Arial-BoldMT"; // Fonte grossa e marcante
                d.fontSize = tamanho || 30; 
                d.fillColor = cor || [1, 1, 1];
                if (alinhamento === "l") d.justification = ParagraphJustification.LEFT_JUSTIFY;
                tp.setValue(d);
            }
            leftAnchor(l); // Ajusta a âncora para o efeito procedural funcionar bem
            AE.sv(AE.pos(l), pos); return l;
        } catch(e) { return null; }
    }

    function addBlur(layer) {
        var blurFx = AE.fx(layer, "ADBE Gaussian Blur 2");
        return blurFx ? AE.gc(blurFx, ["ADBE Gaussian Blur 2-0001"]) : null;
    }

    app.beginUndoGroup("Procedural Scroll Focus");

    try {
        // Criando a composição de 7 Segundos exatos
        var comp = app.project.items.addComp("Scroll_Focus_Viral_7s", 1080, 1920, 1, 7.0, 30);
        
        var cBlack = AE.hex("#050505");
        var cWhite = AE.hex("#FFFFFF");

        // Fundo Preto Profundo
        mkSolid(comp, cBlack, "Fundo_Preto");

        // ─────────────────────────────────────
        // 1. A SETA INDICADORA (Fixa no Centro-Esquerda)
        // ─────────────────────────────────────
        var seta = mkText(comp, "→", [200, 960], 100, cWhite, "l", "Seta_Indicadora");
        
        // ─────────────────────────────────────
        // 2. A LISTA PROCEDURAL DE PALAVRAS
        // ─────────────────────────────────────
        var palavras = [
            "Marca", "Design", "Anúncios", "Crescimento", "SEO", 
            "Conteúdo", "Marketing", "Ranqueamento", "Vendas", 
            "Lucro", "Jornada", "Site"
        ];

        var listaNull = comp.layers.addNull();
        listaNull.name = "Controlador_da_Lista";
        AE.sv(AE.pos(listaNull), [540, 960]); // Centro da tela

        var espacamentoY = 180; // Distância entre cada palavra
        var posX = 320;         // Posição alinhada à direita da seta

        // EXPRESSÕES MÁGICAS (O segredo do vídeo)
        // A expressão calcula a distância (d) da palavra até o centro vertical (Y=960)
        // E usa a função 'ease' para suavizar entre o estado focado e desfocado
        var exprScale = "d = Math.abs(toComp(anchorPoint)[1] - 960);\nease(d, 0, 250, [115, 115], [75, 75]);";
        var exprOpac  = "d = Math.abs(toComp(anchorPoint)[1] - 960);\nease(d, 0, 300, 100, 15);";
        var exprBlur  = "d = Math.abs(toComp(anchorPoint)[1] - 960);\nease(d, 0, 250, 0, 25);";

        for (var i = 0; i < palavras.length; i++) {
            var posY = 960 + (i * espacamentoY);
            var item = mkText(comp, palavras[i], [posX, posY], 90, cWhite, "l", "Item_" + i);
            
            // Adiciona o Efeito de Desfoque
            var blurProp = addBlur(item);

            // Injeta as Expressões nos parâmetros
            AE.scl(item).expression = exprScale;
            AE.opa(item).expression = exprOpac;
            if (blurProp) blurProp.expression = exprBlur;

            // Prende a palavra no Controlador Central
            item.parent = listaNull;
        }

        // ─────────────────────────────────────
        // 3. A ANIMAÇÃO DE SCROLL (7 Segundos)
        // ─────────────────────────────────────
        var pNull = AE.pos(listaNull);
        
        // Começa com a primeira palavra ("Marca") no centro
        AE.sa(pNull, 0.5, [540, 960]); 
        
        // Termina com a última palavra ("Site") no centro
        // Distância total = (quantidade de palavras - 1) * espaçamento
        var distTotal = (palavras.length - 1) * espacamentoY;
        AE.sa(pNull, 6.5, [540, 960 - distTotal]); 

        // Aplica a nossa curva de 100% para um scroll de luxo, que acelera e depois freia devagar
        AE.maxEase(pNull);

        alert("Lista Procedural Criada com Sucesso! 🤯\n\nAbra qualquer palavra da lista e aperte 'E', 'S' ou 'T'. Você vai ver os códigos em JavaScript (Expressões) que inseri lá dentro.\n\nAgora as palavras sabem automaticamente onde estão na tela. Apenas o que estiver perto da seta (Y=960) fica branco, focado e grande. Tudo o que se afasta desvanece e desfoca.\n\nDê Play na Timeline de 7s e assista à mágica!");

    } catch(e) {
        alert("Erro fatal: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();