# MultiTools for After Effects

Extensao CEP para Adobe After Effects com ferramentas de animacao, legendas automaticas via Whisper (Groq) e AI Scripter em BETA.

Compatibilidade: **After Effects 2020 - 2026 (Windows & Mac)**

---

## Instalacao em um PC novo

### 1. Copiar a pasta da extensao

Copie a pasta inteira `MultiTools` para o diretorio de extensoes CEP da Adobe:

- **Windows:** `C:\Program Files (x86)\Common Files\Adobe\CEP\extensions\MultiTools\`
- **Mac:** `/Library/Application Support/Adobe/CEP/extensions/MultiTools/`

Ao final, voce deve ter a estrutura:
```
.../Adobe/CEP/extensions/MultiTools/
  CSXS/manifest.xml
  css/styles.css
  docs/           (knowledge base da IA)
  js/main.js, ai-prompt.js
  jsx/host.jsx
  index.html
  README.md
```

### 2. Habilitar PlayerDebugMode (so 1 vez por PC)

Como a extensao nao e assinada pela Adobe, e necessario ativar o modo debug do CEP.

**Windows** — abra o CMD como Administrador e rode:
```cmd
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f
reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.9" /v PlayerDebugMode /t REG_SZ /d 1 /f
```

**Mac** — abra o Terminal:
```bash
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.10 PlayerDebugMode 1
defaults write com.adobe.CSXS.9 PlayerDebugMode 1
```

### 3. Abrir no After Effects

1. Feche completamente o After Effects e abra de novo.
2. Menu: **Janela (Window) > Extensoes (Extensions) > MultiTools**.

### 4. Configurar API Keys

Clique no icone de engrenagem no topo do painel e cole as chaves:

- **Groq API Key** (para Captions e Compor Video) — gere em https://console.groq.com
- **OpenRouter API Key** (para AI Scripter) — gere em https://openrouter.ai

As chaves ficam salvas localmente no `localStorage` do CEP, no PC onde foram coladas. Ao transferir pra outro PC, voce precisa colocar as chaves de novo.

---

## Funcionalidades

### Ferramentas de animacao
- **Bounce (BNC):** elastico/overshoot em qualquer propriedade (Posicao, Escala, Rotacao)
- **TextBounce (TXT):** entrada elastica para textos por letras/palavras
- **Aproximar:** zoom in/out com keyframes suaves
- **Desenhar:** traca caminho direto no painel e cria shape layer animado no AE
- **Captions:** transcricao automatica via Whisper (Groq) com sincronia palavra-a-palavra

### Grid de criacao
Null, Solid, Adjustment, Camera, Light com 1 clique. Centralizar, Fit, Mirror H/V, Freeze Frame.

### AI Scripter (BETA)
Chat com IA (qwen3.6-plus via OpenRouter) que gera ExtendScript ES3 e executa direto no AE.

- **Botao de video (Compor Video):** analisa a timeline decupada + transcreve o audio via Whisper + envia tudo pra IA, que cria legendas word-by-word sincronizadas, motion graphics por clip, transicoes entre cortes e destaca keywords. A IA tambem baixa imagens JPEG da internet relevantes ao tema do audio.
- **Botao de imagem:** importa suas proprias imagens pra IA usar no motion.
- Auto-correcao de erros (ate 5 tentativas).
- Conhecimento carregado de `docs/` (padrao final, criatividade, exemplos tecnicos de Card UI 3D e Kinetic Typography).

**⚠️ A AI Scripter esta em BETA** — pode gerar codigo com bugs, nem todo prompt funciona de primeira, sempre salve o projeto antes de executar.

---

## Transferir para outro PC

1. Copie a pasta inteira `MultiTools` pra um pendrive ou zip.
2. No PC novo, cole em `C:\Program Files (x86)\Common Files\Adobe\CEP\extensions\`.
3. Execute os comandos do **passo 2** acima (PlayerDebugMode).
4. Abra o AE, vai em Extensoes > MultiTools.
5. Cole suas API Keys nas configuracoes (elas nao viajam junto).

Nenhum caminho hardcoded de usuario. A extensao e 100% portavel.

---

## Requisitos

- After Effects CC 2020 ou superior
- Conexao com internet (para transcricao Whisper e AI Scripter)
- Para o Captions/Compor Video: template de Render Queue chamado **"WAV"** configurado para exportar audio. Se nao existir, o script avisa.
- Chave gratis na Groq e OpenRouter

---

## Licenca

MIT — veja `LICENSE`.
