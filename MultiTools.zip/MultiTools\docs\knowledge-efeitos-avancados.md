# ADDON — EFEITOS AVANCADOS DE KINETIC TYPOGRAPHY E ADS PROFISSIONAIS

Este addon ensina tecnicas avancadas de animacao descobertas em analise de videos reais profissionais. Inclui: mask reveal, gradiente no texto, transicao de circulo expandindo, brand dots, inversao de fundo, kinetic word-by-word com motion blur, e drift cinematico.

TODAS as funcoes abaixo usam a biblioteca AE segura. Copie-as junto com a biblioteca principal.

---

## 1. MASK REVEAL (Texto sobe de baixo, como se revelado por mascara)

Este eh o efeito mais usado em ads profissionais da Apple, Nike, etc. O texto comeca 50-70px abaixo da posicao final e sobe com ease, combinado com um fade ultra-rapido (0.06s).

```javascript
// Texto entra de baixo pra cima com fade instantaneo
// Parece que esta sendo "revelado" por uma mascara invisivel
function maskReveal(layer, tIn, dur, dist) {
    if (!layer) return;
    dur = dur || 0.25;
    dist = dist || 60;
    var pos = AE.pos(layer);
    if (!pos) return;
    var cur = AE.gv(pos);
    if (!cur) return;
    AE.sa(pos, tIn, [cur[0], cur[1] + dist]);
    AE.sa(pos, tIn + dur, cur);
    AE.snap(pos);
    var op = AE.opa(layer);
    AE.sa(op, tIn, 0);
    AE.sa(op, tIn + 0.06, 100);
    AE.snap(op);
}

// Versao com direcao customizavel
// dir: "cima", "baixo", "esquerda", "direita"
function maskRevealDir(layer, tIn, dur, dir, dist) {
    if (!layer) return;
    dur = dur || 0.25;
    dist = dist || 60;
    dir = dir || "cima";
    var pos = AE.pos(layer);
    if (!pos) return;
    var cur = AE.gv(pos);
    if (!cur) return;
    var ini;
    switch(dir) {
        case "cima":     ini = [cur[0], cur[1] + dist]; break;
        case "baixo":    ini = [cur[0], cur[1] - dist]; break;
        case "esquerda": ini = [cur[0] + dist, cur[1]]; break;
        case "direita":  ini = [cur[0] - dist, cur[1]]; break;
        default:         ini = [cur[0], cur[1] + dist];
    }
    AE.sa(pos, tIn, ini);
    AE.sa(pos, tIn + dur, cur);
    AE.snap(pos);
    var op = AE.opa(layer);
    AE.sa(op, tIn, 0);
    AE.sa(op, tIn + 0.06, 100);
    AE.snap(op);
}
```

### Quando usar:
- Ads profissionais (Apple, Nike, Google)
- Kinetic typography com uma palavra por vez
- Titulos de abertura cinematicos
- Qualquer texto que precisa parecer "limpo" e elegante

---

## 2. EXIT SCALE (Saida com leve zoom + fade)

O texto sai com um scale sutil de 100% > 108% combinado com fade. Da a sensacao de que o texto "se afasta" antes de sumir.

```javascript
function exitScale(layer, tOut, dur) {
    if (!layer) return;
    dur = dur || 0.2;
    var sc = AE.scl(layer);
    AE.sa(sc, tOut, [100, 100]);
    AE.sa(sc, tOut + dur, [108, 108]);
    AE.snap(sc);
    var op = AE.opa(layer);
    AE.sa(op, tOut, 100);
    AE.sa(op, tOut + dur, 0);
    AE.snap(op);
}

// Versao com scale down (texto "encolhe" ao sair)
function exitShrink(layer, tOut, dur) {
    if (!layer) return;
    dur = dur || 0.2;
    var sc = AE.scl(layer);
    AE.sa(sc, tOut, [100, 100]);
    AE.sa(sc, tOut + dur, [90, 90]);
    AE.snap(sc);
    var op = AE.opa(layer);
    AE.sa(op, tOut, 100);
    AE.sa(op, tOut + dur, 0);
    AE.snap(op);
}
```

---

## 3. BRAND DOT (Ponto colorido como identidade visual)

Muitas marcas usam um ponto colorido apos palavras-chave como elemento de marca. Apple usa azul, PicPay usa verde, etc.

```javascript
function brandDot(comp, config) {
    /*
        config = {
            posicao: [800, 380],      // posicao do ponto (depois da palavra)
            raio: 10,
            cor: [0.08, 0.2, 0.78],   // azul Apple
            tempoIn: 1.8,
            tempoOut: 3.0,
            animacao: "fade"           // "fade", "pop", "scale"
        }
    */
    config = config || {};
    var dot = AE.ell(comp, {
        p: config.posicao || [800, 380],
        r: config.raio || 10,
        fc: config.cor || [0.08, 0.2, 0.78],
        nome: config.nome || "BrandDot"
    });
    if (!dot) return null;

    dot.inPoint = config.tempoIn || 0;
    if (config.tempoOut) dot.outPoint = config.tempoOut;

    var tIn = config.tempoIn || 0;
    switch(config.animacao || "fade") {
        case "fade":
            AE.sa(AE.opa(dot), tIn, 0);
            AE.sa(AE.opa(dot), tIn + 0.15, 100);
            AE.snap(AE.opa(dot));
            break;
        case "pop":
            AE.sa(AE.opa(dot), tIn, 0);
            AE.sa(AE.opa(dot), tIn + 0.05, 100);
            AE.sa(AE.scl(dot), tIn, [0, 0]);
            AE.sa(AE.scl(dot), tIn + 0.15, [120, 120]);
            AE.sa(AE.scl(dot), tIn + 0.25, [100, 100]);
            AE.snap(AE.scl(dot));
            AE.snap(AE.opa(dot));
            break;
        case "scale":
            AE.sa(AE.scl(dot), tIn, [0, 0]);
            AE.sa(AE.scl(dot), tIn + 0.2, [100, 100]);
            AE.snap(AE.scl(dot));
            break;
    }
    return dot;
}
```

---

## 4. GRADIENTE NO TEXTO (Estilo Apple — laranja > roxo)

Aplica um Gradient Ramp diretamente no layer de texto para criar texto com gradiente colorido.

```javascript
function textoGradiente(layer, corEsq, corDir, direcao) {
    /*
        layer: text layer ja criado
        corEsq: [r,g,b] cor da esquerda (ex: laranja)
        corDir: [r,g,b] cor da direita (ex: roxo)
        direcao: "horizontal" ou "vertical"
    */
    if (!layer) return;
    direcao = direcao || "horizontal";
    var ramp = AE.fx(layer, "ADBE Ramp");
    if (!ramp) return;

    if (direcao === "horizontal") {
        AE.sv(AE.gp(ramp, "ADBE Ramp-0001"), [200, 360]);   // start point
        AE.sv(AE.gp(ramp, "ADBE Ramp-0003"), [1080, 360]);   // end point
    } else {
        AE.sv(AE.gp(ramp, "ADBE Ramp-0001"), [640, 200]);
        AE.sv(AE.gp(ramp, "ADBE Ramp-0003"), [640, 520]);
    }
    AE.sv(AE.gp(ramp, "ADBE Ramp-0002"), corEsq);           // start color
    AE.sv(AE.gp(ramp, "ADBE Ramp-0004"), corDir);            // end color
    AE.sv(AE.gp(ramp, "ADBE Ramp-0005"), 1);                 // linear
}

// Gradientes prontos (paletas de marcas):
// Apple:     textoGradiente(layer, AE.hex("#E8842C"), AE.hex("#8044C8"))
// Instagram: textoGradiente(layer, AE.hex("#F58529"), AE.hex("#DD2A7B"))
// Spotify:   textoGradiente(layer, AE.hex("#1DB954"), AE.hex("#1ED760"))
// Sunset:    textoGradiente(layer, AE.hex("#FF6B6B"), AE.hex("#FFA07A"))
// Ocean:     textoGradiente(layer, AE.hex("#00C9FF"), AE.hex("#92FE9D"))
// Neon:      textoGradiente(layer, AE.hex("#FF00FF"), AE.hex("#00FFFF"))
```

---

## 5. TRANSICAO CIRCULO EXPANDINDO

Um circulo no centro que expande ate cobrir toda a tela. Serve como transicao entre cenas com fundos diferentes.

```javascript
function transCirculo(comp, config) {
    /*
        config = {
            tempo: 13.0,          // quando comeca
            duracao: 0.6,         // quanto tempo leva pra cobrir tudo
            cor: [0, 0, 0],       // cor do circulo
            posicao: [640, 360],  // centro do circulo
            scaleMax: 8000        // o quao grande fica (8000% cobre 1280x720)
        }
    */
    config = config || {};
    var t = config.tempo || 0;
    var dur = config.duracao || 0.6;
    var circ = AE.ell(comp, {
        p: config.posicao || [640, 360],
        r: 10,
        fc: config.cor || [0, 0, 0],
        nome: "Trans_Circle"
    });
    if (!circ) return null;

    circ.inPoint = t;
    circ.outPoint = t + dur + 0.5;

    AE.sa(AE.scl(circ), t, [100, 100]);
    AE.sa(AE.scl(circ), t + dur, [config.scaleMax || 8000, config.scaleMax || 8000]);
    AE.snap(AE.scl(circ));

    return circ;
}
```

---

## 6. INVERSAO DE FUNDO (Preto > Branco > Preto)

Trocar o fundo entre preto e branco em momentos especificos, invertendo a cor do texto junto.

```javascript
function fundoBranco(comp, tIn, tOut) {
    var bg = AE.solid(comp, [1, 1, 1], "BG_Branco_" + tIn, comp.width, comp.height);
    if (bg) {
        bg.inPoint = tIn;
        bg.outPoint = tOut;
        bg.moveToEnd();
    }
    return bg;
}

// Para usar: crie textos pretos durante o periodo do fundo branco
// Ex:
// fundoBranco(comp, 11.0, 14.0);
// var txt = AE.txt(comp, "texto aqui", { c: [0,0,0], ... });
// txt.inPoint = 11.0; txt.outPoint = 14.0;
```

---

## 7. KINETIC WORD-BY-WORD COM MOTION BLUR

Cada palavra eh uma layer separada, entrando da direita com motion blur horizontal, driftando pra esquerda. Estilo TikTok/Reels viral.

```javascript
function kineticWord(comp, palavra, config) {
    /*
        config = {
            posInicial: [900, 360],   // comeca aqui (fora da tela, direita)
            posFinal: [500, 360],     // para aqui
            posSaida: [100, 360],     // sai por aqui (esquerda) — null = fica parado
            tEntrada: 0.15,
            tParada: 0.30,
            tSaida: 0.70,
            tFim: 1.10,
            scaleInicio: [120, 120],
            scaleFinal: [100, 100],
            scaleSaida: [140, 140],   // null = nao cresce ao sair
            tamanho: 80,
            fonte: "Arial-BoldMT",
            cor: [1, 1, 1],
            tracking: -15,
            motionBlur: true
        }
    */
    config = config || {};
    var layer = comp.layers.addText(palavra);
    if (!layer) return null;
    layer.name = "KW_" + palavra;

    // Ativar motion blur
    if (config.motionBlur !== false) layer.motionBlur = true;

    // Estilo
    var tp = AE.gc(layer, ["ADBE Text Properties", "ADBE Text Document"]);
    if (tp) {
        var doc = tp.value;
        doc.font = config.fonte || "Arial-BoldMT";
        doc.fontSize = config.tamanho || 80;
        doc.fillColor = config.cor || [1, 1, 1];
        doc.justification = ParagraphJustification.CENTER_JUSTIFY;
        doc.tracking = config.tracking || -15;
        tp.setValue(doc);
    }

    // Posicao
    var pos = AE.pos(layer);
    if (pos && config.posInicial && config.posFinal) {
        AE.sa(pos, config.tEntrada || 0, config.posInicial);
        AE.sa(pos, config.tParada || 0.2, config.posFinal);
        if (config.posSaida && config.tSaida) {
            AE.sa(pos, config.tSaida, config.posFinal);
            if (config.tFim) {
                var exitX = config.posSaida[0] - 300;
                AE.sa(pos, config.tFim, [exitX, config.posFinal[1]]);
            }
        }
        AE.snap(pos);
    }

    // Scale
    var sc = AE.scl(layer);
    if (sc) {
        AE.sa(sc, config.tEntrada || 0, config.scaleInicio || [120, 120]);
        AE.sa(sc, config.tParada || 0.2, config.scaleFinal || [100, 100]);
        if (config.scaleSaida && config.tSaida && config.tFim) {
            AE.sa(sc, config.tSaida, config.scaleFinal || [100, 100]);
            AE.sa(sc, config.tFim, config.scaleSaida);
        }
        AE.snap(sc);
    }

    // Opacity
    var op = AE.opa(layer);
    if (op) {
        AE.sa(op, config.tEntrada || 0, 0);
        AE.sa(op, (config.tEntrada || 0) + 0.05, 100);
        if (config.tFim) {
            AE.sa(op, config.tFim - 0.08, 100);
            AE.sa(op, config.tFim, 0);
        }
        AE.snap(op);
    }

    // Directional Blur horizontal (simula motion blur extra)
    var dblur = AE.fx(layer, "ADBE Motion Blur");
    if (dblur) {
        var blurLen = AE.gp(dblur, "ADBE Motion Blur-0001");
        if (blurLen) {
            AE.sa(blurLen, config.tEntrada || 0, 35);
            AE.sa(blurLen, config.tParada || 0.2, 0);
            if (config.tSaida && config.tFim) {
                AE.sa(blurLen, config.tSaida, 0);
                AE.sa(blurLen, config.tFim, 25);
            }
            AE.snap(blurLen);
        }
        var blurDir = AE.gp(dblur, "ADBE Motion Blur-0002");
        if (blurDir) AE.sv(blurDir, 90); // horizontal
    }

    return layer;
}
```

### Quando usar:
- Reels virais estilo TikTok
- Textos rapidos com beat musical
- Hook de abertura ("Are u looking for a job?")

---

## 8. DECORATIVE SQUARES (Quadrados como brand element)

Quadrados coloridos empilhados que aparecem ao lado de textos importantes. Estilo Apple Business.

```javascript
function brandSquares(comp, config) {
    /*
        config = {
            posicao: [400, 340],       // posicao do primeiro quadrado
            cor1: AE.hex("#1432C8"),   // quadrado de cima
            cor2: AE.hex("#0C1E8A"),   // quadrado de baixo
            tamanho1: [50, 50],
            tamanho2: [50, 60],
            gap: 55,                   // espaco vertical entre eles
            tempoIn: 1.7,
            tempoOut: 3.0,
            animacao: "scale"          // "scale", "slide"
        }
    */
    config = config || {};
    var p = config.posicao || [400, 340];
    var gap = config.gap || 55;

    var sq1 = AE.rect(comp, {
        p: p,
        sz: config.tamanho1 || [50, 50],
        fc: config.cor1 || AE.hex("#1432C8"),
        nome: "BrandSq_1"
    });
    var sq2 = AE.rect(comp, {
        p: [p[0], p[1] + gap],
        sz: config.tamanho2 || [50, 60],
        fc: config.cor2 || AE.hex("#0C1E8A"),
        nome: "BrandSq_2"
    });

    var tIn = config.tempoIn || 0;
    if (sq1) {
        sq1.inPoint = tIn;
        if (config.tempoOut) sq1.outPoint = config.tempoOut;
        AE.sa(AE.scl(sq1), tIn, [0, 0]);
        AE.sa(AE.scl(sq1), tIn + 0.25, [100, 100]);
        AE.snap(AE.scl(sq1));
    }
    if (sq2) {
        sq2.inPoint = tIn;
        if (config.tempoOut) sq2.outPoint = config.tempoOut;
        AE.sa(AE.scl(sq2), tIn + 0.05, [0, 0]);
        AE.sa(AE.scl(sq2), tIn + 0.3, [100, 100]);
        AE.snap(AE.scl(sq2));
    }

    return { sq1: sq1, sq2: sq2 };
}
```

---

## 9. LOADING DOTS (Bolinhas de carregamento durante transicoes)

3 bolinhas que aparecem e somem sequencialmente, simulando loading.

```javascript
function loadingDots(comp, config) {
    config = config || {};
    var cx = config.x || 640;
    var cy = config.y || 360;
    var gap = config.gap || 30;
    var r = config.raio || 8;
    var tIn = config.tempoIn || 0;
    var tOut = config.tempoOut || 1;
    var dots = [];

    for (var i = 0; i < 3; i++) {
        var dot = AE.ell(comp, {
            p: [cx - gap + (i * gap), cy],
            r: r,
            fc: config.cor || [0.5, 0.5, 0.5],
            nome: "LoadDot_" + i
        });
        if (dot) {
            dot.inPoint = tIn;
            dot.outPoint = tOut;
            // Pulso de opacidade sequencial
            var op = AE.opa(dot);
            var delay = i * 0.12;
            AE.sa(op, tIn, 0);
            AE.sa(op, tIn + 0.1 + delay, 80);
            AE.sa(op, tIn + 0.5 + delay, 40);
            AE.sa(op, tOut - 0.2, 20);
            AE.sa(op, tOut, 0);
            AE.snap(op);
            dots.push(dot);
        }
    }
    return dots;
}
```

---

## 10. SEQUENCIA RAPIDA DE PALAVRAS (Uma palavra por vez, estilo ad)

Funcao helper que recebe um array de palavras com timing e cria todas automaticamente.

```javascript
function sequenciaKinetic(comp, beats, config) {
    /*
        beats = [
            { texto: "Where",     tIn: 0.5,  tOut: 1.8,  s: 90, bold: true },
            { texto: "Business",  tIn: 1.8,  tOut: 3.0,  s: 85, bold: true, dot: true },
            { texto: "IT",        tIn: 3.0,  tOut: 3.8,  s: 100, bold: true },
            { texto: "deal",      tIn: 3.8,  tOut: 4.8,  s: 95, bold: true, dot: true },
            { texto: "demands",   tIn: 17.0, tOut: 18.5, s: 90, gradiente: true }
        ]
        config = {
            corTexto: [1,1,1],
            corFundo: [0,0,0],         // pra saber se fundo eh preto ou branco
            fonte: "Helvetica-Bold",
            corDot: AE.hex("#1432C8"),
            gradCor1: AE.hex("#E8842C"),
            gradCor2: AE.hex("#8044C8"),
            posY: 370
        }
    */
    config = config || {};
    var posY = config.posY || 370;
    var corTxt = config.corTexto || [1, 1, 1];
    var corDot = config.corDot || AE.hex("#1432C8");
    var layers = [];

    for (var i = 0; i < beats.length; i++) {
        var b = beats[i];
        var cor = b.cor || corTxt;
        var fonte = b.bold ? (config.fonte || "Helvetica-Bold") : "Helvetica";

        var layer = AE.txt(comp, b.texto, {
            p: [640, posY],
            f: fonte,
            s: b.s || 80,
            c: cor,
            al: "c",
            tr: b.tr || -20,
            nome: "Beat_" + i + "_" + b.texto
        });

        if (layer) {
            layer.inPoint = b.tIn;
            layer.outPoint = b.tOut;

            // Entrada
            maskReveal(layer, b.tIn, 0.25);

            // Saida
            exitScale(layer, b.tOut - 0.25, 0.2);

            // Gradiente Apple (se configurado)
            if (b.gradiente) {
                textoGradiente(
                    layer,
                    config.gradCor1 || AE.hex("#E8842C"),
                    config.gradCor2 || AE.hex("#8044C8")
                );
            }

            layers.push(layer);

            // Brand dot (se configurado)
            if (b.dot) {
                // Estimar posicao do ponto (apos o texto)
                var dotX = 640 + (b.texto.length * (b.s || 80) * 0.3);
                var bDot = brandDot(comp, {
                    posicao: [dotX, posY + 15],
                    cor: corDot,
                    tempoIn: b.tIn + 0.1,
                    tempoOut: b.tOut,
                    animacao: "fade"
                });
                if (bDot) layers.push(bDot);
            }
        }
    }
    return layers;
}
```

### Uso completo:
```javascript
var beats = [
    { texto: "Where",     tIn: 0.5,  tOut: 1.8,  s: 90, bold: true },
    { texto: "Business",  tIn: 1.8,  tOut: 3.0,  s: 85, bold: true, dot: true },
    { texto: "IT",        tIn: 3.0,  tOut: 3.8,  s: 100, bold: true },
    { texto: "deal",      tIn: 3.8,  tOut: 4.8,  s: 95, bold: true, dot: true },
    { texto: "demands",   tIn: 17.0, tOut: 18.5, s: 90, bold: true, gradiente: true }
];

var layers = sequenciaKinetic(comp, beats, {
    corTexto: [1,1,1],
    fonte: "Helvetica-Bold",
    corDot: AE.hex("#1432C8"),
    gradCor1: AE.hex("#E8842C"),
    gradCor2: AE.hex("#8044C8")
});
```

---

## 11. REGRAS DE USO — QUANDO APLICAR CADA EFEITO

| Efeito | Quando usar |
|--------|-------------|
| maskReveal | SEMPRE para textos em ads profissionais (Apple, Nike, Google) |
| exitScale | SEMPRE como saida de textos em ads (combinado com maskReveal) |
| brandDot | Quando o usuario pede ad pra marca. Usar cor da marca |
| textoGradiente | Palavra-chave de impacto ("demands", "power", "future") |
| transCirculo | Transicao entre fundos preto/branco ou cenas contrastantes |
| inversaoFundo | Quando ad tem 2+ identidades visuais (escuro e claro) |
| kineticWord | Reels virais TikTok/Instagram com texto rapido |
| brandSquares | Ads corporativos, identidade visual geometrica |
| loadingDots | Durante transicoes longas, efeito "carregando" |
| sequenciaKinetic | Ad completo com multiplas palavras uma por vez |

## 12. COMBINACOES RECOMENDADAS

- **Ad Apple-style:** maskReveal + exitScale + brandDot + textoGradiente + transCirculo
- **Reel Viral TikTok:** kineticWord (com motionBlur) + drift + tamanhos variados
- **Ad Corporativo:** maskReveal + brandSquares + brandDot + inversaoFundo
- **Storytelling:** maskReveal + orbital3D + carrossel3D + textoComDestaque
- **Hook Rapido:** kineticWord com stagger de 0.04s entre palavras
