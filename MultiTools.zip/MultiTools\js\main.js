/**
 * MultiTools ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â Controlador do Painel
 * PrimeTools-style: dark mode, tactile buttons, macros.
 */
(function () {
    'use strict';

    var csInterface = new CSInterface();

    window.MT = {

        init: function () {
            this.setupSettings();
            this.setupBounce();
            this.setupTextBounce();
            this.setupCaptions();
            this.setupBreakWords();
            this.setupTextExploder();
            this.setupIcons();
            this.setupElements();
            console.log('[MultiTools] Pronto.');
        },

        // ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Executar Script ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
        exec: function (fn, successMsg, errorMsg, btn) {
            if (btn) btn.classList.add('clicked');
            csInterface.evalScript(fn, function (result) {
                if (btn) {
                    setTimeout(function () { btn.classList.remove('clicked'); }, 350);
                }
                if (result === 'true') {
                    if (btn) {
                        btn.classList.add('success');
                        setTimeout(function () { btn.classList.remove('success'); }, 700);
                    }
                    MT.toast(successMsg, false);
                } else {
                    MT.toast(errorMsg || 'AÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o falhou', true);
                }
            });
        },

        btn: function () {
            return event && event.currentTarget;
        },


        // ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â ANCHOR POINT ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â
        moveAnchor: function (pos) {
            // Update active state
            var btns = document.querySelectorAll('.anc');
            btns.forEach(function (b) { b.classList.remove('active-anchor'); });
            if (event && event.currentTarget) event.currentTarget.classList.add('active-anchor');

            this.exec(
                'moveAnchorPoint("' + pos + '")',
                'ÃƒÆ’Ã¢â‚¬Å¡ncora ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ ' + pos,
                'Selecione uma camada',
                event && event.currentTarget
            );
        },

        // ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â CAMADAS ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â
        createNull: function () {
            this.exec('createNullLayer()', 'Nulo criado', 'Sem comp ativa', this.btn());
        },
        createSolid: function () {
            this.exec('createSolidLayer()', 'SÃƒÆ’Ã‚Â³lido criado', 'Sem comp ativa', this.btn());
        },
        createAdjustment: function () {
            this.exec('createAdjustmentLayer()', 'Ajuste criado', 'Sem comp ativa', this.btn());
        },
        createShape: function () {
            this.exec('createShapeLayer()', 'Forma criada', 'Sem comp ativa', this.btn());
        },
        createCamera: function () {
            this.exec('createCameraLayer()', 'CÃƒÆ’Ã‚Â¢mera criada', 'Sem comp ativa', this.btn());
        },
        createLight: function () {
            this.exec('createLightLayer()', 'Luz criada', 'Sem comp ativa', this.btn());
        },

        // ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â TRANSFORMAR ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â
        centerLayer: function () {
            this.exec('centerSelectedLayer()', 'Camada centralizada', 'Selecione uma camada', this.btn());
        },
        fitToComp: function () {
            this.exec('fitLayerToComp()', 'Camada ajustada', 'Selecione uma camada', this.btn());
        },
        mirrorH: function () {
            this.exec('mirrorLayerH()', 'Espelhado H', 'Selecione uma camada', this.btn());
        },
        mirrorV: function () {
            this.exec('mirrorLayerV()', 'Espelhado V', 'Selecione uma camada', this.btn());
        },

        // ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â COMPOSIÃƒÆ’Ã¢â‚¬Â¡ÃƒÆ’Ã†â€™O ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â
        preComp: function () {
            this.exec('preCompSelected()', 'PrÃƒÆ’Ã‚Â©-composto', 'Selecione camadas', this.btn());
        },
        duplicateComp: function () {
            this.exec('duplicateActiveComp()', 'Comp duplicada', 'Sem comp ativa', this.btn());
        },
        freezeFrame: function () {
            this.exec('freezeCurrentFrame()', 'Frame congelado', 'Selecione uma camada', this.btn());
        },
        saveFrame: function () {
            this.exec('saveCurrentFrame()', 'Frame salvo!', 'Sem comp ativa', this.btn());
        },

        // ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â EFEITOS ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â
        gaussianBlur: function () {
            this.exec('applyGaussianBlur()', 'Blur aplicado', 'Selecione uma camada', this.btn());
        },
        addGlow: function () {
            this.exec('applyGlow()', 'Brilho aplicado', 'Selecione uma camada', this.btn());
        },

        // ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â PROJETO ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â
        saveProject: function () {
            this.exec('saveCurrentProject()', 'Projeto salvo', 'Falha ao salvar', this.btn());
        },
        purge: function () {
            this.exec('purgeAllMemory()', 'MemÃƒÆ’Ã‚Â³ria limpa', 'Falha ao limpar', this.btn());
        },

        projectInfo: function () {
            csInterface.evalScript('getProjectInfo()', function (result) {
                if (result && result !== 'EvalScript error.' && result !== 'undefined') {
                    try {
                        var info = JSON.parse(result);
                        document.getElementById('info-project').textContent = info.projectName || 'ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â';
                        document.getElementById('info-comp').textContent = info.compName || 'ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â';
                        document.getElementById('info-resolution').textContent = info.resolution || 'ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â';
                        document.getElementById('info-duration').textContent = info.duration || 'ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â';
                        document.getElementById('info-fps').textContent = info.fps || 'ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â';
                        document.getElementById('info-layers').textContent = info.layerCount || '0';
                    } catch (e) { }
                }
                document.getElementById('info-overlay').classList.add('open');
            });
        },

        // ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â BOUNCE ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â
        _bounceParams: { amp: 0.06, freq: 1.8, decay: 5 },
        _bounceAnimFrame: null,
        _bounceAnimStart: 0,

        openBounce: function () {
            document.getElementById('bounce-overlay').classList.add('open');
            this.startBouncePreview();
        },
        closeBounce: function () {
            document.getElementById('bounce-overlay').classList.remove('open');
            this.stopBouncePreview();
        },

        startBouncePreview: function () {
            this.stopBouncePreview();
            this._bounceAnimStart = performance.now();
            var self = this;
            var loop = function () {
                self.drawBounce();
                self._bounceAnimFrame = requestAnimationFrame(loop);
            };
            this._bounceAnimFrame = requestAnimationFrame(loop);
        },

        stopBouncePreview: function () {
            if (this._bounceAnimFrame) {
                cancelAnimationFrame(this._bounceAnimFrame);
                this._bounceAnimFrame = null;
            }
        },

        restartBouncePreview: function () {
            this._bounceAnimStart = performance.now();
        },

        setupBounce: function () {
            var self = this;
            document.getElementById('btn-close-bounce').addEventListener('click', function () { self.closeBounce(); });
            document.getElementById('bounce-overlay').addEventListener('click', function (e) {
                if (e.target === this) self.closeBounce();
            });

            var sliderAmp = document.getElementById('slider-amp');
            var sliderFreq = document.getElementById('slider-freq');
            var sliderDecay = document.getElementById('slider-decay');

            sliderAmp.addEventListener('input', function () {
                self._bounceParams.amp = parseFloat(this.value);
                document.getElementById('val-amp').textContent = parseFloat(this.value).toFixed(2);
                self.restartBouncePreview();
            });
            sliderFreq.addEventListener('input', function () {
                self._bounceParams.freq = parseFloat(this.value);
                document.getElementById('val-freq').textContent = parseFloat(this.value).toFixed(1);
                self.restartBouncePreview();
            });
            sliderDecay.addEventListener('input', function () {
                self._bounceParams.decay = parseFloat(this.value);
                document.getElementById('val-decay').textContent = parseFloat(this.value).toFixed(1);
                self.restartBouncePreview();
            });
        },

        bouncePreset: function (amp, freq, decay) {
            this._bounceParams = { amp: amp, freq: freq, decay: decay };
            document.getElementById('slider-amp').value = amp;
            document.getElementById('slider-freq').value = freq;
            document.getElementById('slider-decay').value = decay;
            document.getElementById('val-amp').textContent = amp.toFixed(2);
            document.getElementById('val-freq').textContent = freq.toFixed(1);
            document.getElementById('val-decay').textContent = decay.toFixed(1);

            var modal = document.getElementById('bounce-overlay');
            var btns = modal.querySelectorAll('.preset-btn');
            btns.forEach(function (b) { b.classList.remove('active'); });
            if (event && event.currentTarget) event.currentTarget.classList.add('active');
            this.restartBouncePreview();
        },

        drawBounce: function () {
            var canvas = document.getElementById('bounce-canvas');
            if (!canvas) return;
            var ctx = canvas.getContext('2d');
            var W = canvas.width, H = canvas.height;
            var p = this._bounceParams;

            var duration = 1.2;
            var loopTime = duration + 0.8;
            var elapsed = (performance.now() - this._bounceAnimStart) / 1000;
            var t_global = elapsed % loopTime;
            var progress = Math.min(t_global / duration, 1.0);

            ctx.clearRect(0, 0, W, H);

            // Grid
            ctx.strokeStyle = 'rgba(255,255,255,0.03)';
            ctx.lineWidth = 1;
            for (var gx = 0; gx < W; gx += 24) { ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke(); }
            for (var gy = 0; gy < H; gy += 18) { ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke(); }

            // Baseline
            var baseline = H * 0.5;
            ctx.strokeStyle = 'rgba(226,226,230,0.08)';
            ctx.setLineDash([3, 3]);
            ctx.beginPath(); ctx.moveTo(0, baseline); ctx.lineTo(W, baseline); ctx.stroke();
            ctx.setLineDash([]);

            // Keyframe diamond
            var keyX = 25;
            ctx.fillStyle = '#e2e2e6';
            ctx.globalAlpha = 0.8;
            ctx.beginPath();
            ctx.moveTo(keyX, baseline - 5);
            ctx.lineTo(keyX + 4, baseline);
            ctx.lineTo(keyX, baseline + 5);
            ctx.lineTo(keyX - 4, baseline);
            ctx.closePath();
            ctx.fill();
            ctx.globalAlpha = 1;

            // Pre-compute curve and find max
            var steps = W - keyX;
            var maxVal = 0;
            for (var i = 0; i < steps; i++) {
                var t = (i / steps) * duration;
                var v = p.amp * Math.sin(p.freq * t * 2 * Math.PI) / Math.exp(p.decay * t);
                if (Math.abs(v) > maxVal) maxVal = Math.abs(v);
            }
            var scale = (H * 0.38) / (maxVal > 0 ? maxVal : 1);

            var currentStep = Math.floor(progress * steps);

            // Ghost curve (full, faded)
            ctx.strokeStyle = 'rgba(226,226,230,0.06)';
            ctx.lineWidth = 1.5;
            ctx.lineJoin = 'round';
            ctx.beginPath();
            ctx.moveTo(keyX, baseline);
            for (var g = 1; g < steps; g++) {
                var tg = (g / steps) * duration;
                var vg = p.amp * Math.sin(p.freq * tg * 2 * Math.PI) / Math.exp(p.decay * tg);
                ctx.lineTo(keyX + g, baseline - (vg * scale));
            }
            ctx.stroke();

            // Active curve glow (up to playhead)
            if (currentStep > 0) {
                ctx.strokeStyle = 'rgba(226,226,230,0.12)';
                ctx.lineWidth = 6;
                ctx.beginPath();
                ctx.moveTo(keyX, baseline);
                for (var kg = 1; kg <= currentStep && kg < steps; kg++) {
                    var tkg = (kg / steps) * duration;
                    var vkg = p.amp * Math.sin(p.freq * tkg * 2 * Math.PI) / Math.exp(p.decay * tkg);
                    ctx.lineTo(keyX + kg, baseline - (vkg * scale));
                }
                ctx.stroke();
            }

            // Active curve (bright, up to playhead)
            if (currentStep > 0) {
                ctx.strokeStyle = '#e2e2e6';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(keyX, baseline);
                for (var j = 1; j <= currentStep && j < steps; j++) {
                    var t2 = (j / steps) * duration;
                    var val = p.amp * Math.sin(p.freq * t2 * 2 * Math.PI) / Math.exp(p.decay * t2);
                    ctx.lineTo(keyX + j, baseline - (val * scale));
                }
                ctx.stroke();
            }

            // Playhead dot
            if (progress < 1.0) {
                var dotT = progress * duration;
                var dotVal = p.amp * Math.sin(p.freq * dotT * 2 * Math.PI) / Math.exp(p.decay * dotT);
                var dotX = keyX + currentStep;
                var dotY = baseline - (dotVal * scale);

                // Dot glow
                ctx.beginPath();
                ctx.arc(dotX, dotY, 8, 0, Math.PI * 2);
                ctx.fillStyle = 'rgba(226,226,230,0.15)';
                ctx.fill();

                // Dot
                ctx.beginPath();
                ctx.arc(dotX, dotY, 3.5, 0, Math.PI * 2);
                ctx.fillStyle = '#e2e2e6';
                ctx.fill();
                ctx.strokeStyle = 'rgba(255,255,255,0.6)';
                ctx.lineWidth = 1;
                ctx.stroke();

                // Bounce indicator ball (left side)
                var ballX = 10;
                var ballY = baseline - (dotVal * scale);
                ballY = Math.max(6, Math.min(H - 6, ballY));

                ctx.beginPath();
                ctx.arc(ballX, ballY, 4, 0, Math.PI * 2);
                ctx.fillStyle = '#e2e2e6';
                ctx.shadowColor = '#e2e2e6';
                ctx.shadowBlur = 6;
                ctx.fill();
                ctx.shadowBlur = 0;
            }
        },

        applyBounce: function () {
            var p = this._bounceParams;
            var script = 'applyBounceWithParams(' + p.amp + ', ' + p.freq + ', ' + p.decay + ')';
            csInterface.evalScript(script, function (result) {
                if (result === 'true') {
                    MT.toast('Bounce aplicado!', false);
                    MT.closeBounce();
                } else {
                    MT.toast('Selecione camadas com keyframes', true);
                }
            });
        },

        // ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â TEXT BOUNCE ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â
        _tbParams: { delay: 3, freq: 2.5, amp: 150, decay: 7, speed: 1.0, mode: 3 },
        _tbAnimFrame: null,
        _tbAnimStart: 0,

        openTextBounce: function () {
            document.getElementById('textbounce-overlay').classList.add('open');
            this.startTbPreview();
        },
        closeTextBounce: function () {
            document.getElementById('textbounce-overlay').classList.remove('open');
            this.stopTbPreview();
        },

        startTbPreview: function () {
            this.stopTbPreview();
            this._tbAnimStart = performance.now();
            var self = this;
            var loop = function () {
                self.drawTextBounce();
                self._tbAnimFrame = requestAnimationFrame(loop);
            };
            this._tbAnimFrame = requestAnimationFrame(loop);
        },

        stopTbPreview: function () {
            if (this._tbAnimFrame) {
                cancelAnimationFrame(this._tbAnimFrame);
                this._tbAnimFrame = null;
            }
        },

        restartTbPreview: function () {
            this._tbAnimStart = performance.now();
        },

        drawTextBounce: function () {
            var canvas = document.getElementById('tb-canvas');
            if (!canvas) return;
            var ctx = canvas.getContext('2d');
            var W = canvas.width, H = canvas.height;
            var p = this._tbParams;

            ctx.clearRect(0, 0, W, H);

            // Determine units based on mode
            var sampleWords = ['Multi', 'Tools', 'Preview'];
            var sampleChars = 'Bounce'.split('');
            var isWords = (p.mode === 3);
            var units = isWords ? sampleWords : sampleChars;
            var unitCount = units.length;

            // Timing
            var frameDuration = 1 / 24;
            var elapsed = (performance.now() - this._tbAnimStart) / 1000;
            var totalDuration = (p.delay * frameDuration * (unitCount - 1)) / p.speed + 2.0;
            var loopTime = totalDuration + 1.0;
            var t_global = elapsed % loopTime;

            // Font setup
            var fontSize = isWords ? 16 : 20;
            ctx.font = '700 ' + fontSize + 'px "Segoe UI", sans-serif';
            ctx.textBaseline = 'middle';
            ctx.textAlign = 'left';

            // Measure total width for centering
            var gap = isWords ? 8 : 2;
            var widths = [];
            var totalW = 0;
            for (var i = 0; i < unitCount; i++) {
                var w = ctx.measureText(units[i]).width;
                widths.push(w);
                totalW += w + (i < unitCount - 1 ? gap : 0);
            }

            var startX = (W - totalW) / 2;
            var baseY = H * 0.55;
            var curX = startX;

            // Draw each unit
            for (var u = 0; u < unitCount; u++) {
                var unitDelay = (p.delay * frameDuration * u) / p.speed;
                var t = t_global * p.speed - unitDelay * p.speed;

                var yOffset = 0;
                var alpha = 0;

                if (t >= 0) {
                    // Bounce formula matching AE expression:
                    // s = amplitude * cos(freq * t * 2PI) / exp(decay * t)
                    var bounce = Math.cos(p.freq * t * 2 * Math.PI) / Math.exp(p.decay * t);

                    // Position offset: animator has y=-50, so offset scales with amplitude
                    yOffset = -30 * (p.amp / 150) * bounce;

                    // Opacity: starts from 0, settles to 1
                    alpha = 1 - Math.abs(bounce);
                    alpha = Math.max(0, Math.min(1, alpha));
                } else {
                    yOffset = -30 * (p.amp / 150);
                    alpha = 0;
                }

                // Draw text with glow
                if (alpha > 0.01) {
                    ctx.save();
                    ctx.globalAlpha = alpha * 0.15;
                    ctx.fillStyle = '#e2e2e6';
                    ctx.shadowColor = '#e2e2e6';
                    ctx.shadowBlur = 8;
                    ctx.fillText(units[u], curX, baseY + yOffset);
                    ctx.restore();

                    ctx.save();
                    ctx.globalAlpha = alpha;
                    ctx.fillStyle = '#e8e8e8';
                    ctx.shadowColor = 'rgba(226,226,230, 0.3)';
                    ctx.shadowBlur = alpha > 0.5 ? 4 : 0;
                    ctx.fillText(units[u], curX, baseY + yOffset);
                    ctx.restore();
                }

                curX += widths[u] + gap;
            }

            // Subtle baseline
            ctx.strokeStyle = 'rgba(226,226,230, 0.06)';
            ctx.setLineDash([2, 4]);
            ctx.beginPath();
            ctx.moveTo(startX - 10, baseY);
            ctx.lineTo(startX + totalW + 10, baseY);
            ctx.stroke();
            ctx.setLineDash([]);
        },

        setTextBounceMode: function (mode) {
            this._tbParams.mode = mode;

            // Visual update
            document.getElementById('btn-mode-chars').classList.remove('active');
            document.getElementById('btn-mode-words').classList.remove('active');

            if (mode === 1) document.getElementById('btn-mode-chars').classList.add('active');
            if (mode === 3) document.getElementById('btn-mode-words').classList.add('active');
            this.restartTbPreview();
        },

        setupTextBounce: function () {
            var self = this;
            document.getElementById('btn-close-textbounce').addEventListener('click', function () { self.closeTextBounce(); });
            document.getElementById('textbounce-overlay').addEventListener('click', function (e) {
                if (e.target === this) self.closeTextBounce();
            });

            document.getElementById('slider-tb-delay').addEventListener('input', function () {
                self._tbParams.delay = parseInt(this.value);
                document.getElementById('val-tb-delay').textContent = this.value;
                self.restartTbPreview();
            });
            document.getElementById('slider-tb-freq').addEventListener('input', function () {
                self._tbParams.freq = parseFloat(this.value);
                document.getElementById('val-tb-freq').textContent = parseFloat(this.value).toFixed(1);
                self.restartTbPreview();
            });
            document.getElementById('slider-tb-amp').addEventListener('input', function () {
                self._tbParams.amp = parseInt(this.value);
                document.getElementById('val-tb-amp').textContent = this.value;
                self.restartTbPreview();
            });
            document.getElementById('slider-tb-speed').addEventListener('input', function () {
                self._tbParams.speed = parseFloat(this.value);
                document.getElementById('val-tb-speed').textContent = parseFloat(this.value).toFixed(1) + 'x';
                self.restartTbPreview();
            });
            document.getElementById('slider-tb-decay').addEventListener('input', function () {
                self._tbParams.decay = parseFloat(this.value);
                document.getElementById('val-tb-decay').textContent = parseFloat(this.value).toFixed(1);
                self.restartTbPreview();
            });
        },

        textBouncePreset: function (delay, freq, amp, decay, speed) {
            this._tbParams.delay = delay;
            this._tbParams.freq = freq;
            this._tbParams.amp = amp;
            this._tbParams.decay = decay;
            this._tbParams.speed = speed;

            document.getElementById('slider-tb-delay').value = delay;
            document.getElementById('slider-tb-freq').value = freq;
            document.getElementById('slider-tb-amp').value = amp;
            document.getElementById('slider-tb-decay').value = decay;
            document.getElementById('slider-tb-speed').value = speed;
            document.getElementById('val-tb-delay').textContent = delay;
            document.getElementById('val-tb-freq').textContent = freq.toFixed(1);
            document.getElementById('val-tb-amp').textContent = amp;
            document.getElementById('val-tb-decay').textContent = decay.toFixed(1);
            document.getElementById('val-tb-speed').textContent = speed.toFixed(1) + 'x';

            // Update active preset in the textbounce modal only
            var modal = document.getElementById('textbounce-overlay');
            var btns = modal.querySelectorAll('.preset-btn');
            btns.forEach(function (b) { b.classList.remove('active'); });
            if (event && event.currentTarget) event.currentTarget.classList.add('active');
            this.restartTbPreview();
        },

        applyTextBounce: function () {
            var p = this._tbParams;
            var script = 'applyTextBounceWithParams(' + p.delay + ', ' + p.freq + ', ' + p.amp + ', ' + p.decay + ', ' + p.speed + ', ' + p.mode + ')';
            csInterface.evalScript(script, function (result) {
                if (result === 'true') {
                    MT.toast('TextBounce aplicado!', false);
                    MT.closeTextBounce();
                } else {
                    MT.toast('Selecione uma camada de texto', true);
                }
            });
        },

        // ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â CAPTIONS (AI) ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â
        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• SPREAD / APROXIMAÃ‡ÃƒO â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        _spreadParams: { intensity: 0.50, speed: 1.5, easing: 3.0 },
        _spreadAnimFrame: null,
        _spreadAnimStart: 0,

        openSpread: function () {
            document.getElementById('spread-overlay').classList.add('open');
            this.startSpreadPreview();
        },
        closeSpread: function () {
            document.getElementById('spread-overlay').classList.remove('open');
            this.stopSpreadPreview();
        },

        startSpreadPreview: function () {
            this.stopSpreadPreview();
            this._spreadAnimStart = performance.now();
            var self = this;
            var loop = function () {
                self.drawSpread();
                self._spreadAnimFrame = requestAnimationFrame(loop);
            };
            this._spreadAnimFrame = requestAnimationFrame(loop);
        },

        stopSpreadPreview: function () {
            if (this._spreadAnimFrame) {
                cancelAnimationFrame(this._spreadAnimFrame);
                this._spreadAnimFrame = null;
            }
        },

        restartSpreadPreview: function () {
            this._spreadAnimStart = performance.now();
        },

        drawSpread: function () {
            var canvas = document.getElementById('spread-canvas');
            if (!canvas) return;
            var ctx = canvas.getContext('2d');
            var W = canvas.width, H = canvas.height;
            var p = this._spreadParams;

            var duration = 2.0;
            var loopTime = duration + 1.2;
            var elapsed = (performance.now() - this._spreadAnimStart) / 1000;
            var t_global = elapsed % loopTime;
            var t = Math.min(t_global, duration);
            var rawProgress = 1 - Math.exp(-p.speed * t);
            var progress = Math.pow(rawProgress, 1 / Math.max(p.easing * 0.5, 0.3));

            ctx.clearRect(0, 0, W, H);

            var cx = W / 2, cy = H / 2;

            // Grid dots
            ctx.fillStyle = 'rgba(255,255,255,0.03)';
            for (var gx = 0; gx < W; gx += 20) {
                for (var gy = 0; gy < H; gy += 20) {
                    ctx.fillRect(gx, gy, 1, 1);
                }
            }

            // Sample layers at positions around center
            var layers = [
                { x: -18, y: -12, w: 20, h: 14, color: '#e2e2e6' },
                { x: 14,  y: -10, w: 16, h: 12, color: '#3b82f6' },
                { x: -22, y: 10,  w: 18, h: 10, color: '#a78bfa' },
                { x: 10,  y: 14,  w: 22, h: 12, color: '#f472b6' },
                { x: -4,  y: -22, w: 14, h: 10, color: '#34d399' },
                { x: 2,   y: 18,  w: 12, h: 8,  color: '#fbbf24' },
                { x: -35, y: 0,   w: 16, h: 10, color: '#fb923c' },
                { x: 30,  y: 2,   w: 14, h: 12, color: '#60a5fa' }
            ];

            // Crosshair
            ctx.strokeStyle = 'rgba(226,226,230,0.1)';
            ctx.lineWidth = 1;
            ctx.setLineDash([2, 3]);
            ctx.beginPath(); ctx.moveTo(cx, 0); ctx.lineTo(cx, H); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(0, cy); ctx.lineTo(W, cy); ctx.stroke();
            ctx.setLineDash([]);

            // Draw layers spreading
            for (var i = 0; i < layers.length; i++) {
                var L = layers[i];
                var spread = p.intensity * progress;
                var lx = cx + L.x * (1 + spread);
                var ly = cy + L.y * (1 + spread);

                // Ghost at original position
                ctx.fillStyle = 'rgba(255,255,255,0.03)';
                ctx.fillRect(cx + L.x - L.w / 2, cy + L.y - L.h / 2, L.w, L.h);

                // Trail line
                if (progress > 0.01) {
                    ctx.strokeStyle = L.color;
                    ctx.globalAlpha = 0.1;
                    ctx.lineWidth = 1;
                    ctx.beginPath();
                    ctx.moveTo(cx + L.x, cy + L.y);
                    ctx.lineTo(lx, ly);
                    ctx.stroke();
                    ctx.globalAlpha = 1;
                }

                // Layer rect
                var alpha = 0.6 + 0.4 * progress;
                ctx.globalAlpha = alpha;
                ctx.fillStyle = L.color;
                ctx.shadowColor = L.color;
                ctx.shadowBlur = 4 * progress;

                var rw = L.w, rh = L.h;
                var rx = lx - rw / 2, ry = ly - rh / 2;
                ctx.beginPath();
                ctx.moveTo(rx + 2, ry);
                ctx.lineTo(rx + rw - 2, ry);
                ctx.quadraticCurveTo(rx + rw, ry, rx + rw, ry + 2);
                ctx.lineTo(rx + rw, ry + rh - 2);
                ctx.quadraticCurveTo(rx + rw, ry + rh, rx + rw - 2, ry + rh);
                ctx.lineTo(rx + 2, ry + rh);
                ctx.quadraticCurveTo(rx, ry + rh, rx, ry + rh - 2);
                ctx.lineTo(rx, ry + 2);
                ctx.quadraticCurveTo(rx, ry, rx + 2, ry);
                ctx.closePath();
                ctx.fill();

                ctx.shadowBlur = 0;
                ctx.globalAlpha = 1;
            }

            // Center dot
            ctx.beginPath();
            ctx.arc(cx, cy, 2.5, 0, Math.PI * 2);
            ctx.fillStyle = '#e2e2e6';
            ctx.shadowColor = '#e2e2e6';
            ctx.shadowBlur = 6;
            ctx.fill();
            ctx.shadowBlur = 0;
        },

        setupSpread: function () {
            var self = this;
            document.getElementById('btn-close-spread').addEventListener('click', function () { self.closeSpread(); });
            document.getElementById('spread-overlay').addEventListener('click', function (e) {
                if (e.target === this) self.closeSpread();
            });

            document.getElementById('slider-sp-intensity').addEventListener('input', function () {
                self._spreadParams.intensity = parseFloat(this.value);
                document.getElementById('val-sp-intensity').textContent = parseFloat(this.value).toFixed(2);
                self.restartSpreadPreview();
            });
            document.getElementById('slider-sp-speed').addEventListener('input', function () {
                self._spreadParams.speed = parseFloat(this.value);
                document.getElementById('val-sp-speed').textContent = parseFloat(this.value).toFixed(1);
                self.restartSpreadPreview();
            });
            document.getElementById('slider-sp-easing').addEventListener('input', function () {
                self._spreadParams.easing = parseFloat(this.value);
                document.getElementById('val-sp-easing').textContent = parseFloat(this.value).toFixed(1);
                self.restartSpreadPreview();
            });
        },

        spreadPreset: function (intensity, speed, easing) {
            this._spreadParams = { intensity: intensity, speed: speed, easing: easing };
            document.getElementById('slider-sp-intensity').value = intensity;
            document.getElementById('slider-sp-speed').value = speed;
            document.getElementById('slider-sp-easing').value = easing;
            document.getElementById('val-sp-intensity').textContent = intensity.toFixed(2);
            document.getElementById('val-sp-speed').textContent = speed.toFixed(1);
            document.getElementById('val-sp-easing').textContent = easing.toFixed(1);

            var modal = document.getElementById('spread-overlay');
            var btns = modal.querySelectorAll('.preset-btn');
            btns.forEach(function (b) { b.classList.remove('active'); });
            if (event && event.currentTarget) event.currentTarget.classList.add('active');
            this.restartSpreadPreview();
        },

        applySpread: function () {
            var p = this._spreadParams;
            var script = 'applySpreadEffect(' + p.intensity + ', ' + p.speed + ', ' + p.easing + ')';
            csInterface.evalScript(script, function (result) {
                if (result === 'true') {
                    MT.toast('AproximaÃ§Ã£o aplicada!', false);
                    MT.closeSpread();
                } else {
                    MT.toast('Selecione camadas com Position', true);
                }
            });
        },

        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• CAPTIONS (AI) â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        _captionMode: 'single', // single or separate

        setCaptionMode: function (mode) {
            this._captionMode = mode;
            var btnSingle = document.getElementById('btn-cap-single');
            var btnSeparate = document.getElementById('btn-cap-separate');

            if (mode === 'single') {
                btnSingle.classList.add('active');
                btnSeparate.classList.remove('active');
            } else {
                btnSingle.classList.remove('active');
                btnSeparate.classList.add('active');
            }
        },

        openCaptions: function () {
            document.getElementById('captions-overlay').classList.add('open');
            var key = localStorage.getItem('multiTools_groqKey');
            if (key) {
                document.getElementById('captions-status').textContent = "Pronto para transcrever.";
                document.getElementById('captions-status').style.color = "var(--text-muted)";
            } else {
                document.getElementById('captions-status').textContent = "ÃƒÂ¢Ã…Â¡Ã‚Â ÃƒÂ¯Ã‚Â¸Ã‚Â Configure a API Key na engrenagem.";
                document.getElementById('captions-status').style.color = "#ffaa00";
            }
            // Ensure UI matches state (or reset to single)
            this.setCaptionMode(this._captionMode);
        },
        closeCaptions: function () {
            document.getElementById('captions-overlay').classList.remove('open');
        },
        setupCaptions: function () {
            var self = this;
            document.getElementById('btn-close-captions').addEventListener('click', function () { self.closeCaptions(); });
            document.getElementById('captions-overlay').addEventListener('click', function (e) {
                if (e.target === this) self.closeCaptions();
            });
            // Initial UI State
            this.setCaptionMode('single');
        },

        _captionData: null,
        _captionAudioPath: null,

        transcribeAudio: function () {
            var self = this;
            var key = localStorage.getItem('multiTools_groqKey');
            if (!key) { MT.toast("Configure a API Key antes!", true); return; }

            var btn = document.getElementById('cap-transcribe-btn');
            btn.textContent = 'RENDERING...';
            btn.disabled = true;
            document.getElementById('captions-status').textContent = "Renderizando audio...";
            document.getElementById('captions-status').style.color = "var(--accent)";

            csInterface.evalScript('renderAudioOnly()', function (result) {
                if (result === 'false' || result.indexOf('Error') !== -1) {
                    MT.toast("Erro no render.", true);
                    document.getElementById('captions-status').textContent = "Erro no render.";
                    btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:6px"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg> TRANSCRIBE';
                    btn.disabled = false;
                    return;
                }
                self._captionAudioPath = result;
                self._uploadAndPreview(result, key);
            });
        },

        _uploadAndPreview: function (path, key) {
            var self = this;
            var btn = document.getElementById('cap-transcribe-btn');
            btn.textContent = 'TRANSCRIBING...';
            document.getElementById('captions-status').textContent = "Enviando para Groq AI...";

            var readRes = window.cep.fs.readFile(path, cep.encoding.Base64);
            if (readRes.err !== 0) { MT.toast("Erro ao ler audio.", true); return; }

            var blob = self.b64toBlob(readRes.data, 'audio/wav');
            var formData = new FormData();
            formData.append('file', blob, 'audio.wav');
            formData.append('model', 'whisper-large-v3-turbo');
            formData.append('response_format', 'verbose_json');
            formData.append('timestamp_granularities[]', 'word');
            formData.append('timestamp_granularities[]', 'segment');

            fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
                method: 'POST',
                headers: { 'Authorization': 'Bearer ' + key },
                body: formData
            })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (data.error) throw new Error(data.error.message);

                var captions = [];

                if (data.words && data.words.length > 0) {
                    for (var i = 0; i < data.words.length; i++) {
                        var w = data.words[i];
                        captions.push({ start: w.start, end: w.end, text: w.word.trim() });
                    }
                } else if (data.segments) {
                    for (var s = 0; s < data.segments.length; s++) {
                        var seg = data.segments[s];
                        var segText = seg.text.trim();
                        if (!segText) continue;
                        var words = segText.split(/\s+/);
                        var dur = seg.end - seg.start;
                        var totalW = 0;
                        for (var c = 0; c < words.length; c++) totalW += words[c].length;
                        var ct = seg.start;
                        for (var j = 0; j < words.length; j++) {
                            var wDur = (words[j].length / totalW) * dur;
                            captions.push({ start: ct, end: ct + wDur, text: words[j] });
                            ct += wDur;
                        }
                    }
                } else if (data.text) {
                    captions.push({ start: 0, end: 5, text: data.text });
                }

                if (captions.length === 0) {
                    document.getElementById('captions-status').textContent = "Nenhuma fala detectada.";
                    btn.textContent = 'TRANSCRIBE';
                    btn.disabled = false;
                    return;
                }

                // Store captions and show review
                self._captionData = captions;
                self._showCaptionReview(captions);
            })
            .catch(function(err) {
                document.getElementById('captions-status').textContent = "Erro: " + err.message;
                document.getElementById('captions-status').style.color = "var(--red)";
                btn.textContent = 'TRANSCRIBE';
                btn.disabled = false;
            });
        },

        _showCaptionReview: function (captions) {
            var self = this;
            var lines = [];
            var line = '';
            var lineStart = captions[0].start;
            for (var i = 0; i < captions.length; i++) {
                var cap = captions[i];
                line += (line ? ' ' : '') + cap.text;
                var wordCount = line.split(/\s+/).length;
                var isLast = (i === captions.length - 1);
                var bigGap = (!isLast && captions[i + 1].start - cap.end > 0.5);

                if (wordCount >= 8 || isLast || bigGap) {
                    var ts = self._formatTs(lineStart);
                    lines.push(ts + '  ' + line);
                    line = '';
                    if (!isLast) lineStart = captions[i + 1].start;
                }
            }
            document.getElementById('cap-step1').style.display = 'none';
            document.getElementById('cap-step2').style.display = '';
            document.getElementById('cap-review-text').value = lines.join('\n');
            document.getElementById('cap-word-count').textContent = captions.length + ' WORDS';
        },

        _formatTs: function (sec) {
            var m = Math.floor(sec / 60);
            var s = Math.floor(sec % 60);
            var ms = Math.floor((sec % 1) * 10);
            return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s + '.' + ms;
        },

        captionRetry: function () {
            // Go back to step 1
            document.getElementById('cap-step1').style.display = '';
            document.getElementById('cap-step2').style.display = 'none';
            var btn = document.getElementById('cap-transcribe-btn');
            btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:6px"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg> TRANSCRIBE';
            btn.disabled = false;
            document.getElementById('captions-status').textContent = "Requires Groq API Key";
            document.getElementById('captions-status').style.color = "var(--text-muted)";
            this._captionData = null;
        },

        captionCreate: function () {
            var self = this;
            if (!this._captionData || this._captionData.length === 0) return;

            // Re-parse edited text to update caption texts
            var editedText = document.getElementById('cap-review-text').value;
            var editedLines = editedText.split('\n');
            var allWords = [];
            for (var i = 0; i < editedLines.length; i++) {
                var line = editedLines[i].replace(/^\d{2}:\d{2}\.\d\s*/, '').trim();
                if (!line) continue;
                var words = line.split(/\s+/);
                for (var j = 0; j < words.length; j++) {
                    if (words[j]) allWords.push(words[j]);
                }
            }

            // Update caption texts with edited words (keep original timing)
            var captions = this._captionData;
            for (var k = 0; k < captions.length && k < allWords.length; k++) {
                captions[k].text = allWords[k];
            }
            // If user added words, append with estimated timing
            if (allWords.length > captions.length) {
                var lastEnd = captions.length > 0 ? captions[captions.length - 1].end : 0;
                for (var a = captions.length; a < allWords.length; a++) {
                    captions.push({ start: lastEnd, end: lastEnd + 0.3, text: allWords[a] });
                    lastEnd += 0.3;
                }
            }
            // If user removed words, trim captions
            if (allWords.length < captions.length) {
                captions.length = allWords.length;
            }

            var createBtn = document.getElementById('cap-create-btn');
            createBtn.textContent = 'CREATING...';
            createBtn.disabled = true;

            var jsonStr = JSON.stringify(captions).replace(/\\/g, "\\\\").replace(/'/g, "\\'");
            var mode = self._captionMode || 'single';

            csInterface.evalScript("createCaptionsFromJSON('" + jsonStr + "', '" + mode + "')", function (res) {
                MT.toast("Captions created!", false);
                createBtn.textContent = 'CREATE CAPTIONS';
                createBtn.disabled = false;

                // Clean up
                if (self._captionAudioPath) {
                    window.cep.fs.deleteFile(self._captionAudioPath);
                    self._captionAudioPath = null;
                }
                self._captionData = null;
                self.closeCaptions();

                // Reset UI
                document.getElementById('cap-step1').style.display = '';
                document.getElementById('cap-step2').style.display = 'none';
                var btn = document.getElementById('cap-transcribe-btn');
                btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:6px"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg> TRANSCRIBE';
                btn.disabled = false;
            });
        },


        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• AI AGENT â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        // ============ QUEBRAR PALAVRAS (break words) ============
        _bwMode: 'words', // words | chars | lines

        openBreakWords: function () {
            document.getElementById('breakwords-overlay').classList.add('open');
        },
        closeBreakWords: function () {
            document.getElementById('breakwords-overlay').classList.remove('open');
        },

        setupBreakWords: function () {
            var self = this;
            var overlay = document.getElementById('breakwords-overlay');
            if (!overlay) return;
            var closeBtn = document.getElementById('btn-close-breakwords');
            if (closeBtn) closeBtn.addEventListener('click', function () { self.closeBreakWords(); });
            overlay.addEventListener('click', function (e) {
                if (e.target === this) self.closeBreakWords();
            });
            this.setBreakMode('words');
        },

        setBreakMode: function (mode) {
            this._bwMode = mode;
            var map = { words: 'btn-bw-words', chars: 'btn-bw-chars', lines: 'btn-bw-lines' };
            for (var key in map) {
                var el = document.getElementById(map[key]);
                if (el) el.classList.toggle('active', key === mode);
            }
        },

        applyBreakWords: function () {
            var self = this;
            var mode = this._bwMode || 'words';
            var keepEl = document.getElementById('bw-keep');
            var keep = keepEl && keepEl.checked ? 'true' : 'false';
            var ctrlEl = document.getElementById('bw-controls');
            var ctrl = (!ctrlEl || ctrlEl.checked) ? 'true' : 'false';
            var btn = document.getElementById('bw-apply-btn');
            if (btn) { btn.disabled = true; btn.classList.add('clicked'); }

            var script = 'breakTextIntoWords("' + mode + '", ' + keep + ', ' + ctrl + ')';
            csInterface.evalScript(script, function (res) {
                if (btn) { btn.disabled = false; btn.classList.remove('clicked'); }
                res = (res == null ? '' : ('' + res));
                if (/^\d+$/.test(res)) {
                    var n = parseInt(res, 10);
                    if (n > 0) {
                        MT.toast(n + ' camadas criadas!', false);
                        MT.closeBreakWords();
                    } else {
                        MT.toast('Nenhuma palavra encontrada no texto', true);
                    }
                } else if (res.indexOf('ERR:') === 0) {
                    MT.toast(res.substring(4), true);
                } else if (res.indexOf('EvalScript') !== -1 || res.indexOf('undefined') !== -1 || res === '') {
                    MT.toast('Recarregue o painel: feche e reabra a extensao', true);
                } else {
                    MT.toast(res, true);
                }
            });
        },

        // ============ TEXT EXPLODER (preset .ffx no playhead) ============
        _expVariant: 1, // 1 = Explosion.ffx | 2 = Explosion 2.ffx
        _expAnimFrame: null,
        _expAnimStart: 0,

        openTextExploder: function () {
            document.getElementById('exploder-overlay').classList.add('open');
            this.startExploderPreview();
        },
        closeTextExploder: function () {
            document.getElementById('exploder-overlay').classList.remove('open');
            this.stopExploderPreview();
        },

        setupTextExploder: function () {
            var self = this;
            var overlay = document.getElementById('exploder-overlay');
            if (!overlay) return;
            var closeBtn = document.getElementById('btn-close-exploder');
            if (closeBtn) closeBtn.addEventListener('click', function () { self.closeTextExploder(); });
            overlay.addEventListener('click', function (e) {
                if (e.target === this) self.closeTextExploder();
            });
            this.setExploderVariant(1);
        },

        setExploderVariant: function (v) {
            this._expVariant = v;
            var b1 = document.getElementById('btn-exp-1');
            var b2 = document.getElementById('btn-exp-2');
            if (b1) b1.classList.toggle('active', v === 1);
            if (b2) b2.classList.toggle('active', v === 2);
            this._expAnimStart = performance.now();
        },

        startExploderPreview: function () {
            this.stopExploderPreview();
            this._expAnimStart = performance.now();
            var self = this;
            var loop = function () {
                self.drawExploder();
                self._expAnimFrame = requestAnimationFrame(loop);
            };
            this._expAnimFrame = requestAnimationFrame(loop);
        },
        stopExploderPreview: function () {
            if (this._expAnimFrame) {
                cancelAnimationFrame(this._expAnimFrame);
                this._expAnimFrame = null;
            }
        },

        // pseudo-random deterministico por indice (0..1)
        _expHash: function (i, salt) {
            var x = Math.sin((i + 1) * 12.9898 + (salt || 0) * 78.233) * 43758.5453;
            return x - Math.floor(x);
        },

        drawExploder: function () {
            var canvas = document.getElementById('exploder-canvas');
            if (!canvas) return;
            var ctx = canvas.getContext('2d');
            var W = canvas.width, H = canvas.height;
            var v2 = (this._expVariant === 2);

            ctx.clearRect(0, 0, W, H);

            var word = 'EXPLODE';
            var chars = word.split('');
            var n = chars.length;

            var loopTime = 2.6;
            var elapsed = (performance.now() - this._expAnimStart) / 1000;
            var tg = elapsed % loopTime;

            // fases: 0..0.35 montado | 0.35..1.6 explode | resto pausa/reset
            var hold = 0.35, boom = 1.55;
            var e = 0;
            if (tg > hold) e = Math.min((tg - hold) / (boom - hold), 1);
            var ease = e * e * (3 - 2 * e); // smoothstep

            var fontSize = 26;
            ctx.font = '800 ' + fontSize + 'px "Segoe UI", sans-serif';
            ctx.textBaseline = 'middle';
            ctx.textAlign = 'center';

            // largura total pra centralizar
            var gap = 3, widths = [], total = 0;
            for (var m = 0; m < n; m++) { var w = ctx.measureText(chars[m]).width; widths.push(w); total += w + gap; }
            var startX = (W - total) / 2 + widths[0] / 2;
            var baseY = H * 0.5;
            var cx = startX;

            for (var i = 0; i < n; i++) {
                var ang = this._expHash(i, v2 ? 7 : 1) * Math.PI * 2;
                var upBias = v2 ? -0.6 : 0;                 // variante 2 explode mais pra cima
                var dist = (40 + this._expHash(i, 2) * (v2 ? 130 : 90)) * ease;
                var dx = Math.cos(ang) * dist;
                var dy = Math.sin(ang) * dist + upBias * dist;
                var spin = (this._expHash(i, 3) - 0.5) * (v2 ? 1080 : 540) * ease * Math.PI / 180;
                var scl = 1 - 0.75 * ease;
                var alpha = 1 - ease;

                var px = cx + dx;
                var py = baseY + dy;

                ctx.save();
                ctx.translate(px, py);
                ctx.rotate(spin);
                ctx.scale(scl, scl);
                ctx.globalAlpha = Math.max(0, alpha);
                // glow leve
                ctx.shadowColor = 'rgba(226,226,230,0.5)';
                ctx.shadowBlur = alpha > 0.5 ? 8 : 3;
                ctx.fillStyle = '#e8e8e8';
                ctx.fillText(chars[i], 0, 0);
                ctx.restore();

                cx += widths[i] + gap;
            }

            // marcador do playhead (linha vertical) no inicio
            ctx.strokeStyle = 'rgba(226,226,230,0.18)';
            ctx.setLineDash([2, 3]);
            ctx.beginPath();
            ctx.moveTo(startX - widths[0] / 2 - 12, 12);
            ctx.lineTo(startX - widths[0] / 2 - 12, H - 12);
            ctx.stroke();
            ctx.setLineDash([]);
            ctx.fillStyle = 'rgba(226,226,230,0.35)';
            ctx.font = '700 8px "Segoe UI", sans-serif';
            ctx.textAlign = 'left';
            ctx.fillText('PLAYHEAD', startX - widths[0] / 2 - 8, 16);
        },

        applyTextExploder: function () {
            var self = this;
            var which = this._expVariant === 2 ? 'Explosion 2.ffx' : 'Explosion.ffx';
            var extPath = csInterface.getSystemPath(SystemPath.EXTENSION);
            var full = extPath + '/presets/' + which;
            full = full.replace(/\\/g, '\\\\').replace(/'/g, "\\'");

            var btn = document.getElementById('exp-apply-btn');
            if (btn) { btn.disabled = true; btn.classList.add('clicked'); }

            csInterface.evalScript("applyTextExploder('" + full + "')", function (res) {
                if (btn) { btn.disabled = false; btn.classList.remove('clicked'); }
                res = (res == null ? '' : ('' + res));
                if (/^\d+$/.test(res)) {
                    var count = parseInt(res, 10);
                    if (count > 0) {
                        MT.toast('Explosão aplicada no playhead!', false);
                        MT.closeTextExploder();
                    } else {
                        MT.toast('Selecione uma camada de texto', true);
                    }
                } else if (res.indexOf('ERR:') === 0) {
                    MT.toast(res.substring(4), true);
                } else if (res.indexOf('EvalScript') !== -1 || res.indexOf('undefined') !== -1 || res === '') {
                    MT.toast('Recarregue o painel: feche e reabra a extensao', true);
                } else {
                    MT.toast(res, true);
                }
            });
        },

        // ============ ICONES (Feather local + Iconify online -> shape layer) ============
        _iconSize: 200,
        _iconStroke: 2,
        _iconColor: '#ffffff',
        _iconMode: 'local',        // local | online
        _iconLocalHtml: '',        // grade local pronta (cache)
        _iconOnlineCache: {},      // "prefix:name" -> {body, w, h, x, y}
        _iconSearchTimer: null,

        openIcons: function () {
            document.getElementById('icons-overlay').classList.add('open');
            var s = document.getElementById('icon-search');
            if (s) {
                s.value = '';
                if (this._iconMode === 'local') this._filterIcons('');
                else this._renderOnlineEmpty();
                setTimeout(function () { s.focus(); }, 50);
            }
        },
        closeIcons: function () {
            document.getElementById('icons-overlay').classList.remove('open');
        },

        setIconMode: function (mode) {
            this._iconMode = mode;
            var bl = document.getElementById('btn-icons-local');
            var bo = document.getElementById('btn-icons-online');
            if (bl) bl.classList.toggle('active', mode === 'local');
            if (bo) bo.classList.toggle('active', mode === 'online');
            var s = document.getElementById('icon-search');
            var grid = document.getElementById('icon-grid');
            if (mode === 'local') {
                s.placeholder = 'Buscar... (heart, star, play)';
                grid.innerHTML = this._iconLocalHtml;
                this._filterIcons(s.value);
            } else {
                s.placeholder = 'Buscar em 200.000+ ícones... (coffee, rocket)';
                if (s.value && s.value.length >= 2) this._iconSearchOnline(s.value);
                else this._renderOnlineEmpty();
            }
        },

        setupIcons: function () {
            var self = this;
            var overlay = document.getElementById('icons-overlay');
            if (!overlay || typeof MT_ICONS === 'undefined') return;
            var closeBtn = document.getElementById('btn-close-icons');
            if (closeBtn) closeBtn.addEventListener('click', function () { self.closeIcons(); });
            overlay.addEventListener('click', function (e) {
                if (e.target === this) self.closeIcons();
            });

            // monta a grade local (SVG real como preview) e guarda no cache
            var grid = document.getElementById('icon-grid');
            var names = [];
            for (var k in MT_ICONS) { if (MT_ICONS.hasOwnProperty(k)) names.push(k); }
            names.sort();
            var html = '';
            for (var n = 0; n < names.length; n++) {
                html += '<button class="icon-cell" data-icon="' + names[n] + '" title="' + names[n] + '">' +
                    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                    MT_ICONS[names[n]] + '</svg></button>';
            }
            this._iconLocalHtml = html;
            grid.innerHTML = html;
            grid.addEventListener('click', function (e) {
                var cell = e.target.closest ? e.target.closest('.icon-cell') : null;
                if (!cell) return;
                if (cell.getAttribute('data-icon')) self.applyIcon(cell.getAttribute('data-icon'), cell);
                else if (cell.getAttribute('data-full')) self.applyOnlineIcon(cell.getAttribute('data-full'), cell);
            });
            document.getElementById('icon-count').textContent = names.length + ' ícones';

            document.getElementById('icon-search').addEventListener('input', function () {
                if (self._iconMode === 'local') {
                    self._filterIcons(this.value);
                } else {
                    var term = this.value;
                    clearTimeout(self._iconSearchTimer);
                    if (!term || term.length < 2) { self._renderOnlineEmpty(); return; }
                    document.getElementById('icon-count').textContent = 'buscando...';
                    self._iconSearchTimer = setTimeout(function () { self._iconSearchOnline(term); }, 450);
                }
            });

            document.getElementById('sl-icon-size').addEventListener('input', function () {
                self._iconSize = parseInt(this.value, 10);
                document.getElementById('val-icon-size').textContent = this.value + 'px';
            });
            document.getElementById('sl-icon-stroke').addEventListener('input', function () {
                self._iconStroke = parseFloat(this.value);
                document.getElementById('val-icon-stroke').textContent = parseFloat(this.value).toFixed(1);
            });

            var colors = document.getElementById('icon-colors');
            colors.addEventListener('click', function (e) {
                var b = e.target.closest ? e.target.closest('.icon-c') : null;
                if (!b) return;
                self._iconColor = b.getAttribute('data-color');
                var all = colors.querySelectorAll('.icon-c');
                for (var i = 0; i < all.length; i++) all[i].classList.remove('active');
                b.classList.add('active');
            });
        },

        _filterIcons: function (term) {
            term = (term || '').toLowerCase().replace(/\s+/g, '-');
            var cells = document.querySelectorAll('#icon-grid .icon-cell');
            var shown = 0;
            for (var i = 0; i < cells.length; i++) {
                var ok = !term || cells[i].getAttribute('data-icon').indexOf(term) !== -1;
                cells[i].style.display = ok ? '' : 'none';
                if (ok) shown++;
            }
            document.getElementById('icon-count').textContent = shown + ' ícones';
        },

        applyIcon: function (name, cell) {
            if (!name || typeof MT_ICONS === 'undefined' || !MT_ICONS[name]) return;
            // icones Feather sao de traco (stroke) por natureza
            this._applyIconBody(name, MT_ICONS[name], 0, 0, 24, 24, true, cell);
        },

        _renderOnlineEmpty: function () {
            document.getElementById('icon-grid').innerHTML =
                '<div class="icon-empty">Digite pra buscar em 200.000+ ícones open-source<br>(Material, Tabler, Phosphor, Lucide...)<br><span>API gratuita Iconify</span></div>';
            document.getElementById('icon-count').textContent = 'online';
        },

        _iconSearchOnline: function (term) {
            var self = this;
            fetch('https://api.iconify.design/search?query=' + encodeURIComponent(term) + '&limit=96')
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (self._iconMode !== 'online') return;
                    self._renderOnlineResults(data && data.icons ? data.icons : []);
                })
                .catch(function () {
                    document.getElementById('icon-count').textContent = 'sem conexão';
                    MT.toast('Falha na busca online (internet?)', true);
                });
        },

        _renderOnlineResults: function (list) {
            var grid = document.getElementById('icon-grid');
            if (!list.length) {
                grid.innerHTML = '<div class="icon-empty">Nada encontrado — tenta outro termo (em inglês)</div>';
                document.getElementById('icon-count').textContent = '0 resultados';
                return;
            }
            var html = '';
            for (var i = 0; i < list.length; i++) {
                var full = list[i];
                var slash = full.replace(':', '/');
                html += '<button class="icon-cell" data-full="' + full + '" title="' + full + '">' +
                    '<img src="https://api.iconify.design/' + slash + '.svg?height=20&color=%23c9c9ce" loading="lazy" alt=""></button>';
            }
            grid.innerHTML = html;
            document.getElementById('icon-count').textContent = list.length + ' resultados';
        },

        applyOnlineIcon: function (full, cell) {
            var self = this;
            var cached = this._iconOnlineCache[full];
            if (cached) {
                this._applyIconBody(full.replace(':', ' '), cached.body, cached.x, cached.y, cached.w, cached.h, false, cell);
                return;
            }
            var parts = full.split(':');
            if (parts.length !== 2) return;
            if (cell) cell.classList.add('clicked');
            fetch('https://api.iconify.design/' + parts[0] + '.json?icons=' + encodeURIComponent(parts[1]))
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    var ic = data && data.icons && data.icons[parts[1]];
                    if (!ic || !ic.body) throw new Error('sem dados');
                    var entry = {
                        body: ic.body,
                        x: ic.left || data.left || 0,
                        y: ic.top || data.top || 0,
                        w: ic.width || data.width || 16,
                        h: ic.height || data.height || 16
                    };
                    self._iconOnlineCache[full] = entry;
                    self._applyIconBody(full.replace(':', ' '), entry.body, entry.x, entry.y, entry.w, entry.h, false, cell);
                })
                .catch(function () {
                    if (cell) cell.classList.remove('clicked');
                    MT.toast('Falha ao baixar o ícone', true);
                });
        },

        /**
         * Caminho comum: converte o corpo SVG e cria a shape layer no AE.
         * forceStroke: true = trata como icone de traco (Feather local);
         * false = detecta pelo corpo (stroke=... -> traco; senao preenchido).
         */
        _applyIconBody: function (name, body, vbX, vbY, vbW, vbH, forceStroke, cell) {
            var paths = this._svgToPaths(body);
            if (!paths.length) { MT.toast('Não consegui converter esse ícone', true); if (cell) cell.classList.remove('clicked'); return; }

            var isStroke = forceStroke || /stroke="currentColor"|stroke-width/.test(body);
            var fillRule = /fill-rule\s*=\s*"evenodd"/i.test(body) ? 2 : 1;

            // ---- animacao: icone animado importa ja animado (equivalente AE) ----
            var animSel = document.getElementById('icon-anim');
            var animMode = animSel ? animSel.value : 'auto';
            var hasAnim = /<animate|<set\b|@keyframes|animation[:-]/i.test(body);
            var animType = 'none';
            if (animMode === 'auto') {
                if (hasAnim) {
                    if (/animateTransform[^>]*type="rotate"/i.test(body)) animType = 'spin';
                    else if (isStroke) animType = 'draw';
                    else animType = 'pop';
                }
            } else if (animMode !== 'none') {
                animType = animMode; // draw | pop | spin forcado pelo usuario
            }
            // duracao extraida do proprio SVG (dur/begin), com fallback
            var animDur = 0.8;
            if (hasAnim) {
                var maxDur = 0, maxBegin = 0, am;
                var reD = /dur="([\d.]+)(m?s)"/g;
                while ((am = reD.exec(body)) !== null) maxDur = Math.max(maxDur, am[2] === 'ms' ? parseFloat(am[1]) / 1000 : parseFloat(am[1]));
                var reB = /begin="([\d.]+)(m?s)"/g;
                while ((am = reB.exec(body)) !== null) maxBegin = Math.max(maxBegin, am[2] === 'ms' ? parseFloat(am[1]) / 1000 : parseFloat(am[1]));
                if (maxDur > 0) animDur = Math.min(4, maxBegin + maxDur);
            }

            // ---- icone COLORIDO: importa com as cores/opacidades originais ----
            var coloredLikely = /(fill|stroke|stop-color)\s*[:=]\s*["']?\s*(#|rgb|hsl)/i.test(body);
            if (coloredLikely) {
                var els = this._svgToElements(body, vbX, vbY, vbW, vbH);
                var anyColor = false;
                for (var ce = 0; ce < els.length; ce++) {
                    if ((els[ce].fill && els[ce].fill !== 'user') || (els[ce].stroke && els[ce].stroke !== 'user')) { anyColor = true; break; }
                }
                if (anyColor && els.length) {
                    if (animType === 'draw') animType = 'pop'; // colorido e preenchido: pop no lugar
                    this._sendColorIcon(name, els, vbW, vbH, animType, animDur, cell);
                    return;
                }
            }

            // centra na origem e escala pro tamanho final
            var k = this._iconSize / Math.max(vbW, vbH);
            var ox = vbX + vbW / 2, oy = vbY + vbH / 2;
            var out = [];
            function rnd(x) { return Math.round(x * 100) / 100; }
            for (var p = 0; p < paths.length; p++) {
                var sp = paths[p], v = [], ti = [], to = [];
                for (var j = 0; j < sp.v.length; j++) {
                    v.push([rnd((sp.v[j][0] - ox) * k), rnd((sp.v[j][1] - oy) * k)]);
                    ti.push([rnd(sp.i[j][0] * k), rnd(sp.i[j][1] * k)]);
                    to.push([rnd(sp.o[j][0] * k), rnd(sp.o[j][1] * k)]);
                }
                out.push({ closed: sp.closed, v: v, i: ti, o: to });
            }

            var c = this._hexToRgb(this._iconColor);
            var json = JSON.stringify(out).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
            var splitEl = document.getElementById('icon-split');
            var split = (splitEl && splitEl.checked) ? 'true' : 'false';
            var script = "createIconFromJSON('" + name.replace(/[^a-zA-Z0-9 _-]/g, '') + "', '" + json + "', " +
                this._iconStroke + ", " + c[0] + ", " + c[1] + ", " + c[2] + ", " +
                (isStroke ? 'false' : 'true') + ", " + fillRule + ", '" + animType + "', " + animDur + ", " + split + ")";

            if (cell) cell.classList.add('clicked');
            csInterface.evalScript(script, function (res) {
                if (cell) setTimeout(function () { cell.classList.remove('clicked'); }, 350);
                res = (res == null ? '' : ('' + res));
                if (res === '1') {
                    MT.toast('Ícone "' + name + '" criado!', false);
                } else if (res.indexOf('ERR:') === 0) {
                    MT.toast(res.substring(4), true);
                } else {
                    MT.toast('Recarregue o painel: feche e reabra a extensao', true);
                }
            });
        },

        /**
         * Monta o payload do icone COLORIDO (cores/opacidades por elemento)
         * e envia pro host. Ordem invertida: no shape layer do AE o primeiro
         * item da lista renderiza NA FRENTE; no SVG o ultimo elemento fica
         * na frente.
         */
        _sendColorIcon: function (name, els, vbW, vbH, animType, animDur, cell) {
            var k = this._iconSize / Math.max(vbW, vbH);
            var ox = vbW / 2, oy = vbH / 2;
            var user = this._hexToRgb(this._iconColor);
            function rnd(x) { return Math.round(x * 100) / 100; }

            // funde elementos VIZINHOS com a mesma pintura num so (menos
            // grupos na shape layer = AE bem mais leve, emojis repetem cor)
            var merged = [];
            for (var m = 0; m < els.length; m++) {
                var sig = JSON.stringify([els[m].fill, els[m].fillOp, els[m].stroke, els[m].strokeOp, els[m].sw, els[m].rule]);
                if (merged.length && merged[merged.length - 1]._sig === sig) {
                    merged[merged.length - 1].paths = merged[merged.length - 1].paths.concat(els[m].paths);
                } else {
                    var cp = { paths: els[m].paths.slice(0), fill: els[m].fill, fillOp: els[m].fillOp, stroke: els[m].stroke, strokeOp: els[m].strokeOp, sw: els[m].sw, rule: els[m].rule, _sig: sig };
                    merged.push(cp);
                }
            }
            els = merged;

            var payload = [];
            for (var e = els.length - 1; e >= 0; e--) {
                var el = els[e];
                var paths = [];
                for (var p = 0; p < el.paths.length; p++) {
                    var sp = el.paths[p], v = [], ti = [], to = [];
                    for (var j = 0; j < sp.v.length; j++) {
                        v.push([rnd((sp.v[j][0] - ox) * k), rnd((sp.v[j][1] - oy) * k)]);
                        ti.push([rnd(sp.i[j][0] * k), rnd(sp.i[j][1] * k)]);
                        to.push([rnd(sp.o[j][0] * k), rnd(sp.o[j][1] * k)]);
                    }
                    paths.push({ closed: sp.closed, v: v, i: ti, o: to });
                }
                var fill = el.fill === 'user' ? user : el.fill;
                var stroke = el.stroke === 'user' ? user : el.stroke;
                payload.push({
                    paths: paths,
                    fill: fill ? [rnd(fill[0]), rnd(fill[1]), rnd(fill[2])] : null,
                    fillOp: rnd(el.fillOp),
                    stroke: stroke ? [rnd(stroke[0]), rnd(stroke[1]), rnd(stroke[2])] : null,
                    strokeOp: rnd(el.strokeOp),
                    sw: rnd(Math.max(0.1, el.sw * k)),
                    rule: el.rule
                });
            }

            var splitEl = document.getElementById('icon-split');
            var split = (splitEl && splitEl.checked) ? 'true' : 'false';
            var json = JSON.stringify(payload).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
            var script = "createColorIconFromJSON('" + name.replace(/[^a-zA-Z0-9 _-]/g, '') + "', '" + json + "', '" +
                animType + "', " + animDur + ", " + split + ")";

            if (cell) cell.classList.add('clicked');
            csInterface.evalScript(script, function (res) {
                if (cell) setTimeout(function () { cell.classList.remove('clicked'); }, 350);
                res = (res == null ? '' : ('' + res));
                if (res === '1') {
                    MT.toast('Ícone "' + name + '" criado (colorido)!', false);
                } else if (res.indexOf('ERR:') === 0) {
                    MT.toast(res.substring(4), true);
                } else {
                    MT.toast('Recarregue o painel: feche e reabra a extensao', true);
                }
            });
        },

        _hexToRgb: function (hex) {
            var h = (hex || '#ffffff').replace('#', '');
            if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
            var n = parseInt(h, 16);
            return [
                Math.round(((n >> 16) & 255) / 255 * 1000) / 1000,
                Math.round(((n >> 8) & 255) / 255 * 1000) / 1000,
                Math.round((n & 255) / 255 * 1000) / 1000
            ];
        },

        /**
         * Otimiza caminhos pro AE: remove vertices consecutivos duplicados
         * (dist < 0.05 e tangentes retas) e caminhos degenerados. Menos
         * vertices = shape layers mais leves = menos travamento no AE.
         */
        _optimizePaths: function (paths) {
            var out = [];
            for (var p = 0; p < paths.length; p++) {
                var sp = paths[p];
                var v = [], ti = [], to = [];
                for (var j = 0; j < sp.v.length; j++) {
                    if (v.length > 0) {
                        var lx = v[v.length - 1][0], ly = v[v.length - 1][1];
                        var straight = Math.abs(to[to.length - 1][0]) < 0.001 && Math.abs(to[to.length - 1][1]) < 0.001 &&
                                       Math.abs(sp.i[j][0]) < 0.001 && Math.abs(sp.i[j][1]) < 0.001;
                        if (straight && Math.abs(sp.v[j][0] - lx) < 0.05 && Math.abs(sp.v[j][1] - ly) < 0.05) {
                            // duplicado em cima do anterior: herda so a tangente de saida
                            to[to.length - 1] = sp.o[j];
                            continue;
                        }
                    }
                    v.push(sp.v[j]); ti.push(sp.i[j]); to.push(sp.o[j]);
                }
                if (v.length >= 2) out.push({ closed: sp.closed, v: v, i: ti, o: to });
            }
            return out;
        },

        // ---- conversor SVG -> caminhos bezier (v/i/o relativos, padrao AE) ----
        _svgToPaths: function (svgInner) {
            var paths = [];
            var tagRe = /<(path|circle|rect|line|polyline|polygon|ellipse)\b[^>]*>/g;
            var m;
            while ((m = tagRe.exec(svgInner)) !== null) {
                var tag = m[0], kind = m[1];
                var a = this._svgAttr;
                try {
                    if (kind === 'path') {
                        var d = a(tag, 'd');
                        if (d) this._parsePathD(d, paths);
                    } else if (kind === 'circle') {
                        this._pushEllipse(paths, +a(tag, 'cx') || 0, +a(tag, 'cy') || 0, +a(tag, 'r') || 0, +a(tag, 'r') || 0);
                    } else if (kind === 'ellipse') {
                        this._pushEllipse(paths, +a(tag, 'cx') || 0, +a(tag, 'cy') || 0, +a(tag, 'rx') || 0, +a(tag, 'ry') || 0);
                    } else if (kind === 'rect') {
                        this._pushRect(paths, +a(tag, 'x') || 0, +a(tag, 'y') || 0, +a(tag, 'width') || 0, +a(tag, 'height') || 0, +a(tag, 'rx') || 0);
                    } else if (kind === 'line') {
                        paths.push({ closed: false, v: [[+a(tag, 'x1') || 0, +a(tag, 'y1') || 0], [+a(tag, 'x2') || 0, +a(tag, 'y2') || 0]], i: [[0, 0], [0, 0]], o: [[0, 0], [0, 0]] });
                    } else if (kind === 'polyline' || kind === 'polygon') {
                        var pts = (a(tag, 'points') || '').replace(/,/g, ' ').split(/\s+/);
                        var v = [], t = [];
                        for (var q = 0; q + 1 < pts.length; q += 2) {
                            if (pts[q] === '') continue;
                            v.push([+pts[q], +pts[q + 1]]);
                            t.push([0, 0]);
                        }
                        if (v.length > 1) paths.push({ closed: kind === 'polygon', v: v, i: t.slice(0), o: t.slice(0) });
                    }
                } catch (e) { /* ignora elemento invalido */ }
            }
            return this._optimizePaths(paths);
        },

        _svgAttr: function (tag, name) {
            var re = new RegExp(name + '\\s*=\\s*"([^"]*)"');
            var m = re.exec(tag);
            return m ? m[1] : null;
        },

        _pushEllipse: function (paths, cx, cy, rx, ry) {
            if (rx <= 0 || ry <= 0) return;
            var K = 0.5522847498;
            paths.push({
                closed: true,
                v: [[cx + rx, cy], [cx, cy + ry], [cx - rx, cy], [cx, cy - ry]],
                i: [[0, -ry * K], [rx * K, 0], [0, ry * K], [-rx * K, 0]],
                o: [[0, ry * K], [-rx * K, 0], [0, -ry * K], [rx * K, 0]]
            });
        },

        _pushRect: function (paths, x, y, w, h, rx) {
            if (w <= 0 || h <= 0) return;
            if (!rx || rx <= 0) {
                paths.push({
                    closed: true,
                    v: [[x, y], [x + w, y], [x + w, y + h], [x, y + h]],
                    i: [[0, 0], [0, 0], [0, 0], [0, 0]],
                    o: [[0, 0], [0, 0], [0, 0], [0, 0]]
                });
                return;
            }
            rx = Math.min(rx, w / 2, h / 2);
            var K = 0.5522847498, kr = rx * K;
            paths.push({
                closed: true,
                v: [
                    [x + rx, y], [x + w - rx, y],
                    [x + w, y + rx], [x + w, y + h - rx],
                    [x + w - rx, y + h], [x + rx, y + h],
                    [x, y + h - rx], [x, y + rx]
                ],
                i: [
                    [-kr, 0], [0, 0],
                    [0, -kr], [0, 0],
                    [kr, 0], [0, 0],
                    [0, kr], [0, 0]
                ],
                o: [
                    [0, 0], [kr, 0],
                    [0, 0], [0, kr],
                    [0, 0], [-kr, 0],
                    [0, 0], [0, -kr]
                ]
            });
        },

        _parsePathD: function (d, paths) {
            var tokens = d.match(/[a-zA-Z]|-?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?/g);
            if (!tokens) return;
            var ti = 0;
            function num() { return parseFloat(tokens[ti++]); }

            var sp = null;            // subpath atual {v,i,o,closed}
            var cx = 0, cy = 0;       // ponto atual
            var sx = 0, sy = 0;       // inicio do subpath
            var pcx = null, pcy = null; // controle anterior (S/T)
            var cmd = '', lastCmd = '';

            function open(x, y) {
                sp = { closed: false, v: [[x, y]], i: [[0, 0]], o: [[0, 0]] };
                paths.push(sp);
            }
            function lineTo(x, y) {
                if (!sp) open(cx, cy);
                sp.v.push([x, y]); sp.i.push([0, 0]); sp.o.push([0, 0]);
            }
            function cubicTo(x1, y1, x2, y2, x, y) {
                if (!sp) open(cx, cy);
                var li = sp.v.length - 1;
                sp.o[li] = [x1 - sp.v[li][0], y1 - sp.v[li][1]];
                sp.v.push([x, y]);
                sp.i.push([x2 - x, y2 - y]);
                sp.o.push([0, 0]);
            }
            function closePath() {
                if (!sp || sp.v.length < 2) { sp = null; return; }
                var first = sp.v[0], last = sp.v[sp.v.length - 1];
                if (Math.abs(first[0] - last[0]) < 0.001 && Math.abs(first[1] - last[1]) < 0.001) {
                    // funde o ultimo vertice no primeiro (herda a tangente de chegada)
                    sp.i[0] = sp.i[sp.v.length - 1];
                    sp.v.pop(); sp.i.pop(); sp.o.pop();
                }
                sp.closed = true;
                sp = null;
            }

            while (ti < tokens.length) {
                var t = tokens[ti];
                if (/[a-zA-Z]/.test(t)) { cmd = t; ti++; }
                // comando implicito: M vira L nas repeticoes
                else if (cmd === 'M') cmd = 'L';
                else if (cmd === 'm') cmd = 'l';

                var rel = (cmd === cmd.toLowerCase());
                var C = cmd.toUpperCase();

                if (C === 'M') {
                    var x = num(), y = num();
                    if (rel) { x += cx; y += cy; }
                    cx = x; cy = y; sx = x; sy = y;
                    open(x, y);
                } else if (C === 'L') {
                    var x2 = num(), y2 = num();
                    if (rel) { x2 += cx; y2 += cy; }
                    lineTo(x2, y2); cx = x2; cy = y2;
                } else if (C === 'H') {
                    var xh = num(); if (rel) xh += cx;
                    lineTo(xh, cy); cx = xh;
                } else if (C === 'V') {
                    var yv = num(); if (rel) yv += cy;
                    lineTo(cx, yv); cy = yv;
                } else if (C === 'C') {
                    var a1 = num(), b1 = num(), a2 = num(), b2 = num(), ax = num(), ay = num();
                    if (rel) { a1 += cx; b1 += cy; a2 += cx; b2 += cy; ax += cx; ay += cy; }
                    cubicTo(a1, b1, a2, b2, ax, ay);
                    pcx = a2; pcy = b2; cx = ax; cy = ay;
                } else if (C === 'S') {
                    var s2x = num(), s2y = num(), sxx = num(), syy = num();
                    if (rel) { s2x += cx; s2y += cy; sxx += cx; syy += cy; }
                    var r1x = cx, r1y = cy;
                    if (lastCmd === 'C' || lastCmd === 'S') { r1x = 2 * cx - pcx; r1y = 2 * cy - pcy; }
                    cubicTo(r1x, r1y, s2x, s2y, sxx, syy);
                    pcx = s2x; pcy = s2y; cx = sxx; cy = syy;
                } else if (C === 'Q') {
                    var qx = num(), qy = num(), qex = num(), qey = num();
                    if (rel) { qx += cx; qy += cy; qex += cx; qey += cy; }
                    var c1x = cx + (2 / 3) * (qx - cx), c1y = cy + (2 / 3) * (qy - cy);
                    var c2x = qex + (2 / 3) * (qx - qex), c2y = qey + (2 / 3) * (qy - qey);
                    cubicTo(c1x, c1y, c2x, c2y, qex, qey);
                    pcx = qx; pcy = qy; cx = qex; cy = qey;
                } else if (C === 'T') {
                    var tex = num(), tey = num();
                    if (rel) { tex += cx; tey += cy; }
                    var rqx = cx, rqy = cy;
                    if (lastCmd === 'Q' || lastCmd === 'T') { rqx = 2 * cx - pcx; rqy = 2 * cy - pcy; }
                    var d1x = cx + (2 / 3) * (rqx - cx), d1y = cy + (2 / 3) * (rqy - cy);
                    var d2x = tex + (2 / 3) * (rqx - tex), d2y = tey + (2 / 3) * (rqy - tey);
                    cubicTo(d1x, d1y, d2x, d2y, tex, tey);
                    pcx = rqx; pcy = rqy; cx = tex; cy = tey;
                } else if (C === 'A') {
                    var arx = num(), ary = num(), rot = num(), laf = num(), swf = num(), aex = num(), aey = num();
                    if (rel) { aex += cx; aey += cy; }
                    var segs = this._arcToCubics(cx, cy, arx, ary, rot, laf, swf, aex, aey);
                    for (var g = 0; g < segs.length; g++) {
                        cubicTo(segs[g][0], segs[g][1], segs[g][2], segs[g][3], segs[g][4], segs[g][5]);
                    }
                    cx = aex; cy = aey;
                } else if (C === 'Z') {
                    closePath();
                    cx = sx; cy = sy;
                } else {
                    ti++; // token desconhecido, pula
                }
                lastCmd = C;
            }
        },

        // converte um arco SVG em segmentos cubicos (parametrizacao por centro)
        _arcToCubics: function (x1, y1, rx, ry, phiDeg, fa, fs, x2, y2) {
            var out = [];
            rx = Math.abs(rx); ry = Math.abs(ry);
            if (rx < 1e-6 || ry < 1e-6 || (x1 === x2 && y1 === y2)) {
                return [[x1, y1, x2, y2, x2, y2]];
            }
            var phi = phiDeg * Math.PI / 180;
            var cosP = Math.cos(phi), sinP = Math.sin(phi);

            var dx = (x1 - x2) / 2, dy = (y1 - y2) / 2;
            var x1p = cosP * dx + sinP * dy;
            var y1p = -sinP * dx + cosP * dy;

            var lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry);
            if (lam > 1) { var sl = Math.sqrt(lam); rx *= sl; ry *= sl; }

            var num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p;
            var den = rx * rx * y1p * y1p + ry * ry * x1p * x1p;
            var co = Math.sqrt(Math.max(0, num / den));
            if (fa === fs) co = -co;

            var cxp = co * rx * y1p / ry;
            var cyp = -co * ry * x1p / rx;
            var cxa = cosP * cxp - sinP * cyp + (x1 + x2) / 2;
            var cya = sinP * cxp + cosP * cyp + (y1 + y2) / 2;

            function ang(ux, uy, vx, vy) {
                var dot = ux * vx + uy * vy;
                var len = Math.sqrt((ux * ux + uy * uy) * (vx * vx + vy * vy));
                var a = Math.acos(Math.max(-1, Math.min(1, dot / len)));
                return (ux * vy - uy * vx < 0) ? -a : a;
            }
            var th1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry);
            var dth = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry);
            if (!fs && dth > 0) dth -= 2 * Math.PI;
            if (fs && dth < 0) dth += 2 * Math.PI;

            var nSegs = Math.max(1, Math.ceil(Math.abs(dth) / (Math.PI / 2)));
            var delta = dth / nSegs;
            var alpha = (4 / 3) * Math.tan(delta / 4);

            var th = th1;
            for (var s = 0; s < nSegs; s++) {
                var thNext = th + delta;
                var cos1 = Math.cos(th), sin1 = Math.sin(th);
                var cos2 = Math.cos(thNext), sin2 = Math.sin(thNext);

                function pt(cosT, sinT) {
                    var px = rx * cosT, py = ry * sinT;
                    return [cosP * px - sinP * py + cxa, sinP * px + cosP * py + cya];
                }
                function dpt(cosT, sinT) {
                    var dxr = -rx * sinT, dyr = ry * cosT;
                    return [cosP * dxr - sinP * dyr, sinP * dxr + cosP * dyr];
                }

                var p1 = pt(cos1, sin1), p2 = pt(cos2, sin2);
                var d1 = dpt(cos1, sin1), d2 = dpt(cos2, sin2);

                out.push([
                    p1[0] + alpha * d1[0], p1[1] + alpha * d1[1],
                    p2[0] - alpha * d2[0], p2[1] - alpha * d2[1],
                    p2[0], p2[1]
                ]);
                th = thNext;
            }
            return out;
        },

        // ============ ELEMENTOS (UIs prontas + bonecos + formas) ============
        _elemCat: 'ui', // ui | bonecos | formas
        _elemSearchTimer: null,
        _elemTemplates: [
            { id: 'chat', label: 'Chat conversa', svg: '<rect x="12" y="4" width="24" height="40" rx="4"/><rect x="16" y="12" width="12" height="6" rx="3" fill="currentColor" stroke="none"/><rect x="20" y="22" width="12" height="6" rx="3" fill="currentColor" stroke="none" opacity="0.5"/><rect x="16" y="36" width="16" height="4" rx="2" fill="currentColor" stroke="none" opacity="0.4"/>' },
            { id: 'aichat', label: 'Chat IA', svg: '<rect x="4" y="8" width="40" height="32" rx="4"/><circle cx="10" cy="20" r="2.5" fill="currentColor" stroke="none"/><path d="M16 18h20M16 23h24M16 28h16"/><rect x="10" y="32" width="24" height="4" rx="2" fill="currentColor" stroke="none" opacity="0.4"/>' },
            { id: 'phone', label: 'Celular', svg: '<rect x="14" y="4" width="20" height="40" rx="5"/><rect x="20" y="7" width="8" height="2.5" rx="1.2" fill="currentColor" stroke="none"/><rect x="19" y="39" width="10" height="2" rx="1" fill="currentColor" stroke="none" opacity="0.5"/>' },
            { id: 'browser', label: 'Navegador', svg: '<rect x="4" y="8" width="40" height="32" rx="3"/><path d="M4 16h40"/><circle cx="9" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="14" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.4" fill="currentColor" stroke="none"/><rect x="10" y="22" width="28" height="12" rx="2" fill="currentColor" stroke="none" opacity="0.25"/>' },
            { id: 'card', label: 'Notificação', svg: '<rect x="4" y="14" width="40" height="20" rx="5"/><rect x="8" y="18" width="12" height="12" rx="3" fill="currentColor" stroke="none"/><path d="M24 21h14M24 27h10"/>' },
            { id: 'player', label: 'Player', svg: '<rect x="6" y="10" width="36" height="24" rx="3"/><path d="M21 17l8 5-8 5z" fill="currentColor" stroke="none"/><path d="M10 39h28" opacity="0.4"/><path d="M10 39h12"/>' },
            { id: 'terminal', label: 'Terminal', svg: '<rect x="6" y="8" width="36" height="32" rx="3"/><path d="M6 15h36" opacity="0.5"/><path d="M12 22l5 4-5 4M20 30h10"/>' },
            { id: 'prompt', label: 'Barra de IA', svg: '<rect x="4" y="17" width="40" height="15" rx="7.5"/><path d="M9 23h12" opacity="0.5"/><circle cx="38" cy="24.5" r="3.5" fill="currentColor" stroke="none"/><path d="M4 12c3-3 7-4 10-3M44 37c-3 3-7 4-10 3" opacity="0.35"/>' },
            { id: 'gauge', label: 'Medidor', svg: '<path d="M13 34a15 15 0 1 1 22 0"/><path d="M13 34a15 15 0 0 1-4-12" opacity="0.3"/><rect x="19" y="19" width="10" height="9" rx="2" fill="currentColor" stroke="none" opacity="0.7"/><rect x="17" y="35" width="14" height="3.5" rx="1.7" fill="currentColor" stroke="none" opacity="0.4"/>' },
            { id: 'stats', label: 'Estatísticas', svg: '<rect x="6" y="7" width="36" height="15" rx="7.5"/><circle cx="14" cy="14.5" r="4"/><path d="M22 12h13M22 17h8" opacity="0.5"/><rect x="6" y="26" width="36" height="15" rx="7.5"/><circle cx="14" cy="33.5" r="4"/><path d="M22 31h13M22 36h8" opacity="0.5"/>' }
        ],

        // 30 apps estilo iOS (squircle + brilho + glifo Feather) — desenhos
        // genericos nossos, na vibe da Apple, sem copiar os icones originais.
        _appleApps: [
            { nome: 'Telefone', glifo: 'phone', bg: [0.20, 0.84, 0.29] },
            { nome: 'Mensagens', glifo: 'message-circle', bg: [0.13, 0.80, 0.25] },
            { nome: 'Mail', glifo: 'mail', bg: [0.11, 0.56, 0.95] },
            { nome: 'Câmera', glifo: 'camera', bg: [0.45, 0.45, 0.48] },
            { nome: 'Fotos', glifo: 'aperture', bg: [0.98, 0.98, 0.98], gc: [0.95, 0.35, 0.25] },
            { nome: 'Música', glifo: 'music', bg: [0.98, 0.24, 0.44] },
            { nome: 'Navegador', glifo: 'compass', bg: [0.15, 0.48, 0.99] },
            { nome: 'Ajustes', glifo: 'settings', bg: [0.52, 0.55, 0.58] },
            { nome: 'Relógio', glifo: 'clock', bg: [0.08, 0.08, 0.10] },
            { nome: 'Calendário', glifo: 'calendar', bg: [0.98, 0.98, 0.98], gc: [1.0, 0.23, 0.19] },
            { nome: 'Calculadora', glifo: 'percent', bg: [1.0, 0.58, 0.0] },
            { nome: 'Mapas', glifo: 'map-pin', bg: [0.30, 0.75, 0.98] },
            { nome: 'Clima', glifo: 'sun', bg: [0.25, 0.60, 0.98], gc: [1.0, 0.80, 0.20] },
            { nome: 'Notas', glifo: 'file-text', bg: [0.99, 0.97, 0.89], gc: [0.85, 0.65, 0.13] },
            { nome: 'Lembretes', glifo: 'check-circle', bg: [0.98, 0.98, 0.98], gc: [0.35, 0.55, 0.98] },
            { nome: 'Vídeo', glifo: 'video', bg: [0.20, 0.84, 0.29] },
            { nome: 'Loja', glifo: 'shopping-bag', bg: [0.16, 0.55, 0.98] },
            { nome: 'Carteira', glifo: 'credit-card', bg: [0.10, 0.10, 0.12] },
            { nome: 'Saúde', glifo: 'heart', bg: [0.98, 0.98, 0.98], gc: [1.0, 0.20, 0.35] },
            { nome: 'Atividade', glifo: 'activity', bg: [0.08, 0.08, 0.10], gc: [0.65, 1.0, 0.10] },
            { nome: 'Podcasts', glifo: 'radio', bg: [0.58, 0.31, 0.95] },
            { nome: 'Livros', glifo: 'book-open', bg: [1.0, 0.48, 0.12] },
            { nome: 'TV', glifo: 'tv', bg: [0.08, 0.08, 0.10] },
            { nome: 'Arquivos', glifo: 'folder', bg: [0.98, 0.98, 0.98], gc: [0.15, 0.48, 0.99] },
            { nome: 'Ações', glifo: 'trending-up', bg: [0.08, 0.08, 0.10], gc: [0.25, 0.90, 0.50] },
            { nome: 'Casa', glifo: 'home', bg: [1.0, 0.60, 0.15] },
            { nome: 'Notícias', glifo: 'rss', bg: [0.98, 0.23, 0.30] },
            { nome: 'Gravador', glifo: 'mic', bg: [0.12, 0.12, 0.14], gc: [1.0, 0.27, 0.25] },
            { nome: 'Contatos', glifo: 'user', bg: [0.90, 0.90, 0.92], gc: [0.35, 0.35, 0.40] },
            { nome: 'Traduzir', glifo: 'globe', bg: [0.15, 0.42, 0.90] }
        ],

        _renderApps: function () {
            var grid = document.getElementById('elem-grid');
            function rgb(c) { return 'rgb(' + Math.round(c[0] * 255) + ',' + Math.round(c[1] * 255) + ',' + Math.round(c[2] * 255) + ')'; }
            var html = '';
            for (var i = 0; i < this._appleApps.length; i++) {
                var a = this._appleApps[i];
                var gc = a.gc || [1, 1, 1];
                html += '<button class="icon-cell" data-app="' + i + '" title="' + a.nome + '">' +
                    '<svg viewBox="0 0 24 24"><rect x="2" y="2" width="20" height="20" rx="5" fill="' + rgb(a.bg) + '"/>' +
                    '<g fill="none" stroke="' + rgb(gc) + '" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" transform="translate(12 12) scale(0.5) translate(-12 -12)">' +
                    (typeof MT_ICONS !== 'undefined' ? MT_ICONS[a.glifo] || '' : '') + '</g></svg></button>';
            }
            grid.innerHTML = html;
            document.getElementById('elem-count').textContent = this._appleApps.length + ' apps';
        },

        /**
         * Monta o icone de app estilo iOS: squircle colorido + brilho na
         * metade de cima + glifo. Reusa o pipeline colorido inteiro
         * (createColorIconFromJSON) — cores, split e tamanho do modal Ícones.
         */
        _applyAppleIcon: function (idx, cell) {
            var a = this._appleApps[idx];
            if (!a || typeof MT_ICONS === 'undefined' || !MT_ICONS[a.glifo]) return;
            var els = [];

            // fundo squircle (cantos ~21% estilo iOS)
            var tmp = [];
            this._pushRect(tmp, 4, 4, 92, 92, 21);
            els.push({ paths: tmp, fill: a.bg, fillOp: 1, stroke: null, strokeOp: 1, sw: 1, rule: 1 });

            // brilho: metade superior com cantos de cima arredondados
            els.push({ paths: [this._appleTopShine(4, 4, 92, 46, 21)], fill: [1, 1, 1], fillOp: 0.14, stroke: null, strokeOp: 1, sw: 1, rule: 1 });

            // glifo Feather centrado a ~52% do quadro
            var gpaths = this._svgToPaths(MT_ICONS[a.glifo]);
            var k2 = 52 / 24;
            var glifo = [];
            for (var p = 0; p < gpaths.length; p++) {
                var sp = gpaths[p], v = [], ti = [], to = [];
                for (var j = 0; j < sp.v.length; j++) {
                    v.push([(sp.v[j][0] - 12) * k2 + 50, (sp.v[j][1] - 12) * k2 + 50]);
                    ti.push([sp.i[j][0] * k2, sp.i[j][1] * k2]);
                    to.push([sp.o[j][0] * k2, sp.o[j][1] * k2]);
                }
                glifo.push({ closed: sp.closed, v: v, i: ti, o: to });
            }
            els.push({ paths: glifo, fill: null, fillOp: 1, stroke: a.gc || [1, 1, 1], strokeOp: 1, sw: 5, rule: 1 });

            var animEl = document.getElementById('elem-anim');
            var anim = (animEl && animEl.checked) ? 'pop' : 'none';
            this._sendColorIcon('app ' + a.nome, els, 100, 100, anim, 0.5, cell);
        },

        // retangulo com SO os cantos de cima arredondados (brilho do squircle)
        _appleTopShine: function (x, y, w, h, r) {
            var K = 0.5522847498, kr = r * K;
            return {
                closed: true,
                v: [[x + r, y], [x + w - r, y], [x + w, y + r], [x + w, y + h], [x, y + h], [x, y + r]],
                i: [[-kr, 0], [0, 0], [0, -kr], [0, 0], [0, 0], [0, 0]],
                o: [[0, 0], [kr, 0], [0, 0], [0, 0], [0, 0], [0, -kr]]
            };
        },

        openElements: function () {
            document.getElementById('elements-overlay').classList.add('open');
            this.setElemCat(this._elemCat || 'ui');
        },
        closeElements: function () {
            document.getElementById('elements-overlay').classList.remove('open');
        },

        setupElements: function () {
            var self = this;
            var overlay = document.getElementById('elements-overlay');
            if (!overlay) return;
            var closeBtn = document.getElementById('btn-close-elements');
            if (closeBtn) closeBtn.addEventListener('click', function () { self.closeElements(); });
            overlay.addEventListener('click', function (e) {
                if (e.target === this) self.closeElements();
            });

            var grid = document.getElementById('elem-grid');
            grid.addEventListener('click', function (e) {
                var cell = e.target.closest ? e.target.closest('[data-tpl],[data-full],[data-app]') : null;
                if (!cell) return;
                if (cell.getAttribute('data-tpl')) self.applyUITemplate(cell.getAttribute('data-tpl'), cell);
                else if (cell.getAttribute('data-app') !== null && cell.getAttribute('data-app') !== undefined && cell.hasAttribute('data-app')) self._applyAppleIcon(parseInt(cell.getAttribute('data-app'), 10), cell);
                else self.applyOnlineIcon(cell.getAttribute('data-full'), cell);
            });

            document.getElementById('elem-search').addEventListener('input', function () {
                if (self._elemCat === 'ui') return;
                var term = this.value;
                clearTimeout(self._elemSearchTimer);
                document.getElementById('elem-count').textContent = 'buscando...';
                self._elemSearchTimer = setTimeout(function () { self._elemSearch(term); }, 450);
            });
        },

        setElemCat: function (cat) {
            this._elemCat = cat;
            var ids = { ui: 'btn-elem-ui', apps: 'btn-elem-apps', bonecos: 'btn-elem-bonecos', formas: 'btn-elem-formas' };
            for (var k in ids) {
                var b = document.getElementById(ids[k]);
                if (b) b.classList.toggle('active', k === cat);
            }
            var toolbar = document.getElementById('elem-toolbar');
            var animRow = document.getElementById('elem-anim-row');
            var s = document.getElementById('elem-search');
            if (cat === 'ui') {
                toolbar.style.display = 'none';
                animRow.style.display = '';
                this._renderTemplates();
            } else if (cat === 'apps') {
                toolbar.style.display = 'none';
                animRow.style.display = '';
                this._renderApps();
            } else {
                toolbar.style.display = '';
                animRow.style.display = 'none';
                s.placeholder = cat === 'bonecos' ? 'Buscar bonecos... (person, robot, dance)' : 'Buscar formas... (sword, skull, arrow)';
                s.value = '';
                this._elemSearch('');
            }
        },

        _renderTemplates: function () {
            var grid = document.getElementById('elem-grid');
            var html = '';
            for (var i = 0; i < this._elemTemplates.length; i++) {
                var t = this._elemTemplates[i];
                html += '<button class="elem-card" data-tpl="' + t.id + '" title="' + t.label + '">' +
                    '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + t.svg + '</svg>' +
                    '<span>' + t.label + '</span></button>';
            }
            grid.innerHTML = html;
            document.getElementById('elem-count').textContent = this._elemTemplates.length + ' templates';
        },

        _elemSearch: function (term) {
            var self = this;
            var cat = this._elemCat;
            var prefixes = cat === 'bonecos' ? 'fluent-emoji,noto,openmoji,twemoji' : 'game-icons,healthicons,map';
            var q = (term && term.length >= 2) ? term : (cat === 'bonecos' ? 'person' : 'star');
            fetch('https://api.iconify.design/search?query=' + encodeURIComponent(q) + '&limit=96&prefixes=' + prefixes)
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (self._elemCat !== cat) return;
                    var list = (data && data.icons) ? data.icons : [];
                    var grid = document.getElementById('elem-grid');
                    if (!list.length) {
                        grid.innerHTML = '<div class="icon-empty">Nada encontrado — tenta outro termo (em inglês)</div>';
                        document.getElementById('elem-count').textContent = '0 resultados';
                        return;
                    }
                    var html = '';
                    for (var i = 0; i < list.length; i++) {
                        var slash = list[i].replace(':', '/');
                        html += '<button class="icon-cell" data-full="' + list[i] + '" title="' + list[i] + '">' +
                            '<img src="https://api.iconify.design/' + slash + '.svg?height=20&color=%23c9c9ce" loading="lazy" alt=""></button>';
                    }
                    grid.innerHTML = html;
                    document.getElementById('elem-count').textContent = list.length + ' resultados';
                })
                .catch(function () {
                    document.getElementById('elem-count').textContent = 'sem conexão';
                    MT.toast('Falha na busca online (internet?)', true);
                });
        },

        applyUITemplate: function (kind, cell) {
            var animEl = document.getElementById('elem-anim');
            var anim = (animEl && animEl.checked) ? 'true' : 'false';
            if (cell) cell.classList.add('clicked');
            csInterface.evalScript("createUITemplate('" + kind + "', " + anim + ")", function (res) {
                if (cell) setTimeout(function () { cell.classList.remove('clicked'); }, 350);
                res = (res == null ? '' : ('' + res));
                if (/^\d+$/.test(res)) {
                    MT.toast('UI criada (' + res + ' camadas)!', false);
                } else if (res.indexOf('ERR:') === 0) {
                    MT.toast(res.substring(4), true);
                } else {
                    MT.toast('Recarregue o painel: feche e reabra a extensao', true);
                }
            });
        },

        /**
         * Conversor COLORIDO: injeta o SVG escondido no DOM e usa o proprio
         * navegador pra resolver cores/heranca/estilos (getComputedStyle) e
         * transforms acumulados (getCTM). Retorna elementos em ordem do
         * documento: [{ paths, fill, fillOp, stroke, strokeOp, sw, rule }]
         * fill/stroke: [r,g,b] 0-1 | 'user' (currentColor) | null (sem pintura)
         */
        _svgToElements: function (body, vbX, vbY, vbW, vbH) {
            var holder = document.createElement('div');
            holder.style.cssText = 'position:absolute;left:-99999px;top:0;pointer-events:none;';
            holder.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="' + vbW + '" height="' + vbH +
                '" viewBox="' + vbX + ' ' + vbY + ' ' + vbW + ' ' + vbH + '" style="color:rgb(1,2,3)">' + body + '</svg>';
            document.body.appendChild(holder);
            var out = [];
            try {
                var svg = holder.querySelector('svg');
                var els = svg.querySelectorAll('path,circle,rect,line,polyline,polygon,ellipse');
                for (var e = 0; e < els.length; e++) {
                    var el = els[e];
                    if (el.closest && el.closest('defs,clipPath,mask,symbol,pattern')) continue;

                    // geometria (mesmos conversores da versao mono)
                    var paths = [];
                    var tn = el.tagName.toLowerCase();
                    if (tn === 'path') {
                        var d = el.getAttribute('d');
                        if (d) this._parsePathD(d, paths);
                    } else if (tn === 'circle') {
                        var rr = +el.getAttribute('r') || 0;
                        this._pushEllipse(paths, +el.getAttribute('cx') || 0, +el.getAttribute('cy') || 0, rr, rr);
                    } else if (tn === 'ellipse') {
                        this._pushEllipse(paths, +el.getAttribute('cx') || 0, +el.getAttribute('cy') || 0, +el.getAttribute('rx') || 0, +el.getAttribute('ry') || 0);
                    } else if (tn === 'rect') {
                        this._pushRect(paths, +el.getAttribute('x') || 0, +el.getAttribute('y') || 0, +el.getAttribute('width') || 0, +el.getAttribute('height') || 0, +el.getAttribute('rx') || 0);
                    } else if (tn === 'line') {
                        paths.push({ closed: false, v: [[+el.getAttribute('x1') || 0, +el.getAttribute('y1') || 0], [+el.getAttribute('x2') || 0, +el.getAttribute('y2') || 0]], i: [[0, 0], [0, 0]], o: [[0, 0], [0, 0]] });
                    } else {
                        var pts = (el.getAttribute('points') || '').replace(/,/g, ' ').split(/\s+/);
                        var pv = [], pt2 = [];
                        for (var q = 0; q + 1 < pts.length; q += 2) {
                            if (pts[q] === '') continue;
                            pv.push([+pts[q], +pts[q + 1]]);
                            pt2.push([0, 0]);
                        }
                        if (pv.length > 1) paths.push({ closed: tn === 'polygon', v: pv, i: pt2.slice(0), o: pt2.slice(0) });
                    }
                    if (!paths.length) continue;

                    // transform acumulado (viewBox + transforms de <g> e do elemento)
                    var mx = null;
                    try { mx = el.getCTM(); } catch (eM) {}
                    for (var p = 0; p < paths.length; p++) {
                        var sp = paths[p];
                        for (var j = 0; j < sp.v.length; j++) {
                            var vx = sp.v[j][0], vy = sp.v[j][1];
                            if (mx) sp.v[j] = [mx.a * vx + mx.c * vy + mx.e, mx.b * vx + mx.d * vy + mx.f];
                            else sp.v[j] = [vx - vbX, vy - vbY];
                            var ix = sp.i[j][0], iy = sp.i[j][1];
                            var ox2 = sp.o[j][0], oy2 = sp.o[j][1];
                            if (mx) {
                                sp.i[j] = [mx.a * ix + mx.c * iy, mx.b * ix + mx.d * iy];
                                sp.o[j] = [mx.a * ox2 + mx.c * oy2, mx.b * ox2 + mx.d * oy2];
                            }
                        }
                    }

                    paths = this._optimizePaths(paths);
                    if (!paths.length) continue;

                    // pintura efetiva (resolve heranca, <style>, currentColor)
                    var cs = window.getComputedStyle(el);
                    var fill = this._cssPaint(cs.fill, svg);
                    var stroke = this._cssPaint(cs.stroke, svg);
                    if (!fill && !stroke) continue; // invisivel
                    var op = parseFloat(cs.opacity); if (isNaN(op)) op = 1;
                    var fo = parseFloat(cs.fillOpacity); if (isNaN(fo)) fo = 1;
                    var so = parseFloat(cs.strokeOpacity); if (isNaN(so)) so = 1;
                    var sw = parseFloat(cs.strokeWidth); if (isNaN(sw)) sw = 1;

                    out.push({
                        paths: paths,
                        fill: fill, fillOp: Math.max(0, Math.min(1, op * fo)),
                        stroke: stroke, strokeOp: Math.max(0, Math.min(1, op * so)),
                        sw: sw,
                        rule: (cs.fillRule === 'evenodd') ? 2 : 1
                    });
                }
            } catch (eAll) { out = []; }
            document.body.removeChild(holder);
            return out;
        },

        // 'rgb(...)'/'rgba(...)' -> [r,g,b] 0-1 | 'none' -> null | url(#grad) -> 1a stop | sentinela -> 'user'
        _cssPaint: function (val, svg) {
            if (!val || val === 'none') return null;
            var m = /rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)(?:[,\s\/]+([\d.%]+))?\s*\)/.exec(val);
            if (m) {
                var r = +m[1], g = +m[2], b = +m[3];
                if (r === 1 && g === 2 && b === 3) return 'user'; // sentinela = currentColor
                if (m[4] !== undefined && parseFloat(m[4]) === 0) return null;
                return [Math.round(r / 255 * 1000) / 1000, Math.round(g / 255 * 1000) / 1000, Math.round(b / 255 * 1000) / 1000];
            }
            var u = /url\(["']?#([^"')]+)/.exec(val);
            if (u && svg) {
                // gradiente -> cor solida da primeira stop (AE nao aceita gradiente via script)
                var grad = svg.querySelector('[id="' + u[1] + '"]');
                var stop = grad ? grad.querySelector('stop') : null;
                if (stop) {
                    var sc = null;
                    try { sc = window.getComputedStyle(stop).stopColor; } catch (eS) {}
                    if (!sc) sc = stop.getAttribute('stop-color');
                    var solved = sc ? this._cssPaint(sc, null) : null;
                    if (solved && solved !== 'user') return solved;
                }
                return [0.5, 0.5, 0.5];
            }
            return 'user';
        },

        _aiMsgs: [],
        _aiBusy: false,
        _aiFixCount: 0,
        _aiKey: '',

        _aiPrompt: AI_SYSTEM_PROMPT,

        _loadAIKnowledge: function () {
            try {
                var extPath = csInterface.getSystemPath(SystemPath.EXTENSION);

                // So os .md de conhecimento puro (regras/principios). JSX templates removidos.
                var mdFiles = [
                    { file: 'knowledge-padrao-final.md',       label: 'PADRAO FINAL OBRIGATORIO' },
                    { file: 'knowledge-anti-erros.md',         label: 'ANTI-ERROS (ES3, common pitfalls)' },
                    { file: 'knowledge-cenas-complexas.md',    label: 'CENAS COMPLEXAS (multi-elemento, timing)' },
                    { file: 'knowledge-criatividade.md',       label: 'CRIATIVIDADE OBRIGATORIA' },
                    { file: 'knowledge-efeitos-avancados.md',  label: 'EFEITOS AVANCADOS' },
                    { file: 'knowledge-motion-graphics.md',    label: 'MOTION GRAPHICS (principios)' },
                    { file: 'knowledge-viral-storytelling.md', label: 'VIRAL REEL STORYTELLING' }
                ];

                var kb = '\n\n# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n';
                kb += '# CONHECIMENTO E PADROES (REGRAS OBRIGATORIAS)\n';
                kb += '# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n\n';

                var mdLoaded = 0;
                var mdContent = '';
                var kbMaxChars = 120000; // ~120KB (~30K tokens)
                var kbChars = kb.length;
                for (var mi = 0; mi < mdFiles.length; mi++) {
                    var mf = window.cep.fs.readFile(extPath + '/docs/' + mdFiles[mi].file);
                    if (mf.err === 0 && mf.data) {
                        var mdEntry = '\n\n## ' + mdFiles[mi].label + '\n\n' + mf.data + '\n';
                        if (kbChars + mdEntry.length > kbMaxChars) continue;
                        kb += mdEntry;
                        mdContent += mdEntry;
                        kbChars += mdEntry.length;
                        mdLoaded++;
                    }
                }

                kb += '\n\n## TUDO DENTRO DO FRAME\n';
                kb += 'A comp tem W x H. Todos os elementos precisam estar COMPLETAMENTE visiveis.\n';
                kb += 'fontSize proporcional: title=W*0.08, subtitle=W*0.045, body=W*0.028.\n';
                kb += 'Se nao couber, REDUZA fontSize ou quebre em 2 layers. Nunca deixe vazar.\n';

                this._aiPrompt = AI_SYSTEM_PROMPT + kb;

                // Modo agente: sÃ³ AI_AGENT_PROMPT + MDs resumidos. Sem templates JSX.
                var agentKB = '\n\n# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n';
                agentKB += '# PRINCIPIOS DE MOTION DESIGN\n';
                agentKB += '# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n';
                agentKB += mdContent.length > 25000 ? mdContent.substring(0, 25000) + '\n\n[...truncado...]\n' : mdContent;

                this._aiAgentPrompt = (typeof AI_AGENT_PROMPT !== 'undefined' ? AI_AGENT_PROMPT : '') + agentKB;

                console.log('[MultiTools] AI knowledge (SCRIPT): ' + (this._aiPrompt.length / 1024).toFixed(0) + 'KB (' + mdLoaded + ' MDs)');
                console.log('[MultiTools] AI knowledge (AGENT):  ' + (this._aiAgentPrompt.length / 1024).toFixed(0) + 'KB (' + mdLoaded + ' MDs)');
            } catch (e) {
                this._aiPrompt = AI_SYSTEM_PROMPT;
                this._aiAgentPrompt = (typeof AI_AGENT_PROMPT !== 'undefined' ? AI_AGENT_PROMPT : '');
            }
        },

        _aiAudioTranscript: null,
        _aiUserImages: [], // [{name, path, b64thumb}]

        openAI: function () {
            if (!localStorage.getItem('multiTools_aiBetaSeen')) {
                document.getElementById('ai-beta-overlay').classList.add('open');
                return;
            }
            document.getElementById('ai-panel').classList.add('open');
            // Aplica estado do toggle salvo
        },
        closeAI: function () { document.getElementById('ai-panel').classList.remove('open'); },

        _acceptBeta: function () {
            localStorage.setItem('multiTools_aiBetaSeen', '1');
            document.getElementById('ai-beta-overlay').classList.remove('open');
            document.getElementById('ai-panel').classList.add('open');
        },

        // Import images from user's computer
        aiAddImages: function () {
            var self = this;
            var input = document.createElement('input');
            input.type = 'file';
            input.multiple = true;
            input.accept = 'image/png,image/jpeg,image/jpg,image/webp';
            input.onchange = function () {
                var files = input.files;
                if (!files || files.length === 0) return;

                for (var i = 0; i < files.length; i++) {
                    (function (file) {
                        var reader = new FileReader();
                        reader.onload = function (e) {
                            var b64 = e.target.result.split(',')[1];
                            var idx = self._aiUserImages.length;

                            // Save to temp via ExtendScript
                            csInterface.evalScript('Folder.temp.fsName', function (td) {
                                var filePath = td + '/mt_user_img_' + idx + '.png';
                                window.cep.fs.writeFile(filePath, b64, cep.encoding.Base64);

                                self._aiUserImages.push({
                                    name: file.name,
                                    path: filePath,
                                    thumb: e.target.result
                                });

                                self._aiUpdateImgPanel();
                            });
                        };
                        reader.readAsDataURL(file);
                    })(files[i]);
                }
            };
            input.click();
        },

        aiClearImages: function () {
            // Delete temp files
            for (var i = 0; i < this._aiUserImages.length; i++) {
                try { window.cep.fs.deleteFile(this._aiUserImages[i].path); } catch (e) {}
            }
            this._aiUserImages = [];
            this._aiUpdateImgPanel();
        },

        _aiRemoveImage: function (idx) {
            try { window.cep.fs.deleteFile(this._aiUserImages[idx].path); } catch (e) {}
            this._aiUserImages.splice(idx, 1);
            // Re-index remaining files
            for (var i = 0; i < this._aiUserImages.length; i++) {
                var self = this;
                (function (newIdx, img) {
                    csInterface.evalScript('Folder.temp.fsName', function (td) {
                        var newPath = td + '/mt_user_img_' + newIdx + '.png';
                        if (img.path !== newPath) {
                            // Read and rewrite with new index
                            var r = window.cep.fs.readFile(img.path, cep.encoding.Base64);
                            if (r.err === 0) {
                                window.cep.fs.writeFile(newPath, r.data, cep.encoding.Base64);
                                try { window.cep.fs.deleteFile(img.path); } catch (e) {}
                                img.path = newPath;
                            }
                        }
                    });
                })(i, this._aiUserImages[i]);
            }
            this._aiUpdateImgPanel();
        },

        _aiUpdateImgPanel: function () {
            var panel = document.getElementById('ai-imgs');
            var list = document.getElementById('ai-imgs-list');
            var count = document.getElementById('ai-imgs-count');

            if (this._aiUserImages.length === 0) {
                panel.style.display = 'none';
                return;
            }

            panel.style.display = '';
            count.textContent = this._aiUserImages.length + ' imagem(ns)';
            list.innerHTML = '';

            var self = this;
            for (var i = 0; i < this._aiUserImages.length; i++) {
                (function (idx) {
                    var item = document.createElement('div');
                    item.className = 'ai-img-item';

                    var thumb = document.createElement('img');
                    thumb.className = 'ai-img-thumb';
                    thumb.src = self._aiUserImages[idx].thumb;
                    thumb.title = self._aiUserImages[idx].name;

                    var removeBtn = document.createElement('button');
                    removeBtn.className = 'ai-img-remove';
                    removeBtn.textContent = 'x';
                    removeBtn.onclick = function (e) {
                        e.stopPropagation();
                        self._aiRemoveImage(idx);
                    };

                    item.appendChild(thumb);
                    item.appendChild(removeBtn);
                    list.appendChild(item);
                })(i);
            }
        },

        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• IMPORTAR AUDIO â€” IA CRIA MOTION SINCRONIZADO â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        // Fluxo: user importa audio (<=15s) -> Whisper transcreve com word timestamps ->
        // Gemini analisa o tema -> junta com prompt universal SaaS -> gera motion sincronizado com a fala.
        aiImportAudio: function () {
            var self = this;

            var groqKey = localStorage.getItem('multiTools_groqKey');
            if (!groqKey) { MT.toast('Configure a API Key Groq nas configuracoes', true); return; }
            var provider = self._aiGetProvider();
            if (!provider) { MT.toast('Configure a chave Ollama Cloud nas configuracoes', true); return; }

            var input = document.createElement('input');
            input.type = 'file';
            input.accept = 'audio/mp3,audio/mpeg,audio/wav,audio/m4a,audio/x-m4a,audio/ogg,audio/webm,audio/*';
            input.onchange = function () {
                var file = input.files && input.files[0];
                if (!file) return;

                // Tamanho razoavel â€” 25MB max (15s de audio raramente passa disso)
                if (file.size > 25 * 1024 * 1024) {
                    MT.toast('Audio muito grande (max 25MB)', true);
                    return;
                }

                var welcome = document.querySelector('.ai-welcome');
                if (welcome) welcome.remove();

                self._aiAddMsg('user', 'ðŸŽ™ ' + file.name + ' (' + (file.size / 1024).toFixed(0) + ' KB)');
                self._aiStatus('Verificando duracao do audio...');

                // Verificar duracao via <audio> element
                var audioEl = document.createElement('audio');
                var objUrl = URL.createObjectURL(file);
                audioEl.src = objUrl;
                audioEl.onloadedmetadata = function () {
                    var dur = audioEl.duration;
                    URL.revokeObjectURL(objUrl);
                    if (dur > 15.5) {
                        self._aiAddMsg('bot', 'Audio tem ' + dur.toFixed(1) + 's â€” o limite atual e 15s. Corte o audio antes de importar.');
                        self._aiBusy = false;
                        return;
                    }
                    self._aiStatus('Transcrevendo com Whisper (word timestamps)... ' + dur.toFixed(1) + 's');
                    self._aiTranscribeAudio(file, groqKey, dur, provider);
                };
                audioEl.onerror = function () {
                    URL.revokeObjectURL(objUrl);
                    self._aiAddMsg('bot', 'Nao consegui ler o arquivo de audio. Verifique o formato.');
                };
            };
            input.click();
        },

        // Step 1: manda o audio pro Whisper e pega word-level timestamps
        _aiTranscribeAudio: function (file, groqKey, duration, provider) {
            var self = this;
            var reader = new FileReader();
            reader.onload = function (e) {
                var blob = new Blob([e.target.result], { type: file.type || 'audio/mpeg' });
                var formData = new FormData();
                formData.append('file', blob, file.name);
                formData.append('model', 'whisper-large-v3-turbo');
                formData.append('response_format', 'verbose_json');
                formData.append('timestamp_granularities[]', 'word');
                formData.append('timestamp_granularities[]', 'segment');

                fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
                    method: 'POST',
                    headers: { 'Authorization': 'Bearer ' + groqKey },
                    body: formData
                })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.error) {
                        self._aiAddMsg('bot', 'Erro Whisper: ' + data.error.message);
                        return;
                    }
                    var wordList = [];
                    var fullText = data.text || '';
                    if (data.words && data.words.length > 0) {
                        for (var i = 0; i < data.words.length; i++) {
                            var w = data.words[i];
                            wordList.push({ word: w.word.replace(/^\s+|\s+$/g, ''), start: w.start, end: w.end });
                        }
                    }
                    if (wordList.length === 0) {
                        self._aiAddMsg('bot', 'Nenhuma palavra detectada no audio. Tente um audio com fala clara.');
                        return;
                    }

                    self._aiAddMsg('status', 'âœ“ Transcrito: ' + wordList.length + ' palavras em ' + duration.toFixed(1) + 's');
                    self._aiStatus('Analisando tema do audio...');

                    // Step 2: Gemini/OpenRouter one-shot pra extrair tema/paleta/tom
                    self._aiAnalyzeAudioTheme(fullText, wordList, duration, provider);
                })
                .catch(function (err) {
                    self._aiAddMsg('bot', 'Erro transcrevendo: ' + err.message);
                });
            };
            reader.onerror = function () { self._aiAddMsg('bot', 'Erro lendo arquivo de audio'); };
            reader.readAsArrayBuffer(file);
        },

        // Step 2: analisa o texto pra derivar tema/paleta/CTA/keywords
        _aiAnalyzeAudioTheme: function (fullText, wordList, duration, provider) {
            var self = this;
            var analysisPrompt = 'Analise esta transcricao de audio (pt-BR) e retorne APENAS um JSON (sem markdown, sem explicacao) com esta estrutura exata:\n' +
                '{"tema":"tema principal em 1 frase","marca_sugerida":"nome curto da marca/produto mencionado ou sugerido","paleta":["#HEX1","#HEX2","#HEX3","#HEX4"],"tom":"adjetivo do tom de voz","keywords":["palavra1","palavra2","palavra3","palavra4","palavra5","palavra6","palavra7","palavra8"],"cta":"frase curta call-to-action baseada no audio"}\n\n' +
                'Transcricao:\n"' + fullText + '"\n\n' +
                'Derive a paleta (4 cores HEX) do tema/marca. Derive keywords das palavras mais importantes ou features mencionadas. CTA deve ser coerente com o tom do audio. APENAS JSON, nada mais.';

            self._aiOneShot(analysisPrompt, 800, function (jsonText) {
                var meta = null;
                try {
                    // Limpa markdown caso o modelo devolva com ```json
                    var cleaned = jsonText.replace(/```json\s*/g, '').replace(/```\s*/g, '').replace(/^\s+|\s+$/g, '');
                    meta = JSON.parse(cleaned);
                } catch (e) {}
                if (!meta || !meta.tema) {
                    // Fallback: usa valores neutros
                    meta = {
                        tema: fullText.substring(0, 80),
                        marca_sugerida: 'Produto',
                        paleta: ['#820AD1', '#39007A', '#FAFAFA', '#E81CFF'],
                        tom: 'moderno',
                        keywords: wordList.slice(0, 8).map(function (w) { return w.word; }),
                        cta: 'Saiba mais'
                    };
                }

                self._aiAddMsg('status', 'âœ“ Tema: ' + meta.tema);
                self._aiStatus('Gerando motion SaaS sincronizado...');

                // Step 3: constroi master prompt universal + dados sincronizados
                self._aiBuildSyncedMotionPrompt(fullText, wordList, duration, meta, provider);
            });
        },

        // Step 3: monta o prompt universal + word timestamps + metadata e envia pro LLM
        _aiBuildSyncedMotionPrompt: function (fullText, wordList, duration, meta, provider) {
            var self = this;

            // Word list â€” palavra por palavra com timestamps exatos
            var wordLines = '';
            for (var i = 0; i < wordList.length; i++) {
                var w = wordList[i];
                wordLines += '  ' + w.word + ' | in=' + w.start.toFixed(2) + 's | out=' + w.end.toFixed(2) + 's\n';
            }

            var paleta = (meta.paleta && meta.paleta.length >= 4) ? meta.paleta : ['#820AD1', '#39007A', '#FAFAFA', '#E81CFF'];
            var keywords = (meta.keywords && meta.keywords.length > 0) ? meta.keywords : wordList.slice(0, 8).map(function (w) { return w.word; });

            var prompt = 'Crie um motion SaaS premium de ' + duration.toFixed(1) + ' segundos sincronizado com a fala do audio transcrito abaixo. Use a comp ativa (NAO crie comp nova).\n\n' +

                'â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n' +
                'TEMA DERIVADO DO AUDIO\n' +
                'â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n' +
                '- Tema: ' + meta.tema + '\n' +
                '- Marca: ' + (meta.marca_sugerida || 'Produto') + '\n' +
                '- Tom: ' + (meta.tom || 'moderno') + '\n' +
                '- Paleta: principal ' + paleta[0] + ', escura ' + paleta[1] + ', clara ' + paleta[2] + ', accent ' + paleta[3] + '\n' +
                '- Keywords: ' + keywords.join(', ') + '\n' +
                '- CTA final: "' + (meta.cta || 'Saiba mais') + '"\n\n' +

                'â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n' +
                'TRANSCRICAO COMPLETA\n' +
                'â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n' +
                '"' + fullText + '"\n\n' +

                'â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n' +
                'WORD TIMESTAMPS (' + wordList.length + ' palavras â€” use EXATAMENTE esses valores)\n' +
                'â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n' +
                wordLines + '\n' +

                'â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n' +
                'REGRAS DE SINCRONIZACAO (OBRIGATORIO)\n' +
                'â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n' +
                '1. LEGENDA WORD-BY-WORD (OTIMIZADA â€” use UM LOOP com array):\n' +
                '   NAO crie cada text layer manualmente. Use um ARRAY e um FOR LOOP:\n' +
                '   var words = [' + wordList.map(function(w) { return '{t:"' + w.word.replace(/"/g, '') + '",s:' + w.start.toFixed(2) + ',e:' + w.end.toFixed(2) + '}'; }).join(',') + '];\n' +
                '   for (var wi = 0; wi < words.length; wi++) {\n' +
                '     var ww = words[wi];\n' +
                '     var tl = comp.layers.addText(ww.t);\n' +
                '     tl.name = "W_" + wi;\n' +
                '     var td = tl.property("ADBE Text Properties").property("ADBE Text Document").value;\n' +
                '     td.font = "Arial-BoldMT"; td.fontSize = Math.round(W * 0.08);\n' +
                '     td.fillColor = [1,1,1]; td.justification = ParagraphJustification.CENTER_JUSTIFY;\n' +
                '     tl.property("ADBE Text Properties").property("ADBE Text Document").setValue(td);\n' +
                '     var r = tl.sourceRectAtTime(0, false);\n' +
                '     tl.transform.anchorPoint.setValue([r.left+r.width/2, r.top+r.height/2]);\n' +
                '     tl.transform.position.setValue([cx, H * 0.82]);\n' +
                '     tl.inPoint = ww.s;\n' +
                '     tl.outPoint = ww.e;\n' +
                '   }\n' +
                '   COPIE esse bloco EXATO no codigo. NAO crie layers individualmente. O array ja tem todas as palavras.\n' +
                '   Como cada palavra tem inPoint/outPoint DIFERENTE, elas NUNCA se sobrepoem â€” so 1 aparece por vez.\n\n' +
                '2. KEYWORDS DESTACADAS: identifique 3-5 palavras de impacto. Crie destaques SEPARADOS em [cx, H*0.5] com cor accent (' + paleta[3] + '), fontSize W*0.12, inPoint = timestamp da keyword, outPoint = inPoint + 0.8.\n' +
                '3. ARQUITETURA DE CENAS: divida o video em 3-5 cenas baseadas em PAUSAS NA FALA (gaps > 0.3s entre palavras). Cada cena tem background de cor diferente da paleta (alterna ' + paleta[0] + ' / ' + paleta[1] + ' / ' + paleta[2] + ') com inPoint/outPoint alinhados aos limites da cena.\n' +
                '4. MOTION POR CENA: cada cena deve ter UM elemento visual principal coerente com as palavras daquele range (ex: cena que fala de PIX = icone de seta + numeros animados; cena que fala de cartao = card 3D; cena de metricas = numero gigante com counter; cena de CTA = botao pill com ripple).\n' +
                '5. AURORA BLOBS de fundo (exemplo 4 saas premium) presentes em toda a duracao com inPoint=0 outPoint=' + duration.toFixed(2) + ' â€” da continuidade visual entre cenas.\n' +
                '6. TRANSICOES entre cenas: color wipe organico (ellipse gigante crescendo com blur) nos pontos de corte.\n' +
                '7. Decoracao constante (exemplo 8): 1-2 spinners pequenos nos cantos com expression "time * 360" durante todo o video.\n\n' +

                'â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n' +
                'TECNICAS OBRIGATORIAS DO KNOWLEDGE BASE\n' +
                'â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n' +
                '- Helpers AE.* completos no topo (gc, pos, scl, opa, rot, rX, rY, anc, sv, sa, gv, hex, fx, smoothEase, maxEase)\n' +
                '- Helpers locais: centerAnchor (sourceRectAtTime), mkText com CENTER_JUSTIFY + leading colado, mkSolid, mkRect, mkEllipse BLINDADOS (busca refs por match name DEPOIS de addProperty)\n' +
                '- smoothPopIn(layer, tIn, dur, scale), smoothFadeOut(layer, tOut), springPop(layer, tIn) com overshoot 115/95/100\n' +
                '- Aurora blobs: 2 ellipses gigantes com Gaussian Blur 2 (amount 350-450), opacity 40-50, movimento lento\n' +
                '- Paleta EXCLUSIVAMENTE a derivada do audio: ' + paleta.join(', ') + '\n' +
                '- Ease 100% (maxEase) em todos keyframes\n' +
                '- Motion blur: comp.motionBlur = true; comp.shutterAngle = 180\n' +
                '- Textos NUNCA sobrepostos â€” respeite espacamento vertical (distancia Y >= (fontSize1+fontSize2)/2 + 20)\n' +
                '- Conteudo dentro de cards SEMPRE respeitando cardTop/cardBottom calculados\n' +
                '- Botoes com stroke SIMPLES ou so fill, NUNCA borda dupla\n' +
                '- Cada layer de cada cena com inPoint/outPoint absolutos â€” NUNCA deixe layer sem inPoint/outPoint\n' +
                '- Keyframes em tempo ABSOLUTO (tIn + offset), nunca relativos\n' +
                '- ES3 absoluto, var, function(){}, sem const/let/arrow/template/class/destructuring\n' +
                '- app.beginUndoGroup("Audio Synced Motion") em try/finally\n' +
                '- NAO use alert de sucesso\n\n' +

                'Gere o script ExtendScript COMPLETO pronto pra executar. NAO resuma. Use as tecnicas dos exemplos tecnicos 1-8 do knowledge base conforme necessario. Os textos das legendas word-by-word sao EXATAMENTE as palavras da transcricao â€” nao invente novos textos.';

            // Injeta no historico e envia via fluxo padrao
            self._aiMsgs.push({ role: 'user', content: prompt });
            self._aiFixCount = 0;

            var msgs = [{ role: 'system', content: self._aiPrompt }];
            msgs = msgs.concat(self._aiMsgs.slice(-4));

            self._aiCallLLM(msgs, function (response) {
                if (!self._aiCheckActions(response, msgs)) {
                    self._aiProcessResponse(response);
                }
            });
        },

        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• IMPORTAR VIDEO â€” GEMINI ASSISTE E RECRIA â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        // Abre file picker, faz upload do video via Gemini Files API, aguarda processamento,
        // e pede pro Gemini analisar visualmente e recriar o video no After Effects como motion graphics.
        aiImportVideo: function () {
            MT.toast('Analise de video indisponivel (Gemini Video API removido). Use imagens no botao de imagem.', true);
            return;
            /* eslint-disable */
            var self = this;

            // So funciona com Gemini
            var provider = self._aiGetProvider();
            if (!provider) {
                MT.toast('Importar video requer chave OpenRouter configurada.', true);
                return;
            }

            var input = document.createElement('input');
            input.type = 'file';
            input.accept = 'video/mp4,video/mpeg,video/quicktime,video/x-msvideo,video/webm,video/x-matroska,video/*';
            input.onchange = function () {
                var file = input.files && input.files[0];
                if (!file) return;

                // Limite sensato â€” Files API aceita ate 2GB mas upload fica lento
                if (file.size > 500 * 1024 * 1024) {
                    MT.toast('Video muito grande (max 500MB)', true);
                    return;
                }

                var welcome = document.querySelector('.ai-welcome');
                if (welcome) welcome.remove();

                self._aiAddMsg('user', 'ðŸŽž ' + file.name + ' (' + (file.size / 1024 / 1024).toFixed(1) + ' MB)');
                self._aiStatus('Enviando video pro Gemini... (' + (file.size / 1024 / 1024).toFixed(1) + ' MB)');

                self._aiUploadVideoToGemini(file, provider, function (fileUri, mimeType, err) {
                    if (err) {
                        self._aiAddMsg('bot', 'Erro no upload: ' + err);
                        return;
                    }
                    self._aiStatus('Gemini analisando o video...');
                    // Pega info da comp ativa pra dar contexto de resolucao/duracao
                    csInterface.evalScript('getActiveCompInfo()', function (ci) {
                        var compCtx = '';
                        try {
                            var info = JSON.parse(ci);
                            if (info && !info.error) {
                                compCtx = '[COMP ATIVA: ' + info.name + ' | ' + info.width + 'x' + info.height + ' @ ' + info.fps + 'fps | ' + info.duration + 's]\nUse app.project.activeItem, NAO crie comp nova. Resolucao: ' + info.width + 'x' + info.height + '. Centro: [' + Math.round(info.width/2) + ', ' + Math.round(info.height/2) + '].\n\n';
                            }
                        } catch (e) {}

                        self._aiSendVideoPrompt(fileUri, mimeType, provider, compCtx);
                    });
                });
            };
            input.click();
        },

        // Upload resumavel pra Gemini Files API
        // Ref: https://ai.google.dev/gemini-api/docs/files
        _aiUploadVideoToGemini: function (file, provider, callback) {
            var self = this;
            var apiKey = provider.key;
            var mimeType = file.type || 'video/mp4';
            var numBytes = file.size;

            // Step 1 â€” Start resumable upload, pega upload URL
            fetch('https://generativelanguage.googleapis.com/upload/v1beta/files?key=' + encodeURIComponent(apiKey), {
                method: 'POST',
                headers: {
                    'X-Goog-Upload-Protocol': 'resumable',
                    'X-Goog-Upload-Command': 'start',
                    'X-Goog-Upload-Header-Content-Length': String(numBytes),
                    'X-Goog-Upload-Header-Content-Type': mimeType,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ file: { display_name: file.name } })
            })
            .then(function (res) {
                if (!res.ok) return res.text().then(function (t) { throw new Error('Start upload: ' + res.status + ' ' + t.substring(0, 150)); });
                var uploadUrl = res.headers.get('X-Goog-Upload-URL') || res.headers.get('x-goog-upload-url');
                if (!uploadUrl) throw new Error('Sem upload URL na resposta');
                return uploadUrl;
            })
            .then(function (uploadUrl) {
                // Step 2 â€” Le os bytes e envia
                self._aiStatus('Enviando bytes do video...');
                return new Promise(function (resolve, reject) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        var bytes = e.target.result; // ArrayBuffer
                        fetch(uploadUrl, {
                            method: 'POST',
                            headers: {
                                'Content-Length': String(numBytes),
                                'X-Goog-Upload-Offset': '0',
                                'X-Goog-Upload-Command': 'upload, finalize'
                            },
                            body: bytes
                        })
                        .then(function (r) {
                            if (!r.ok) return r.text().then(function (t) { reject(new Error('Upload bytes: ' + r.status + ' ' + t.substring(0, 150))); });
                            return r.json();
                        })
                        .then(function (data) { if (data) resolve(data); })
                        .catch(reject);
                    };
                    reader.onerror = function () { reject(new Error('Erro ao ler arquivo local')); };
                    reader.readAsArrayBuffer(file);
                });
            })
            .then(function (uploadResult) {
                // uploadResult.file = { name, uri, mimeType, state, ... }
                var f = uploadResult.file;
                if (!f || !f.name) throw new Error('Sem dados de arquivo na resposta');

                // Step 3 â€” Polling ate state === ACTIVE (videos levam 10-60s pra processar)
                self._aiStatus('Gemini processando video... (pode demorar ate 1 minuto)');
                var attempts = 0;
                function poll() {
                    attempts++;
                    if (attempts > 60) { callback(null, null, 'Timeout no processamento (>60s)'); return; }
                    fetch('https://generativelanguage.googleapis.com/v1beta/' + f.name + '?key=' + encodeURIComponent(apiKey))
                        .then(function (r) { return r.json(); })
                        .then(function (fileData) {
                            if (fileData.error) { callback(null, null, fileData.error.message); return; }
                            if (fileData.state === 'ACTIVE') {
                                callback(fileData.uri, fileData.mimeType || mimeType, null);
                            } else if (fileData.state === 'FAILED') {
                                callback(null, null, 'Processamento do video falhou');
                            } else {
                                setTimeout(poll, 2000);
                            }
                        })
                        .catch(function (e) { callback(null, null, e.message); });
                }
                poll();
            })
            .catch(function (err) { callback(null, null, err.message); });
        },

        // Envia prompt pro Gemini com o video como fileData + instrucoes de recriacao
        // DESABILITADO: Gemini removido. Usuario ve mensagem no aiAddVideo.
        _aiSendVideoPrompt: function (fileUri, mimeType, provider, compCtx) {
            this._aiAddMsg('bot', 'Analise de video nao disponivel (Gemini removido).');
            this._aiBusy = false;
            document.getElementById('ai-send').disabled = false;
            return;
            /* eslint-disable */
            // Codigo legado abaixo â€” dead code, mantido pra referencia futura
            var self = this;
            var instruction = compCtx +
                'VOCE ACABOU DE ASSISTIR UM VIDEO. Analise ele VISUALMENTE com atencao:\n\n' +
                '1. IDENTIFIQUE o tema, estilo visual, paleta de cores, fontes usadas\n' +
                '2. LISTE CADA CENA com os timestamps EXATOS onde entra e sai (ex: "Cena 1: 0.0s-2.0s texto preto Pague sobre fundo preto")\n' +
                '3. OBSERVE as animacoes â€” entradas, saidas, transicoes, overshoots, easing, cut seco\n' +
                '4. IDENTIFIQUE os tipos de elementos â€” texto, shapes, imagens, icones, graficos\n' +
                '5. REPARE em detalhes: drop shadows, gradientes, bordas, sombras, glow\n\n' +
                'Agora RECRIE esse video como motion graphics no Adobe After Effects usando ExtendScript ES3. ' +
                'Reproduza fielmente o estilo visual, paleta, timing, animacoes e sequencia de cenas que voce viu.\n\n' +
                'ðŸš¨ REGRAS CRITICAS DE SEPARACAO DE CENAS (SE VIOLAR, O VIDEO FICA TODO SOBREPOSTO E CAGADO):\n' +
                '1. CADA elemento de CADA cena DEVE ter layer.inPoint = tInicio_da_cena e layer.outPoint = tFim_da_cena\n' +
                '2. Backgrounds tambem â€” cada cor de fundo e UM solid diferente com seu proprio inPoint/outPoint\n' +
                '3. Elementos da cena 1 NAO DEVEM aparecer na cena 2 â€” sem inPoint/outPoint, TODOS aparecem desde 0s sobrepostos\n' +
                '4. Keyframes de entrada de uma cena que comeca em tIn=3s DEVEM ser: AE.sa(scale, 3.0, [0,0]); AE.sa(scale, 3.3, [100,100]); â€” tempos ABSOLUTOS, nao 0 e 0.3\n' +
                '5. Texto: SEMPRE sourceRectAtTime + anchorPoint no centro do rect + justification CENTER_JUSTIFY. Sem isso fica colado na esquerda\n' +
                '6. Use UMA CAMADA POR TEXTO â€” nao tente multi-linha em uma so layer pra manter controle do timing\n\n' +
                'Use a comp ativa (NAO crie comp nova). Siga TODAS as regras ES3 do system prompt e use os helpers AE.* completos no topo. ' +
                'Gere um motion completo, polido, pronto pra executar no AE. NAO resuma. NAO pule etapas. NAO use placeholder tipo "texto de exemplo" â€” use os textos REAIS que voce viu no video.';

            // Constroi o request Gemini com fileData part + text part
            var generationConfig = { temperature: 0.2, maxOutputTokens: 65000 };
            if (self._aiGeminiSupportsThinking(provider.model)) {
                generationConfig.thinkingConfig = { thinkingBudget: 8000 };
            }

            var body = {
                contents: [{
                    role: 'user',
                    parts: [
                        { fileData: { mimeType: mimeType, fileUri: fileUri } },
                        { text: instruction }
                    ]
                }],
                generationConfig: generationConfig
            };

            // Usa system prompt da extension
            if (self._aiPrompt) {
                body.systemInstruction = { parts: [{ text: self._aiPrompt }] };
            }

            self._aiMsgs.push({ role: 'user', content: '[VIDEO ENVIADO] ' + instruction });
            self._aiFixCount = 0;
            self._aiBusy = true;
            document.getElementById('ai-send').disabled = true;

            var url = 'https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(provider.model) + ':streamGenerateContent?alt=sse&key=' + encodeURIComponent(provider.key);

            var videoAttempt = self._videoAttempt || 0;
            fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            })
            .then(function (res) {
                if (!res.ok) {
                    if (self._aiIsRetryable(res.status) && videoAttempt < self._aiMaxRetries) {
                        var delay = self._aiRetryDelay(videoAttempt);
                        self._aiStatus('Rate limit (' + res.status + ') â€” retry em ' + (delay/1000).toFixed(0) + 's... (' + (videoAttempt+2) + '/' + (self._aiMaxRetries+1) + ')');
                        self._videoAttempt = videoAttempt + 1;
                        setTimeout(function () { self._aiSendVideoPrompt(fileUri, mimeType, provider, compCtx); }, delay);
                        return null;
                    }
                    self._videoAttempt = 0;
                    return res.text().then(function (t) { throw new Error('Gemini ' + res.status + ': ' + t.substring(0, 200)); });
                }
                self._videoAttempt = 0;
                var statusEl = document.querySelector('.ai-msg.status:last-child');
                if (statusEl) statusEl.remove();
                var bubble = self._aiAddMsg('bot', '');
                bubble.innerHTML = '<span class="ai-generating">Gemini assistindo e gerando codigo...</span>';
                var full = '';
                var buf = '';
                var finishReason = null;
                var reader = res.body.getReader();
                var dec = new TextDecoder();
                function read() {
                    reader.read().then(function (r) {
                        if (r.done) {
                            if (finishReason === 'MAX_TOKENS' && full.length > 0) {
                                self._aiAddMsg('status', 'Resposta truncada â€” continuando...');
                                var cont = self._aiMsgs.slice();
                                cont.push({ role: 'assistant', content: full });
                                cont.push({ role: 'user', content: 'Continue EXATAMENTE de onde parou. NAO repita nada. Termine o script completo.' });
                                self._aiCallGemini(cont, provider, function (c) { self._aiProcessResponse(full + c); });
                                return;
                            }
                            self._aiProcessResponse(full);
                            return;
                        }
                        buf += dec.decode(r.value, { stream: true });
                        var parts = buf.split('\n');
                        buf = parts.pop();
                        for (var i = 0; i < parts.length; i++) {
                            var ln = parts[i];
                            if (ln.indexOf('data: ') !== 0) continue;
                            var payload = ln.slice(6).trim();
                            if (!payload || payload === '[DONE]') continue;
                            try {
                                var d = JSON.parse(payload);
                                if (d.candidates && d.candidates[0]) {
                                    if (d.candidates[0].finishReason) finishReason = d.candidates[0].finishReason;
                                    if (d.candidates[0].content && d.candidates[0].content.parts) {
                                        var ps = d.candidates[0].content.parts;
                                        for (var k = 0; k < ps.length; k++) {
                                            if (ps[k].thought) continue;
                                            if (ps[k].text) { full += ps[k].text; bubble.textContent = full; self._aiScroll(); }
                                        }
                                    }
                                }
                            } catch (e) {}
                        }
                        read();
                    }).catch(function () { self._aiProcessResponse(full || ''); });
                }
                read();
            })
            .catch(function (err) {
                self._aiAddMsg('bot', 'Erro Gemini: ' + err.message);
                self._aiBusy = false;
                document.getElementById('ai-send').disabled = false;
            });
        },

        // Legacy: kept unreachable (button no longer calls this) â€” aiImportVideo substituiu
        aiComposeVideo: function () {
            var groqKey = localStorage.getItem('multiTools_groqKey');
            if (!groqKey) { MT.toast('Configure a API Key Groq', true); return; }
            if (!self._aiGetProvider()) { MT.toast('Configure a chave OpenRouter nas configuracoes', true); return; }

            var btn = document.getElementById('ai-audio-btn');
            btn.classList.add('loading');

            var welcome = document.querySelector('.ai-welcome');
            if (welcome) welcome.remove();

            self._aiStatus('Analisando timeline (cortes, clips, duracoes)...');

            // Step 1: Get detailed timeline composition
            csInterface.evalScript('getTimelineComposition()', function (tlRaw) {
                var timeline = null;
                try { timeline = JSON.parse(tlRaw); } catch (e) {}
                if (!timeline || timeline.error) {
                    btn.classList.remove('loading');
                    self._aiStatus('Erro: ' + (timeline && timeline.error ? timeline.error : 'comp nao encontrada'));
                    MT.toast('Abra uma comp com o video ja decupado', true);
                    return;
                }
                if (!timeline.layers || timeline.layers.length === 0) {
                    btn.classList.remove('loading');
                    self._aiStatus('Timeline vazia â€” adicione os clips antes de compor');
                    MT.toast('Timeline vazia', true);
                    return;
                }

                self._aiStatus('Renderizando audio da comp...');

                // Step 2: Render audio
                csInterface.evalScript('renderAudioOnly()', function (audioPath) {
                    if (audioPath === 'false' || audioPath.indexOf('Error') !== -1 || audioPath.indexOf('Erro') !== -1) {
                        btn.classList.remove('loading');
                        self._aiStatus('Erro ao renderizar audio');
                        MT.toast('Erro no render de audio', true);
                        return;
                    }

                    self._aiStatus('Transcrevendo com Whisper (word-level timestamps)...');

                    var readRes = window.cep.fs.readFile(audioPath, cep.encoding.Base64);
                    if (readRes.err !== 0) {
                        btn.classList.remove('loading');
                        self._aiStatus('Erro ao ler arquivo de audio');
                        return;
                    }

                    var blob = self.b64toBlob(readRes.data, 'audio/wav');
                    var formData = new FormData();
                    formData.append('file', blob, 'audio.wav');
                    formData.append('model', 'whisper-large-v3-turbo');
                    formData.append('response_format', 'verbose_json');
                    formData.append('timestamp_granularities[]', 'word');
                    formData.append('timestamp_granularities[]', 'segment');

                    fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
                        method: 'POST',
                        headers: { 'Authorization': 'Bearer ' + groqKey },
                        body: formData
                    })
                    .then(function (r) { return r.json(); })
                    .then(function (data) {
                        btn.classList.remove('loading');
                        try { window.cep.fs.deleteFile(audioPath); } catch (e) {}

                        if (data.error) {
                            self._aiStatus('Erro Whisper: ' + data.error.message);
                            return;
                        }

                        // Build word-level + segment-level transcripts
                        var wordLine = '';
                        var segLine = '';
                        var wordData = [];

                        if (data.segments && data.segments.length > 0) {
                            for (var s = 0; s < data.segments.length; s++) {
                                var seg = data.segments[s];
                                segLine += '[' + seg.start.toFixed(2) + 's â†’ ' + seg.end.toFixed(2) + 's] ' + seg.text.replace(/^\s+|\s+$/g, '') + '\n';
                            }
                        }
                        if (data.words && data.words.length > 0) {
                            for (var i = 0; i < data.words.length; i++) {
                                var w = data.words[i];
                                wordData.push({ word: w.word, start: w.start, end: w.end });
                                // Formato "word|start|end" â€” um por linha, facil da IA parsear
                                wordLine += '  ' + w.word.replace(/^\s+|\s+$/g, '') + ' | in=' + w.start.toFixed(2) + 's | out=' + w.end.toFixed(2) + 's\n';
                            }
                        }

                        var totalDur = data.duration || timeline.duration;
                        self._aiAudioTranscript = {
                            text: segLine || wordLine || (data.text || ''),
                            words: wordData,
                            duration: totalDur
                        };

                        if (!segLine && !wordLine) {
                            self._aiAddMsg('status', 'âš  Nenhuma fala detectada â€” compondo apenas com base nos cortes da timeline');
                        } else {
                            self._aiAddMsg('status', 'âœ“ Audio transcrito (' + wordData.length + ' palavras, ' + totalDur.toFixed(1) + 's) + Timeline com ' + timeline.layers.length + ' clips analisada');
                        }

                        // Step 3: Build the compose prompt and auto-send
                        self._aiComposeAndSend(timeline, segLine, wordLine);
                    })
                    .catch(function (err) {
                        btn.classList.remove('loading');
                        try { window.cep.fs.deleteFile(audioPath); } catch (e) {}
                        self._aiStatus('Erro: ' + err.message);
                    });
                });
            });
        },

        // Builds the compose-video master prompt and auto-sends it
        _aiComposeAndSend: function (timeline, segLine, wordLine) {
            var self = this;

            // Format timeline clips for AI
            var clipsTxt = '';
            for (var i = 0; i < timeline.layers.length; i++) {
                var l = timeline.layers[i];
                clipsTxt += '  [' + l.index + '] "' + l.name + '" (' + l.category + ')';
                clipsTxt += ' | inPoint=' + l.inPoint.toFixed(2) + 's';
                clipsTxt += ' | outPoint=' + l.outPoint.toFixed(2) + 's';
                clipsTxt += ' | duracao=' + l.duration.toFixed(2) + 's';
                if (l.hasVideo) clipsTxt += ' [VIDEO]';
                if (l.hasAudio) clipsTxt += ' [AUDIO]';
                if (l.srcWidth > 0) clipsTxt += ' | src=' + l.srcWidth + 'x' + l.srcHeight;
                clipsTxt += '\n';
            }

            var prompt = 'COMPOR VIDEO: analise a timeline JA DECUPADA + audio transcrito e adicione motion graphics sincronizadas.\n\n';

            prompt += '[COMP ATIVA] "' + timeline.name + '" | ' + timeline.width + 'x' + timeline.height + ' @ ' + timeline.fps + 'fps | duracao ' + timeline.duration.toFixed(2) + 's\n\n';

            prompt += '[TIMELINE DECUPADA â€” ' + timeline.layers.length + ' clips ja posicionados NAO MEXA neles]\n';
            prompt += clipsTxt + '\n';

            if (wordLine) {
                prompt += '[TRANSCRICAO PALAVRA-POR-PALAVRA â€” use EXATAMENTE esses timestamps para cada legenda]\n';
                prompt += 'Cada linha e: palavra | in=inicio | out=fim (em segundos)\n';
                prompt += wordLine + '\n';
            }
            if (segLine) {
                prompt += '[AGRUPAMENTO EM FRASES â€” use apenas pra entender o TEMA da narrativa, NAO pra legendas]\n' + segLine + '\n';
            }

            prompt += 'â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• INSTRUCOES OBRIGATORIAS â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n\n';

            prompt += 'REGRAS CRITICAS:\n';
            prompt += '1. NAO CRIE COMP NOVA â€” use app.project.activeItem (a comp ativa acima)\n';
            prompt += '2. NAO MOVA, NAO CORTE, NAO DELETE os clips existentes. Eles ja estao decupados pelo editor.\n';
            prompt += '3. NAO altere inPoint/outPoint/startTime dos layers existentes.\n';
            prompt += '4. Voce vai ADICIONAR camadas NOVAS (text, shape, solid, null) POR CIMA dos clips existentes.\n';
            prompt += '5. Cada nova camada que voce adicionar DEVE ter inPoint e outPoint alinhados com algum clip ou frase da transcricao.\n';
            prompt += '6. Use layer.inPoint = X; layer.outPoint = Y; para limitar o tempo de vida de cada elemento novo.\n\n';

            prompt += 'ðŸ“š REFERENCIA TECNICA OBRIGATORIA: o EXEMPLO TECNICO 3 (KINETIC TYPOGRAPHY VIRAL REELS/TIKTOK) no knowledge base e o PADRAO que voce DEVE seguir. Use springPop + cutOut, mix Serif/Sans, contraste de tamanhos, cor accent em keywords, drop shadow leve, ease 100%. Copie a tecnica, NUNCA os textos placeholder do exemplo.\n\n';

            prompt += 'O QUE COMPOR:\n';
            prompt += 'A) LEGENDAS PALAVRA-POR-PALAVRA (OBRIGATORIO â€” a mais importante):\n';
            prompt += '   - Para CADA palavra da lista [TRANSCRICAO PALAVRA-POR-PALAVRA], crie UM text layer SEPARADO contendo APENAS aquela palavra.\n';
            prompt += '   - inPoint = valor "in" da palavra (EXATAMENTE, copie o numero)\n';
            prompt += '   - outPoint = valor "out" da palavra (EXATAMENTE, copie o numero)\n';
            prompt += '   - NAO agrupe palavras, NAO junte em frases. Uma palavra = uma layer = um timestamp.\n';
            prompt += '   - Posicione TODAS as palavras no MESMO lugar da tela (ex: centro baixo, [comp.width/2, comp.height*0.82]) para simular legenda pulando palavra por palavra estilo TikTok/Reels viral.\n';
            prompt += '   - Use a MESMA fonte, MESMA cor (branca), MESMO tamanho (comp.width*0.06) em TODAS as palavras â€” so muda o texto e os timestamps.\n';
            prompt += '   - Anime cada palavra com popIn no inPoint (scale 0â†’115â†’100 em 0.1s) e opacity fade out no outPoint (0.05s).\n';
            prompt += '   - SEMPRE calcule anchorPoint via sourceRectAtTime imediatamente apos criar o text para centralizar.\n';
            prompt += '   - Use um loop for percorrendo um array com TODAS as palavras (copie os dados exatos da lista fornecida acima).\n';
            prompt += 'B) KEYWORDS VISUAIS DESTACADAS (ALEM das legendas word-by-word):\n';
            prompt += '   - Identifique 3-6 palavras-chave de IMPACTO (nomes, numeros, verbos fortes) e crie destaques SEPARADOS maiores, com cor accent da paleta, posicao diferente (meio da tela), scale pop exagerado.\n';
            prompt += 'C) MOTION POR CLIP: para cada clip da timeline, analise o contexto (nome, posicao, duracao, categoria) e adicione um motion coerente:\n';
            prompt += '   - Clip de abertura: intro com titulo, lower-third, ou hook visual\n';
            prompt += '   - Clips de meio: supports (shapes decorativos, numeros contando, linhas)\n';
            prompt += '   - Clip final: CTA ou fechamento\n';
            prompt += 'D) TRANSICOES ENTRE CLIPS: nos pontos de corte, elemento de transicao (flash, swipe, shape wipe) cobrindo ~0.3s antes e depois do corte.\n';
            prompt += 'E) REACAO AO CONTEUDO: numeros=counter animado; produto=badge; emocao=particulas; acao=glitch/shake.\n\n';

            prompt += 'SINCRONIZACAO:\n';
            prompt += '- Cada keyword destacada deve aparecer EXATAMENTE no timestamp da palavra (use word-level timestamps)\n';
            prompt += '- Cada legenda deve entrar 0.1s antes do segmento e sair 0.1s depois\n';
            prompt += '- Elementos visuais respondendo a clips devem ter inPoint = clip.inPoint e outPoint <= clip.outPoint\n\n';

            prompt += 'â›” REGRAS ANTI-GENERICO (CRITICAS):\n';
            prompt += '- PROIBIDO usar "Google", logo do Google, cores do Google, bolinhas coloridas do Google, ou qualquer coisa do exemplo tecnico salvo no knowledge.\n';
            prompt += '- PROIBIDO colocar palavras, marcas, conceitos ou imagens que NAO aparecem literalmente na transcricao acima.\n';
            prompt += '- PROIBIDO usar textos placeholder tipo "Titulo", "Subtitulo", "Sua marca aqui", "Texto de exemplo".\n';
            prompt += '- TODO texto visivel no video DEVE vir DIRETAMENTE da transcricao real.\n';
            prompt += '- TODA imagem baixada DEVE representar algo mencionado na transcricao real.\n';
            prompt += '- A paleta de cores deve ser derivada do TEMA real da transcricao, nao de exemplos.\n\n';

            prompt += 'ESTILO VISUAL:\n';
            prompt += '- Escolha paleta DEDUZINDO o tema REAL da transcricao acima\n';
            prompt += '- Aplique butter ease 95% (AE.smoothEase) em TODOS os keyframes\n';
            prompt += '- Use a TECNICA popIn/popOut (nao o conteudo) do exemplo tecnico salvo\n';
            prompt += '- fontSize proporcional: legenda word-by-word=comp.width*0.06, keyword destacada=comp.width*0.09\n';
            prompt += '- SEMPRE use comp.width e comp.height, NUNCA valores fixos\n';
            prompt += '- SEMPRE calcule anchorPoint via sourceRectAtTime para texts\n\n';

            prompt += 'ðŸŒ BUSCA DE IMAGENS JPEG NA INTERNET (OBRIGATORIO NO MODO COMPOR):\n';
            prompt += '- Voce TEM ACESSO A INTERNET para baixar imagens JPEG relevantes ao TEMA real do video.\n';
            prompt += '- ANALISE a transcricao REAL acima e identifique 3 a 8 conceitos visuais ESPECIFICOS DO TEMA (produto/lugar/objeto/personagem mencionados literalmente no audio).\n';
            prompt += '- PROIBIDO: NAO invente conceitos aleatorios. NAO use coisas que nao foram mencionadas. NAO repita exemplos genericos.\n';
            prompt += '- Para CADA conceito, emita UMA linha no formato exato (ANTES do bloco de codigo):\n';
            prompt += '  [IMAGEM: descricao especifica em ingles JPEG]\n';
            prompt += '- As descricoes DEVEM ser derivadas PALAVRA POR PALAVRA do que foi dito no audio. Se o audio fala de "cachorro correndo no parque", use [IMAGEM: dog running park JPEG], NAO [IMAGEM: animal JPEG].\n';
            prompt += '- Os arquivos serao baixados em Folder.temp + "/mt_img_N.jpg" onde N e o indice (0, 1, 2...) da ordem que voce pediu.\n';
            prompt += '- No CODIGO, importe e use cada imagem assim:\n';
            prompt += '  var f0 = new File(Folder.temp.fsName + "/mt_img_0.jpg");\n';
            prompt += '  if (f0.exists) { var it0 = app.project.importFile(new ImportOptions(f0)); var img0 = comp.layers.add(it0); img0.inPoint = X; img0.outPoint = Y; AE.sv(AE.pos(img0), [cx, cy]); AE.sv(AE.scl(img0), [scl, scl]); }\n';
            prompt += '- Anime CADA imagem (popIn/popOut, scale, position, opacity) e alinhe inPoint/outPoint com o momento EXATO da transcricao em que o conceito e mencionado (use os timestamps word-by-word).\n\n';

            prompt += 'ESTRUTURA DO CODIGO:\n';
            prompt += '- IIFE com var AE = {} e helpers gc/pos/scl/opa/rot/sv/sa/hex/smoothEase no topo\n';
            prompt += '- var comp = app.project.activeItem; // NAO cria, usa a ativa\n';
            prompt += '- app.beginUndoGroup("AI Compose Video") / endUndoGroup em try/finally\n';
            prompt += '- Cada secao (legendas, keywords, transicoes, constantes) em um bloco comentado\n\n';

            prompt += 'ENTREGA UM MOTION POLIDO E COMPLETO. NAO RESUMA. NAO PULE ETAPAS. GERE CODIGO FINAL PRONTO PRA EXECUTAR.';

            // Auto-send: inject into history and call LLM directly (skip sendAI's re-fetch since we already have full context)
            this._aiMsgs.push({ role: 'user', content: prompt });
            this._aiAddMsg('user', 'ðŸŽ¬ Compor video da timeline (' + timeline.layers.length + ' clips, ' + timeline.duration.toFixed(1) + 's)');
            this._aiFixCount = 0;

            self._aiStatus('IA analisando timeline + narrativa...');

            // Build msgs exactly like sendAI does
            var msgs = [{ role: 'system', content: self._aiPrompt }];
            msgs = msgs.concat(self._aiMsgs.slice(-6));

            self._aiCallLLM(msgs, function (response) {
                if (!self._aiCheckActions(response, msgs)) {
                    self._aiProcessResponse(response);
                }
            });
        },

        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• SETUP AI â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        setupAI: function () {
            var self = this;
            document.getElementById('btn-close-ai').addEventListener('click', function () { self.closeAI(); });
            document.getElementById('ai-send').addEventListener('click', function () { self.sendAI(); });
            document.getElementById('ai-input').addEventListener('keydown', function (e) {
                if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); self.sendAI(); }
            });
            var betaBtn = document.getElementById('beta-ok-btn');
            if (betaBtn) betaBtn.addEventListener('click', function () { self._acceptBeta(); });
        },

        // Inicializar sistema RAG (CEPAI)
        _cepai: null,
        _initRAG: function () {
            var self = this;
            var groqKey = localStorage.getItem('multiTools_groqKey');
            if (!groqKey || typeof CEPAI === 'undefined') return;

            self._cepai = new CEPAI(groqKey, {
                maxChunks: 1,
                maxTokens: 4000,
                temperature: 0.7,
                onStatus: function (phase, msg) {
                    self._aiStatus(msg);
                }
            });

            var extPath = csInterface.getSystemPath(SystemPath.EXTENSION);
            var kbFile = window.cep.fs.readFile(extPath + '/js/knowledge-chunks.json');
            if (kbFile.err === 0 && kbFile.data) {
                try {
                    var kbData = JSON.parse(kbFile.data);
                    self._cepai.loadKnowledge(kbData).then(function () {
                        console.log('[MultiTools] RAG carregado');
                    });
                } catch (e) {
                    console.warn('[MultiTools] Erro RAG:', e);
                }
            }
        },

        sendAI: function () {
            if (this._aiBusy) return;
            var input = document.getElementById('ai-input');
            var text = input.value.trim();
            if (!text) return;

            if (!localStorage.getItem('multiTools_ollamaKey')) {
                MT.toast('Configure a chave Ollama Cloud nas configuracoes (engrenagem)', true);
                return;
            }

            this._aiAddMsg('user', text);
            input.value = '';
            var welcomeAG = document.querySelector('.ai-welcome');
            if (welcomeAG) welcomeAG.remove();
            this._sendAgent(text);
            return;
        },

        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        // MODO AGENTE â€” IA chama tools uma-por-uma (Fase 2)
        // Agora com: header fixo com model + progress + stop button,
        // agrupamento por step, tool cards colapsaveis (click)
        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        _sendAgent: function(userPrompt) {
            var self = this;
            var provider = self._aiGetProvider();
            if (!provider) { MT.toast('Configure chave Ollama', true); return; }
            if (!window.MT_AGENT) { MT.toast('agent-tools.js nao carregado', true); return; }

            self._aiBusy = true;
            document.getElementById('ai-send').disabled = true;

            // Carrega tools.jsx sob demanda se nao estiver carregado
            var extPath = csInterface.getSystemPath(SystemPath.EXTENSION);
            var toolsPath = (extPath + '/jsx/tools.jsx').replace(/\\/g, '/');
            var loadScript =
                'if (typeof MT_tool_dispatch !== "function") {' +
                '  try {' +
                '    var _f = new File("' + toolsPath + '");' +
                '    if (_f.exists) { $.evalFile(_f); }' +
                '  } catch(_e) {}' +
                '}' +
                '(typeof MT_resetRegistry === "function") ? MT_resetRegistry() : ("no_tools path=' + toolsPath + '")';

            csInterface.evalScript(loadScript, function(res) {
                if (String(res).indexOf('no_tools') !== -1) {
                    self._aiAddMsg('bot', 'âš  tools.jsx nao foi carregado. Debug: ' + res);
                    self._aiBusy = false;
                    document.getElementById('ai-send').disabled = false;
                    return;
                }

                self._renderAgentBubble(provider, userPrompt);
            });
        },

        // Renderiza a bolha do agente com header fixo + steps + stop button
        _renderAgentBubble: function(provider, userPrompt) {
            var self = this;
            var MAX_STEPS = 30;  // Reduzido de 60 â€” cada step manda 45K+ tokens, queima quota rapido

            var bubble = self._aiAddMsg('bot', '');
            bubble.innerHTML = '';

            // === AGENT HEADER (fixo no topo) ===
            var head = document.createElement('div');
            head.className = 'agent-head';

            var headTop = document.createElement('div');
            headTop.className = 'agent-head-top';

            var badge = document.createElement('span');
            badge.className = 'agent-head-badge';
            var providerLabelMap = { gemini: 'GEMINI', groq: 'GROQ âš¡', ollama: 'OLLAMA' };
            badge.textContent = providerLabelMap[provider.name] || provider.name.toUpperCase();
            headTop.appendChild(badge);

            var model = document.createElement('span');
            model.className = 'agent-head-model';
            model.textContent = provider.model;
            headTop.appendChild(model);

            var stepCounter = document.createElement('span');
            stepCounter.className = 'agent-head-step';
            stepCounter.textContent = '0/' + MAX_STEPS;
            headTop.appendChild(stepCounter);

            var stopBtn = document.createElement('button');
            stopBtn.className = 'agent-head-stop';
            stopBtn.textContent = 'STOP';
            stopBtn.title = 'Interromper o agente';
            headTop.appendChild(stopBtn);

            head.appendChild(headTop);

            var bar = document.createElement('div');
            bar.className = 'agent-head-bar';
            var fill = document.createElement('div');
            fill.className = 'agent-head-fill';
            bar.appendChild(fill);
            head.appendChild(bar);

            bubble.appendChild(head);

            // === STEPS CONTAINER ===
            var stepsContainer = document.createElement('div');
            bubble.appendChild(stepsContainer);

            // === Final message (aparece no fim) ===
            var finalMsg = null;

            // === State ===
            var cardsByIdx = {};
            var stepGroups = {}; // step number -> step DOM element
            var currentStepEl = null;
            var toolCount = 0;

            function getOrCreateStepGroup(stepNum) {
                if (stepGroups[stepNum]) return stepGroups[stepNum];
                // Marca step anterior como "done"
                if (currentStepEl) {
                    currentStepEl.classList.remove('running');
                    currentStepEl.classList.add('done');
                }
                var stepEl = document.createElement('div');
                stepEl.className = 'agent-step running';
                var lbl = document.createElement('div');
                lbl.className = 'agent-step-lbl';
                lbl.textContent = 'STEP ' + stepNum;
                stepEl.appendChild(lbl);
                stepsContainer.appendChild(stepEl);
                stepGroups[stepNum] = stepEl;
                currentStepEl = stepEl;
                return stepEl;
            }

            function updateStepCount(toolsInStep) {
                // Atualiza label do step atual com contagem
                if (currentStepEl) {
                    var lbl = currentStepEl.querySelector('.agent-step-lbl');
                    if (lbl) {
                        var match = lbl.textContent.match(/^STEP (\d+)/);
                        if (match) {
                            lbl.textContent = 'STEP ' + match[1] + ' â€” ' + toolsInStep + ' tool call' + (toolsInStep > 1 ? 's' : '');
                        }
                    }
                }
            }

            var finalSystemPrompt = self._aiAgentPrompt || AI_AGENT_PROMPT;
            console.log('[Agent] systemPrompt: ' + (finalSystemPrompt.length / 1024).toFixed(0) + 'KB, model=' + provider.model);

            self._aiAgentHandle = window.MT_AGENT.runAgent({
                provider: provider,
                systemPrompt: finalSystemPrompt,
                userPrompt: userPrompt,
                maxSteps: MAX_STEPS,
                csInterface: csInterface,

                onStatus: function(msg) {
                    // (sem UI pra status agora, usa step counter)
                },

                onStep: function(stepNum, maxSteps) {
                    stepCounter.textContent = stepNum + '/' + maxSteps;
                    fill.style.width = Math.min(100, (stepNum / maxSteps) * 100) + '%';
                    getOrCreateStepGroup(stepNum);
                },

                onToolCall: function(name, args, idx, step) {
                    var stepEl = getOrCreateStepGroup(step);
                    var card = self._agentToolCard(name, args);
                    cardsByIdx[idx] = card;
                    stepEl.appendChild(card);
                    toolCount++;
                    // Conta tools desse step
                    var toolsInStep = stepEl.querySelectorAll('.agent-tool').length;
                    updateStepCount(toolsInStep);
                    self._aiScroll();
                },

                onToolResult: function(name, result, idx, step) {
                    var card = cardsByIdx[idx];
                    if (!card) return;
                    card.classList.remove('pending', 'running');
                    var summary = self._agentResultSummary(result);
                    if (result.ok) {
                        card.classList.add('ok');
                        card.querySelector('.agent-tool-status').textContent = 'âœ“';
                        var s = card.querySelector('.agent-tool-summary');
                        if (s) s.textContent = summary;
                        var rd = card.querySelector('.agent-tool-result');
                        if (rd) rd.textContent = summary;
                    } else {
                        card.classList.add('err');
                        card.classList.add('expanded'); // abre automatico em erro
                        card.querySelector('.agent-tool-status').textContent = 'âœ—';
                        var s2 = card.querySelector('.agent-tool-summary');
                        if (s2) s2.textContent = (result.error || 'erro').substring(0, 50);
                        var rdE = card.querySelector('.agent-tool-result');
                        if (rdE) rdE.textContent = result.error || 'erro';
                    }
                    var elapsed = card.querySelector('.agent-tool-elapsed');
                    if (elapsed && result._elapsed_ms !== undefined) {
                        elapsed.textContent = result._elapsed_ms + 'ms';
                    }
                    self._aiScroll();
                },

                onAssistant: function(text) {
                    if (currentStepEl) {
                        currentStepEl.classList.remove('running');
                        currentStepEl.classList.add('done');
                    }
                    stopBtn.disabled = true;
                    stopBtn.textContent = 'DONE';
                    fill.style.width = '100%';
                    if (text && text.trim()) {
                        finalMsg = document.createElement('div');
                        finalMsg.className = 'agent-final';
                        finalMsg.textContent = text;
                        bubble.appendChild(finalMsg);
                    }
                    self._aiBusy = false;
                    document.getElementById('ai-send').disabled = false;
                    self._aiAgentHandle = null;
                    self._aiScroll();
                },

                onError: function(err) {
                    if (currentStepEl) currentStepEl.classList.remove('running');
                    stopBtn.disabled = true;
                    stopBtn.textContent = 'ERROR';
                    var errMsg = document.createElement('div');
                    errMsg.className = 'agent-final';
                    errMsg.style.cssText = 'background:rgba(231,76,60,0.08);border-color:var(--red);color:var(--red)';
                    errMsg.textContent = 'âœ— ' + err.message;
                    bubble.appendChild(errMsg);
                    self._aiBusy = false;
                    document.getElementById('ai-send').disabled = false;
                    self._aiAgentHandle = null;
                    self._aiScroll();
                }
            });

            // Wire stop button
            stopBtn.onclick = function() {
                if (self._aiAgentHandle) {
                    self._aiAgentHandle.abort();
                    stopBtn.disabled = true;
                    stopBtn.textContent = 'STOPPED';
                    if (currentStepEl) currentStepEl.classList.remove('running');
                    self._aiBusy = false;
                    document.getElementById('ai-send').disabled = false;
                    self._aiAgentHandle = null;
                }
            };
        },

        // Resume do resultado pra mostrar no summary
        _agentResultSummary: function(result) {
            if (!result) return '';
            if (!result.ok) return result.error || 'erro';
            var d = result.data || {};
            var parts = [];
            if (d.layer_id !== undefined) parts.push('layer_id=' + d.layer_id);
            if (d.comp_id !== undefined) parts.push('comp_id=' + d.comp_id);
            if (d.name) parts.push('"' + d.name + '"');
            if (d.keyframes_added !== undefined) parts.push(d.keyframes_added + ' kf');
            if (d.helper) parts.push(d.helper);
            if (d.keyframe_count !== undefined) parts.push(d.keyframe_count + ' kf total');
            return parts.join(' ') || 'ok';
        },

        // Cria um card de tool call pra UI (colapsavel, com retry em erro)
        _agentToolCard: function(name, args) {
            var card = document.createElement('div');
            card.className = 'agent-tool pending running';
            // Guarda referencia pras args pro retry button
            card._mtToolName = name;
            card._mtToolArgs = args;
            card.onclick = function(ev) {
                // Nao colapsa se clicou em botoes filhos
                if (ev.target.tagName === 'BUTTON') return;
                card.classList.toggle('expanded');
            };

            var hdr = document.createElement('div');
            hdr.className = 'agent-tool-hdr';

            var status = document.createElement('span');
            status.className = 'agent-tool-status';
            status.textContent = 'âš¡';
            hdr.appendChild(status);

            var nm = document.createElement('span');
            nm.className = 'agent-tool-name';
            nm.textContent = name;
            hdr.appendChild(nm);

            // Summary (compact, visible when collapsed)
            var summary = document.createElement('span');
            summary.className = 'agent-tool-summary';
            summary.textContent = MT._agentArgsSummary(args);
            hdr.appendChild(summary);

            var elapsed = document.createElement('span');
            elapsed.className = 'agent-tool-elapsed';
            elapsed.textContent = '...';
            hdr.appendChild(elapsed);

            card.appendChild(hdr);

            // Details (expanded view)
            var details = document.createElement('div');
            details.className = 'agent-tool-details';

            var argsEl = document.createElement('div');
            argsEl.className = 'agent-tool-args';
            argsEl.textContent = MT._agentArgsFull(args);
            details.appendChild(argsEl);

            var resEl = document.createElement('div');
            resEl.className = 'agent-tool-result';
            details.appendChild(resEl);

            // Retry button (fica visivel so em erro via CSS)
            var retryBtn = document.createElement('button');
            retryBtn.className = 'agent-tool-retry';
            retryBtn.textContent = 'â†» RETRY';
            retryBtn.onclick = function(ev) {
                ev.stopPropagation();
                MT._retryToolCall(card, retryBtn);
            };
            details.appendChild(retryBtn);

            card.appendChild(details);

            return card;
        },

        // Re-executa uma tool call que falhou
        _retryToolCall: function(card, btn) {
            if (!window.MT_AGENT || !card._mtToolName) return;
            if (btn.disabled) return;

            btn.disabled = true;
            btn.classList.add('retrying');
            btn.textContent = 'âŸ³';
            card.classList.remove('err');
            card.classList.add('running');
            var status = card.querySelector('.agent-tool-status');
            if (status) status.textContent = 'âš¡';
            var resEl = card.querySelector('.agent-tool-result');
            if (resEl) resEl.textContent = 'retrying...';

            window.MT_AGENT.dispatchTool(csInterface, card._mtToolName, card._mtToolArgs, function(result) {
                btn.disabled = false;
                btn.classList.remove('retrying');
                btn.textContent = 'â†» RETRY';
                card.classList.remove('running');
                var summary = MT._agentResultSummary(result);
                if (result.ok) {
                    card.classList.add('ok');
                    card.classList.remove('err', 'expanded');
                    if (status) status.textContent = 'âœ“';
                    var sEl = card.querySelector('.agent-tool-summary');
                    if (sEl) sEl.textContent = summary;
                    if (resEl) resEl.textContent = summary;
                } else {
                    card.classList.add('err');
                    if (status) status.textContent = 'âœ—';
                    if (resEl) resEl.textContent = result.error || 'erro';
                }
                var el = card.querySelector('.agent-tool-elapsed');
                if (el && result._elapsed_ms !== undefined) {
                    el.textContent = result._elapsed_ms + 'ms (retry)';
                }
            });
        },

        // Compact summary das args (uma linha pra caber no header)
        _agentArgsSummary: function(args) {
            if (!args) return '';
            // Prioriza os args mais importantes pra mostrar na linha
            var priority = ['text', 'name', 'color', 'helper', 'property', 'layer_id'];
            var parts = [];
            for (var i = 0; i < priority.length; i++) {
                var k = priority[i];
                if (args[k] !== undefined) {
                    var v = args[k];
                    var vs = typeof v === 'string' ? '"' + (v.length > 20 ? v.substring(0,17)+'...' : v) + '"' : String(v);
                    parts.push(k + ':' + vs);
                    if (parts.length >= 2) break;
                }
            }
            return parts.join(' ');
        },

        // Full args (multi-line, visible when expanded)
        _agentArgsFull: function(args) {
            if (!args) return '';
            try {
                var keys = Object.keys(args);
                var parts = [];
                for (var i = 0; i < keys.length; i++) {
                    var k = keys[i];
                    var v = args[k];
                    var vs;
                    if (typeof v === 'string') vs = '"' + v + '"';
                    else if (v instanceof Array) vs = '[' + v.join(',') + ']';
                    else if (typeof v === 'object' && v !== null) vs = JSON.stringify(v);
                    else vs = String(v);
                    parts.push(k + ': ' + vs);
                }
                return '{ ' + parts.join(', ') + ' }';
            } catch(e) { return '{...}'; }
        },

        // Faz uma chamada LLM one-shot (sem streaming) no provider configurado â€” usado pra search e URL lookup
        _aiOneShot: function (userPrompt, maxTokens, cb, attempt) {
            var self = this;
            attempt = attempt || 0;
            var provider = self._aiGetProvider();
            if (!provider) { cb(''); return; }

            function retry() {
                if (attempt < self._aiMaxRetries) {
                    var delay = self._aiRetryDelay(attempt);
                    setTimeout(function () { self._aiOneShot(userPrompt, maxTokens, cb, attempt + 1); }, delay);
                } else {
                    cb('');
                }
            }

            // Ollama Cloud native â€” one-shot sem streaming (stream:false)
            {
                var epOneShot = provider.endpoint;
                var hdOneShot = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + provider.key };
                var oneShotBody = {
                    model: provider.model,
                    messages: [{ role: 'user', content: userPrompt }],
                    stream: false,
                    options: {
                        temperature: 0.3,
                        num_predict: maxTokens || 500
                    }
                };
                fetch(epOneShot, {
                    method: 'POST',
                    headers: hdOneShot,
                    body: JSON.stringify(oneShotBody)
                })
                .then(function (r) {
                    if (!r.ok && self._aiIsRetryable(r.status)) { retry(); return null; }
                    return r.json();
                })
                .then(function (data) {
                    if (!data) return;
                    var txt = '';
                    try { txt = (data.message && data.message.content) || ''; } catch (e) {}
                    // Limpar <think> tags do reasoning
                    txt = txt.replace(/<think>[\s\S]*?<\/think>/g, '').replace(/^\s+/, '');
                    cb(txt);
                })
                .catch(function () { retry(); });
            }
        },

        // Step 3: Search the web if AI requests it
        // Salva novo script gerado pela IA como referencia futura
        _aiSaveNewScript: function (name, fullText) {
            var self = this;
            try {
                // Pega o SEGUNDO bloco de codigo (o primeiro e o motion, o segundo e o script reutilizavel)
                var blocks = fullText.match(/```(?:javascript|jsx)?\s*\n([\s\S]*?)```/g);
                var scriptCode = '';
                if (blocks && blocks.length >= 2) {
                    // Segundo bloco = o script reutilizavel
                    var m2 = blocks[1].match(/```(?:javascript|jsx)?\s*\n([\s\S]*?)```/);
                    if (m2) scriptCode = m2[1].replace(/^\s+|\s+$/g, '');
                } else if (blocks && blocks.length === 1) {
                    // So 1 bloco = usa ele mesmo
                    var m1 = blocks[0].match(/```(?:javascript|jsx)?\s*\n([\s\S]*?)```/);
                    if (m1) scriptCode = m1[1].replace(/^\s+|\s+$/g, '');
                }

                if (!scriptCode || scriptCode.length < 50) {
                    self._aiAddMsg('status', 'âš  Script muito curto pra salvar');
                    return;
                }

                // Sanitiza o nome
                var safeName = name.toLowerCase().replace(/[^a-z0-9\-]/g, '-').replace(/--+/g, '-');
                var fileName = 'ai-gen-' + safeName + '.jsx';
                var extPath = csInterface.getSystemPath(SystemPath.EXTENSION);
                var filePath = extPath + '/docs/' + fileName;

                // Salva
                var result = window.cep.fs.writeFile(filePath, scriptCode);
                if (result.err === 0) {
                    self._aiAddMsg('status', 'ðŸ’¾ Novo script salvo: docs/' + fileName + ' (' + scriptCode.split('\n').length + ' linhas)');

                    // Registra no localStorage pra carregar nas proximas sessoes
                    var existing = localStorage.getItem('multiTools_aiGenScripts') || '';
                    if (existing.indexOf(fileName) === -1) {
                        localStorage.setItem('multiTools_aiGenScripts', existing ? existing + ',' + fileName : fileName);
                    }

                    // Recarrega o knowledge base pra incluir o novo script
                    self._loadAIKnowledge();
                    self._aiAddMsg('status', 'ðŸ§  Knowledge base atualizado â€” ' + fileName + ' disponivel como referencia');
                } else {
                    self._aiAddMsg('status', 'âš  Erro ao salvar script: ' + result.err);
                }
            } catch (e) {
                self._aiAddMsg('status', 'âš  Erro: ' + e.message);
            }
        },

        // Importar video/GIF como referencia visual â€” IA analisa e usa pra recriar
        aiAddVideo: function () {
            MT.toast('Analise de video indisponivel (dependia do Gemini Video API). Use imagens no botao de imagem.', true);
        },

        // Upload resumable pro Gemini Files API (mesmo codigo do aiImportVideo)
        _aiUploadToGemini: function (file, apiKey, mimeType, callback) {
            var self = this;
            fetch('https://generativelanguage.googleapis.com/upload/v1beta/files?key=' + encodeURIComponent(apiKey), {
                method: 'POST',
                headers: {
                    'X-Goog-Upload-Protocol': 'resumable',
                    'X-Goog-Upload-Command': 'start',
                    'X-Goog-Upload-Header-Content-Length': String(file.size),
                    'X-Goog-Upload-Header-Content-Type': mimeType,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ file: { display_name: file.name } })
            })
            .then(function (res) {
                if (!res.ok) return res.text().then(function (t) { throw new Error(res.status + ': ' + t.substring(0, 100)); });
                var uploadUrl = res.headers.get('X-Goog-Upload-URL') || res.headers.get('x-goog-upload-url');
                if (!uploadUrl) throw new Error('Sem upload URL');
                return uploadUrl;
            })
            .then(function (uploadUrl) {
                self._aiStatus('Enviando bytes...');
                return new Promise(function (resolve, reject) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        fetch(uploadUrl, {
                            method: 'POST',
                            headers: { 'Content-Length': String(file.size), 'X-Goog-Upload-Offset': '0', 'X-Goog-Upload-Command': 'upload, finalize' },
                            body: e.target.result
                        }).then(function (r) { return r.json(); }).then(resolve).catch(reject);
                    };
                    reader.readAsArrayBuffer(file);
                });
            })
            .then(function (uploadResult) {
                var f = uploadResult.file;
                if (!f || !f.name) throw new Error('Upload sem file data');
                self._aiStatus('Gemini processando video...');
                var attempts = 0;
                function poll() {
                    attempts++;
                    if (attempts > 60) { callback(null, null, 'Timeout'); return; }
                    fetch('https://generativelanguage.googleapis.com/v1beta/' + f.name + '?key=' + encodeURIComponent(apiKey))
                        .then(function (r) { return r.json(); })
                        .then(function (d) {
                            if (d.state === 'ACTIVE') callback(d.uri, d.mimeType || mimeType, null);
                            else if (d.state === 'FAILED') callback(null, null, 'Processamento falhou');
                            else setTimeout(poll, 2000);
                        }).catch(function (e) { callback(null, null, e.message); });
                }
                poll();
            })
            .catch(function (err) { callback(null, null, err.message); });
        },

        // Analisa video/GIF com o provider ativo (Gemini ou OpenRouter)
        _aiAnalyzeVideoWithGemini: function (fileUri, mimeType, inlineB64, fileName) {
            var self = this;
            var provider = self._aiGetProvider();

            var prompt = 'Voce esta vendo um video/GIF de referencia de MOTION GRAPHICS.\n' +
                'Analise e descreva TECNICAMENTE como RECRIAR no After Effects:\n\n' +
                '1. CENAS: cada cena/corte com timestamp e o que acontece\n' +
                '2. ELEMENTOS: textos (conteudo, tamanho, cor), shapes, icones\n' +
                '3. CORES: HEX codes de todas as cores\n' +
                '4. ANIMACOES: tipo de entrada/saida, timing, stagger\n' +
                '5. TRANSICOES: como muda de cena\n' +
                '6. TIPOGRAFIA: tipo de fonte, peso, tamanho\n' +
                '7. TIMING: duracao total, por cena\n' +
                'Seja DETALHADO. Vai ser usado pra ExtendScript.';

            var isGif = mimeType.indexOf('gif') !== -1;
            self._aiStatus((provider ? provider.name : 'LLM') + ' analisando ' + (isGif ? 'GIF' : 'video') + '...');

            // Se tem inline base64 (GIF pequeno) â€” manda direto pro provider ativo com visao
            if (inlineB64 && provider && (provider.name === 'openrouter')) {
                var endpoint = provider.endpoint || 'https://openrouter.ai/api/v1/chat/completions';
                var headers = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + provider.key };
                if (provider.name === 'openrouter') headers['HTTP-Referer'] = 'https://multitools.cep';

                fetch(endpoint, {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify({
                        model: provider.model,
                        messages: [{ role: 'user', content: [
                            { type: 'image_url', image_url: { url: 'data:' + mimeType + ';base64,' + inlineB64 } },
                            { type: 'text', text: prompt }
                        ] }],
                        max_tokens: 4000, temperature: 0.3
                    })
                })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    var txt = '';
                    try { txt = data.choices[0].message.content || ''; } catch (e) {}
                    txt = txt.replace(/<think>[\s\S]*?<\/think>/g, '').replace(/^\s+/, '');
                    self._aiHandleVideoAnalysis(txt, fileName);
                })
                .catch(function (err) { self._aiHandleVideoAnalysis('', fileName); });
                return;
            }

            // Se tem fileUri (video grande uploaded) â€” precisa Gemini (Files API so funciona com Gemini)
            var geminiKey = localStorage.getItem('multiTools_geminiKey');
            if (fileUri && geminiKey) {
                var geminiModel = self._aiGetVisionModel ? self._aiGetVisionModel() : (localStorage.getItem('multiTools_geminiModel') || 'gemini-2.5-flash');
                var gUrl = 'https://generativelanguage.googleapis.com/v1beta/models/' + geminiModel + ':generateContent?key=' + geminiKey;
                var parts = [{ fileData: { mimeType: mimeType, fileUri: fileUri } }, { text: prompt }];

                fetch(gUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ contents: [{ parts: parts }], generationConfig: { temperature: 0.3, maxOutputTokens: 4000 } })
                })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    var txt = '';
                    try { var ps = data.candidates[0].content.parts; for (var i = 0; i < ps.length; i++) { if (!ps[i].thought && ps[i].text) txt += ps[i].text; } } catch (e) {}
                    self._aiHandleVideoAnalysis(txt, fileName);
                })
                .catch(function (err) { self._aiHandleVideoAnalysis('', fileName); });
                return;
            }

            // Fallback: inline com Gemini
            if (inlineB64 && geminiKey) {
                var gModel = self._aiGetVisionModel ? self._aiGetVisionModel() : (localStorage.getItem('multiTools_geminiModel') || 'gemini-2.5-flash');
                fetch('https://generativelanguage.googleapis.com/v1beta/models/' + gModel + ':generateContent?key=' + geminiKey, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ contents: [{ parts: [{ inlineData: { mimeType: mimeType, data: inlineB64 } }, { text: prompt }] }], generationConfig: { temperature: 0.3, maxOutputTokens: 4000 } })
                })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    var txt = '';
                    try { var ps = data.candidates[0].content.parts; for (var i = 0; i < ps.length; i++) { if (!ps[i].thought && ps[i].text) txt += ps[i].text; } } catch (e) {}
                    self._aiHandleVideoAnalysis(txt, fileName);
                })
                .catch(function () { self._aiHandleVideoAnalysis('', fileName); });
                return;
            }

            self._aiAddMsg('bot', 'Nao consegui analisar â€” configure Gemini ou use Groq/Gemini.');
        },

        // Retorna o melhor modelo Gemini pra visao de video/GIF
        _aiGetVisionModel: function () {
            var model = localStorage.getItem('multiTools_geminiModel') || 'gemini-2.5-flash';
            // Se o usuario selecionou Gemma 4, usa pra visao
            // Senao, usa o modelo selecionado (todos Gemini 2.x suportam visao)
            return model;
        },

        _aiHandleVideoAnalysis: function (analysis, fileName) {
            var self = this;
            if (!analysis) {
                self._aiAddMsg('bot', 'Nao consegui analisar o video/GIF.');
                return;
            }
            self._aiAddMsg('status', 'âœ… Analisado: ' + analysis.substring(0, 120) + '...');
            self._aiVideoAnalysis = analysis;
            self._aiAddMsg('bot', 'ðŸ‘ Analisei "' + fileName + '". Diga o que quer criar baseado nele â€” ou diga "recrie esse video".');
        },

        _aiVideoAnalysis: null,

        _aiSearchCount: 0,
        _aiMaxSearches: 5,

        // Detecta acoes na resposta: [PESQUISAR], [REFERENCIA], [ANIMACAO], [PINTEREST]
        _aiCheckActions: function (response, msgs) {
            // Se ja tem code block, NAO dispara acoes â€” Gemini ja gerou o codigo,
            // qualquer [PESQUISAR:] ou [PINTEREST:] e ruido que causa chamada extra
            if (response && response.indexOf('```') !== -1) return false;
            // Tambem nao dispara se a resposta tem (function( â€” codigo cru sem markdown
            if (response && response.indexOf('(function') !== -1) return false;

            var searchMatch = response.match(/\[PESQUISAR:\s*(.+?)\]/);
            if (searchMatch) { this._aiSearch(searchMatch[1], msgs, response); return true; }
            var refMatch = response.match(/\[REFERENCIA:\s*(.+?)\]/);
            if (refMatch) { this._aiVisualRef(refMatch[1], msgs, response); return true; }
            var animMatch = response.match(/\[ANIMACAO:\s*(.+?)\]/);
            if (animMatch) { this._aiAnimationRef(animMatch[1], msgs, response); return true; }
            var pinMatch = response.match(/\[PINTEREST:\s*(.+?)\]/);
            if (pinMatch) { this._aiPinterestRef(pinMatch[1], msgs, response); return true; }
            return false;
        },

        // Busca GIF/video de motion no Pinterest, baixa thumbnail, analisa com visao
        _aiPinterestRef: function (query, originalMsgs, partialResponse) {
            var self = this;
            self._aiSearchCount++;
            if (self._aiSearchCount > self._aiMaxSearches) {
                originalMsgs.push({ role: 'assistant', content: partialResponse });
                originalMsgs.push({ role: 'user', content: 'Limite de pesquisas. Gere o codigo final.' });
                self._aiCallLLM(originalMsgs, function (r) {
                    if (!self._aiCheckActions(r, originalMsgs)) { self._aiSearchCount = 0; self._aiProcessResponse(r); }
                });
                return;
            }

            self._aiAddMsg('status', 'ðŸ“Œ Pinterest (' + self._aiSearchCount + '/' + self._aiMaxSearches + '): ' + query);

            // Passo 1: pedir ao LLM uma URL de GIF/video do Pinterest sobre o tema
            self._aiOneShot(
                'Find a direct GIF or image URL from Pinterest showing: "' + query + ' motion graphics animation design".\n' +
                'Search for URLs from these domains: i.pinimg.com, media.giphy.com, dribbble.com, cdn.dribbble.com\n' +
                'Give me ONLY one direct URL ending in .gif, .jpg, .png or .mp4. Just the raw URL, nothing else.\n' +
                'Prefer .gif URLs from i.pinimg.com (Pinterest CDN) as they show the animation.',
                400,
                function (urlText) {
                    var gifMatch = (urlText || '').match(/https?:\/\/[^\s"'<>]+\.gif/i);
                    var imgMatch = (urlText || '').match(/https?:\/\/[^\s"'<>]+\.(?:jpe?g|png|webp)/i);
                    var url = gifMatch ? gifMatch[0] : (imgMatch ? imgMatch[0] : null);

                    if (!url) {
                        // Fallback: buscar no Dribbble que tem mais GIFs de motion
                        url = 'https://cdn.dribbble.com/userupload/search?' + encodeURIComponent(query + ' motion animation');
                        // Usar Unsplash como ultimo fallback
                        url = 'https://source.unsplash.com/800x600/?' + encodeURIComponent(query + ' motion graphics design');
                    }

                    self._aiAddMsg('status', 'ðŸ“· Baixando referencia Pinterest...');

                    // Passo 2: baixar a imagem/GIF
                    var img = new Image();
                    img.crossOrigin = 'anonymous';
                    img.onload = function () {
                        var canvas = document.createElement('canvas');
                        canvas.width = Math.min(img.naturalWidth || img.width, 800);
                        canvas.height = Math.min(img.naturalHeight || img.height, 800);
                        var ctx = canvas.getContext('2d');
                        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                        var b64 = canvas.toDataURL('image/jpeg', 0.85).split(',')[1];

                        if (!b64) {
                            self._aiPinterestFallback(query, originalMsgs, partialResponse);
                            return;
                        }

                        // Passo 3: mandar pro provider ativo analisar
                        var provider = self._aiGetProvider();
                        var analysisPrompt = 'Voce esta vendo um frame/GIF de uma ANIMACAO DE MOTION GRAPHICS do Pinterest.\n' +
                            'Analise DETALHADAMENTE pra eu poder RECRIAR no After Effects:\n\n' +
                            '1. CENAS: quantas cenas/estados voce identifica? Descreva cada uma.\n' +
                            '2. CORES: liste TODOS os HEX codes visiveis (fundo, texto, accent, shapes)\n' +
                            '3. ELEMENTOS: textos (conteudo, tamanho), shapes (tipo, tamanho, roundness), icones\n' +
                            '4. LAYOUT: onde cada elemento esta posicionado (centro, topo, grid)\n' +
                            '5. ANIMACAO: como os elementos provavelmente se movem (bounce, slide, fade, scale)\n' +
                            '6. TIMING: stagger entre elementos, duracao de cada animacao\n' +
                            '7. ESTILO: mood geral (minimal, bold, elegant, playful, corporate)\n' +
                            '8. TIPOGRAFIA: sans-serif/serif, peso (bold/light), tamanhos\n' +
                            '9. TRANSICOES: como muda entre estados\n' +
                            'Seja TECNICO. Isso vai virar ExtendScript.';
                        var dataUrl = 'data:image/jpeg;base64,' + b64;

                        self._aiAddMsg('status', 'ðŸ‘ Analisando referencia Pinterest...');

                        if (provider && (provider.name === 'openrouter')) {
                            var endpoint = provider.endpoint || 'https://openrouter.ai/api/v1/chat/completions';
                            var headers = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + provider.key };
                            if (provider.name === 'openrouter') headers['HTTP-Referer'] = 'https://multitools.cep';

                            fetch(endpoint, {
                                method: 'POST',
                                headers: headers,
                                body: JSON.stringify({
                                    model: provider.model,
                                    messages: [{ role: 'user', content: [
                                        { type: 'image_url', image_url: { url: dataUrl } },
                                        { type: 'text', text: analysisPrompt }
                                    ] }],
                                    max_tokens: 3000, temperature: 0.3
                                })
                            })
                            .then(function (r) { return r.json(); })
                            .then(function (data) {
                                var txt = '';
                                try { txt = data.choices[0].message.content || ''; } catch (e) {}
                                txt = txt.replace(/<think>[\s\S]*?<\/think>/g, '').replace(/^\s+/, '');
                                self._aiHandlePinterestResult(txt, query, originalMsgs, partialResponse);
                            })
                            .catch(function () { self._aiPinterestFallback(query, originalMsgs, partialResponse); });
                        } else if (localStorage.getItem('multiTools_geminiKey')) {
                            var gKey = localStorage.getItem('multiTools_geminiKey');
                            var gModel = self._aiGetVisionModel ? self._aiGetVisionModel() : (localStorage.getItem('multiTools_geminiModel') || 'gemini-2.5-flash');
                            fetch('https://generativelanguage.googleapis.com/v1beta/models/' + gModel + ':generateContent?key=' + gKey, {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({
                                    contents: [{ parts: [{ inlineData: { mimeType: 'image/jpeg', data: b64 } }, { text: analysisPrompt }] }],
                                    generationConfig: { temperature: 0.3, maxOutputTokens: 3000 }
                                })
                            })
                            .then(function (r) { return r.json(); })
                            .then(function (data) {
                                var txt = '';
                                try { var ps = data.candidates[0].content.parts; for (var i = 0; i < ps.length; i++) { if (!ps[i].thought && ps[i].text) txt += ps[i].text; } } catch (e) {}
                                self._aiHandlePinterestResult(txt, query, originalMsgs, partialResponse);
                            })
                            .catch(function () { self._aiPinterestFallback(query, originalMsgs, partialResponse); });
                        } else {
                            self._aiPinterestFallback(query, originalMsgs, partialResponse);
                        }
                    };
                    img.onerror = function () { self._aiPinterestFallback(query, originalMsgs, partialResponse); };
                    img.src = url;
                }
            );
        },

        _aiHandlePinterestResult: function (analysis, query, originalMsgs, partialResponse) {
            var self = this;
            if (!analysis) { self._aiPinterestFallback(query, originalMsgs, partialResponse); return; }
            self._aiAddMsg('status', 'âœ… Pinterest: ' + analysis.substring(0, 120) + '...');

            originalMsgs.push({ role: 'assistant', content: partialResponse });
            originalMsgs.push({ role: 'user', content:
                '[REFERENCIA PINTEREST "' + query + '"]\n' + analysis + '\n[/PINTEREST]\n\n' +
                'RECRIE esse estilo no After Effects. Use as cores, layout, tipografia e animacoes que voce identificou.\n' +
                'Adapte pro pedido do usuario (marca, textos, resolucao).\n' +
                'Se precisar mais referencias: [PINTEREST: outro termo]. Senao, gere ```javascript.'
            });

            self._aiCallLLM(originalMsgs, function (response) {
                if (!self._aiCheckActions(response, originalMsgs)) {
                    self._aiSearchCount = 0;
                    self._aiProcessResponse(response);
                }
            });
        },

        _aiPinterestFallback: function (query, originalMsgs, partialResponse) {
            var self = this;
            self._aiOneShot('Descreva o estilo visual de motion graphics com o tema "' + query + '" que seria encontrado no Pinterest: cores HEX, layout, tipografia, animacoes, mood. CURTO e TECNICO.', 1000, function (desc) {
                originalMsgs.push({ role: 'assistant', content: partialResponse });
                originalMsgs.push({ role: 'user', content: '[DESCRICAO PINTEREST "' + query + '"]\n' + (desc || 'Sem descricao') + '\n[/DESCRICAO]\nRecrie esse estilo no AE.' });
                self._aiCallLLM(originalMsgs, function (r) {
                    if (!self._aiCheckActions(r, originalMsgs)) { self._aiSearchCount = 0; self._aiProcessResponse(r); }
                });
            });
        },

        // Busca ANIMACAO na internet, baixa screenshot, analisa visualmente, devolve pro LLM recriar
        _aiAnimationRef: function (query, originalMsgs, partialResponse) {
            var self = this;
            self._aiSearchCount++;

            if (self._aiSearchCount > self._aiMaxSearches) {
                originalMsgs.push({ role: 'assistant', content: partialResponse });
                originalMsgs.push({ role: 'user', content: 'Limite de pesquisas. Gere o codigo final agora.' });
                self._aiCallLLM(originalMsgs, function (r) {
                    if (!self._aiCheckActions(r, originalMsgs)) { self._aiSearchCount = 0; self._aiProcessResponse(r); }
                });
                return;
            }

            self._aiAddMsg('status', 'ðŸŽ¬ Buscando animacao (' + self._aiSearchCount + '/' + self._aiMaxSearches + '): ' + query);

            // Passo 1: buscar URL de imagem/screenshot da animacao
            self._aiOneShot('I need a direct image URL (JPG/PNG) showing a screenshot or frame of this animation: "' + query + '". Give me a URL from dribbble, behance, pinterest, or any design site. Just the raw URL, nothing else.', 300, function (urlText) {
                var urlMatch = (urlText || '').match(/https?:\/\/[^\s"'<>]+\.(?:jpe?g|png|gif|webp)/i);
                if (!urlMatch) {
                    urlMatch = ['https://source.unsplash.com/800x600/?' + encodeURIComponent(query + ' motion graphics animation')];
                }

                self._aiAddMsg('status', 'ðŸ“· Baixando frame da animacao...');

                // Passo 2: baixar imagem
                var img = new Image();
                img.crossOrigin = 'anonymous';
                img.onload = function () {
                    var canvas = document.createElement('canvas');
                    canvas.width = Math.min(img.naturalWidth || img.width, 800);
                    canvas.height = Math.min(img.naturalHeight || img.height, 600);
                    var ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                    var b64 = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];

                    if (!b64) {
                        self._aiAnimationFallback(query, originalMsgs, partialResponse);
                        return;
                    }

                    // Passo 3: analisar com VISAO (Qwen nativo ou Gemini)
                    var provider = self._aiGetProvider();
                    var analysisPrompt = 'Voce esta vendo um FRAME/SCREENSHOT de uma animacao de motion graphics.\n' +
                        'Analise e descreva COMO RECRIAR esta animacao no After Effects:\n\n' +
                        '1. ELEMENTOS VISUAIS: liste cada elemento que voce ve (textos, shapes, imagens, icones, fundo)\n' +
                        '2. CORES: HEX codes exatos de todas as cores visiveis\n' +
                        '3. TIPOGRAFIA: tipo de fonte (serif/sans/mono), peso (bold/regular), tamanho relativo\n' +
                        '4. LAYOUT: posicao de cada elemento (centro, topo, esquerda, grid)\n' +
                        '5. ANIMACAO PROVAVEL: baseado nos elementos, descreva como eles provavelmente animam:\n' +
                        '   - Ordem de entrada (o que aparece primeiro)\n' +
                        '   - Tipo de entrada (fade, scale pop, slide, reveal, bounce)\n' +
                        '   - Transicoes entre estados\n' +
                        '   - Micro-interacoes (hover, pulse, glow)\n' +
                        '6. TECNICA ExtendScript: qual abordagem usar pra recriar (keyframes, expressions, shape morph, text animators)\n' +
                        '7. TIMING sugerido: duracao total, duracao por cena, stagger entre elementos\n\n' +
                        'Seja TECNICO e PRECISO. Eu vou usar sua analise pra gerar ExtendScript ES3.';
                    var dataUrl = 'data:image/jpeg;base64,' + b64;

                    self._aiAddMsg('status', 'ðŸ‘ Analisando animacao...');

                    if (provider && (provider.name === 'openrouter')) {
                        var endpoint = provider.endpoint || 'https://openrouter.ai/api/v1/chat/completions';
                        var headers = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + provider.key };
                        if (provider.name === 'openrouter') headers['HTTP-Referer'] = 'https://multitools.cep';

                        fetch(endpoint, {
                            method: 'POST',
                            headers: headers,
                            body: JSON.stringify({
                                model: provider.model,
                                messages: [{ role: 'user', content: [
                                    { type: 'image_url', image_url: { url: dataUrl } },
                                    { type: 'text', text: analysisPrompt }
                                ] }],
                                max_tokens: 2000, temperature: 0.3
                            })
                        })
                        .then(function (r) { return r.json(); })
                        .then(function (data) {
                            var analysis = '';
                            try { analysis = data.choices[0].message.content || ''; } catch (e) {}
                            analysis = analysis.replace(/<think>[\s\S]*?<\/think>/g, '').replace(/^\s+/, '');
                            self._aiHandleAnimationResult(analysis, query, originalMsgs, partialResponse);
                        })
                        .catch(function () { self._aiAnimationFallback(query, originalMsgs, partialResponse); });

                    } else if (localStorage.getItem('multiTools_geminiKey')) {
                        var gKey = localStorage.getItem('multiTools_geminiKey');
                        var gModel = self._aiGetVisionModel ? self._aiGetVisionModel() : (localStorage.getItem('multiTools_geminiModel') || 'gemini-2.5-flash');
                        fetch('https://generativelanguage.googleapis.com/v1beta/models/' + gModel + ':generateContent?key=' + gKey, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                contents: [{ parts: [
                                    { inlineData: { mimeType: 'image/jpeg', data: b64 } },
                                    { text: analysisPrompt }
                                ] }],
                                generationConfig: { temperature: 0.3, maxOutputTokens: 2000 }
                            })
                        })
                        .then(function (r) { return r.json(); })
                        .then(function (data) {
                            var analysis = '';
                            try { analysis = data.candidates[0].content.parts[0].text || ''; } catch (e) {}
                            self._aiHandleAnimationResult(analysis, query, originalMsgs, partialResponse);
                        })
                        .catch(function () { self._aiAnimationFallback(query, originalMsgs, partialResponse); });
                    } else {
                        self._aiAnimationFallback(query, originalMsgs, partialResponse);
                    }
                };
                img.onerror = function () { self._aiAnimationFallback(query, originalMsgs, partialResponse); };
                img.src = urlMatch[0];
            });
        },

        _aiHandleAnimationResult: function (analysis, query, originalMsgs, partialResponse) {
            var self = this;
            if (!analysis) analysis = 'Nao consegui analisar a animacao.';
            self._aiAddMsg('status', 'âœ… Animacao analisada: ' + analysis.substring(0, 120) + '...');

            originalMsgs.push({ role: 'assistant', content: partialResponse });
            originalMsgs.push({ role: 'user', content:
                '[ANIMACAO ANALISADA "' + query + '"]\n' + analysis + '\n[/ANIMACAO]\n\n' +
                'RECRIE esta animacao no After Effects usando ExtendScript ES3.\n' +
                'Use os elementos, cores, layout, timing e tecnica que voce identificou.\n' +
                'ADAPTE pro pedido do usuario (cores da marca, textos, resolucao da comp).\n' +
                'Se precisar mais referencias, [ANIMACAO: ...] ou [REFERENCIA: ...] ou [PESQUISAR: ...]. Senao, gere o codigo final.'
            });

            self._aiCallLLM(originalMsgs, function (response) {
                if (!self._aiCheckActions(response, originalMsgs)) {
                    self._aiSearchCount = 0;
                    self._aiProcessResponse(response);
                }
            });
        },

        _aiAnimationFallback: function (query, originalMsgs, partialResponse) {
            var self = this;
            self._aiOneShot('Descreva TECNICAMENTE como recriar esta animacao no After Effects: "' + query + '". Liste: elementos visuais, cores HEX, timing, tipo de entrada/saida, tecnica ExtendScript. CURTO e TECNICO.', 1000, function (desc) {
                originalMsgs.push({ role: 'assistant', content: partialResponse });
                originalMsgs.push({ role: 'user', content: '[DESCRICAO ANIMACAO "' + query + '"]\n' + (desc || 'Sem descricao') + '\n[/DESCRICAO]\nRecrie no AE.' });
                self._aiCallLLM(originalMsgs, function (r) {
                    if (!self._aiCheckActions(r, originalMsgs)) { self._aiSearchCount = 0; self._aiProcessResponse(r); }
                });
            });
        },

        // Busca IMAGEM de referencia na internet, manda pro Gemini Vision analisar, devolve a analise
        _aiVisualRef: function (query, originalMsgs, partialResponse) {
            var self = this;
            self._aiSearchCount++;

            if (self._aiSearchCount > self._aiMaxSearches) {
                self._aiAddMsg('status', 'âš  Limite de pesquisas visuais atingido');
                originalMsgs.push({ role: 'assistant', content: partialResponse });
                originalMsgs.push({ role: 'user', content: 'Limite de referencias. Gere o codigo final agora.' });
                self._aiCallLLM(originalMsgs, function (r) {
                    if (!self._aiCheckActions(r, originalMsgs)) self._aiProcessResponse(r);
                });
                return;
            }

            self._aiAddMsg('status', 'ðŸ‘ Buscando referencia visual (' + self._aiSearchCount + '/' + self._aiMaxSearches + '): ' + query);
            self._aiStatus('Buscando imagem: ' + query + '...');

            // Passo 1: pedir URL de imagem ao LLM
            self._aiOneShot('I need a direct image URL (JPEG/PNG) of: "' + query + ' motion graphics design screenshot". Give ONLY one URL from a real website. Just the raw URL, nothing else.', 300, function (urlText) {
                var urlMatch = (urlText || '').match(/https?:\/\/[^\s"'<>]+\.(?:jpe?g|png|webp)/i);

                if (!urlMatch) {
                    // Fallback: usar Unsplash
                    urlMatch = ['https://source.unsplash.com/800x600/?' + encodeURIComponent(query)];
                }

                var imgUrl = urlMatch[0];
                self._aiAddMsg('status', 'ðŸ“· Baixando: ' + imgUrl.substring(0, 60) + '...');

                // Passo 2: baixar e converter pra base64
                var img = new Image();
                img.crossOrigin = 'anonymous';
                img.onload = function () {
                    var canvas = document.createElement('canvas');
                    canvas.width = Math.min(img.naturalWidth || img.width, 800);
                    canvas.height = Math.min(img.naturalHeight || img.height, 600);
                    var ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                    var b64 = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];

                    if (!b64) {
                        self._aiAddMsg('status', 'âš  Falha ao processar imagem. Continuando sem referencia.');
                        self._aiFallbackRef(query, originalMsgs, partialResponse);
                        return;
                    }

                    // Passo 3: analisar a imagem com VISAO
                    // Groq/Gemini TEM visao nativa â€” manda direto pra ele
                    // Gemini tambem tem â€” usa quem estiver disponivel
                    var provider = self._aiGetProvider();
                    var analysisPrompt = 'Analise esta imagem de referencia visual de motion graphics. Descreva PRECISAMENTE:\n1. PALETA: 4-5 HEX codes das cores dominantes\n2. TIPOGRAFIA: serif/sans/mono, pesos, tamanhos\n3. LAYOUT: alinhamento, grid, espacamento\n4. ELEMENTOS: shapes, icones, cards, blobs, gradientes\n5. ANIMACAO: como animar esses elementos (entrada/saida/transicao)\n6. MOOD: 3 adjetivos do estilo\nCURTO e PRECISO.';
                    var dataUrl = 'data:image/jpeg;base64,' + b64;

                    self._aiAddMsg('status', 'ðŸ‘ Analisando com ' + (provider ? provider.name : 'LLM') + '...');

                    if (provider && (provider.name === 'openrouter')) {
                        // OpenRouter/Groq: formato OpenAI multimodal
                        var endpoint = provider.endpoint || 'https://openrouter.ai/api/v1/chat/completions';
                        var headers = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + provider.key };
                        if (provider.name === 'openrouter') { headers['HTTP-Referer'] = 'https://multitools.cep'; }

                        fetch(endpoint, {
                            method: 'POST',
                            headers: headers,
                            body: JSON.stringify({
                                model: provider.model,
                                messages: [{ role: 'user', content: [
                                    { type: 'image_url', image_url: { url: dataUrl } },
                                    { type: 'text', text: analysisPrompt }
                                ] }],
                                max_tokens: 1500, temperature: 0.3
                            })
                        })
                        .then(function (r) { return r.json(); })
                        .then(function (data) {
                            var analysis = '';
                            try { analysis = data.choices[0].message.content || ''; } catch (e) {}
                            analysis = analysis.replace(/<think>[\s\S]*?<\/think>/g, '').replace(/^\s+/, '');
                            self._aiHandleVisualResult(analysis, query, originalMsgs, partialResponse);
                        })
                        .catch(function () { self._aiFallbackRef(query, originalMsgs, partialResponse); });

                    } else if (localStorage.getItem('multiTools_geminiKey')) {
                        // Gemini Vision fallback
                        var geminiKey = localStorage.getItem('multiTools_geminiKey');
                        var geminiModel = self._aiGetVisionModel ? self._aiGetVisionModel() : (localStorage.getItem('multiTools_geminiModel') || 'gemini-2.5-flash');
                        fetch('https://generativelanguage.googleapis.com/v1beta/models/' + geminiModel + ':generateContent?key=' + geminiKey, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                contents: [{ parts: [
                                    { inlineData: { mimeType: 'image/jpeg', data: b64 } },
                                    { text: analysisPrompt }
                                ] }],
                                generationConfig: { temperature: 0.3, maxOutputTokens: 1000 }
                            })
                        })
                        .then(function (r) { return r.json(); })
                        .then(function (data) {
                            var analysis = '';
                            try { analysis = data.candidates[0].content.parts[0].text || ''; } catch (e) {}
                            self._aiHandleVisualResult(analysis, query, originalMsgs, partialResponse);
                        })
                        .catch(function () { self._aiFallbackRef(query, originalMsgs, partialResponse); });
                    } else {
                        self._aiFallbackRef(query, originalMsgs, partialResponse);
                    }
                };
                img.onerror = function () { self._aiFallbackRef(query, originalMsgs, partialResponse); };
                img.src = imgUrl;
            });
        },

        // Processa resultado da analise visual e injeta na conversa
        _aiHandleVisualResult: function (analysis, query, originalMsgs, partialResponse) {
            var self = this;
            if (!analysis) analysis = 'Nao consegui analisar a imagem.';
            self._aiAddMsg('status', 'âœ… Referencia: ' + analysis.substring(0, 120) + '...');

            originalMsgs.push({ role: 'assistant', content: partialResponse });
            originalMsgs.push({ role: 'user', content: '[ANALISE VISUAL "' + query + '"]\n' + analysis + '\n[/ANALISE]\n\nUse esta analise pra guiar o estilo. Se precisar mais, [REFERENCIA: ...] ou [PESQUISAR: ...]. Senao, gere o codigo final.' });

            self._aiCallLLM(originalMsgs, function (response) {
                if (!self._aiCheckActions(response, originalMsgs)) {
                    self._aiSearchCount = 0;
                    self._aiProcessResponse(response);
                }
            });
        },

        // Fallback quando Vision nao ta disponivel â€” descreve via texto
        _aiFallbackRef: function (query, originalMsgs, partialResponse) {
            var self = this;
            self._aiOneShot('Descreva o estilo visual de "' + query + '" em motion graphics: cores HEX, formas, layout, tipografia, animacoes. CURTO.', 800, function (desc) {
                originalMsgs.push({ role: 'assistant', content: partialResponse });
                originalMsgs.push({ role: 'user', content: '[DESCRICAO VISUAL "' + query + '"]\n' + (desc || 'Sem descricao') + '\n[/DESCRICAO]\nGere o codigo.' });
                self._aiCallLLM(originalMsgs, function (r) {
                    if (!self._aiCheckActions(r, originalMsgs)) { self._aiSearchCount = 0; self._aiProcessResponse(r); }
                });
            });
        },

        _aiSearch: function (query, originalMsgs, partialResponse) {
            var self = this;
            self._aiSearchCount++;

            if (self._aiSearchCount > self._aiMaxSearches) {
                self._aiAddMsg('status', 'âš  Limite de pesquisas atingido (' + self._aiMaxSearches + ')');
                originalMsgs.push({ role: 'assistant', content: partialResponse });
                originalMsgs.push({ role: 'user', content: 'Limite de pesquisas atingido. Gere o codigo final agora com o que voce tem.' });
                self._aiCallLLM(originalMsgs, function (response) { self._aiProcessResponse(response); });
                return;
            }

            self._aiAddMsg('status', 'ðŸ” Pesquisando (' + self._aiSearchCount + '/' + self._aiMaxSearches + '): ' + query);
            self._aiStatus('Pesquisando: ' + query + '...');

            // Pesquisa INTELIGENTE â€” prompt adaptado ao tipo de query
            var searchPrompt = '';
            if (query.toLowerCase().indexOf('cor') !== -1 || query.toLowerCase().indexOf('paleta') !== -1 || query.toLowerCase().indexOf('marca') !== -1) {
                searchPrompt = 'Quais sao as cores oficiais, tipografia e estilo visual de: ' + query + '? Liste os HEX codes exatos, fontes usadas e adjetivos do estilo. CURTO e PRECISO.';
            } else if (query.toLowerCase().indexOf('tendencia') !== -1 || query.toLowerCase().indexOf('estilo') !== -1 || query.toLowerCase().indexOf('trend') !== -1) {
                searchPrompt = 'Descreva o estilo visual "' + query + '" em motion graphics: cores tipicas (HEX), formas, animacoes, tipografia, layout. CURTO e PRECISO.';
            } else if (query.toLowerCase().indexOf('extendscript') !== -1 || query.toLowerCase().indexOf('after effects') !== -1 || query.toLowerCase().indexOf('erro') !== -1) {
                searchPrompt = 'ExtendScript ES3 After Effects: ' + query + '. Responda com a solucao em codigo funcional ES3 (so var, sem const/let). Maximo 10 linhas.';
            } else {
                searchPrompt = query + '. Responda de forma CURTA e PRECISA com informacoes uteis pra um motion designer.';
            }

            self._aiOneShot(searchPrompt, 1500, function (searchResult) {
                if (!searchResult) { searchResult = 'Sem resultados para: ' + query; }

                self._aiAddMsg('status', 'âœ… Resultado: ' + searchResult.substring(0, 100) + '...');

                originalMsgs.push({ role: 'assistant', content: partialResponse });
                originalMsgs.push({ role: 'user', content: '[RESULTADO DA PESQUISA "' + query + '"]\n' + searchResult + '\n[/RESULTADO]\n\nUse essa informacao. Se precisar pesquisar MAIS, diga [PESQUISAR: outro termo]. Senao, gere o codigo final completo.' });

                self._aiCallLLM(originalMsgs, function (response) {
                    // Checa se a IA quer pesquisar MAIS (encadeamento)
                    var nextSearch = response.match(/\[PESQUISAR:\s*(.+?)\]/);
                    if (nextSearch) {
                        self._aiSearch(nextSearch[1], originalMsgs, response);
                    } else {
                        self._aiSearchCount = 0; // reset pro proximo request
                        self._aiProcessResponse(response);
                    }
                });
            });
        },

        // Download images from web, save as PNG in temp folder
        _aiDownloadImages: function (imageRequests, callback) {
            var self = this;
            if (!imageRequests || imageRequests.length === 0) { callback(); return; }

            var completed = 0;
            var total = imageRequests.length;
            self._aiStatus('Baixando ' + total + ' imagem(ns)...');

            // Get temp dir first
            csInterface.evalScript('Folder.temp.fsName', function (tempDir) {

                for (var i = 0; i < total; i++) {
                    (function (idx, query) {
                        self._aiSearchAndDownloadImage(query, idx, tempDir, function (success) {
                            if (success) {
                                self._aiAddMsg('status', 'Imagem ' + (idx + 1) + ': ' + query);
                            } else {
                                self._aiAddMsg('status', 'Falha imagem ' + (idx + 1));
                            }
                            completed++;
                            if (completed >= total) callback();
                        });
                    })(i, imageRequests[i]);
                }

            });
        },

        // Search for image URL using the AI, then download it
        _aiSearchAndDownloadImage: function (query, idx, tempDir, callback) {
            var self = this;
            var provider = self._aiGetProvider();

            if (provider) {
                self._aiOneShot('I need a direct JPEG/JPG image URL for: "' + query + '". Give me ONLY one direct URL ending in .jpg or .jpeg from a real website (stock photo, wikipedia, cdn). No explanation, no markdown, JUST the raw URL. MUST be .jpg or .jpeg format, real photo.', 200, function (content) {
                    var urlMatch = content.match(/https?:\/\/[^\s"'<>]+\.(?:jpe?g|png)/i);
                    if (urlMatch) {
                        self._aiDownloadFromURL(urlMatch[0], idx, tempDir, callback);
                    } else {
                        self._aiDownloadFromUnsplash(query, idx, tempDir, callback);
                    }
                });
            } else {
                self._aiDownloadFromUnsplash(query, idx, tempDir, callback);
            }
        },

        // Download image and convert to REAL JPEG via canvas
        _aiDownloadFromURL: function (url, idx, tempDir, callback) {
            var self = this;
            var img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = function () {
                // Convert to real JPEG using canvas (fundo branco pois JPEG nao tem alpha)
                var canvas = document.createElement('canvas');
                canvas.width = img.naturalWidth || img.width;
                canvas.height = img.naturalHeight || img.height;
                var ctx = canvas.getContext('2d');
                ctx.fillStyle = '#ffffff';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(img, 0, 0);
                var jpgDataUrl = canvas.toDataURL('image/jpeg', 0.92);
                var b64 = jpgDataUrl.split(',')[1];
                if (b64) {
                    var filePath = tempDir + '/mt_img_' + idx + '.jpg';
                    window.cep.fs.writeFile(filePath, b64, cep.encoding.Base64);
                    callback(true);
                } else {
                    callback(false);
                }
            };
            img.onerror = function () {
                self._aiDownloadFromUnsplash('', idx, tempDir, callback);
            };
            img.src = url;
        },

        // Fallback: Unsplash â†’ convert to JPEG via canvas
        _aiDownloadFromUnsplash: function (query, idx, tempDir, callback) {
            var url = 'https://source.unsplash.com/1080x1080/?' + encodeURIComponent(query || 'abstract');
            var img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = function () {
                var canvas = document.createElement('canvas');
                canvas.width = img.naturalWidth || img.width;
                canvas.height = img.naturalHeight || img.height;
                var ctx = canvas.getContext('2d');
                ctx.fillStyle = '#ffffff';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(img, 0, 0);
                var jpgDataUrl = canvas.toDataURL('image/jpeg', 0.92);
                var b64 = jpgDataUrl.split(',')[1];
                if (b64) {
                    var filePath = tempDir + '/mt_img_' + idx + '.jpg';
                    window.cep.fs.writeFile(filePath, b64, cep.encoding.Base64);
                    callback(true);
                } else { callback(false); }
            };
            img.onerror = function () { callback(false); };
            img.src = url;
        },

        // Download icons from Iconify API, convert SVGâ†’PNG, save to temp
        _aiDownloadIcons: function (iconRequests, callback) {
            var self = this;
            if (!iconRequests || iconRequests.length === 0) { callback(); return; }

            var completed = 0;
            var total = iconRequests.length;
            self._aiStatus('Baixando ' + total + ' icone(s) do Flaticon...');

            csInterface.evalScript('Folder.temp.fsName', function (tempDir) {
                for (var i = 0; i < total; i++) {
                    (function (idx, name) {
                        self._aiDownloadIconFromFlaticon(name, idx, tempDir, function (ok) {
                            if (ok) self._aiAddMsg('status', 'âœ“ Icone ' + (idx + 1) + ': ' + name);
                            else self._aiAddMsg('status', 'âš  Icone nao encontrado: ' + name);
                            completed++;
                            if (completed >= total) callback();
                        });
                    })(i, iconRequests[i]);
                }
            });
        },

        // Baixa icone via APIs deterministicas (sem depender de LLM):
        // 1. Simple Icons (logos/marcas): cdn.simpleicons.org
        // 2. Iconify Search API (busca real): api.iconify.design/search
        // 3. Iconify Lucide/MDI por nome (fallback)
        _aiDownloadIconFromFlaticon: function (name, idx, tempDir, callback) {
            var self = this;
            var cleanName = name.toLowerCase().replace(/[^a-z0-9 -]/g, '').replace(/\s+/g, '-').replace(/--+/g, '-');
            // Remove sufixos como "logo", "icon", "icone" pra busca mais limpa
            var searchName = cleanName.replace(/-?(logo|icon|icone|logotipo)s?$/g, '').replace(/^(logo|icon|icone)-?/g, '');
            if (!searchName) searchName = cleanName;

            console.log('[MultiTools] Icon download: "' + name + '" â†’ clean="' + cleanName + '" search="' + searchName + '"');

            // Funcao auxiliar: renderiza SVG ou PNG no canvas 128x128 e salva
            function renderAndSave(imgUrl, onFail) {
                var isSvg = imgUrl.indexOf('.svg') !== -1;
                var img = new Image();
                img.crossOrigin = 'anonymous';
                img.onload = function () {
                    var canvas = document.createElement('canvas');
                    canvas.width = 128; canvas.height = 128;
                    canvas.getContext('2d').drawImage(img, 0, 0, 128, 128);
                    var b64 = canvas.toDataURL('image/png').split(',')[1];
                    if (b64) {
                        window.cep.fs.writeFile(tempDir + '/mt_icon_' + idx + '.png', b64, cep.encoding.Base64);
                        callback(true);
                    } else { onFail ? onFail() : callback(false); }
                };
                img.onerror = function () { onFail ? onFail() : callback(false); };
                if (isSvg) {
                    fetch(imgUrl).then(function(r){ return r.text(); }).then(function(svg) {
                        if (svg.indexOf('<svg') === -1) { onFail ? onFail() : callback(false); return; }
                        var blob = new Blob([svg], { type: 'image/svg+xml' });
                        img.src = URL.createObjectURL(blob);
                    }).catch(function() { onFail ? onFail() : callback(false); });
                } else {
                    img.src = imgUrl;
                }
            }

            // STEP 1: Simple Icons (marcas/logos â€” Google, Apple, Instagram, etc.)
            var simpleIconUrl = 'https://cdn.simpleicons.org/' + searchName + '/white';
            console.log('[MultiTools] Step 1 - Simple Icons: ' + simpleIconUrl);
            renderAndSave(simpleIconUrl, function () {
                // STEP 2: Iconify Search API (busca real, nao adivinhacao)
                var searchUrl = 'https://api.iconify.design/search?query=' + encodeURIComponent(name.replace(/logo|icon|icone/gi, '').trim()) + '&limit=5';
                console.log('[MultiTools] Step 2 - Iconify Search: ' + searchUrl);
                fetch(searchUrl).then(function(r){ return r.json(); }).then(function(data) {
                    if (data.icons && data.icons.length > 0) {
                        // Pega o primeiro resultado: formato "prefix:name"
                        var iconId = data.icons[0];
                        var parts = iconId.split(':');
                        var iconUrl = 'https://api.iconify.design/' + parts[0] + '/' + parts[1] + '.svg?color=white&width=128&height=128';
                        console.log('[MultiTools] Iconify found: ' + iconId + ' â†’ ' + iconUrl);
                        renderAndSave(iconUrl, function () {
                            // STEP 3: Iconify Lucide por nome direto
                            var lucideUrl = 'https://api.iconify.design/lucide/' + searchName + '.svg?color=white&width=128&height=128';
                            console.log('[MultiTools] Step 3 - Lucide fallback: ' + lucideUrl);
                            renderAndSave(lucideUrl, function () {
                                // STEP 4: Iconify MDI por nome direto
                                var mdiUrl = 'https://api.iconify.design/mdi/' + searchName + '.svg?color=white&width=128&height=128';
                                console.log('[MultiTools] Step 4 - MDI fallback: ' + mdiUrl);
                                renderAndSave(mdiUrl, function () { callback(false); });
                            });
                        });
                    } else {
                        // Search retornou vazio â€” pula pro Lucide/MDI
                        var lucideUrl = 'https://api.iconify.design/lucide/' + searchName + '.svg?color=white&width=128&height=128';
                        renderAndSave(lucideUrl, function () {
                            var mdiUrl = 'https://api.iconify.design/mdi/' + searchName + '.svg?color=white&width=128&height=128';
                            renderAndSave(mdiUrl, function () { callback(false); });
                        });
                    }
                }).catch(function() {
                    // Iconify search falhou â€” tenta direto por nome
                    var lucideUrl = 'https://api.iconify.design/lucide/' + searchName + '.svg?color=white&width=128&height=128';
                    renderAndSave(lucideUrl, function () {
                        var mdiUrl = 'https://api.iconify.design/mdi/' + searchName + '.svg?color=white&width=128&height=128';
                        renderAndSave(mdiUrl, function () { callback(false); });
                    });
                });
            });
        },

        // Process AI response: extract images, code, fix, execute
        _aiProcessResponse: function (text) {
            var self = this;
            self._aiMsgs.push({ role: 'assistant', content: text });
            var bubble = self._aiAddMsg('bot', text);

            // Check for image requests [IMAGEM: description]
            var imgRegex = /\[IMAGEM:\s*(.+?)\]/g;
            var imgMatch;
            var imageRequests = [];
            while ((imgMatch = imgRegex.exec(text)) !== null) {
                imageRequests.push(imgMatch[1]);
            }

            // Check for icon requests [ICONE: name]
            var iconRegex = /\[ICONE:\s*(.+?)\]/g;
            var iconMatch;
            var iconRequests = [];
            while ((iconMatch = iconRegex.exec(text)) !== null) {
                iconRequests.push(iconMatch[1]);
            }

            // Check for new script creation [NOVO_SCRIPT: name]
            var newScriptMatch = text.match(/\[NOVO_SCRIPT:\s*(.+?)\]/);
            if (newScriptMatch) {
                self._aiSaveNewScript(newScriptMatch[1], text);
            }

            // Extrair bloco HTML (preview) se existir
            // Aceita code block COMPLETO ou TRUNCADO. Aceita com/sem linguagem.
            var m = text.match(/```(?:javascript|jsx|js)?\s*\n([\s\S]*?)```/);
            if (!m) {
                // Tenta fallback: code block sem fechamento (truncado)
                var openIdx = text.search(/```(?:javascript|jsx|js)?\s*\n\(function/);
                if (openIdx !== -1) {
                    var afterOpen = text.substring(openIdx).replace(/^```(?:javascript|jsx|js)?\s*\n/, '');
                    if (afterOpen.length > 50 && afterOpen.indexOf('(function') !== -1) {
                        self._aiAddMsg('status', 'âš  Code block sem fechamento â€” usando o que tem (' + afterOpen.length + ' chars)');
                        m = [null, afterOpen];
                    }
                }
                // Tenta fallback 2: codigo cru sem ``` (IA esqueceu o markdown)
                if (!m) {
                    var rawIife = text.indexOf('(function');
                    if (rawIife !== -1 && text.length > rawIife + 100) {
                        self._aiAddMsg('status', 'âš  Sem ``` mas tem (function â€” usando codigo cru');
                        m = [null, text.substring(rawIife)];
                    }
                }
            }

            if (!m) {
                // Sem codigo de jeito nenhum â€” NAO faz mais retry (causava rate limit em loop)
                self._aiAddMsg('status', 'âœ— IA nao gerou codigo (' + (text || '').length + ' chars). Tente reformular o pedido.');
                self._aiBusy = false;
                document.getElementById('ai-send').disabled = false;
                return;
            }

            var raw = m[1].trim();

            // Se o codigo eh tao curto que claramente e um stub (IA parou no meio),
            // NAO tenta executar â€” avisa e para.
            if (raw.length < 200 || raw.indexOf('app.beginUndoGroup') === -1) {
                self._aiAddMsg('status', 'âœ— IA gerou apenas ' + raw.length + ' chars (incompleto). Tente novamente.');
                self._aiBusy = false;
                document.getElementById('ai-send').disabled = false;
                return;
            }

            // PROTECAO contra IIFE duplicado: se a IA gerou 2x "(function() {" no mesmo bloco,
            // pegar SO o primeiro IIFE completo (do primeiro "(function" ate o ")();" correspondente)
            var firstIife = raw.indexOf('(function');
            if (firstIife !== -1) {
                var secondIife = raw.indexOf('(function', firstIife + 10);
                if (secondIife !== -1) {
                    self._aiAddMsg('status', 'âš  IA gerou 2 scripts grudados â€” usando apenas o primeiro');
                    // Achar o fim do primeiro IIFE contando chaves
                    var depth = 0, inStr = false, strCh = '', endIdx = -1;
                    for (var ix = firstIife; ix < secondIife; ix++) {
                        var ch = raw.charAt(ix);
                        if (inStr) { if (ch === strCh && raw.charAt(ix-1) !== '\\') inStr = false; continue; }
                        if (ch === '"' || ch === "'") { inStr = true; strCh = ch; continue; }
                        if (ch === '{') depth++;
                        else if (ch === '}') { depth--; if (depth === 0 && ix > firstIife + 10) { endIdx = ix + 1; break; } }
                    }
                    if (endIdx > 0) {
                        // Pegar do (function ate o ) ou )() depois do }
                        var tail = raw.substring(endIdx, Math.min(endIdx + 10, secondIife));
                        var closeMatch = tail.match(/^\s*\)\s*\(\s*\)\s*;?/);
                        if (closeMatch) endIdx += closeMatch[0].length;
                        raw = raw.substring(firstIife, endIdx);
                    }
                }
            }

            var code = self._aiFixES3(raw);
            var before = text.substring(0, text.indexOf('```')).trim();

            // Download assets then render code
            var totalTasks = (imageRequests.length > 0 ? 1 : 0) + (iconRequests.length > 0 ? 1 : 0);
            if (totalTasks === 0) {
                self._aiRenderCode(bubble, code, raw, before);
            } else {
                var done = 0;
                var checkDone = function () { done++; if (done >= totalTasks) self._aiRenderCode(bubble, code, raw, before); };
                if (imageRequests.length > 0) self._aiDownloadImages(imageRequests, checkDone);
                if (iconRequests.length > 0) self._aiDownloadIcons(iconRequests, checkDone);
            }
        },

        _aiRenderCode: function (bubble, code, raw, before) {
            var self = this;

            bubble.textContent = '';
            if (before) { var sp = document.createElement('span'); sp.textContent = before; bubble.appendChild(sp); }

            var wrap = document.createElement('div'); wrap.className = 'ai-code';
            var hdr = document.createElement('div'); hdr.className = 'ai-code-hdr';
            hdr.innerHTML = '<span>ExtendScript' + (code !== raw ? ' (auto-fix)' : '') + '</span>';
            var copyBtn = document.createElement('button'); copyBtn.className = 'ai-code-copy'; copyBtn.textContent = 'â§‰ Copiar';
            copyBtn.onclick = function () {
                try {
                    var ta = document.createElement('textarea');
                    ta.value = code;
                    ta.style.cssText = 'position:fixed;left:-9999px';
                    document.body.appendChild(ta);
                    ta.select();
                    document.execCommand('copy');
                    document.body.removeChild(ta);
                    copyBtn.textContent = 'âœ“ Copiado';
                    setTimeout(function () { copyBtn.textContent = 'â§‰ Copiar'; }, 1500);
                } catch (e) { MT.toast('Erro ao copiar', true); }
            };
            hdr.appendChild(copyBtn);
            var btn = document.createElement('button'); btn.className = 'ai-code-run'; btn.textContent = 'â–¶ Executar';
            btn.onclick = function () { self._aiExec(code, wrap, btn); };
            hdr.appendChild(btn);
            var pre = document.createElement('pre'); pre.textContent = code;
            wrap.appendChild(hdr); wrap.appendChild(pre); bubble.appendChild(wrap);
            self._aiScroll();

            // Auto-executa no AE
            self._aiStatus('Executando...');
            setTimeout(function () { self._aiExec(code, wrap, btn); }, 300);
        },

        // Provider fixo: Ollama Cloud com qwen3-coder:480b-cloud (1M context via Yarn).
        _aiGetProvider: function () {
            var ollamaKey = localStorage.getItem('multiTools_ollamaKey');
            if (!ollamaKey) return null;
            return {
                name: 'ollama',
                key: ollamaKey,
                model: 'qwen3-coder:480b-cloud',
                endpoint: 'https://ollama.com/api/chat'
            };
        },

        // Call LLM â€” Ollama Cloud (formato NATIVO Ollama, streaming NDJSON)
        _aiCallLLM: function (msgs, callback) {
            var self = this;
            var provider = self._aiGetProvider();
            if (!provider) {
                self._aiAddMsg('bot', 'Configure a chave Ollama Cloud nas configuracoes (icone de engrenagem). Gera em ollama.com/settings/keys.');
                self._aiBusy = false;
                document.getElementById('ai-send').disabled = false;
                return;
            }
            self._aiBusy = true;
            document.getElementById('ai-send').disabled = true;
            self._aiCallOllama(msgs, provider, callback);
        },

        // Config de retry pra 429 (rate limit) e 503 (overloaded)
        _aiMaxRetries: 5,
        _aiRetryDelay: function (attempt) {
            // Backoff exponencial: 10s, 15s, 20s, 30s, 30s (cap)
            var ms = Math.min(30000, 10000 + attempt * 5000);
            return ms;
        },
        _aiIsRetryable: function (status) {
            return status === 429 || status === 503 || status === 502 || status === 504 || status === 500;
        },

        // Ollama Cloud â€” formato NATIVO Ollama com streaming NDJSON (uma linha JSON por chunk)
        _aiCallOllama: function (msgs, provider, callback, attempt) {
            var self = this;
            attempt = attempt || 0;
            var endpoint = provider.endpoint;
            var headers = {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + provider.key
            };

            // Ollama native chat format â€” options inline, stream=true
            var reqBody = {
                model: provider.model,
                messages: msgs,
                stream: true,
                options: {
                    temperature: 0.4,
                    top_p: 0.9,
                    num_ctx: 131072,        // 128K â€” max pro gpt-oss (nosso prompt tem ~75K tokens)
                    num_predict: 16000      // max tokens gerados
                }
            };

            // Helper: fecha o codigo manualmente contando chaves
            function closeIIFE(src) {
                var fixed = src;
                var open = 0, close = 0, inStr = false, strCh = '';
                for (var ci = 0; ci < fixed.length; ci++) {
                    var ch = fixed.charAt(ci);
                    if (inStr) { if (ch === strCh && fixed.charAt(ci-1) !== '\\') inStr = false; continue; }
                    if (ch === '"' || ch === "'") { inStr = true; strCh = ch; continue; }
                    if (ch === '{') open++;
                    else if (ch === '}') close++;
                }
                for (var cf = 0; cf < (open - close); cf++) fixed += '\n}';
                if (fixed.indexOf(')();') === -1 && fixed.lastIndexOf(')()') === -1) {
                    fixed += ')();';
                }
                if (fixed.indexOf('```') !== -1 && (fixed.match(/```/g) || []).length % 2 === 1) {
                    fixed += '\n```';
                }
                return fixed;
            }

            fetch(endpoint, {
                method: 'POST',
                headers: headers,
                body: JSON.stringify(reqBody)
            })
            .then(function (res) {
                if (!res.ok) {
                    if (self._aiIsRetryable(res.status) && attempt < self._aiMaxRetries) {
                        var delay = self._aiRetryDelay(attempt);
                        self._aiStatus('Rate limit Ollama (' + res.status + ') â€” aguardando ' + (delay/1000).toFixed(0) + 's e tentando novamente... (' + (attempt+2) + '/' + (self._aiMaxRetries+1) + ')');
                        setTimeout(function () {
                            self._aiCallOllama(msgs, provider, callback, attempt + 1);
                        }, delay);
                        return null;
                    }
                    return res.text().then(function (errBody) {
                        console.error('[MultiTools] Ollama API ' + res.status + ' (' + provider.model + '): ' + errBody.substring(0, 500));
                        throw new Error('Ollama API ' + res.status + ' â€” ' + (errBody.substring(0, 160) || 'sem detalhes'));
                    });
                }
                var statusEl = document.querySelector('.ai-msg.status:last-child');
                if (statusEl) statusEl.remove();
                var bubble = self._aiAddMsg('bot', '');
                bubble.innerHTML = '<span class="ai-generating">Pensando...</span>';
                var full = '';
                var inThink = false;
                var aborted = false;
                var doneReason = null;
                var reader = res.body.getReader();
                var dec = new TextDecoder();
                var buf = '';

                function read() {
                    if (aborted) return;
                    reader.read().then(function (r) {
                        if (aborted) return;
                        if (r.done) {
                            full = full.replace(/<think>[\s\S]*?<\/think>/g, '').replace(/^\s+/, '');
                            console.log('[Ollama] Stream done. done_reason=' + doneReason + ' chars=' + full.length + ' hasIIFE=' + (full.indexOf('(function') !== -1));
                            if (doneReason === 'length' && full.length > 0) {
                                self._aiAddMsg('status', 'âš  Ollama truncou (length @ ' + full.length + ' chars) â€” fechando codigo manualmente');
                                callback(closeIIFE(full));
                                return;
                            }
                            if (doneReason && doneReason !== 'stop' && doneReason !== null) {
                                self._aiAddMsg('status', 'âš  Ollama parou: ' + doneReason + ' (' + full.length + ' chars)');
                            }
                            callback(full);
                            return;
                        }
                        // === NDJSON parser â€” Ollama stream: uma linha JSON por chunk ===
                        // Cada linha: {"model":"...","message":{"role":"assistant","content":"chunk"},"done":false}
                        // Linha final: {"done":true,"done_reason":"stop",...}
                        buf += dec.decode(r.value, { stream: true });
                        var lines = buf.split('\n');
                        buf = lines.pop(); // incompleta
                        for (var i = 0; i < lines.length; i++) {
                            var ln = lines[i].replace(/\r$/, '').trim();
                            if (!ln) continue;
                            try {
                                var d = JSON.parse(ln);
                                if (d.done) {
                                    if (d.done_reason) doneReason = d.done_reason;
                                }
                                if (d.error) {
                                    self._aiAddMsg('bot', 'Ollama erro: ' + d.error);
                                    aborted = true;
                                    try { reader.cancel(); } catch(eC) {}
                                    self._aiBusy = false;
                                    document.getElementById('ai-send').disabled = false;
                                    return;
                                }
                                if (d.message && typeof d.message.content === 'string') {
                                    var chunk = d.message.content;
                                    // <think> tags (Qwen reasoning) â€” filtrar
                                    if (chunk.indexOf('<think>') !== -1) {
                                        inThink = true;
                                        bubble.innerHTML = '<span class="ai-generating">Pensando...</span>';
                                    }
                                    if (inThink) {
                                        if (chunk.indexOf('</think>') !== -1) {
                                            inThink = false;
                                            bubble.innerHTML = '<span class="ai-generating">Gerando codigo...</span>';
                                            var afterThink = chunk.split('</think>')[1] || '';
                                            if (afterThink) { full += afterThink; bubble.textContent = full; }
                                        }
                                    } else {
                                        full += chunk;
                                        bubble.textContent = full;
                                    }
                                    self._aiScroll();

                                    // ABORT MID-STREAM se duplicar IIFE (2x "(function" na resposta)
                                    var firstIife = full.indexOf('(function');
                                    if (firstIife !== -1) {
                                        var secondIife = full.indexOf('(function', firstIife + 50);
                                        if (secondIife !== -1) {
                                            aborted = true;
                                            self._aiAddMsg('status', 'ðŸ›‘ IA duplicou o script â€” abortando e fechando');
                                            try { reader.cancel(); } catch(eC) {}
                                            var truncated = full.substring(0, secondIife).replace(/\s+$/, '');
                                            callback(closeIIFE(truncated));
                                            return;
                                        }
                                    }
                                }
                            } catch (e) {
                                // Linha nao-JSON (provavelmente parcial, vai ser unida na proxima)
                            }
                        }
                        if (!aborted) read();
                    }).catch(function () { if (!aborted) callback(full || ''); });
                }
                read();
            })
            .catch(function (err) {
                self._aiAddMsg('bot', 'Erro Ollama (' + provider.model + '): ' + err.message);
                self._aiBusy = false;
                document.getElementById('ai-send').disabled = false;
            });
        },

        _aiFixES3: function (code) {
            // === CONVERSOES ES6 â†’ ES3 (seguras) ===
            code = code.replace(/\b(const|let)\s+/g, 'var ');
            code = code.replace(/\(([^)]*)\)\s*=>\s*\{/g, 'function($1) {');
            code = code.replace(/\(([^)]*)\)\s*=>\s*([^{;\n]+)/g, 'function($1) { return $2; }');
            code = code.replace(/([a-zA-Z_$]\w*)\s*=>\s*\{/g, 'function($1) {');
            code = code.replace(/([a-zA-Z_$]\w*)\s*=>\s*([^{;\n]+)/g, 'function($1) { return $2; }');
            code = code.replace(/`([^`]*)`/g, function (m, inner) {
                var p = inner.split(/\$\{([^}]+)\}/), r = [];
                for (var i = 0; i < p.length; i++) {
                    if (i % 2 === 0) { if (p[i]) r.push('"' + p[i].replace(/"/g, '\\"').replace(/\n/g, '\\n') + '"'); }
                    else r.push('(' + p[i] + ')');
                }
                return r.join('+') || '""';
            });
            code = code.replace(/JSON\.parse\s*\(([^)]+)\)/g, 'eval("("+$1+")")');
            code = code.replace(/\.includes\s*\(([^)]+)\)/g, '.indexOf($1)!==-1');
            code = code.replace(/\.trim\(\)/g, '.replace(/^\\s+|\\s+$/g,"")');

            // Troca alert() por $.writeln() â€” evita popup bloqueante no AE quando IA gera codigo com bug.
            // O erro ainda eh capturado via safeExecuteFile â†’ _aiAutoFix trata.
            code = code.replace(/\balert\s*\(/g, '$.writeln(');

            // === INJETAR helpers AE.* faltantes ===
            var helpers = '';
            var needed = {
                'AE.gc': 'AE.gc=function(p,ns){var c=p;for(var i=0;i<ns.length;i++){try{c=c.property(ns[i])}catch(e){return null}if(!c)return null}return c};',
                'AE.pos': 'AE.pos=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Position"]):null};',
                'AE.scl': 'AE.scl=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Scale"]):null};',
                'AE.opa': 'AE.opa=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Opacity"]):null};',
                'AE.rot': 'AE.rot=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Rotate Z"]):null};',
                'AE.anc': 'AE.anc=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Anchor Point"]):null};',
                'AE.sv': 'AE.sv=function(p,v){if(!p)return;try{p.setValue(v)}catch(e){}};',
                'AE.sa': 'AE.sa=function(p,t,v){if(!p)return;try{p.setValueAtTime(t,v)}catch(e){}};',
                'AE.gv': 'AE.gv=function(p){if(!p)return null;try{return p.value}catch(e){return null}};',
                'AE.hex': 'AE.hex=function(h){h=h.replace("#","");return[parseInt(h.substr(0,2),16)/255,parseInt(h.substr(2,2),16)/255,parseInt(h.substr(4,2),16)/255]};',
                'AE.fx': 'AE.fx=function(l,mn){if(!l)return null;try{return l.property("ADBE Effect Parade").addProperty(mn)}catch(e){return null}};',
                // === LAYOUT HELPERS (anti-fora-de-tela) ===
                'AE.safeXY': 'AE.safeXY=function(x,y,w,h){var c=app.project.activeItem;if(!c||!(c instanceof CompItem))return[x,y];w=w||0;h=h||0;var m=Math.min(c.width,c.height)*0.03;var minX=m+w/2,maxX=c.width-m-w/2,minY=m+h/2,maxY=c.height-m-h/2;if(minX>maxX){minX=maxX=c.width/2}if(minY>maxY){minY=maxY=c.height/2}return[Math.max(minX,Math.min(maxX,x)),Math.max(minY,Math.min(maxY,y))]};',
                'AE.slot': 'AE.slot=function(anc,w,h){var c=app.project.activeItem;if(!c||!(c instanceof CompItem))return[0,0];w=w||0;h=h||0;var m=Math.min(c.width,c.height)*0.05;var L=m+w/2,R=c.width-m-w/2,T=m+h/2,B=c.height-m-h/2;var CX=c.width/2,CY=c.height/2;var map={TL:[L,T],TC:[CX,T],TR:[R,T],ML:[L,CY],MC:[CX,CY],MR:[R,CY],BL:[L,B],BC:[CX,B],BR:[R,B]};return map[anc]||[CX,CY]};',
                'AE.sizeOf': 'AE.sizeOf=function(l){if(!l)return[100,100];try{var r=l.sourceRectAtTime(l.inPoint+0.01,false);if(r&&r.width>0)return[r.width,r.height]}catch(e){}try{if(l.source&&l.source.width)return[l.source.width,l.source.height]}catch(e){}return[100,100]};'
            };
            for (var key in needed) {
                // Se o codigo USA o helper mas NAO o define
                if (code.indexOf(key + '(') !== -1 && code.indexOf(key + '=') === -1 && code.indexOf(key + ' =') === -1) {
                    helpers += needed[key] + '\n';
                }
            }
            if (helpers) {
                helpers = 'if(typeof AE==="undefined")var AE={};\n' + helpers;
                var iifeStart = code.indexOf('{');
                if (iifeStart !== -1) {
                    code = code.substring(0, iifeStart + 1) + '\n' + helpers + code.substring(iifeStart + 1);
                } else {
                    code = helpers + code;
                }
            }

            // === POST-FIX IIFE â€” roda como IIFE SEPARADO depois do codigo da IA ===
            // Versao BULLETPROOF v2: nao depende de sourceRectAtTime (que mudou comportamento
            // em AE 2024+). Usa CLAMP ABSOLUTO pelas coordenadas da comp: se position.x tÃ¡
            // fora de [0, W] ou position.y fora de [0, H], forÃ§a pra centro da comp com
            // uma margem generosa (pos dentro de [W*0.1, W*0.9], [H*0.1, H*0.9]).
            //
            // Isso significa que mesmo se a IA gerar position = [9999, -500], o elemento
            // Ã© TRAZIDO DE VOLTA pro frame â€” garantido.
            //
            // Tambem escreve log em arquivo "mt_postfix.log" no Desktop pra diagnostico.
            var postFix = '\n\n' +
                '(function(){\n' +
                'var _log = "";\n' +
                'function _L(s){_log += s + "\\n"; try{$.writeln(s);}catch(_){}}\n' +
                'try{\n' +
                'app.beginUndoGroup("MT_PostFix");\n' +

                // --- Detecta a comp alvo (tenta activeItem, senao ultima CompItem) ---
                'var _sc = null;\n' +
                'try{if(app.project.activeItem && app.project.activeItem instanceof CompItem){_sc=app.project.activeItem;}}catch(_e){}\n' +
                'if(!_sc){for(var _pi=app.project.numItems;_pi>=1;_pi--){try{var _it=app.project.item(_pi);if(_it && _it instanceof CompItem){_sc=_it;try{_it.openInViewer();}catch(_){}break;}}catch(_e){}}}\n' +
                'if(!_sc){_L("[MT PostFix] Nenhuma comp encontrada!"); app.endUndoGroup(); return;}\n' +
                '_L("[MT PostFix] AE=" + (app.version||"?") + " Comp=" + _sc.name + " " + _sc.width + "x" + _sc.height + " layers=" + _sc.numLayers);\n' +

                // --- EASE 100% em todos keyframes ---
                'function _eAll(g){if(!g)return;try{for(var i=1;i<=g.numProperties;i++){try{var p=g.property(i);if(!p)continue;' +
                'if(p.numProperties>0){_eAll(p);continue;}if(!p.numKeys||p.numKeys<1)continue;' +
                'var d=1;try{var v=p.propertyValueType;if(v===PropertyValueType.TwoD||v===PropertyValueType.TwoD_SPATIAL)d=2;' +
                'if(v===PropertyValueType.ThreeD||v===PropertyValueType.ThreeD_SPATIAL)d=3;}catch(e){}' +
                'for(var k=1;k<=p.numKeys;k++){try{var ei=[],eo=[];for(var j=0;j<d;j++){ei.push(new KeyframeEase(0,100));eo.push(new KeyframeEase(0,100));}' +
                'p.setTemporalEaseAtKey(k,ei,eo);}catch(e){}}' +
                '}catch(e){}}}catch(e){}}\n' +
                'for(var _i=1;_i<=_sc.numLayers;_i++){try{_eAll(_sc.layer(_i))}catch(_e){}}\n' +

                // --- CLAMP POSICOES FORA DO FRAME (BULLETPROOF) ---
                'var _SW = _sc.width, _SH = _sc.height;\n' +
                // Margem minima â€” so clampa se estiver REALMENTE fora do frame (< 2% da borda)
                // Permite status bars (Y=60), footers, elementos proximos das bordas â€” designs mobile.
                'var _MIN_X = _SW * 0.02;\n' +
                'var _MAX_X = _SW * 0.98;\n' +
                'var _MIN_Y = _SH * 0.02;\n' +
                'var _MAX_Y = _SH * 0.98;\n' +
                'var _CX = _SW / 2, _CY = _SH / 2;\n' +
                'var _clamped = 0;\n' +

                // --- Detecta se uma layer eh BG (cobre a comp inteira) pra nao clampar ---
                'function _isBG(lay) {\n' +
                    'try {\n' +
                        // Solid layer do tamanho da comp = BG
                        'if (lay.source && lay.source.mainSource && lay.source.mainSource.color) {\n' +
                            'if (lay.source.width >= _SW * 0.95 && lay.source.height >= _SH * 0.95) return true;\n' +
                        '}\n' +
                        // Ou nome comeca com BG_
                        'if (lay.name && lay.name.indexOf("BG") === 0) return true;\n' +
                    '} catch(e) {}\n' +
                    'return false;\n' +
                '}\n' +

                'for(var _li=1; _li<=_sc.numLayers; _li++){try{\n' +
                    'var _lay = _sc.layer(_li);\n' +
                    'if (_isBG(_lay)) { _L("  [skip BG] " + _lay.name); continue; }\n' +

                    // Pega Position property â€” se existir
                    'var _pp = null;\n' +
                    'try { _pp = _lay.property("ADBE Transform Group").property("ADBE Position"); } catch(_e){}\n' +
                    'if(!_pp) continue;\n' +

                    // CLAMP ABSOLUTO: forca position pra estar em [W*0.10, W*0.90] x [H*0.10, H*0.90]
                    // Isso nao depende de sourceRectAtTime â€” funciona em QUALQUER versao do AE.
                    'function _clamp(v) {\n' +
                        'if (!v || v.length < 2) return v;\n' +
                        'var x = v[0], y = v[1];\n' +
                        'var nx = Math.max(_MIN_X, Math.min(_MAX_X, x));\n' +
                        'var ny = Math.max(_MIN_Y, Math.min(_MAX_Y, y));\n' +
                        'if (nx !== x || ny !== y) {\n' +
                            'return v.length === 3 ? [nx, ny, v[2]] : [nx, ny];\n' +
                        '}\n' +
                        'return null;\n' +
                    '}\n' +

                    'if(_pp.numKeys === 0) {\n' +
                        'var _v = null; try{_v = _pp.value;}catch(_){}\n' +
                        'if (!_v) continue;\n' +
                        'var _nv = _clamp(_v);\n' +
                        'if (_nv) {\n' +
                            'try { _pp.setValue(_nv); _clamped++; _L("  [clamp] \\"" + _lay.name + "\\" [" + Math.round(_v[0]) + "," + Math.round(_v[1]) + "] -> [" + Math.round(_nv[0]) + "," + Math.round(_nv[1]) + "]"); } catch(_e){_L("  [clamp ERRO] " + _lay.name + ": " + _e);}\n' +
                        '}\n' +
                    '} else {\n' +
                        'var _kfixed = 0;\n' +
                        'for(var _ki=1; _ki<=_pp.numKeys; _ki++) {\n' +
                            'try {\n' +
                                'var _kv = _pp.keyValue(_ki);\n' +
                                'var _knv = _clamp(_kv);\n' +
                                'if (_knv) {\n' +
                                    'var _kt = _pp.keyTime(_ki);\n' +
                                    '_pp.setValueAtTime(_kt, _knv);\n' +
                                    '_kfixed++;\n' +
                                '}\n' +
                            '} catch(_e){}\n' +
                        '}\n' +
                        'if (_kfixed > 0) { _clamped++; _L("  [clamp-kf] \\"" + _lay.name + "\\" " + _kfixed + " keyframes reposicionados"); }\n' +
                    '}\n' +
                '}catch(_e){_L("  [layer ERRO] " + _e);}}\n' +

                '_L("[MT PostFix] " + _clamped + " layers reposicionadas de " + _sc.numLayers + " totais");\n' +

                // --- ANTI-OVERLAP â€” detecta layers que sobrepoem em TEMPO + POSICAO e empilha Y ---
                '_L("[MT AntiOverlap] Checando sobreposicoes temporais+espaciais...");\n' +
                'var _grps = {};\n' + // agrupar por "time bucket + pos bucket"
                'for (var _oi = 1; _oi <= _sc.numLayers; _oi++) {\n' +
                    'try {\n' +
                        'var _ol = _sc.layer(_oi);\n' +
                        'if (_isBG(_ol)) continue;\n' +
                        // Skip layers muito grandes (cards/BGs decorativos)
                        'var _olIsCard = false;\n' +
                        'try {\n' +
                            'if (_ol.source && _ol.source.width >= _SW * 0.7) _olIsCard = true;\n' +
                        '} catch(_){}\n' +
                        'if (_olIsCard) continue;\n' +
                        // So mexe em TEXT layers (TextLayer)
                        'if (!(_ol instanceof TextLayer)) continue;\n' +
                        'var _opp = _ol.property("ADBE Transform Group").property("ADBE Position");\n' +
                        'if (!_opp) continue;\n' +
                        'var _opv = null; try{_opv = _opp.value;}catch(_){}\n' +
                        'if (!_opv) continue;\n' +
                        // Bucket: inPoint arredondado pra 0.5s + posY arredondado pra 50px
                        'var _tBucket = Math.round(_ol.inPoint * 2) / 2;\n' +
                        'var _yBucket = Math.round(_opv[1] / 40) * 40;\n' +
                        'var _xBucket = Math.round(_opv[0] / 100) * 100;\n' +
                        'var _key = _tBucket + "_" + _xBucket + "_" + _yBucket;\n' +
                        'if (!_grps[_key]) _grps[_key] = [];\n' +
                        '_grps[_key].push({layer:_ol, pos:_opv, idx:_oi});\n' +
                    '} catch(_e){}\n' +
                '}\n' +
                'var _unstacked = 0;\n' +
                'for (var _k in _grps) {\n' +
                    'var _grp = _grps[_k];\n' +
                    'if (_grp.length < 2) continue;\n' +
                    // Encontrou 2+ texts no mesmo tempo+posicao â€” empilha verticalmente
                    '_L("  [overlap] " + _grp.length + " textos sobrepostos em key=" + _k);\n' +
                    'var _gap = _SH * 0.06;\n' + // 6% do H como gap
                    'var _totalH = _gap * (_grp.length - 1);\n' +
                    'var _centerY = _grp[0].pos[1];\n' +
                    'var _startY = _centerY - _totalH / 2;\n' +
                    'for (var _gi = 0; _gi < _grp.length; _gi++) {\n' +
                        'var _gl = _grp[_gi];\n' +
                        'var _newY = _startY + _gap * _gi;\n' +
                        'var _ppg = _gl.layer.property("ADBE Transform Group").property("ADBE Position");\n' +
                        'if (!_ppg) continue;\n' +
                        'try {\n' +
                            'if (_ppg.numKeys === 0) {\n' +
                                'var _nv = _gl.pos.length === 3 ? [_gl.pos[0], _newY, _gl.pos[2]] : [_gl.pos[0], _newY];\n' +
                                '_ppg.setValue(_nv);\n' +
                            '} else {\n' +
                                // Ajusta TODOS os keyframes com mesmo delta Y
                                'var _dY = _newY - _gl.pos[1];\n' +
                                'for (var _kki = 1; _kki <= _ppg.numKeys; _kki++) {\n' +
                                    'try {\n' +
                                        'var _kkv = _ppg.keyValue(_kki);\n' +
                                        'var _knvK = _kkv.length === 3 ? [_kkv[0], _kkv[1] + _dY, _kkv[2]] : [_kkv[0], _kkv[1] + _dY];\n' +
                                        'var _kkt = _ppg.keyTime(_kki);\n' +
                                        '_ppg.setValueAtTime(_kkt, _knvK);\n' +
                                    '} catch(_){}\n' +
                                '}\n' +
                            '}\n' +
                            '_unstacked++;\n' +
                            '_L("    \\"" + _gl.layer.name + "\\" Y " + Math.round(_gl.pos[1]) + " -> " + Math.round(_newY));\n' +
                        '} catch(_e){_L("    [unstack ERRO] " + _e);}\n' +
                    '}\n' +
                '}\n' +
                'if (_unstacked > 0) _L("[MT AntiOverlap] " + _unstacked + " textos empilhados verticalmente");\n' +

                '}catch(_e){_L("[MT PostFix ERRO FATAL] " + _e);}\n' +
                'finally { try{app.endUndoGroup();}catch(_){} }\n' +

                // Grava log no Desktop pra diagnostico
                'try {\n' +
                    'var _logFile = new File(Folder.desktop.fsName + "/mt_postfix.log");\n' +
                    '_logFile.open("w");\n' +
                    '_logFile.encoding = "UTF-8";\n' +
                    '_logFile.write(_log);\n' +
                    '_logFile.close();\n' +
                '} catch(_) {}\n' +

                '})();\n';

            // Injeta APOS o IIFE principal fechar (})();) â€” IIFE separado, imune a erros do codigo da IA
            var mainIIFEClose = code.lastIndexOf(')();');
            if (mainIIFEClose !== -1) {
                code = code.substring(0, mainIIFEClose + 4) + postFix + code.substring(mainIIFEClose + 4);
            } else {
                code += postFix;
            }

            // === FIX cores com 4 valores [r,g,b,a] â†’ [r,g,b] ===
            // AE fillColor/strokeColor aceita APENAS 3 valores, nunca 4
            code = code.replace(/setValue\s*\(\s*\[\s*([0-9.]+)\s*,\s*([0-9.]+)\s*,\s*([0-9.]+)\s*,\s*[0-9.]+\s*\]\s*\)/g, 'setValue([$1, $2, $3])');

            return code;
        },

        // Sanitiza codigo ES6+ pra ES3 (After Effects ExtendScript)
        _aiSanitizeES3: function (code) {
            // const/let â†’ var (robusto â€” pega const{}, const sem espaÃ§o etc)
            code = code.replace(/\b(const|let)\b\s*/g, 'var ');
            // export/import â†’ remover
            code = code.replace(/\bexport\s+(default\s+)?/g, '');
            code = code.replace(/\bimport\s+[\s\S]*?from\s+['"][^'"]*['"];?\s*\n?/g, '');
            code = code.replace(/\bimport\s+['"][^'"]*['"];?\s*\n?/g, '');
            // async/await â†’ remover
            code = code.replace(/\basync\s+function/g, 'function');
            code = code.replace(/\bawait\s+/g, '');
            // class â†’ function (basico)
            code = code.replace(/\bclass\s+(\w+)\s*(extends\s+\w+\s*)?\{/g, 'function $1() {');
            // Arrow functions: (args) => { body } â†’ function(args){ body }
            code = code.replace(/\(([^)]*)\)\s*=>\s*\{/g, 'function($1){');
            // Arrow functions: (args) => expr â†’ function(args){ return expr; }
            code = code.replace(/\(([^)]*)\)\s*=>\s*([^{;\n]+)/g, 'function($1){ return $2; }');
            // Single arg arrow: arg => { body }
            code = code.replace(/([a-zA-Z_$][a-zA-Z0-9_$]*)\s*=>\s*\{/g, 'function($1){');
            // Single arg arrow: arg => expr
            code = code.replace(/([a-zA-Z_$][a-zA-Z0-9_$]*)\s*=>\s*([^{;\n]+)/g, 'function($1){ return $2; }');
            // Template literals `...${expr}...` â†’ "..." + expr + "..."
            code = code.replace(/`([^`]*)`/g, function (m, inner) {
                var result = inner.replace(/\$\{([^}]+)\}/g, '" + ($1) + "');
                return '"' + result + '"';
            });
            // for...of â†’ for com indice (basico, funciona pra arrays)
            code = code.replace(/for\s*\(\s*(?:var\s+)?(\w+)\s+of\s+(\w+)\s*\)/g,
                'for(var _oi=0;_oi<$2.length;_oi++){var $1=$2[_oi]; void(0)}');
            // .includes() â†’ .indexOf() !== -1
            code = code.replace(/\.includes\(([^)]+)\)/g, '.indexOf($1) !== -1');
            // .startsWith() â†’ .indexOf($1) === 0
            code = code.replace(/\.startsWith\(([^)]+)\)/g, '.indexOf($1) === 0');
            // .endsWith(s) â†’ .indexOf(s, this.length - s.length) !== -1
            code = code.replace(/\.endsWith\(([^)]+)\)/g, function(m, arg) {
                return '.slice(-(' + arg + ').length) === ' + arg;
            });
            // Default params function(a = 1) â†’ remover defaults
            code = code.replace(/function\s*\(([^)]*)\)/g, function (m, params) {
                var cleaned = params.replace(/\s*=\s*[^,)]+/g, '');
                return 'function(' + cleaned + ')';
            });
            // Spread ...args â†’ nao tem fix perfeito, mas remove syntax invalida
            code = code.replace(/\.\.\.(\w+)/g, '$1');
            return code;
        },

        _aiExec: function (code, wrap, btn) {
            var self = this;
            btn.textContent = 'âŸ³ Executando...'; btn.disabled = true;

            var execCode = code;
            var origCode = code;

            // Pedir ao ExtendScript o path temp e gravar lÃ¡
            csInterface.evalScript('Folder.temp.fsName', function (tempDir) {
                var fileName = 'mt_ai_' + Date.now() + '.jsx';
                var fullPath = tempDir + '/' + fileName;

                // Gravar via ExtendScript (mais confiÃ¡vel que cep.fs)
                var writeCode = '(function(){var f=new File("' +
                    fullPath.replace(/\\/g, '/').replace(/"/g, '\\"') +
                    '");f.open("w");f.encoding="UTF-8";f.write(' +
                    'decodeURI("' + encodeURIComponent(execCode) + '")' +
                    ');f.close();return f.exists?"ok":"fail";})()';

                csInterface.evalScript(writeCode, function (wr) {
                    if (wr !== 'ok') {
                        // Fallback: safeExecute com string
                        var esc = execCode.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '');
                        csInterface.evalScript('safeExecute("' + esc + '")', function (res) {
                            self._aiHandleResult(res, wrap, btn, origCode);
                        });
                        return;
                    }

                    var safePath = fullPath.replace(/\\/g, '/').replace(/"/g, '\\"');
                    csInterface.evalScript('safeExecuteFile("' + safePath + '")', function (res) {
                        self._aiHandleResult(res, wrap, btn, origCode);
                    });
                });
            });
        },

        _aiHandleResult: function (res, wrap, btn, code) {
            var self = this;
            var old = wrap.querySelector('.ai-result'); if (old) old.remove();
            var isErr = res && (res.indexOf('ERRO') === 0 || res.indexOf('Error') !== -1);
            if (isErr) {
                btn.textContent = 'âœ— Erro'; btn.style.borderColor = '#ef4444'; btn.style.color = '#ef4444';
                var r = document.createElement('div'); r.className = 'ai-result err'; r.textContent = res; wrap.appendChild(r);
                self._aiScroll();
                self._aiAutoFix(code, res);
            } else {
                btn.textContent = 'âœ“ OK'; btn.className = 'ai-code-run done';
                self._aiAddMsg('status', 'âœ“ Executado com sucesso');
                if (res && res !== 'undefined' && res !== 'null' && res !== 'OK') {
                    var r2 = document.createElement('div'); r2.className = 'ai-result ok'; r2.textContent = 'â†’ ' + res; wrap.appendChild(r2);
                }
                self._aiBusy = false;
                document.getElementById('ai-send').disabled = false;
                self._aiFixCount = 0;
            }
            btn.disabled = false;
            self._aiScroll();
        },

        // Auto-fix: erro â†’ pesquisa causa â†’ corrige â†’ tenta de novo (ate 5x)
        _aiAutoFix: function (badCode, error) {
            var self = this;
            self._aiFixCount++;
            if (self._aiFixCount > 5) {
                self._aiAddMsg('status', 'âœ— Falhou apos 5 tentativas');
                self._aiBusy = false;
                document.getElementById('ai-send').disabled = false;
                self._aiFixCount = 0;
                return;
            }

            self._aiAddMsg('status', 'ðŸ”§ Fix ' + self._aiFixCount + '/5 â€” pesquisando erro...');

            // Pesquisa o erro primeiro
            self._aiOneShot('ExtendScript ES3 After Effects erro: ' + error.substring(0, 200) + '. Causa e solucao em 2 linhas.', 500, function (solution) {
                self._aiAddMsg('status', 'ðŸ’¡ ' + (solution || 'sem solucao').substring(0, 100));

                // Extrair numero da linha do erro pra mostrar contexto ao redor
                var lineMatch = error.match(/[Ll]inha:?\s*(\d+)/);
                var errorContext = badCode;
                if (lineMatch && badCode.length > 3000) {
                    var errLine = parseInt(lineMatch[1]);
                    var lines = badCode.split('\n');
                    var startL = Math.max(0, errLine - 15);
                    var endL = Math.min(lines.length, errLine + 15);
                    errorContext = '// ... linhas ' + startL + '-' + endL + ' ao redor do erro na linha ' + errLine + ':\n' + lines.slice(startL, endL).join('\n');
                }

                var fixMsg = 'ERRO no AE:\n```\n' + error + '\n```\n' +
                    'PESQUISA: ' + (solution || '') + '\n\n' +
                    'Codigo com erro (contexto ao redor da linha):\n```javascript\n' + errorContext.substring(0, 4000) + '\n```\n\n' +
                    'REGRAS PRA CORRIGIR:\n' +
                    '- Se "Objeto invalido": voce guardou retorno de addProperty. NAO FACA ISSO. Use: vec.addProperty("X"); depois busque: layer.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group").property("X")\n' +
                    '- Se "comp.property": CompItem NAO tem .property(). Use comp.layer(i).property()\n' +
                    '- Se "null nao e objeto": alguma variavel e null. Adicione if(var) antes de usar.\n' +
                    '- GERE O CODIGO INTEIRO CORRIGIDO. NAO so o trecho.';

                self._aiMsgs.push({ role: 'user', content: fixMsg });
                var msgs = [{ role: 'system', content: self._aiPrompt }];
                msgs = msgs.concat(self._aiMsgs.slice(-6));

                self._aiCallLLM(msgs, function (response) {
                    if (!self._aiCheckActions(response, msgs)) {
                        self._aiProcessResponse(response);
                    }
                });
            });
        },

        // Status message (small, gray, centered)
        _aiStatus: function (text) {
            // Remove previous status
            var prev = document.querySelectorAll('.ai-msg.status');
            for (var i = 0; i < prev.length; i++) {
                if (prev[i].textContent.indexOf('âœ“') === -1) prev[i].remove();
            }
            this._aiAddMsg('status', text);
        },

        _aiAddMsg: function (role, text) {
            var chat = document.getElementById('ai-chat');
            var el = document.createElement('div');
            el.className = 'ai-msg ' + role;
            el.textContent = text;
            chat.appendChild(el);
            this._aiScroll();
            return el;
        },

        _aiScroll: function () {
            var c = document.getElementById('ai-chat');
            c.scrollTop = c.scrollHeight;
        },

        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• GERAR IMAGEM â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• DESENHAR CAMINHO â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        _drawStrokes: [],    // Array of strokes [{points:[{x,y,t},...], color, width}]
        _drawCurrent: null,  // Current stroke being drawn
        _drawIsDrawing: false,
        _drawStartTime: 0,

        openDraw: function () {
            document.getElementById('draw-overlay').classList.add('open');
            var self = this;
            // Busca o aspect da comp ativa pra o canvas mapear sem distorção
            csInterface.evalScript('getActiveCompInfo()', function (r) {
                try {
                    var info = JSON.parse(r);
                    if (info && info.width && info.height) self._drawCompAspect = info.width / info.height;
                } catch (e) { self._drawCompAspect = 16 / 9; }
                // resize após o layout do overlay assentar
                requestAnimationFrame(function () { self._drawResize(); });
            });
        },
        closeDraw: function () {
            document.getElementById('draw-overlay').classList.remove('open');
            this._drawHideCursor();
        },

        // Coordenada do ponteiro em pixels do backing-store do canvas
        _drawPos: function (e, canvas) {
            var r = canvas.getBoundingClientRect();
            return {
                x: (e.clientX - r.left) * (canvas.width / r.width),
                y: (e.clientY - r.top) * (canvas.height / r.height)
            };
        },

        // Pressão da caneta (0-1). Mouse reporta 0.5; sem pressão ativa = 1 (espessura constante)
        _drawPressure: function (e) {
            var on = document.getElementById('draw-pressure');
            if (on && !on.checked) return 1;
            var p = (e.pressure != null) ? e.pressure : 0.5;
            if (!p || p <= 0) p = 0.5;
            return Math.max(0.05, Math.min(1, p));
        },

        // Cursor de pincel (anel) acompanhando o ponteiro, com o tamanho real do traço
        _drawMoveCursor: function (e, canvas) {
            var cur = document.getElementById('draw-cursor');
            if (!cur) return;
            var wrap = canvas.parentElement;
            var wr = wrap.getBoundingClientRect();
            var cr = canvas.getBoundingClientRect();
            var w = parseInt(document.getElementById('draw-width').value);
            var disp = Math.max(4, w * (cr.width / canvas.width));
            cur.style.width = disp + 'px';
            cur.style.height = disp + 'px';
            cur.style.left = (e.clientX - wr.left) + 'px';
            cur.style.top = (e.clientY - wr.top) + 'px';
            cur.style.display = 'block';
        },
        _drawHideCursor: function () {
            var c = document.getElementById('draw-cursor');
            if (c) c.style.display = 'none';
        },

        // Ajusta o backing-store do canvas pra preencher o palco mantendo o aspect da comp
        _drawResize: function () {
            var canvas = document.getElementById('draw-canvas');
            if (!canvas) return;
            var wrap = canvas.parentElement;
            var availW = wrap.clientWidth, availH = wrap.clientHeight;
            if (availW < 20 || availH < 20) return;
            var aspect = this._drawCompAspect || (16 / 9);
            var pad = 16;
            var w = availW - pad, h = w / aspect;
            if (h > availH - pad) { h = availH - pad; w = h * aspect; }
            w = Math.round(w); h = Math.round(h);
            canvas.width = w;
            canvas.height = h;
            canvas.style.width = w + 'px';
            canvas.style.height = h + 'px';
            this._drawCanvasW = w;
            this._drawCanvasH = h;
            this._drawRedraw();
        },

        setupDraw: function () {
            var self = this;
            var canvas = document.getElementById('draw-canvas');
            var ctx = canvas.getContext('2d');

            document.getElementById('btn-close-draw').addEventListener('click', function () { self.closeDraw(); });
            document.getElementById('draw-overlay').addEventListener('click', function (e) { if (e.target === this) self.closeDraw(); });

            // ── Drawing events (Pointer Events: mouse + caneta/tablet + touch) ──
            var commitStroke = function () {
                if (self._drawCurrent && self._drawCurrent.points.length > 1) {
                    self._drawStrokes.push(self._drawCurrent);
                }
                self._drawCurrent = null;
                self._drawIsDrawing = false;
                self._drawRedraw();
            };

            canvas.addEventListener('pointerdown', function (e) {
                e.preventDefault();
                try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
                self._drawIsDrawing = true;
                self._drawStartTime = performance.now();
                var pt = self._drawPos(e, canvas);
                self._drawCurrent = {
                    points: [{ x: pt.x, y: pt.y, t: 0, p: self._drawPressure(e) }],
                    color: document.getElementById('draw-color').value,
                    width: parseInt(document.getElementById('draw-width').value)
                };
                self._drawMoveCursor(e, canvas);
            });

            canvas.addEventListener('pointermove', function (e) {
                self._drawMoveCursor(e, canvas);
                if (!self._drawIsDrawing || !self._drawCurrent) return;
                var evs = (e.getCoalescedEvents && e.getCoalescedEvents().length) ? e.getCoalescedEvents() : [e];
                var t = (performance.now() - self._drawStartTime) / 1000;
                for (var i = 0; i < evs.length; i++) {
                    var pt = self._drawPos(evs[i], canvas);
                    self._drawCurrent.points.push({ x: pt.x, y: pt.y, t: t, p: self._drawPressure(evs[i]) });
                }
                self._drawRedraw();
            });

            canvas.addEventListener('pointerup', function (e) {
                try { canvas.releasePointerCapture(e.pointerId); } catch (_) {}
                commitStroke();
            });
            canvas.addEventListener('pointercancel', function () { commitStroke(); });
            canvas.addEventListener('pointerenter', function (e) { self._drawMoveCursor(e, canvas); });
            canvas.addEventListener('pointerleave', function () { if (!self._drawIsDrawing) self._drawHideCursor(); });

            // Recalcula o tamanho do canvas quando a janela muda (mantém traços só se vazio)
            window.addEventListener('resize', function () {
                if (document.getElementById('draw-overlay').classList.contains('open')) {
                    if (self._drawStrokes.length === 0 && !self._drawCurrent) self._drawResize();
                }
            });

            // Controls
            document.getElementById('draw-clear-btn').addEventListener('click', function () {
                self._drawStrokes = [];
                self._drawCurrent = null;
                self._drawRedraw();
            });

            document.getElementById('draw-undo-btn').addEventListener('click', function () {
                self._drawStrokes.pop();
                self._drawRedraw();
            });

            // Color swatches
            var colorBtns = document.querySelectorAll('.draw-c');
            for (var ci = 0; ci < colorBtns.length; ci++) {
                (function(btn) {
                    btn.addEventListener('click', function () {
                        for (var j = 0; j < colorBtns.length; j++) colorBtns[j].classList.remove('active');
                        btn.classList.add('active');
                        document.getElementById('draw-color').value = btn.getAttribute('data-color');
                    });
                })(colorBtns[ci]);
            }

            document.getElementById('draw-width').addEventListener('input', function () {
                document.getElementById('draw-width-val').textContent = this.value;
                self._drawRedraw();
            });
            document.getElementById('draw-smooth').addEventListener('input', function () {
                document.getElementById('draw-smooth-val').textContent = this.value + '%';
                self._drawRedraw();
            });
            document.getElementById('draw-tangent').addEventListener('input', function () {
                document.getElementById('draw-tangent-val').textContent = this.value + '%';
                self._drawRedraw();
            });
            document.getElementById('draw-vertex-type').addEventListener('change', function () {
                self._drawRedraw();
            });
            document.getElementById('draw-show-vertices').addEventListener('change', function () {
                self._drawRedraw();
            });
            var pToggle = document.getElementById('draw-pressure');
            if (pToggle) pToggle.addEventListener('change', function () { self._drawRedraw(); });

            // Refinar curvas (Chaikin corner-cutting â€” converte vertices retos em suaves)
            document.getElementById('draw-refine-btn').addEventListener('click', function () {
                if (self._drawStrokes.length === 0) { MT.toast('Desenhe algo primeiro', true); return; }
                for (var s = 0; s < self._drawStrokes.length; s++) {
                    self._drawStrokes[s].points = self._drawChaikin(self._drawStrokes[s].points);
                }
                // Also auto-switch to smooth vertex type
                document.getElementById('draw-vertex-type').value = 'smooth';
                self._drawUpdateInfo();
                self._drawRedraw();
                MT.toast('Curvas refinadas', false);
            });
        },

        // Chaikin's corner-cutting algorithm â€” each segment p-q becomes two points at 25% and 75%,
        // then the original corners are dropped. Running this once "converts" linear vertices into smooth curves.
        _drawChaikin: function (pts) {
            if (pts.length < 3) return pts;
            var out = [pts[0]];
            for (var i = 0; i < pts.length - 1; i++) {
                var p = pts[i], q = pts[i + 1];
                var t = p.t || 0, tq = q.t || 0;
                out.push({ x: p.x * 0.75 + q.x * 0.25, y: p.y * 0.75 + q.y * 0.25, t: t * 0.75 + tq * 0.25 });
                out.push({ x: p.x * 0.25 + q.x * 0.75, y: p.y * 0.25 + q.y * 0.75, t: t * 0.25 + tq * 0.75 });
            }
            out.push(pts[pts.length - 1]);
            return out;
        },

        _drawUpdateInfo: function () {
            var total = 0;
            for (var i = 0; i < this._drawStrokes.length; i++) total += this._drawStrokes[i].points.length;
            var info = document.getElementById('draw-info');
            if (this._drawStrokes.length === 0) info.textContent = 'Desenhe com o mouse';
            else info.textContent = this._drawStrokes.length + ' traco(s) Â· ' + total + ' vertices';
        },

        _drawRedraw: function () {
            var canvas = document.getElementById('draw-canvas');
            if (!canvas) return;
            var ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // Grid
            ctx.strokeStyle = 'rgba(255,255,255,0.03)';
            ctx.lineWidth = 1;
            for (var gx = 0; gx < canvas.width; gx += 20) { ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, canvas.height); ctx.stroke(); }
            for (var gy = 0; gy < canvas.height; gy += 20) { ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(canvas.width, gy); ctx.stroke(); }

            var smooth = parseInt(document.getElementById('draw-smooth').value) / 100;
            var tangent = parseInt(document.getElementById('draw-tangent').value) / 100;
            var vertexType = document.getElementById('draw-vertex-type').value;
            var showVerts = document.getElementById('draw-show-vertices').checked;
            var pEl = document.getElementById('draw-pressure');
            var pressureOn = pEl && pEl.checked;

            // Draw saved strokes
            for (var s = 0; s < this._drawStrokes.length; s++) {
                var stroke = this._drawStrokes[s];
                var rawPts = stroke.points;
                var finalPts = smooth > 0 ? this._drawSimplify(rawPts, smooth) : rawPts;
                this._drawGhostTrail(ctx, rawPts);
                if (pressureOn) this._drawStrokePathPressure(ctx, finalPts, stroke.color, stroke.width);
                else this._drawStrokePath(ctx, finalPts, stroke.color, stroke.width, vertexType, tangent);
                if (showVerts) this._drawVertexDots(ctx, finalPts, stroke.color);
            }

            // Draw current stroke (real-time preview showing FINAL curve as user draws)
            if (this._drawCurrent && this._drawCurrent.points.length > 1) {
                var rawCur = this._drawCurrent.points;
                var curPts = smooth > 0 ? this._drawSimplify(rawCur, smooth) : rawCur;
                this._drawGhostTrail(ctx, rawCur);
                if (pressureOn) this._drawStrokePathPressure(ctx, curPts, this._drawCurrent.color, this._drawCurrent.width);
                else this._drawStrokePath(ctx, curPts, this._drawCurrent.color, this._drawCurrent.width, vertexType, tangent);
                if (showVerts) this._drawVertexDots(ctx, curPts, this._drawCurrent.color);
            }

            // Live vertex counter
            this._drawUpdateInfo();
        },

        // Ghost trail: shows the raw input behind the final curve (subtle)
        _drawGhostTrail: function (ctx, pts) {
            if (pts.length < 2) return;
            ctx.save();
            ctx.strokeStyle = 'rgba(255,255,255,0.08)';
            ctx.lineWidth = 1;
            ctx.setLineDash([2, 3]);
            ctx.beginPath();
            ctx.moveTo(pts[0].x, pts[0].y);
            for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
            ctx.stroke();
            ctx.restore();
        },

        // Final path: either corner (linear) or smooth (Catmull-Rom â†’ Bezier)
        // Uses EXACTLY the same tangent math as host.jsx so canvas preview matches what AE will build.
        _drawStrokePath: function (ctx, pts, color, width, vertexType, tangentStrength) {
            if (pts.length < 2) return;
            ctx.save();
            ctx.strokeStyle = color;
            ctx.lineWidth = width;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.beginPath();
            ctx.moveTo(pts[0].x, pts[0].y);

            if (vertexType === 'corner' || pts.length < 3) {
                // Linear segments
                for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
            } else {
                // Smooth: Catmull-Rom through each point, converted to cubic bezier segments
                // tangentStrength 0-1 controls how aggressively the curve bends through vertices
                var k = tangentStrength * 0.5; // 0.5 = max uniform Catmull-Rom
                for (var j = 0; j < pts.length - 1; j++) {
                    var p0 = pts[j === 0 ? 0 : j - 1];
                    var p1 = pts[j];
                    var p2 = pts[j + 1];
                    var p3 = pts[j + 2 >= pts.length ? pts.length - 1 : j + 2];
                    var c1x = p1.x + (p2.x - p0.x) * k;
                    var c1y = p1.y + (p2.y - p0.y) * k;
                    var c2x = p2.x - (p3.x - p1.x) * k;
                    var c2y = p2.y - (p3.y - p1.y) * k;
                    ctx.bezierCurveTo(c1x, c1y, c2x, c2y, p2.x, p2.y);
                }
            }
            ctx.stroke();
            ctx.restore();
        },

        // Variable-width stroke (caneta/pressão) — espessura por segmento = width * pressão
        _drawStrokePathPressure: function (ctx, pts, color, baseWidth) {
            if (pts.length < 2) return;
            ctx.save();
            ctx.strokeStyle = color;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            for (var i = 1; i < pts.length; i++) {
                var a = pts[i - 1], b = pts[i];
                var pa = (a.p != null) ? a.p : 1;
                var pb = (b.p != null) ? b.p : 1;
                var pr = (pa + pb) / 2;
                ctx.lineWidth = Math.max(0.6, baseWidth * pr);
                ctx.beginPath();
                ctx.moveTo(a.x, a.y);
                ctx.lineTo(b.x, b.y);
                ctx.stroke();
            }
            ctx.restore();
        },

        // Render the control vertices as small dots so user sees the actual topology
        _drawVertexDots: function (ctx, pts, color) {
            ctx.save();
            ctx.fillStyle = '#ffffff';
            ctx.strokeStyle = color;
            ctx.lineWidth = 1.5;
            for (var i = 0; i < pts.length; i++) {
                ctx.beginPath();
                ctx.arc(pts[i].x, pts[i].y, 2.5, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();
            }
            ctx.restore();
        },

        // Ramer-Douglas-Peucker simplification
        _drawSimplify: function (points, tolerance) {
            if (points.length <= 2) return points;
            var epsilon = tolerance * 5; // scale 0-1 to pixel tolerance
            return this._rdp(points, epsilon);
        },

        _rdp: function (pts, epsilon) {
            if (pts.length <= 2) return pts;
            var maxDist = 0, maxIdx = 0;
            var start = pts[0], end = pts[pts.length - 1];
            for (var i = 1; i < pts.length - 1; i++) {
                var d = this._pointLineDist(pts[i], start, end);
                if (d > maxDist) { maxDist = d; maxIdx = i; }
            }
            if (maxDist > epsilon) {
                var left = this._rdp(pts.slice(0, maxIdx + 1), epsilon);
                var right = this._rdp(pts.slice(maxIdx), epsilon);
                return left.slice(0, left.length - 1).concat(right);
            }
            return [start, end];
        },

        _pointLineDist: function (p, a, b) {
            var dx = b.x - a.x, dy = b.y - a.y;
            var len = Math.sqrt(dx * dx + dy * dy);
            if (len === 0) return Math.sqrt((p.x - a.x) * (p.x - a.x) + (p.y - a.y) * (p.y - a.y));
            return Math.abs(dy * p.x - dx * p.y + b.x * a.y - b.y * a.x) / len;
        },

        drawCreate: function () {
            if (this._drawStrokes.length === 0) { MT.toast('Desenhe algo primeiro', true); return; }

            var mode = document.getElementById('draw-mode').value;
            var durOverride = parseFloat(document.getElementById('draw-duration').value) || 0;
            var easing = document.getElementById('draw-easing').value;
            var atPlayhead = document.getElementById('draw-at-playhead').checked;
            var color = document.getElementById('draw-color').value;
            var width = parseInt(document.getElementById('draw-width').value);
            var smooth = parseInt(document.getElementById('draw-smooth').value) / 100;
            var vertexType = document.getElementById('draw-vertex-type').value;
            var tangentStrength = parseInt(document.getElementById('draw-tangent').value) / 100;

            // Process strokes
            var strokes = [];
            for (var s = 0; s < this._drawStrokes.length; s++) {
                var raw = this._drawStrokes[s];
                var pts = smooth > 0 ? this._drawSimplify(raw.points, smooth) : raw.points;
                strokes.push({ points: pts, color: raw.color, width: raw.width });
            }

            var pEl = document.getElementById('draw-pressure');
            var canvasEl = document.getElementById('draw-canvas');

            var data = {
                mode: mode,
                strokes: strokes,
                duration: durOverride,
                easing: easing,
                atPlayhead: atPlayhead,
                color: color,
                width: width,
                vertexType: vertexType,
                tangentStrength: tangentStrength,
                pressure: !!(pEl && pEl.checked),
                canvasW: this._drawCanvasW || (canvasEl ? canvasEl.width : 320),
                canvasH: this._drawCanvasH || (canvasEl ? canvasEl.height : 200)
            };

            var btn = document.getElementById('draw-create-btn');
            btn.textContent = 'CRIANDO...';
            btn.disabled = true;

            var jsonStr = JSON.stringify(data).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
            csInterface.evalScript("createDrawnPath('" + jsonStr + "')", function (result) {
                btn.textContent = 'CRIAR NO AFTER EFFECTS';
                btn.disabled = false;
                if (result === 'true') {
                    MT.toast('Caminho criado!', false);
                } else {
                    MT.toast(result || 'Erro ao criar', true);
                }
            });
        },

        b64toBlob: function (b64Data, contentType, sliceSize) {
            contentType = contentType || '';
            sliceSize = sliceSize || 512;
            var byteCharacters = atob(b64Data);
            var byteArrays = [];
            for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                var slice = byteCharacters.slice(offset, offset + sliceSize);
                var byteNumbers = new Array(slice.length);
                for (var i = 0; i < slice.length; i++) {
                    byteNumbers[i] = slice.charCodeAt(i);
                }
                var byteArray = new Uint8Array(byteNumbers);
                byteArrays.push(byteArray);
            }
            var blob = new Blob(byteArrays, { type: contentType });
            return blob;
        },

        // ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â CONFIGURAÃƒÆ’Ã¢â‚¬Â¡ÃƒÆ’Ã¢â‚¬Â¢ES ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â
        setupSettings: function () {
            // Settings
            document.getElementById('btn-settings').addEventListener('click', function () {
                document.getElementById('settings-overlay').classList.add('open');
                var k = localStorage.getItem('multiTools_groqKey');
                if (k) document.getElementById('setting-groq-key').value = k;
                var notif = localStorage.getItem('mt_notif');
                document.getElementById('setting-notifications').checked = (notif !== '0');
            });
            document.getElementById('setting-notifications').addEventListener('change', function () {
                localStorage.setItem('mt_notif', this.checked ? '1' : '0');
            });
            document.getElementById('btn-close-settings').addEventListener('click', function () {
                document.getElementById('settings-overlay').classList.remove('open');
            });
            document.getElementById('settings-overlay').addEventListener('click', function (e) {
                if (e.target === this) this.classList.remove('open');
            });
        },

        copyPix: function () {
            var inp = document.getElementById('pix-key');
            if (!inp) return;
            try {
                inp.select();
                inp.setSelectionRange(0, 99999);
                document.execCommand('copy');
                window.getSelection && window.getSelection().removeAllRanges();
                MT.toast('Chave PIX copiada! Obrigado pelo apoio ðŸ’œ', false);
            } catch (e) {
                MT.toast('Copie manualmente: +5588996126717', true);
            }
        },

        saveSettings: function () {
            var groqKey = document.getElementById('setting-groq-key').value.trim();
            if (groqKey) localStorage.setItem('multiTools_groqKey', groqKey);
            MT.toast("Configuracoes salvas!", false);
            document.getElementById('settings-overlay').classList.remove('open');
        },

        // ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â TOAST ÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚ÂÃƒÂ¢Ã¢â‚¬Â¢Ã‚Â
        toast: function (msg, isError) {
            if (localStorage.getItem('mt_notif') === '0') return;
            var toast = document.getElementById('toast');
            var icon = document.getElementById('toast-icon');
            var text = document.getElementById('toast-msg');
            text.textContent = msg;
            toast.className = 'toast show ' + (isError ? 'error' : 'success');
            icon.textContent = isError ? 'ÃƒÂ¢Ã…â€œÃ¢â‚¬Â¢' : 'ÃƒÂ¢Ã…â€œÃ¢â‚¬Å“';
            clearTimeout(this._tt);
            this._tt = setTimeout(function () { toast.classList.remove('show'); }, 2000);
        }
    };

    document.addEventListener('DOMContentLoaded', function () { MT.init(); });
})();
