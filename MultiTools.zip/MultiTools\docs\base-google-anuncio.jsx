(function() {
    // ╔═══════════════════════════════════════════════════════╗
    // ║  ANUNCIO GOOGLE - 10 SEGUNDOS - REELS/SHORTS         ║
    // ║  Motion Graphics Flat Design - 1080x1920 - 30fps     ║
    // ╚═══════════════════════════════════════════════════════╝

    // ════════════════════════════════════════════════════════
    // BIBLIOTECA DE SEGURANCA AE
    // ════════════════════════════════════════════════════════
    var AE = {};
    AE.getProp = function(parent, propName) { if (!parent) return null; try { var p = parent.property(propName); if (!p) return null; return p; } catch(e) { return null; } };
    AE.getPropChain = function(parent, propNames) { var current = parent; for (var i = 0; i < propNames.length; i++) { current = AE.getProp(current, propNames[i]); if (!current) return null; } return current; };
    AE.position = function(layer) { if (!layer) return null; return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Position"]); };
    AE.scale = function(layer) { if (!layer) return null; return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Scale"]); };
    AE.opacity = function(layer) { if (!layer) return null; return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Opacity"]); };
    AE.rotation = function(layer) { if (!layer) return null; return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Rotate Z"]); };
    AE.anchorPoint = function(layer) { if (!layer) return null; return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Anchor Point"]); };
    AE.setValue = function(prop, value) { if (!prop) return false; try { prop.setValue(value); return true; } catch(e) { return false; } };
    AE.setValueAt = function(prop, time, value) { if (!prop) return false; try { prop.setValueAtTime(time, value); return true; } catch(e) { return false; } };
    AE.getValue = function(prop) { if (!prop) return null; try { return prop.value; } catch(e) { return null; } };
    AE.hex = function(h) { h = h.replace("#", ""); return [parseInt(h.substr(0,2), 16) / 255, parseInt(h.substr(2,2), 16) / 255, parseInt(h.substr(4,2), 16) / 255]; };
    AE.easyEase = function(prop, influence) {
        if (!prop) return; if (prop.numKeys === 0) return; influence = influence || 66;
        try {
            var dim = 1; var pvt = prop.propertyValueType;
            if (pvt === PropertyValueType.TwoD || pvt === PropertyValueType.TwoD_SPATIAL) dim = 2;
            if (pvt === PropertyValueType.ThreeD || pvt === PropertyValueType.ThreeD_SPATIAL) dim = 3;
            for (var k = 1; k <= prop.numKeys; k++) {
                var eIn = [], eOut = [];
                for (var d = 0; d < dim; d++) { eIn.push(new KeyframeEase(0, influence)); eOut.push(new KeyframeEase(0, influence)); }
                prop.setTemporalEaseAtKey(k, eIn, eOut);
            }
        } catch(e) {}
    };
    AE.snappyEase = function(prop) { AE.easyEase(prop, 85); };

    // -- Criacao --
    AE.addComp = function(nome, w, h, dur, fps) { try { return app.project.items.addComp(nome || "Comp", w || 1080, h || 1920, 1, dur || 10, fps || 30); } catch(e) { return null; } };
    AE.addSolid = function(comp, cor, nome, w, h) { if (!comp) return null; try { return comp.layers.addSolid(cor || [0,0,0], nome || "Solido", w || comp.width, h || comp.height, 1); } catch(e) { return null; } };
    AE.addShape = function(comp, nome) { if (!comp) return null; try { var s = comp.layers.addShape(); if (s && nome) s.name = nome; return s; } catch(e) { return null; } };
    AE.addNull = function(comp, nome) { if (!comp) return null; try { var n = comp.layers.addNull(); if (n && nome) n.name = nome; return n; } catch(e) { return null; } };
    AE.addText = function(comp, texto, cfg) {
        if (!comp) return null;
        try {
            cfg = cfg || {};
            var layer = comp.layers.addText(texto || "");
            if (!layer) return null;
            layer.name = cfg.nome || "Texto";
            var tp = AE.getPropChain(layer, ["ADBE Text Properties", "ADBE Text Document"]);
            if (tp) {
                var doc = tp.value;
                if (cfg.fonte) doc.font = cfg.fonte;
                if (cfg.tamanho) doc.fontSize = cfg.tamanho;
                if (cfg.cor) doc.fillColor = cfg.cor;
                if (cfg.tracking !== undefined) doc.tracking = cfg.tracking;
                if (cfg.alinhamento === "center") doc.justification = ParagraphJustification.CENTER_JUSTIFY;
                if (cfg.alinhamento === "left") doc.justification = ParagraphJustification.LEFT_JUSTIFY;
                if (cfg.alinhamento === "right") doc.justification = ParagraphJustification.RIGHT_JUSTIFY;
                tp.setValue(doc);
            }
            if (cfg.posicao) AE.setValue(AE.position(layer), cfg.posicao);
            return layer;
        } catch(e) { return null; }
    };
    AE.addEffect = function(layer, matchName) { if (!layer) return null; try { var fx = layer.property("ADBE Effect Parade"); if (!fx) return null; return fx.addProperty(matchName); } catch(e) { return null; } };

    // -- Shapes --
    AE.addRect = function(comp, cfg) {
        cfg = cfg || {};
        var shape = AE.addShape(comp, cfg.nome || "Rect");
        if (!shape) return null;
        try {
            var contents = shape.property("ADBE Root Vectors Group");
            var group = contents.addProperty("ADBE Vector Group");
            var vectors = group.property("ADBE Vectors Group");
            var rect = vectors.addProperty("ADBE Vector Shape - Rect");
            rect.property("ADBE Vector Rect Size").setValue(cfg.tamanho || [200, 200]);
            rect.property("ADBE Vector Rect Roundness").setValue(cfg.roundness || 0);
            if (cfg.corFill !== false) {
                var fill = vectors.addProperty("ADBE Vector Graphic - Fill");
                var c = cfg.corFill || [1,1,1];
                fill.property("ADBE Vector Fill Color").setValue([c[0], c[1], c[2], 1]);
            }
            if (cfg.corStroke) {
                var stroke = vectors.addProperty("ADBE Vector Graphic - Stroke");
                stroke.property("ADBE Vector Stroke Color").setValue([cfg.corStroke[0], cfg.corStroke[1], cfg.corStroke[2], 1]);
                stroke.property("ADBE Vector Stroke Width").setValue(cfg.strokeWidth || 2);
            }
            if (cfg.posicao) AE.setValue(AE.position(shape), cfg.posicao);
            return shape;
        } catch(e) { return null; }
    };
    AE.addEllipse = function(comp, cfg) {
        cfg = cfg || {};
        var shape = AE.addShape(comp, cfg.nome || "Ellipse");
        if (!shape) return null;
        try {
            var contents = shape.property("ADBE Root Vectors Group");
            var group = contents.addProperty("ADBE Vector Group");
            var vectors = group.property("ADBE Vectors Group");
            var ellipse = vectors.addProperty("ADBE Vector Shape - Ellipse");
            var r = cfg.raio || 50;
            ellipse.property("ADBE Vector Ellipse Size").setValue([r * 2, r * 2]);
            if (cfg.corFill !== false) {
                var fill = vectors.addProperty("ADBE Vector Graphic - Fill");
                var c = cfg.corFill || [1,1,1];
                fill.property("ADBE Vector Fill Color").setValue([c[0], c[1], c[2], 1]);
            }
            if (cfg.corStroke) {
                var stroke = vectors.addProperty("ADBE Vector Graphic - Stroke");
                stroke.property("ADBE Vector Stroke Color").setValue([cfg.corStroke[0], cfg.corStroke[1], cfg.corStroke[2], 1]);
                stroke.property("ADBE Vector Stroke Width").setValue(cfg.strokeWidth || 2);
            }
            if (cfg.posicao) AE.setValue(AE.position(shape), cfg.posicao);
            return shape;
        } catch(e) { return null; }
    };
    AE.addLine = function(comp, cfg) {
        cfg = cfg || {};
        var shape = AE.addShape(comp, cfg.nome || "Linha");
        if (!shape) return null;
        try {
            var contents = shape.property("ADBE Root Vectors Group");
            var group = contents.addProperty("ADBE Vector Group");
            var vectors = group.property("ADBE Vectors Group");
            var path = vectors.addProperty("ADBE Vector Shape - Group");
            var sd = new Shape();
            var w = cfg.largura || 200;
            sd.vertices = [[-w/2, 0], [w/2, 0]];
            sd.closed = false;
            path.property("ADBE Vector Shape").setValue(sd);
            var stroke = vectors.addProperty("ADBE Vector Graphic - Stroke");
            var c = cfg.cor || [1,1,1];
            stroke.property("ADBE Vector Stroke Color").setValue([c[0], c[1], c[2], 1]);
            stroke.property("ADBE Vector Stroke Width").setValue(cfg.espessura || 3);
            stroke.property("ADBE Vector Stroke Line Cap").setValue(2);
            if (cfg.posicao) AE.setValue(AE.position(shape), cfg.posicao);
            return { shape: shape, vectors: vectors };
        } catch(e) { return null; }
    };

    // -- Animacoes --
    AE.animFadeIn = function(layer, t, dur) { if (!layer) return; dur = dur || 0.25; AE.setValueAt(AE.opacity(layer), t, 0); AE.setValueAt(AE.opacity(layer), t + dur, 100); AE.snappyEase(AE.opacity(layer)); };
    AE.animFadeOut = function(layer, t, dur) { if (!layer) return; dur = dur || 0.2; AE.setValueAt(AE.opacity(layer), t, 100); AE.setValueAt(AE.opacity(layer), t + dur, 0); AE.snappyEase(AE.opacity(layer)); };
    AE.animFadeScaleIn = function(layer, t, dur) { if (!layer) return; dur = dur || 0.3; AE.setValueAt(AE.opacity(layer), t, 0); AE.setValueAt(AE.opacity(layer), t + dur, 100); AE.setValueAt(AE.scale(layer), t, [80, 80]); AE.setValueAt(AE.scale(layer), t + dur, [100, 100]); AE.snappyEase(AE.opacity(layer)); AE.snappyEase(AE.scale(layer)); };
    AE.animPopIn = function(layer, t) { if (!layer) return; AE.setValueAt(AE.opacity(layer), t, 0); AE.setValueAt(AE.opacity(layer), t + 0.08, 100); AE.setValueAt(AE.scale(layer), t, [0, 0]); AE.setValueAt(AE.scale(layer), t + 0.2, [112, 112]); AE.setValueAt(AE.scale(layer), t + 0.35, [100, 100]); AE.snappyEase(AE.scale(layer)); AE.snappyEase(AE.opacity(layer)); };
    AE.animSlideIn = function(layer, t, dir, dist, dur) {
        if (!layer) return; dur = dur || 0.35; dist = dist || 200; dir = dir || "esquerda";
        var pos = AE.position(layer); if (!pos) return;
        var cur = AE.getValue(pos); if (!cur) return;
        var ini;
        switch(dir) {
            case "esquerda": ini = [cur[0] - dist, cur[1]]; break;
            case "direita":  ini = [cur[0] + dist, cur[1]]; break;
            case "cima":     ini = [cur[0], cur[1] - dist]; break;
            case "baixo":    ini = [cur[0], cur[1] + dist]; break;
            default: ini = [cur[0] - dist, cur[1]];
        }
        AE.setValueAt(pos, t, ini); AE.setValueAt(pos, t + dur, cur); AE.snappyEase(pos);
        AE.animFadeIn(layer, t, dur * 0.4);
    };
    AE.animSlideOut = function(layer, t, dir, dist, dur) {
        if (!layer) return; dur = dur || 0.25; dist = dist || 200; dir = dir || "direita";
        var pos = AE.position(layer); if (!pos) return;
        var cur = AE.getValue(pos); if (!cur) return;
        var fim;
        switch(dir) {
            case "esquerda": fim = [cur[0] - dist, cur[1]]; break;
            case "direita":  fim = [cur[0] + dist, cur[1]]; break;
            case "cima":     fim = [cur[0], cur[1] - dist]; break;
            case "baixo":    fim = [cur[0], cur[1] + dist]; break;
            default: fim = [cur[0] + dist, cur[1]];
        }
        AE.setValueAt(pos, t, cur); AE.setValueAt(pos, t + dur, fim); AE.snappyEase(pos);
        AE.animFadeOut(layer, t + dur * 0.5, dur * 0.5);
    };
    AE.animStagger = function(layers, t, intervalo, tipo) {
        if (!layers) return; intervalo = intervalo || 0.08; tipo = tipo || "fadeScale";
        for (var i = 0; i < layers.length; i++) {
            if (!layers[i]) continue;
            var ti = t + (i * intervalo);
            AE.setValueAt(AE.opacity(layers[i]), 0, 0);
            if (ti > 0.02) AE.setValueAt(AE.opacity(layers[i]), ti - 0.01, 0);
            switch(tipo) {
                case "fadeScale": AE.animFadeScaleIn(layers[i], ti, 0.3); break;
                case "slideEsquerda": AE.animSlideIn(layers[i], ti, "esquerda", 150, 0.35); break;
                case "slideDireita": AE.animSlideIn(layers[i], ti, "direita", 150, 0.35); break;
                case "slideBaixo": AE.animSlideIn(layers[i], ti, "baixo", 100, 0.3); break;
                case "pop": AE.animPopIn(layers[i], ti); break;
            }
        }
    };
    AE.animTrimIn = function(vectors, t, dur) {
        if (!vectors) return;
        try {
            var trim = vectors.addProperty("ADBE Vector Filter - Trim");
            var trimEnd = trim.property("ADBE Vector Trim End");
            AE.setValueAt(trimEnd, t, 0); AE.setValueAt(trimEnd, t + (dur || 0.5), 100); AE.snappyEase(trimEnd);
        } catch(e) {}
    };


    // ════════════════════════════════════════════════════════
    // INICIO DO SCRIPT — ANUNCIO GOOGLE 10s
    // ════════════════════════════════════════════════════════
    app.beginUndoGroup("Anuncio Google 10s");

    try {
        // ──────────────────────────────────
        // CORES GOOGLE
        // ──────────────────────────────────
        var cor = {
            azul:       AE.hex("#4285F4"),
            vermelho:   AE.hex("#EA4335"),
            amarelo:    AE.hex("#FBBC05"),
            verde:      AE.hex("#34A853"),
            fundo:      AE.hex("#FFFFFF"),
            fundoEscuro:AE.hex("#F8F9FA"),
            texto:      AE.hex("#202124"),
            textoSec:   AE.hex("#5F6368"),
            cardBg:     AE.hex("#FFFFFF"),
            borda:      AE.hex("#DADCE0"),
            searchBar:  AE.hex("#F1F3F4")
        };
        var googleCores = [cor.azul, cor.vermelho, cor.amarelo, cor.azul, cor.verde, cor.vermelho];

        // ──────────────────────────────────
        // COMPOSICAO
        // ──────────────────────────────────
        var comp = AE.addComp("Google_Anuncio_10s", 1080, 1920, 10, 30);
        if (!comp) { alert("Erro ao criar composicao."); return; }

        var CX = 540;
        var CY = 960;


        // ══════════════════════════════════════════════════
        // FUNDO BRANCO
        // ══════════════════════════════════════════════════
        var bg = AE.addSolid(comp, cor.fundo, "BG_Branco", 1080, 1920);
        if (bg) bg.moveToEnd();


        // ══════════════════════════════════════════════════
        // PARTICULAS — Bolinhas coloridas Google flutuando
        // ══════════════════════════════════════════════════
        for (var pi = 0; pi < 16; pi++) {
            var px = 60 + Math.round(Math.random() * 960);
            var py = 60 + Math.round(Math.random() * 1800);
            var pr = 4 + Math.round(Math.random() * 14);
            var pCor = googleCores[pi % googleCores.length];
            var pOp = 6 + Math.round(Math.random() * 14);
            var pdot = AE.addEllipse(comp, {
                posicao: [px, py],
                raio: pr,
                corFill: pCor,
                nome: "GDot_" + pi
            });
            if (pdot) {
                AE.setValue(AE.opacity(pdot), pOp);
                var pfreq = (0.4 + Math.random() * 1.8).toFixed(2);
                var pampX = (6 + Math.random() * 20).toFixed(0);
                var pampY = (6 + Math.random() * 20).toFixed(0);
                var pPos = AE.position(pdot);
                if (pPos) {
                    pPos.expression =
                        "var s = " + pi + ";\n" +
                        "var p = value;\n" +
                        "[p[0] + Math.sin(time * " + pfreq + " + s) * " + pampX + ", " +
                        "p[1] + Math.cos(time * " + pfreq + " * 0.7 + s) * " + pampY + "];";
                }
                pdot.moveToEnd();
            }
        }


        // ══════════════════════════════════════════════════
        // CENA 1 — ABERTURA LOGO GOOGLE (0s - 3s)
        // Letras "Google" coloridas com pop stagger
        // ══════════════════════════════════════════════════

        // -- Barra colorida decorativa topo --
        var barraTopoData = [
            { cor: cor.azul, x: 0 },
            { cor: cor.vermelho, x: 270 },
            { cor: cor.amarelo, x: 540 },
            { cor: cor.verde, x: 810 }
        ];
        var barrasTopoLayers = [];
        for (var bi = 0; bi < barraTopoData.length; bi++) {
            var barra = AE.addRect(comp, {
                posicao: [barraTopoData[bi].x + 135, 6],
                tamanho: [270, 12],
                roundness: 0,
                corFill: barraTopoData[bi].cor,
                nome: "BarraTopo_" + bi
            });
            if (barra) {
                barra.inPoint = 0;
                barra.outPoint = 10;
                barrasTopoLayers.push(barra);
            }
        }
        AE.animStagger(barrasTopoLayers, 0.05, 0.06, "fadeScale");

        // -- Letras G-o-o-g-l-e individuais com cores --
        var googleLetras = ["G", "o", "o", "g", "l", "e"];
        var googleLetrasCores = [cor.azul, cor.vermelho, cor.amarelo, cor.azul, cor.verde, cor.vermelho];
        var letraLargura = 85;
        var letraStartX = CX - ((googleLetras.length * letraLargura) / 2) + (letraLargura / 2);
        var letraY = 750;
        var letrasLayers = [];

        for (var li = 0; li < googleLetras.length; li++) {
            var letra = AE.addText(comp, googleLetras[li], {
                posicao: [letraStartX + (li * letraLargura), letraY],
                fonte: "Arial-BoldMT",
                tamanho: 130,
                cor: googleLetrasCores[li],
                alinhamento: "center",
                nome: "G_Letra_" + googleLetras[li] + "_" + li
            });
            if (letra) {
                letra.inPoint = 0;
                letra.outPoint = 3.0;
                letrasLayers.push(letra);
            }
        }

        // -- Stagger pop in das letras --
        AE.animStagger(letrasLayers, 0.15, 0.08, "pop");

        // -- Barra de pesquisa decorativa --
        var searchBar = AE.addRect(comp, {
            posicao: [CX, 920],
            tamanho: [820, 80],
            roundness: 40,
            corFill: cor.searchBar,
            corStroke: cor.borda,
            strokeWidth: 2,
            nome: "SearchBar"
        });
        if (searchBar) {
            searchBar.inPoint = 0;
            searchBar.outPoint = 3.0;
        }

        // -- Texto dentro da search bar --
        var searchTxt = AE.addText(comp, "Pesquisar com IA...", {
            posicao: [CX, 930],
            fonte: "ArialMT",
            tamanho: 28,
            cor: cor.textoSec,
            alinhamento: "center",
            nome: "SearchBar_Texto"
        });
        if (searchTxt) {
            searchTxt.inPoint = 0;
            searchTxt.outPoint = 3.0;
        }

        // -- Icone lupa (circulo + linha) --
        var lupaCirc = AE.addEllipse(comp, {
            posicao: [220, 920],
            raio: 14,
            corFill: false,
            corStroke: cor.textoSec,
            strokeWidth: 3,
            nome: "Lupa_Circulo"
        });
        if (lupaCirc) {
            lupaCirc.inPoint = 0;
            lupaCirc.outPoint = 3.0;
        }

        // -- Tagline abaixo --
        var tagline = AE.addText(comp, "A IA que entende voce", {
            posicao: [CX, 1060],
            fonte: "ArialMT",
            tamanho: 32,
            cor: cor.textoSec,
            alinhamento: "center",
            tracking: 30,
            nome: "Cena1_Tagline"
        });
        if (tagline) {
            tagline.inPoint = 0;
            tagline.outPoint = 3.0;
        }

        // -- Animacoes search bar e tagline --
        AE.animSlideIn(searchBar, 0.7, "baixo", 60, 0.35);
        AE.animSlideIn(searchTxt, 0.75, "baixo", 60, 0.35);
        AE.animFadeScaleIn(lupaCirc, 0.8, 0.3);
        AE.animFadeIn(tagline, 1.1, 0.35);

        // -- Saida Cena 1 --
        for (var lout = 0; lout < letrasLayers.length; lout++) {
            AE.animFadeOut(letrasLayers[lout], 2.5 + (lout * 0.03), 0.25);
        }
        AE.animSlideOut(searchBar, 2.5, "cima", 100, 0.3);
        AE.animSlideOut(searchTxt, 2.5, "cima", 100, 0.3);
        AE.animFadeOut(lupaCirc, 2.5, 0.2);
        AE.animFadeOut(tagline, 2.5, 0.25);


        // ══════════════════════════════════════════════════
        // TRANSICAO — 4 Circulos coloridos expandindo (2.8s)
        // ══════════════════════════════════════════════════
        var transCircData = [
            { cor: cor.azul, delay: 0 },
            { cor: cor.vermelho, delay: 0.04 },
            { cor: cor.amarelo, delay: 0.08 },
            { cor: cor.verde, delay: 0.12 }
        ];
        for (var tci = 0; tci < transCircData.length; tci++) {
            var tcd = transCircData[tci];
            var transCirc = AE.addEllipse(comp, {
                posicao: [CX, CY],
                raio: 10,
                corFill: tcd.cor,
                nome: "Trans_Circ_" + tci
            });
            if (transCirc) {
                transCirc.inPoint = 2.8;
                transCirc.outPoint = 3.4;
                var tSc = AE.scale(transCirc);
                var tStart = 2.8 + tcd.delay;
                AE.setValueAt(tSc, tStart, [0, 0]);
                AE.setValueAt(tSc, tStart + 0.2, [3000, 3000]);
                AE.snappyEase(tSc);
                AE.setValueAt(AE.opacity(transCirc), tStart, 60);
                AE.setValueAt(AE.opacity(transCirc), tStart + 0.2, 0);
                AE.snappyEase(AE.opacity(transCirc));
            }
        }


        // ══════════════════════════════════════════════════
        // CENA 2 — FUNCIONALIDADES (3s - 6.5s)
        // 3 cards com recursos do Google
        // ══════════════════════════════════════════════════

        // -- Titulo --
        var titCena2 = AE.addText(comp, "Feito para simplificar", {
            posicao: [CX, 300],
            fonte: "Arial-BoldMT",
            tamanho: 52,
            cor: cor.texto,
            alinhamento: "center",
            tracking: 10,
            nome: "Cena2_Titulo"
        });
        if (titCena2) {
            titCena2.inPoint = 3.0;
            titCena2.outPoint = 6.5;
        }

        // -- Linha multicolorida abaixo do titulo --
        var lineColors = [cor.azul, cor.vermelho, cor.amarelo, cor.verde];
        var lineSegW = 50;
        var lineStartX = CX - ((lineColors.length * lineSegW) / 2) + (lineSegW / 2);
        var lineMcLayers = [];
        for (var mci = 0; mci < lineColors.length; mci++) {
            var lineSeg = AE.addRect(comp, {
                posicao: [lineStartX + (mci * lineSegW), 355],
                tamanho: [lineSegW - 4, 5],
                roundness: 3,
                corFill: lineColors[mci],
                nome: "LineSeg_" + mci
            });
            if (lineSeg) {
                lineSeg.inPoint = 3.0;
                lineSeg.outPoint = 6.5;
                lineMcLayers.push(lineSeg);
            }
        }

        // -- Cards --
        var cardData = [
            { icone: "AI",  titulo: "Gemini",         desc: "IA generativa\nmais avancada", corIcon: cor.azul },
            { icone: "Fo",  titulo: "Fotos",           desc: "Suas memorias\norganizadas", corIcon: cor.vermelho },
            { icone: "Dr",  titulo: "Drive",           desc: "15GB gratis\nna nuvem", corIcon: cor.verde }
        ];

        var allCardLayers = [];
        var cardStartY = 460;
        var cardH = 300;
        var cardGap = 30;

        for (var ci = 0; ci < cardData.length; ci++) {
            var cd = cardData[ci];
            var cardY = cardStartY + (ci * (cardH + cardGap));

            // Card bg
            var cBg = AE.addRect(comp, {
                posicao: [CX, cardY + (cardH / 2)],
                tamanho: [900, cardH - 10],
                roundness: 24,
                corFill: cor.cardBg,
                corStroke: cor.borda,
                strokeWidth: 1.5,
                nome: "C2_CardBG_" + ci
            });
            if (cBg) {
                cBg.inPoint = 3.0;
                cBg.outPoint = 6.5;
                // Sombra sutil
                var sombra = AE.addEffect(cBg, "ADBE Drop Shadow");
                if (sombra) {
                    AE.setValue(AE.getProp(sombra, "ADBE Drop Shadow-0001"), [0, 0, 0]); // cor
                    AE.setValue(AE.getProp(sombra, "ADBE Drop Shadow-0002"), 15);         // opacidade
                    AE.setValue(AE.getProp(sombra, "ADBE Drop Shadow-0005"), 8);          // distancia
                    AE.setValue(AE.getProp(sombra, "ADBE Drop Shadow-0006"), 25);         // softness
                }
                allCardLayers.push(cBg);
            }

            // Icone quadrado colorido
            var cIcon = AE.addRect(comp, {
                posicao: [190, cardY + (cardH / 2)],
                tamanho: [80, 80],
                roundness: 20,
                corFill: cd.corIcon,
                nome: "C2_Icon_" + ci
            });
            if (cIcon) {
                cIcon.inPoint = 3.0;
                cIcon.outPoint = 6.5;
                allCardLayers.push(cIcon);
            }

            // Letra dentro do icone
            var cIconTxt = AE.addText(comp, cd.icone, {
                posicao: [190, cardY + (cardH / 2) + 12],
                fonte: "Arial-BoldMT",
                tamanho: 30,
                cor: [1, 1, 1],
                alinhamento: "center",
                nome: "C2_IconTxt_" + ci
            });
            if (cIconTxt) {
                cIconTxt.inPoint = 3.0;
                cIconTxt.outPoint = 6.5;
                allCardLayers.push(cIconTxt);
            }

            // Titulo card
            var cTit = AE.addText(comp, cd.titulo, {
                posicao: [530, cardY + (cardH / 2) - 20],
                fonte: "Arial-BoldMT",
                tamanho: 40,
                cor: cor.texto,
                alinhamento: "left",
                nome: "C2_Titulo_" + ci
            });
            if (cTit) {
                cTit.inPoint = 3.0;
                cTit.outPoint = 6.5;
                allCardLayers.push(cTit);
            }

            // Descricao card
            var cDesc = AE.addText(comp, cd.desc, {
                posicao: [530, cardY + (cardH / 2) + 35],
                fonte: "ArialMT",
                tamanho: 24,
                cor: cor.textoSec,
                alinhamento: "left",
                nome: "C2_Desc_" + ci
            });
            if (cDesc) {
                cDesc.inPoint = 3.0;
                cDesc.outPoint = 6.5;
                allCardLayers.push(cDesc);
            }
        }

        // -- Animacoes Cena 2 --
        AE.animSlideIn(titCena2, 3.1, "baixo", 60, 0.35);
        AE.animStagger(lineMcLayers, 3.3, 0.06, "fadeScale");
        AE.animStagger(allCardLayers, 3.5, 0.04, "slideBaixo");

        // -- Saida Cena 2 --
        AE.animFadeOut(titCena2, 6.0, 0.3);
        for (var cl = 0; cl < lineMcLayers.length; cl++) {
            AE.animFadeOut(lineMcLayers[cl], 6.0, 0.25);
        }
        for (var co = 0; co < allCardLayers.length; co++) {
            AE.animFadeOut(allCardLayers[co], 6.0 + (co * 0.01), 0.25);
        }


        // ══════════════════════════════════════════════════
        // TRANSICAO — Wipe branco (6.3s)
        // ══════════════════════════════════════════════════
        var wipe2 = AE.addSolid(comp, cor.fundo, "Wipe_2", 1080, 1920);
        if (wipe2) {
            wipe2.inPoint = 6.2;
            wipe2.outPoint = 7.0;
            var w2Pos = AE.position(wipe2);
            AE.setValueAt(w2Pos, 6.2, [CX, CY + 1920]);
            AE.setValueAt(w2Pos, 6.45, [CX, CY]);
            AE.setValueAt(w2Pos, 6.6, [CX, CY]);
            AE.setValueAt(w2Pos, 6.85, [CX, CY - 1920]);
            AE.snappyEase(w2Pos);
        }


        // ══════════════════════════════════════════════════
        // CENA 3 — CTA FINAL (6.5s - 10s)
        // Logo + "Pesquise. Descubra. Crie."
        // ══════════════════════════════════════════════════

        // -- Circulo decorativo grande atras (azul sutil) --
        var circBgFinal = AE.addEllipse(comp, {
            posicao: [CX, 700],
            raio: 280,
            corFill: cor.azul,
            nome: "CTA_CircBg"
        });
        if (circBgFinal) {
            circBgFinal.inPoint = 6.5;
            AE.setValue(AE.opacity(circBgFinal), 6);
            var circBgRot = AE.rotation(circBgFinal);
            if (circBgRot) circBgRot.expression = "time * 10;";
        }

        // -- Segundo circulo (vermelho sutil) --
        var circBgFinal2 = AE.addEllipse(comp, {
            posicao: [CX, 700],
            raio: 220,
            corFill: cor.vermelho,
            nome: "CTA_CircBg2"
        });
        if (circBgFinal2) {
            circBgFinal2.inPoint = 6.5;
            AE.setValue(AE.opacity(circBgFinal2), 5);
            var circBg2Rot = AE.rotation(circBgFinal2);
            if (circBg2Rot) circBg2Rot.expression = "time * -8;";
        }

        // -- Letras Google grandes novamente --
        var letrasFinais = [];
        var letraFinalY = 700;
        for (var lfi = 0; lfi < googleLetras.length; lfi++) {
            var lf = AE.addText(comp, googleLetras[lfi], {
                posicao: [letraStartX + (lfi * letraLargura), letraFinalY],
                fonte: "Arial-BoldMT",
                tamanho: 130,
                cor: googleLetrasCores[lfi],
                alinhamento: "center",
                nome: "CTA_Letra_" + googleLetras[lfi] + "_" + lfi
            });
            if (lf) {
                lf.inPoint = 6.5;
                letrasFinais.push(lf);
            }
        }
        AE.animStagger(letrasFinais, 6.6, 0.07, "pop");

        // -- Linha multicolorida --
        var lineFinais = [];
        for (var lsi = 0; lsi < lineColors.length; lsi++) {
            var lseg = AE.addRect(comp, {
                posicao: [lineStartX + (lsi * lineSegW), 790],
                tamanho: [lineSegW - 4, 5],
                roundness: 3,
                corFill: lineColors[lsi],
                nome: "CTA_LineSeg_" + lsi
            });
            if (lseg) {
                lseg.inPoint = 6.5;
                lineFinais.push(lseg);
            }
        }
        AE.animStagger(lineFinais, 7.1, 0.05, "fadeScale");

        // -- Texto hero: tres linhas --
        var heroTextos = [
            { txt: "Pesquise.", cor: cor.azul, y: 920 },
            { txt: "Descubra.", cor: cor.vermelho, y: 1000 },
            { txt: "Crie.",     cor: cor.verde, y: 1080 }
        ];
        var heroLayers = [];
        for (var hi = 0; hi < heroTextos.length; hi++) {
            var ht = heroTextos[hi];
            var heroTxt = AE.addText(comp, ht.txt, {
                posicao: [CX, ht.y],
                fonte: "Arial-BoldMT",
                tamanho: 64,
                cor: ht.cor,
                alinhamento: "center",
                tracking: 30,
                nome: "CTA_Hero_" + hi
            });
            if (heroTxt) {
                heroTxt.inPoint = 6.5;
                heroLayers.push(heroTxt);
            }
        }
        AE.animStagger(heroLayers, 7.3, 0.15, "slideBaixo");

        // -- Subtexto --
        var ctaSub = AE.addText(comp, "com a ajuda da IA do Google", {
            posicao: [CX, 1180],
            fonte: "ArialMT",
            tamanho: 28,
            cor: cor.textoSec,
            alinhamento: "center",
            tracking: 40,
            nome: "CTA_Subtexto"
        });
        if (ctaSub) {
            ctaSub.inPoint = 6.5;
        }
        AE.animFadeIn(ctaSub, 8.0, 0.35);

        // -- Botao CTA --
        var btnCTA = AE.addRect(comp, {
            posicao: [CX, 1320],
            tamanho: [520, 80],
            roundness: 40,
            corFill: cor.azul,
            nome: "CTA_Botao"
        });
        if (btnCTA) {
            btnCTA.inPoint = 6.5;
        }

        var btnTxt = AE.addText(comp, "COMECE AGORA", {
            posicao: [CX, 1332],
            fonte: "Arial-BoldMT",
            tamanho: 26,
            cor: [1, 1, 1],
            alinhamento: "center",
            tracking: 100,
            nome: "CTA_BotaoTexto"
        });
        if (btnTxt) {
            btnTxt.inPoint = 6.5;
        }

        AE.animPopIn(btnCTA, 8.3);
        AE.animFadeScaleIn(btnTxt, 8.4, 0.3);

        // -- Pulso suave no botao --
        var btnSc = AE.scale(btnCTA);
        if (btnSc) {
            btnSc.expression = [
                "var t = time - 8.8;",
                "if (t < 0) value;",
                "else {",
                "  var pulse = Math.sin(t * 3.5) * 2.5;",
                "  [100 + pulse, 100 + pulse];",
                "}"
            ].join("\n");
        }

        // -- google.com --
        var urlTxt = AE.addText(comp, "google.com", {
            posicao: [CX, 1440],
            fonte: "ArialMT",
            tamanho: 22,
            cor: cor.textoSec,
            alinhamento: "center",
            tracking: 80,
            nome: "CTA_URL"
        });
        if (urlTxt) {
            urlTxt.inPoint = 6.5;
        }
        AE.animFadeIn(urlTxt, 8.6, 0.3);

        // -- Barra colorida final no rodape --
        var barraBottomLayers = [];
        for (var bbi = 0; bbi < barraTopoData.length; bbi++) {
            var bBot = AE.addRect(comp, {
                posicao: [barraTopoData[bbi].x + 135, 1914],
                tamanho: [270, 12],
                roundness: 0,
                corFill: barraTopoData[bbi].cor,
                nome: "BarraBottom_" + bbi
            });
            if (bBot) {
                bBot.inPoint = 6.5;
                barraBottomLayers.push(bBot);
            }
        }
        AE.animStagger(barraBottomLayers, 8.8, 0.06, "fadeScale");


        // ══════════════════════════════════════════════════
        // REORDENAR — fundo e particulas no final
        // ══════════════════════════════════════════════════
        if (bg) bg.moveToEnd();


        alert("Anuncio Google 10s criado com sucesso!\nComp: Google_Anuncio_10s");

    } catch (e) {
        alert("Erro: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();
