// agent-runner.js — Agente autonomo que controla o AE passo-a-passo
// Em vez de gerar 1 script gigante, o agente:
//   1. PLANEJA (decompoe em cenas com JSON)
//   2. CRIA cada cena individualmente (~50 linhas por vez)
//   3. VERIFICA se a cena foi criada corretamente (le layers do AE)
//   4. CORRIGE erros antes de avancar
//   5. AVANCA pra proxima cena

function AgentRunner(mt) {
    this.mt = mt;
    this.plan = null;
    this.completed = [];
    this.currentScene = 0;
    this.state = 'idle'; // idle | planning | creating | verifying | fixing | reviewing | done | aborted
    this.sceneRetries = 0;
    this.maxSceneRetries = 3;
    this.compState = null;
    this.userPrompt = '';
    this.contexts = { comp: '', layers: '', audio: '', imgs: '' };
}

// ─── PROMPTS DO AGENTE ──────────────────────────────────────────

AgentRunner.PLAN_PROMPT =
    'Voce e um diretor de motion graphics. Sua tarefa e DECOMPOR o pedido do usuario em cenas individuais.\n\n' +
    'Retorne APENAS um JSON valido (sem markdown, sem explicacao, sem ```). Formato EXATO:\n' +
    '{\n' +
    '  "title": "nome curto do projeto",\n' +
    '  "duration": 15,\n' +
    '  "palette": ["#cor1", "#cor2", "#cor3", "#cor4"],\n' +
    '  "font": "Arial-BoldMT",\n' +
    '  "scenes": [\n' +
    '    {\n' +
    '      "id": 0,\n' +
    '      "name": "Hook",\n' +
    '      "start": 0.0,\n' +
    '      "end": 3.0,\n' +
    '      "bg": "#cor_fundo",\n' +
    '      "elements": ["texto grande CHEGA DE", "texto accent BANCO CHATO", "aurora blob roxo"],\n' +
    '      "animation": "springPop stagger 0.2s + cutOut seco",\n' +
    '      "technique": "kinetic typography"\n' +
    '    }\n' +
    '  ]\n' +
    '}\n\n' +
    'REGRAS DO PLANO:\n' +
    '- Maximo 6 cenas (menos e melhor)\n' +
    '- Cada cena tem 2-4s de duracao\n' +
    '- Cada cena lista EXATAMENTE os elementos visuais que vai criar\n' +
    '- palette: 4 cores HEX derivadas do tema\n' +
    '- elements: lista de strings descrevendo cada layer (tipo + conteudo + tamanho)\n' +
    '- animation: como os elementos entram/saem\n' +
    '- technique: qual padrao usar (kinetic typography / card UI 3D / scroll list / aurora blobs / button states / hypnotic loop)\n' +
    '- ULTIMA cena SEMPRE e um CTA com botao\n' +
    '- Duracao total = soma dos ranges de todas as cenas\n\n' +
    'APENAS JSON. Nada mais.';

AgentRunner.SCENE_PROMPT =
    'Voce e um codificador ExtendScript ES3. Gere APENAS o codigo pra UMA cena do motion, SEM explicacao.\n\n' +
    'REGRAS ABSOLUTAS:\n' +
    '- var comp = app.project.activeItem; (NAO crie comp nova)\n' +
    '- CADA layer com layer.inPoint = START e layer.outPoint = END da cena\n' +
    '- Use AE.stackV([layers], cx, cy, gap) pra empilhar textos (NUNCA posicione Y manualmente)\n' +
    '- Use AE.fitInCard([children], cx, cy, w, h, pad, gap) pra conteudo de cards\n' +
    '- Use AE.centerAnchor(layer) em TODO text layer\n' +
    '- Keyframes em tempo ABSOLUTO (start da cena + offset)\n' +
    '- Ease 100% via AE.maxEase(prop) em todos keyframes\n' +
    '- Shape refs BLINDADAS: addProperty tudo primeiro, busque refs via AE.gc depois\n' +
    '- ES3: var, function(){}, for loops. SEM const/let/arrow/class/template/destructuring\n' +
    '- SEM alert(). SEM JSON.parse.\n' +
    '- Max 60 linhas de codigo\n' +
    '- Envolva em app.beginUndoGroup("Scene N")/endUndoGroup em try/finally\n' +
    '- NAO defina helpers AE.* (ja estao definidos na comp — use direto)\n\n' +
    'Gere APENAS o bloco ```javascript ... ```. Nada mais.';

// ─── START ──────────────────────────────────────────────────────

AgentRunner.prototype.start = function (userPrompt, compCtx, layerCtx, audioCtx, imgCtx) {
    this.userPrompt = userPrompt;
    this.contexts = { comp: compCtx, layers: layerCtx, audio: audioCtx || '', imgs: imgCtx || '' };
    this.state = 'planning';
    this.completed = [];
    this.currentScene = 0;
    this.plan = null;

    var self = this;
    self._log('🤖', 'Agente iniciado. Prompt: "' + userPrompt.substring(0, 80) + (userPrompt.length > 80 ? '...' : '') + '"');
    self._log('📐', 'Comp: ' + (compCtx || 'nao detectada'));
    self._log('🧠', 'Fase 1: PLANEJANDO — decompor em cenas individuais...');

    // Carrega um script de exemplo como referencia (pra IA copiar o padrao)
    self._loadExampleScript(function () {
        // Garantir que helpers AE.* existem na comp
        self._ensureHelpers(function () {
            self._log('✓', 'Helpers AE.* carregados no AE');
            self._doPlan();
        });
    });
};

AgentRunner.prototype.abort = function () {
    this.state = 'aborted';
    this._status('Agente parado.');
};

// ─── PHASE 1: PLAN ──────────────────────────────────────────────

AgentRunner.prototype._doPlan = function () {
    if (this.state === 'aborted') return;
    var self = this;

    self._callLLMSilent(
        [
            { role: 'system', content: AgentRunner.PLAN_PROMPT },
            { role: 'user', content: this.contexts.comp + this.contexts.audio + '\n\nPEDIDO DO USUARIO:\n' + this.userPrompt }
        ],
        function (jsonText) {
            if (self.state === 'aborted') return;
            self._log('📨', 'Plano recebido: ' + (jsonText ? jsonText.length : 0) + ' chars');
            if (jsonText) {
                self._log('📝', 'Preview: ' + jsonText.substring(0, 250));
            } else {
                self._log('❌', 'Resposta completamente VAZIA do LLM');
            }
            var plan = self._parsePlan(jsonText);
            if (!plan) {
                self._log('❌', 'Plano invalido — JSON nao parseou. Resposta: ' + (jsonText || '').substring(0, 200));
                self._msg('bot', 'Erro no plano. Tente reformular o pedido.');
                self.state = 'done';
                self.mt._aiBusy = false;
                document.getElementById('ai-send').disabled = false;
                return;
            }
            self.plan = plan;
            self._log('✅', 'Plano criado: "' + plan.title + '" — ' + plan.scenes.length + ' cenas, ' + plan.duration + 's');
            self._log('🎨', 'Paleta: ' + plan.palette.join(' '));

            // Listar cenas no chat
            for (var i = 0; i < plan.scenes.length; i++) {
                var s = plan.scenes[i];
                self._log('📌', 'Cena ' + (i + 1) + ': "' + s.name + '" [' + s.start.toFixed(1) + '-' + s.end.toFixed(1) + 's] — ' + s.technique + ' — ' + s.elements.length + ' elementos');
            }

            self._log('🧠', 'Fase 2: CRIANDO cenas uma por uma... (aguardando 10s pro rate limit)');
            self.currentScene = 0;
            setTimeout(function () { self._doCreateScene(); }, 10000);
        }
    );
};

AgentRunner.prototype._parsePlan = function (text) {
    try {
        var cleaned = text.replace(/```json\s*/g, '').replace(/```\s*/g, '').replace(/^\s+|\s+$/g, '');
        // Tenta achar JSON no texto
        var start = cleaned.indexOf('{');
        var end = cleaned.lastIndexOf('}');
        if (start === -1 || end === -1) return null;
        var json = cleaned.substring(start, end + 1);
        var plan = JSON.parse(json);
        if (!plan.scenes || !plan.scenes.length) return null;
        if (!plan.palette) plan.palette = ['#820AD1', '#39007A', '#FAFAFA', '#E81CFF'];
        if (!plan.duration) {
            var lastScene = plan.scenes[plan.scenes.length - 1];
            plan.duration = lastScene.end || 15;
        }
        return plan;
    } catch (e) {
        return null;
    }
};

// ─── PHASE 2: CREATE SCENE ──────────────────────────────────────

AgentRunner.prototype._doCreateScene = function () {
    if (this.state === 'aborted') return;
    if (this.currentScene >= this.plan.scenes.length) {
        this._doReview();
        return;
    }

    var self = this;
    var scene = this.plan.scenes[this.currentScene];
    var sceneNum = this.currentScene + 1;
    var totalScenes = this.plan.scenes.length;
    self.state = 'creating';
    self.sceneRetries = 0;

    self._log('🎬', '━━━ Cena ' + sceneNum + '/' + totalScenes + ': "' + scene.name + '" ━━━');
    self._log('⏱', 'Timing: ' + scene.start.toFixed(1) + 's → ' + scene.end.toFixed(1) + 's (' + (scene.end - scene.start).toFixed(1) + 's)');
    self._log('🎯', 'Elementos: ' + scene.elements.join(' + '));
    self._log('💡', 'Tecnica: ' + scene.technique + ' | Animacao: ' + scene.animation);
    self._log('📤', 'Pedindo codigo ao LLM (max 60 linhas)...');

    // Le estado atual da comp antes de criar
    self._readCompState(function (compState) {
        self.compState = compState;

        // Monta prompt focado pra essa cena
        var prompt = 'CENA ' + sceneNum + ' de ' + totalScenes + ': "' + scene.name + '"\n' +
            'Timing: ' + scene.start.toFixed(2) + 's ate ' + scene.end.toFixed(2) + 's\n' +
            'Background: ' + (scene.bg || self.plan.palette[0]) + '\n' +
            'Elementos: ' + scene.elements.join(', ') + '\n' +
            'Animacao: ' + scene.animation + '\n' +
            'Tecnica: ' + scene.technique + '\n' +
            'Paleta: ' + self.plan.palette.join(', ') + '\n' +
            'Font: ' + (self.plan.font || 'Arial-BoldMT') + '\n\n' +
            'COMP ATIVA: ' + (compState.comp || 'desconhecida') + '\n' +
            'LAYERS EXISTENTES: ' + (compState.layers || 'nenhuma') + '\n\n' +
            'CENAS JA CRIADAS: ' + (self.completed.length > 0 ? self.completed.map(function (c) { return c.name; }).join(', ') : 'nenhuma') + '\n\n' +
            'Gere o codigo ExtendScript pra APENAS essa cena. Use os helpers AE.* que ja estao definidos (AE.stackV, AE.fitInCard, AE.centerAnchor, AE.maxEase, etc). Max 80 linhas.';

        // Prompt COMPACTO pra cenas — so regras essenciais + exemplo (sem o system prompt gigante)
        var sysPrompt = AgentRunner.SCENE_PROMPT;
        if (self._exampleCode) {
            sysPrompt += '\n\nEXEMPLO DE REFERENCIA (copie o ESTILO e ESTRUTURA, nao o conteudo):\n```javascript\n' + self._exampleCode + '\n```\n';
        }

        self._callLLMSilent(
            [{ role: 'system', content: sysPrompt }, { role: 'user', content: prompt }],
            function (response) {
                if (self.state === 'aborted') return;
                self._handleSceneResponse(response);
            }
        );
    });
};

AgentRunner.prototype._handleSceneResponse = function (response) {
    var self = this;
    var scene = this.plan.scenes[this.currentScene];

    self.mt._aiMsgs.push({ role: 'assistant', content: response });

    var m = response.match(/```(?:javascript|jsx)?\s*\n([\s\S]*?)```/);
    if (!m) {
        self._log('❌', 'LLM nao retornou bloco de codigo. Resposta: ' + response.substring(0, 150));
        self._sceneComplete(scene, false);
        return;
    }

    var rawCode = m[1].replace(/^\s+|\s+$/g, '');
    var lineCount = rawCode.split('\n').length;
    self._log('📥', 'Codigo recebido: ' + lineCount + ' linhas. Aplicando fixES3...');
    var code = self.mt._aiFixES3(rawCode);
    self._log('⚡', 'Executando no After Effects...');

    self._execCode(code, function (result) {
        if (self.state === 'aborted') return;

        if (result && result.indexOf('ERRO') === 0) {
            self._log('💥', 'ExtendScript erro: ' + result.substring(0, 150));
            self._log('🔧', 'Entrando em modo FIX...');
            self._doFixScene(code, result);
        } else {
            self._log('✓', 'ExtendScript executou sem erro. Verificando resultado...');
            self._doVerifyScene();
        }
    });
};

// ─── PHASE 3: VERIFY SCENE ──────────────────────────────────────

AgentRunner.prototype._doVerifyScene = function () {
    if (this.state === 'aborted') return;
    var self = this;
    var scene = this.plan.scenes[this.currentScene];
    self.state = 'verifying';

    self._readCompState(function (newState) {
        var before = (self.compState && self.compState.layerCount) || 0;
        var after = newState.layerCount || 0;
        var newLayers = after - before;

        self._log('🔍', 'Layers antes: ' + before + ' → depois: ' + after + ' (+ ' + newLayers + ' novas)');
        if (newState.layers) self._log('📋', 'Layers atuais: ' + newState.layers);

        if (newLayers > 0) {
            self._log('✅', 'Cena ' + (self.currentScene + 1) + ' VERIFICADA — ' + newLayers + ' layers criadas com sucesso');
            self.compState = newState;
            self._sceneComplete(scene, true);
        } else {
            self._log('⚠', '0 layers novas — codigo pode ter falhado silenciosamente');
            self._doFixScene('', 'Nenhuma layer foi criada. Verifique: comp ativa correta? addText/addShape/addSolid foram chamados?');
        }
    });
};

// ─── PHASE 3B: FIX SCENE ────────────────────────────────────────

AgentRunner.prototype._doFixScene = function (code, error) {
    if (this.state === 'aborted') return;
    var self = this;
    self.sceneRetries++;
    self.state = 'fixing';

    if (self.sceneRetries > self.maxSceneRetries) {
        self._log('❌', 'Cena ' + (self.currentScene + 1) + ' FALHOU apos ' + self.maxSceneRetries + ' tentativas. Pulando pra proxima.');
        self._sceneComplete(self.plan.scenes[self.currentScene], false);
        return;
    }

    self._log('🔧', 'FIX tentativa ' + self.sceneRetries + '/' + self.maxSceneRetries + ' — Desfazendo cena anterior...');

    self._execCode('app.executeCommand(16);', function () {
        self._log('↩', 'Undo OK');

        // PASSO 1: PESQUISAR o erro — perguntar ao LLM o que significa
        self._log('🔍', 'Pesquisando erro: "' + error.substring(0, 100) + '"');

        self._callLLMSilent(
            [{ role: 'user', content: 'ExtendScript ES3 After Effects erro:\n' + error + '\nExplique em 2 linhas a causa e a solucao. CURTO.' }],
            function (searchResult) {
                if (self.state === 'aborted') return;
                var solution = searchResult || 'sem resultado';
                self._log('💡', 'Solucao: ' + solution.substring(0, 150));

                // PASSO 2: CORRIGIR usando a solucao
                var scene = self.plan.scenes[self.currentScene];
                var fixPrompt = 'Cena "' + scene.name + '" erro:\n' + error + '\n\nPESQUISA: ' + solution.substring(0, 300) + '\n\n' +
                    'Timing: ' + scene.start.toFixed(1) + '-' + scene.end.toFixed(1) + 's. Elementos: ' + scene.elements.join(', ') + '\n' +
                    'Gere codigo CORRIGIDO. AE.* ja definidos. Max 80 linhas.';

                var sysPrompt = AgentRunner.SCENE_PROMPT;
                if (self._exampleCode) sysPrompt += '\n\nEXEMPLO:\n```javascript\n' + self._exampleCode + '\n```\n';

                self._log('📤', 'Pedindo codigo corrigido...');
                setTimeout(function () {
                    self._callLLMSilent(
                        [{ role: 'system', content: sysPrompt }, { role: 'user', content: fixPrompt }],
                        function (response) {
                            if (self.state === 'aborted') return;
                            self._handleSceneResponse(response);
                        }
                    );
                }, 5000);
            }
        );
    });
};

// ─── PHASE 4: REVIEW ────────────────────────────────────────────

AgentRunner.prototype._doReview = function () {
    if (this.state === 'aborted') return;
    var self = this;
    self.state = 'reviewing';

    self._log('🧠', 'Fase 4: REVIEW FINAL');

    var ok = 0, fail = 0;
    for (var i = 0; i < self.completed.length; i++) {
        var c = self.completed[i];
        self._log(c.success ? '✅' : '❌', (i + 1) + '. ' + c.name + ' — ' + (c.success ? 'OK' : 'FALHOU'));
        if (c.success) ok++; else fail++;
    }

    self._log('🏁', 'CONCLUIDO: ' + ok + '/' + self.plan.scenes.length + ' cenas OK' + (fail > 0 ? ', ' + fail + ' falharam' : ' — PERFEITO!'));

    self.state = 'done';
    self.mt._aiBusy = false;
    document.getElementById('ai-send').disabled = false;
};

// ─── SCENE COMPLETE ─────────────────────────────────────────────

AgentRunner.prototype._sceneComplete = function (scene, success) {
    this.completed.push({ name: scene.name, success: success });
    this.currentScene++;
    var remaining = this.plan.scenes.length - this.currentScene;

    // Delay grande entre cenas — Qwen free precisa de ~10s entre requests
    var delayMs = 10000;
    if (remaining > 0) {
        this._log('⏭', 'Avancando... ' + remaining + ' cena(s) restante(s). Aguardando ' + (delayMs/1000) + 's...');
    }

    var self = this;
    setTimeout(function () {
        self._doCreateScene();
    }, delayMs);
};

// ─── HELPERS ────────────────────────────────────────────────────

// JSX templates de base removidos — agente gera codigo do zero.
AgentRunner.prototype._loadExampleScript = function (cb) {
    this._exampleCode = '';
    cb();
};

AgentRunner.prototype._ensureHelpers = function (cb) {
    // Avalia o bloco AE.* helpers na comp ativa (so precisa 1 vez)
    var helpersCode =
        'var AE={};' +
        'AE.gc=function(p,ns){var c=p;for(var i=0;i<ns.length;i++){try{c=c.property(ns[i])}catch(e){return null}if(!c)return null}return c};' +
        'AE.pos=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Position"]):null};' +
        'AE.scl=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Scale"]):null};' +
        'AE.opa=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Opacity"]):null};' +
        'AE.rot=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Rotate Z"]):null};' +
        'AE.rX=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Rotate X"]):null};' +
        'AE.rY=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Rotate Y"]):null};' +
        'AE.anc=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Anchor Point"]):null};' +
        'AE.sv=function(p,v){if(!p)return;try{p.setValue(v)}catch(e){}};' +
        'AE.sa=function(p,t,v){if(!p)return;try{p.setValueAtTime(t,v)}catch(e){}};' +
        'AE.gv=function(p){if(!p)return null;try{return p.value}catch(e){return null}};' +
        'AE.hex=function(h){h=h.replace("#","");return[parseInt(h.substr(0,2),16)/255,parseInt(h.substr(2,2),16)/255,parseInt(h.substr(4,2),16)/255]};' +
        'AE.fx=function(l,mn){if(!l)return null;try{return l.property("ADBE Effect Parade").addProperty(mn)}catch(e){return null}};' +
        'AE.maxEase=function(p){if(!p||p.numKeys===0)return;try{var d=1,v=p.propertyValueType;if(v===PropertyValueType.TwoD||v===PropertyValueType.TwoD_SPATIAL)d=2;if(v===PropertyValueType.ThreeD||v===PropertyValueType.ThreeD_SPATIAL)d=3;for(var k=1;k<=p.numKeys;k++){var ei=[],eo=[];for(var j=0;j<d;j++){ei.push(new KeyframeEase(0,100));eo.push(new KeyframeEase(0,100))}p.setTemporalEaseAtKey(k,ei,eo)}}catch(e){}};' +
        'AE.centerAnchor=function(l){if(!l)return;try{var r=l.sourceRectAtTime(0,false);AE.sv(AE.anc(l),[r.left+r.width/2,r.top+r.height/2])}catch(e){}};' +
        'AE.leftAnchor=function(l){if(!l)return;try{var r=l.sourceRectAtTime(0,false);AE.sv(AE.anc(l),[r.left,r.top+r.height/2])}catch(e){}};' +
        'AE.stackV=function(layers,cx,cy,gap){if(!layers||layers.length===0)return;gap=gap||20;var heights=[],totalH=0;for(var i=0;i<layers.length;i++){var h=50;try{var r=layers[i].sourceRectAtTime(0,false);h=r.height||50}catch(e){}heights.push(h);totalH+=h}totalH+=gap*(layers.length-1);var y=cy-totalH/2;for(var j=0;j<layers.length;j++){AE.centerAnchor(layers[j]);AE.sv(AE.pos(layers[j]),[cx,y+heights[j]/2]);y+=heights[j]+gap}};' +
        'AE.fitInCard=function(ch,cx,cy,cw,ch2,pad,gap){if(!ch||ch.length===0)return;pad=pad||60;gap=gap||30;var iT=cy-ch2/2+pad;var iB=cy+ch2/2-pad;var iH=iB-iT;var hs=[],tH=0;for(var i=0;i<ch.length;i++){var h=50;try{var r=ch[i].sourceRectAtTime(0,false);h=r.height||50}catch(e){}hs.push(h);tH+=h}tH+=gap*(ch.length-1);var sc=tH>iH?iH/tH:1;var y=iT+(iH-tH*sc)/2;for(var j=0;j<ch.length;j++){AE.centerAnchor(ch[j]);AE.sv(AE.pos(ch[j]),[cx,y+hs[j]/2*sc]);y+=hs[j]*sc+gap*sc}};' +
        '"helpers_loaded"';

    var csInterface = new CSInterface();
    csInterface.evalScript(helpersCode, function (r) {
        cb();
    });
};

AgentRunner.prototype._readCompState = function (cb) {
    var csInterface = new CSInterface();
    csInterface.evalScript('getActiveCompInfo()', function (ci) {
        var compInfo = '';
        var layerCount = 0;
        try {
            var info = JSON.parse(ci);
            if (info && !info.error) {
                compInfo = info.name + ' ' + info.width + 'x' + info.height + ' @' + info.fps + 'fps ' + info.duration + 's';
                layerCount = info.numLayers || 0;
            }
        } catch (e) {}

        csInterface.evalScript('getLayersList()', function (ll) {
            var layerList = '';
            try {
                var layers = JSON.parse(ll);
                if (layers && layers.length > 0) {
                    var names = [];
                    for (var i = 0; i < Math.min(layers.length, 20); i++) names.push(layers[i].name);
                    layerList = names.join(', ');
                    layerCount = layers.length;
                }
            } catch (e) {}

            cb({ comp: compInfo, layers: layerList, layerCount: layerCount });
        });
    });
};

AgentRunner.prototype._execCode = function (code, cb) {
    var csInterface = new CSInterface();
    csInterface.evalScript('Folder.temp.fsName', function (tempDir) {
        var fileName = 'mt_agent_' + Date.now() + '.jsx';
        var fullPath = tempDir + '/' + fileName;

        var writeCode = '(function(){var f=new File("' +
            fullPath.replace(/\\/g, '/').replace(/"/g, '\\"') +
            '");f.open("w");f.encoding="UTF-8";f.write(' +
            'decodeURI("' + encodeURIComponent(code) + '")' +
            ');f.close();return f.exists?"ok":"fail";})()';

        csInterface.evalScript(writeCode, function (wr) {
            if (wr !== 'ok') {
                cb('ERRO: Falha ao gravar arquivo temp');
                return;
            }
            csInterface.evalScript('safeExecuteFile("' + fullPath.replace(/\\/g, '/') + '")', function (res) {
                if (res && (res.indexOf('ERRO') === 0 || res.indexOf('Error') !== -1)) {
                    cb('ERRO: ' + res);
                } else {
                    cb(res || 'OK');
                }
            });
        });
    });
};

AgentRunner.prototype._status = function (text) {
    this.mt._aiStatus(text);
};

AgentRunner.prototype._msg = function (role, text) {
    this.mt._aiAddMsg(role, text);
};

// Log detalhado do pensamento do agente
AgentRunner.prototype._log = function (emoji, text) {
    // Remove status anterior pra nao acumular
    var oldStatus = document.querySelector('.ai-msg.status:last-child');
    if (oldStatus) oldStatus.remove();

    var el = document.createElement('div');
    el.className = 'ai-msg agent-log';
    el.innerHTML = '<span class="agent-log-icon">' + emoji + '</span><span class="agent-log-text">' + this._esc(text) + '</span>';
    var chat = document.getElementById('ai-chat');
    if (chat) {
        chat.appendChild(el);
        // Auto scroll suave
        chat.scrollTop = chat.scrollHeight;
    }
};

// Escapa HTML pra seguranca
AgentRunner.prototype._esc = function (s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
};

// Chamada LLM silenciosa — sem streaming.
// Usa o provider configurado (Ollama Cloud, formato nativo).
AgentRunner.prototype._callLLMSilent = function (msgs, callback, attempt) {
    var self = this;
    attempt = attempt || 0;
    var maxRetries = 5;
    var provider = self.mt._aiGetProvider();
    if (!provider) { callback(''); return; }

    function retryOrFail(status) {
        if (attempt < maxRetries) {
            var delay = self.mt._aiRetryDelay(attempt);
            self._log('⏳', 'Rate limit (' + status + ') — retry ' + (attempt + 1) + '/' + maxRetries + ' em ' + (delay/1000).toFixed(0) + 's...');
            setTimeout(function () { self._callLLMSilent(msgs, callback, attempt + 1); }, delay);
        } else {
            self._log('❌', 'Rate limit persistente apos ' + maxRetries + ' tentativas. Pulando.');
            callback('');
        }
    }

    var reqBody = JSON.stringify({
        model: provider.model,
        messages: msgs,
        stream: false,
        options: { temperature: 0.2, num_predict: 8000, num_ctx: 131072 }
    });
    var endpoint = provider.endpoint;
    self._log('📤', 'Ollama request: model=' + provider.model + ' msgs=' + msgs.length + ' bodySize=' + (reqBody.length / 1024).toFixed(1) + 'KB');

    var headers = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + provider.key };
    fetch(endpoint, {
        method: 'POST',
        headers: headers,
        body: reqBody
    })
        .then(function (r) {
            self._log('📡', 'Ollama status: ' + r.status);
            if (!r.ok) {
                return r.text().then(function (errBody) {
                    self._log('⚠', 'Erro body: ' + errBody.substring(0, 300));
                    if (self.mt._aiIsRetryable(r.status)) { retryOrFail(r.status); }
                    else { callback(''); }
                    return null;
                });
            }
            return r.text();
        })
        .then(function (rawText) {
            if (rawText === null || rawText === undefined) return;
            self._log('📦', 'Body recebido: ' + (rawText ? rawText.length : 0) + ' chars');
            if (!rawText || rawText.length === 0) {
                self._log('⚠', 'Body completamente vazio');
                callback('');
                return;
            }
            try {
                var data = JSON.parse(rawText);
                var txt = '';
                try { txt = (data.message && data.message.content) || ''; } catch (e) {
                    self._log('⚠', 'message vazio. Keys: ' + Object.keys(data).join(',') + ' Raw: ' + rawText.substring(0, 200));
                }
                if (data.error) { self._log('❌', 'Ollama erro: ' + data.error); callback(''); return; }
                // Filtrar <think> tags do Qwen
                txt = txt.replace(/<think>[\s\S]*?<\/think>/g, '').replace(/^\s+/, '');
                if (txt) {
                    self._log('📥', 'Recebido: ' + txt.length + ' chars. Codigo: ' + (txt.indexOf('```') !== -1 ? 'SIM' : 'NAO'));
                } else {
                    self._log('⚠', 'Content vazio. Raw: ' + rawText.substring(0, 300));
                }
                callback(txt);
            } catch (parseErr) {
                self._log('❌', 'JSON parse falhou: ' + parseErr.message + ' Raw: ' + rawText.substring(0, 200));
                callback('');
            }
        })
        .catch(function (err) { self._log('❌', 'Fetch erro: ' + err.message); callback(''); });
};
