(function() {
    // ╔════════════════════════════════════════════════════════════════╗
    // ║  56 MICRO-ANIMATIONS GRID — After Effects 2019 (v16.x)        ║
    // ║  702x884 @ 30fps — 10s Loop                                    ║
    // ║  7 categorias × 8 animações cada                               ║
    // ║  BLINDADO + EXPRESSIONS para loops                             ║
    // ╚════════════════════════════════════════════════════════════════╝

    var H = {};
    H.sv = function(p, v) { if (p) try { p.setValue(v); } catch(e) {} };
    H.sa = function(p, t, v) { if (p) try { p.setValueAtTime(t, v); } catch(e) {} };
    H.gc = function(par, ns) { var c = par; for (var i = 0; i < ns.length; i++) { try { c = c.property(ns[i]); } catch(e) { return null; } if (!c) return null; } return c; };
    H.pos = function(l) { return H.gc(l, ["ADBE Transform Group", "ADBE Position"]); };
    H.scl = function(l) { return H.gc(l, ["ADBE Transform Group", "ADBE Scale"]); };
    H.opa = function(l) { return H.gc(l, ["ADBE Transform Group", "ADBE Opacity"]); };
    H.rot = function(l) { return H.gc(l, ["ADBE Transform Group", "ADBE Rotate Z"]); };
    H.expr = function(p, e) { if (p) try { p.expression = e; } catch(ex) {} };

    // ===== GRID CONSTANTS =====
    var COMP_W = 702, COMP_H = 884, FPS = 30, DUR = 10.0;
    var COLS = 8, ROWS = 7;
    var CARD_W = 76, CARD_H = 76, GAP = 8, MARGIN_X = 19, MARGIN_TOP = 45;
    var LABEL_H = 18, LABEL_GAP = 8, ROW_GAP = 15;
    var ROW_BLOCK = LABEL_H + LABEL_GAP + CARD_H + ROW_GAP; // 117

    function cellX(c) { return MARGIN_X + c * (CARD_W + GAP) + CARD_W / 2; }
    function cellY(r) { return MARGIN_TOP + r * ROW_BLOCK + LABEL_H + LABEL_GAP + CARD_H / 2; }
    function labelY(r) { return MARGIN_TOP + r * ROW_BLOCK + LABEL_H / 2; }

    var CATEGORIES = ["CIRCLE", "DOTS", "FADE CIRCLES", "BALL", "TIME", "WIFI", "ICONS"];
    var cBg = [0.11, 0.11, 0.13];
    var cCard = [0.16, 0.16, 0.18];
    var cWhite = [1, 1, 1];
    var cGray = [0.55, 0.55, 0.55];

    app.beginUndoGroup("56 Micro Animations");

    try {
        var comp = app.project.items.addComp("MicroAnimations_56", COMP_W, COMP_H, 1, DUR, FPS);

        // ═══════════════════════════════════
        //  BACKGROUND
        // ═══════════════════════════════════
        comp.layers.addSolid(cBg, "BG_Dark", COMP_W, COMP_H, 1);

        // ═══════════════════════════════════
        //  CATEGORY LABELS
        // ═══════════════════════════════════
        for (var r = 0; r < ROWS; r++) {
            var tl = comp.layers.addText(CATEGORIES[r]);
            tl.name = "Label_" + CATEGORIES[r];
            var doc = tl.property("ADBE Text Properties").property("ADBE Text Document");
            var td = doc.value;
            td.fontSize = 13;
            td.fillColor = cGray;
            try { td.font = "Helvetica-Bold"; } catch(e) { try { td.font = "Arial-BoldMT"; } catch(e2) {} }
            td.justification = ParagraphJustification.LEFT_JUSTIFY;
            td.tracking = 100;
            doc.setValue(td);
            H.sv(H.pos(tl), [MARGIN_X + 40, labelY(r) + 5]);
        }

        // ═══════════════════════════════════
        //  56 CARD BACKGROUNDS
        // ═══════════════════════════════════
        for (var r = 0; r < ROWS; r++) {
            for (var c = 0; c < COLS; c++) {
                var cb = comp.layers.addShape();
                cb.name = "CardBg_" + r + "_" + c;
                var rt = cb.property("ADBE Root Vectors Group");
                var g = rt.addProperty("ADBE Vector Group"); g.name = "BG";
                var v = g.property("ADBE Vectors Group");
                v.addProperty("ADBE Vector Shape - Rect");
                v.addProperty("ADBE Vector Graphic - Fill");
                var pS = H.gc(cb, ["ADBE Root Vectors Group", "BG", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Size"]);
                var pR = H.gc(cb, ["ADBE Root Vectors Group", "BG", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Roundness"]);
                var pF = H.gc(cb, ["ADBE Root Vectors Group", "BG", "ADBE Vectors Group", "ADBE Vector Graphic - Fill", "ADBE Vector Fill Color"]);
                H.sv(pS, [CARD_W, CARD_H]);
                H.sv(pR, 12);
                H.sv(pF, cCard);
                H.sv(H.pos(cb), [cellX(c), cellY(r)]);
            }
        }

        // ═══════════════════════════════════════════════════════════
        //  HELPER: Criar shape layer com ellipse + stroke (arco)
        // ═══════════════════════════════════════════════════════════
        function mkArc(row, col, radius, strokeW, nome) {
            var s = comp.layers.addShape();
            s.name = nome;
            var rt = s.property("ADBE Root Vectors Group");
            var g = rt.addProperty("ADBE Vector Group"); g.name = "Arc";
            var vs = g.property("ADBE Vectors Group");
            vs.addProperty("ADBE Vector Shape - Ellipse");
            vs.addProperty("ADBE Vector Graphic - Stroke");
            // Trim paths
            rt.addProperty("ADBE Vector Filter - Trim");

            var pES = H.gc(s, ["ADBE Root Vectors Group", "Arc", "ADBE Vectors Group", "ADBE Vector Shape - Ellipse", "ADBE Vector Ellipse Size"]);
            var pSC = H.gc(s, ["ADBE Root Vectors Group", "Arc", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Color"]);
            var pSW = H.gc(s, ["ADBE Root Vectors Group", "Arc", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Width"]);
            var pCap = H.gc(s, ["ADBE Root Vectors Group", "Arc", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Line Cap"]);
            var pTS = H.gc(s, ["ADBE Root Vectors Group", "ADBE Vector Filter - Trim", "ADBE Vector Trim Start"]);
            var pTE = H.gc(s, ["ADBE Root Vectors Group", "ADBE Vector Filter - Trim", "ADBE Vector Trim End"]);
            var pTO = H.gc(s, ["ADBE Root Vectors Group", "ADBE Vector Filter - Trim", "ADBE Vector Trim Offset"]);

            H.sv(pES, [radius * 2, radius * 2]);
            H.sv(pSC, cWhite);
            H.sv(pSW, strokeW);
            H.sv(pCap, 2);
            H.sv(H.pos(s), [cellX(col), cellY(row)]);

            return { layer: s, trimStart: pTS, trimEnd: pTE, trimOffset: pTO, size: pES, strokeW: pSW };
        }

        // ═══════════════════════════════════════════════════════════
        //  HELPER: Criar dot (ellipse + fill)
        // ═══════════════════════════════════════════════════════════
        function mkDot(row, col, radius, offsetX, offsetY, nome) {
            var s = comp.layers.addShape();
            s.name = nome;
            var rt = s.property("ADBE Root Vectors Group");
            var g = rt.addProperty("ADBE Vector Group"); g.name = "Dot";
            var vs = g.property("ADBE Vectors Group");
            vs.addProperty("ADBE Vector Shape - Ellipse");
            vs.addProperty("ADBE Vector Graphic - Fill");

            var pES = H.gc(s, ["ADBE Root Vectors Group", "Dot", "ADBE Vectors Group", "ADBE Vector Shape - Ellipse", "ADBE Vector Ellipse Size"]);
            var pFC = H.gc(s, ["ADBE Root Vectors Group", "Dot", "ADBE Vectors Group", "ADBE Vector Graphic - Fill", "ADBE Vector Fill Color"]);

            H.sv(pES, [radius * 2, radius * 2]);
            H.sv(pFC, cWhite);
            H.sv(H.pos(s), [cellX(col) + offsetX, cellY(row) + offsetY]);

            return { layer: s, size: pES };
        }

        // ═══════════════════════════════════════════════════════════
        //  HELPER: Criar circle outline (ellipse + stroke, sem trim)
        // ═══════════════════════════════════════════════════════════
        function mkCircleOutline(row, col, radius, strokeW, nome) {
            var s = comp.layers.addShape();
            s.name = nome;
            var rt = s.property("ADBE Root Vectors Group");
            var g = rt.addProperty("ADBE Vector Group"); g.name = "Ring";
            var vs = g.property("ADBE Vectors Group");
            vs.addProperty("ADBE Vector Shape - Ellipse");
            vs.addProperty("ADBE Vector Graphic - Stroke");

            var pES = H.gc(s, ["ADBE Root Vectors Group", "Ring", "ADBE Vectors Group", "ADBE Vector Shape - Ellipse", "ADBE Vector Ellipse Size"]);
            var pSC = H.gc(s, ["ADBE Root Vectors Group", "Ring", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Color"]);
            var pSW = H.gc(s, ["ADBE Root Vectors Group", "Ring", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Width"]);

            H.sv(pES, [radius * 2, radius * 2]);
            H.sv(pSC, cWhite);
            H.sv(pSW, strokeW);
            H.sv(H.pos(s), [cellX(col), cellY(row)]);

            return { layer: s, size: pES };
        }

        // ═══════════════════════════════════════════════════════════
        //  HELPER: Criar rect shape (para ícones)
        // ═══════════════════════════════════════════════════════════
        function mkRect(row, col, w, h, round, strokeW, offsetX, offsetY, nome) {
            var s = comp.layers.addShape();
            s.name = nome;
            var rt = s.property("ADBE Root Vectors Group");
            var g = rt.addProperty("ADBE Vector Group"); g.name = "Rect";
            var vs = g.property("ADBE Vectors Group");
            vs.addProperty("ADBE Vector Shape - Rect");
            vs.addProperty("ADBE Vector Graphic - Stroke");

            var pRS = H.gc(s, ["ADBE Root Vectors Group", "Rect", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Size"]);
            var pRR = H.gc(s, ["ADBE Root Vectors Group", "Rect", "ADBE Vectors Group", "ADBE Vector Shape - Rect", "ADBE Vector Rect Roundness"]);
            var pSC = H.gc(s, ["ADBE Root Vectors Group", "Rect", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Color"]);
            var pSW = H.gc(s, ["ADBE Root Vectors Group", "Rect", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Width"]);
            var pCap = H.gc(s, ["ADBE Root Vectors Group", "Rect", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Line Cap"]);

            H.sv(pRS, [w, h]);
            H.sv(pRR, round);
            H.sv(pSC, cWhite);
            H.sv(pSW, strokeW);
            H.sv(pCap, 2);
            H.sv(H.pos(s), [cellX(col) + offsetX, cellY(row) + offsetY]);

            return { layer: s };
        }

        // ═══════════════════════════════════════════════════════════
        //  HELPER: Path shape layer
        // ═══════════════════════════════════════════════════════════
        function mkPath(row, col, verts, inT, outT, closed, strokeW, offsetX, offsetY, nome, doFill) {
            var s = comp.layers.addShape();
            s.name = nome;
            var rt = s.property("ADBE Root Vectors Group");
            var g = rt.addProperty("ADBE Vector Group"); g.name = "Path";
            var vs = g.property("ADBE Vectors Group");
            vs.addProperty("ADBE Vector Shape - Group");
            if (doFill) {
                vs.addProperty("ADBE Vector Graphic - Fill");
            }
            vs.addProperty("ADBE Vector Graphic - Stroke");

            var pSh = H.gc(s, ["ADBE Root Vectors Group", "Path", "ADBE Vectors Group", "ADBE Vector Shape - Group", "ADBE Vector Shape"]);
            if (doFill) {
                var pFC = H.gc(s, ["ADBE Root Vectors Group", "Path", "ADBE Vectors Group", "ADBE Vector Graphic - Fill", "ADBE Vector Fill Color"]);
                H.sv(pFC, cWhite);
            }
            var pSC = H.gc(s, ["ADBE Root Vectors Group", "Path", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Color"]);
            var pSW = H.gc(s, ["ADBE Root Vectors Group", "Path", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Width"]);
            var pCap = H.gc(s, ["ADBE Root Vectors Group", "Path", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke", "ADBE Vector Stroke Line Cap"]);

            var shape = new Shape();
            shape.vertices = verts;
            if (inT) shape.inTangents = inT;
            if (outT) shape.outTangents = outT;
            shape.closed = closed || false;
            H.sv(pSh, shape);
            H.sv(pSC, cWhite);
            H.sv(pSW, strokeW);
            H.sv(pCap, 2);
            H.sv(H.pos(s), [cellX(col) + (offsetX || 0), cellY(row) + (offsetY || 0)]);

            return { layer: s };
        }

        // ╔══════════════════════════════════════════════════════════╗
        // ║  ROW 0: CIRCLE — 8 Spinning Arc Animations               ║
        // ╚══════════════════════════════════════════════════════════╝

        // C1: Arco simples girando (gap em cima)
        var c1 = mkArc(0, 0, 22, 3.5, "Circ1_SimpleArc");
        H.sv(c1.trimEnd, 75);
        H.expr(c1.trimOffset, "time * 360");

        // C2: Arco girando oposto (mais lento)
        var c2 = mkArc(0, 1, 22, 3, "Circ2_SlowArc");
        H.sv(c2.trimEnd, 70);
        H.expr(c2.trimOffset, "time * -300");

        // C3: Arco que cresce e encolhe girando
        var c3 = mkArc(0, 2, 20, 3, "Circ3_GrowArc");
        H.expr(c3.trimStart, "50 + Math.sin(time * Math.PI * 2) * 40");
        H.expr(c3.trimEnd, "90 + Math.sin(time * Math.PI * 2 + 1) * 10");
        H.expr(c3.trimOffset, "time * 270");

        // C4: Arco grosso girando
        var c4 = mkArc(0, 3, 20, 6, "Circ4_ThickArc");
        H.sv(c4.trimEnd, 65);
        H.expr(c4.trimOffset, "time * 400");

        // C5: Arco que estica CW
        var c5 = mkArc(0, 4, 22, 3, "Circ5_StretchArc");
        H.expr(c5.trimStart, "var t=time%2; t<1 ? t*80 : (2-t)*80");
        H.expr(c5.trimEnd, "var t=time%2; t<1 ? 20+t*80 : 100-(t-1)*80");
        H.expr(c5.trimOffset, "time * 180");

        // C6: Arco fino grande
        var c6 = mkArc(0, 5, 24, 2.5, "Circ6_ThinArc");
        H.sv(c6.trimEnd, 80);
        H.expr(c6.trimOffset, "time * -330");

        // C7: Arco pontilhado girando
        var c7 = mkArc(0, 6, 20, 2, "Circ7_DashedArc");
        H.sv(c7.trimEnd, 100);
        H.expr(c7.trimOffset, "time * 240");
        var pDash = H.gc(c7.layer, ["ADBE Root Vectors Group", "Arc", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke"]);
        if (pDash) try { pDash.property("ADBE Vector Stroke Dashes").addProperty("ADBE Vector Stroke Dash 1").setValue(6); pDash.property("ADBE Vector Stroke Dashes").addProperty("ADBE Vector Stroke Gap 1").setValue(4); } catch(e) {}

        // C8: Múltiplos segmentos girando
        var c8 = mkArc(0, 7, 20, 1.5, "Circ8_SegmentArc");
        H.sv(c8.trimEnd, 100);
        H.expr(c8.trimOffset, "time * -200");
        var pD8 = H.gc(c8.layer, ["ADBE Root Vectors Group", "Arc", "ADBE Vectors Group", "ADBE Vector Graphic - Stroke"]);
        if (pD8) try { pD8.property("ADBE Vector Stroke Dashes").addProperty("ADBE Vector Stroke Dash 1").setValue(3); pD8.property("ADBE Vector Stroke Dashes").addProperty("ADBE Vector Stroke Gap 1").setValue(8); } catch(e) {}

        // ╔══════════════════════════════════════════════════════════╗
        // ║  ROW 1: DOTS — 8 Dot Loading Animations                  ║
        // ╚══════════════════════════════════════════════════════════╝

        for (var di = 0; di < 8; di++) {
            var dotCount, spacing, dotR;
            switch(di) {
                case 0: dotCount = 3; spacing = 14; dotR = 4; break;  // 3 dots wave
                case 1: dotCount = 3; spacing = 14; dotR = 4; break;  // 3 dots slide
                case 2: dotCount = 2; spacing = 12; dotR = 4; break;  // 2 dots bounce
                case 3: dotCount = 3; spacing = 14; dotR = 4; break;  // 3 dots scale
                case 4: dotCount = 3; spacing = 14; dotR = 3.5; break;// 3 dots fade
                case 5: dotCount = 2; spacing = 16; dotR = 4; break;  // 2 dots apart
                case 6: dotCount = 2; spacing = 10; dotR = 3.5; break;// 2 dots vert
                case 7: dotCount = 3; spacing = 14; dotR = 4; break;  // 3 dots trail
            }

            var totalW = (dotCount - 1) * spacing;
            for (var dj = 0; dj < dotCount; dj++) {
                var ox = -totalW / 2 + dj * spacing;
                var dot = mkDot(1, di, dotR, ox, 0, "Dot_" + di + "_" + dj);
                var pPos = H.pos(dot.layer);
                var pScl = H.scl(dot.layer);
                var pOpa = H.opa(dot.layer);
                var delay = dj * 0.2;

                switch(di) {
                    case 0: // Wave scale
                        H.expr(pScl, "var d=" + delay + "; var s=50+50*Math.abs(Math.sin((time-d)*Math.PI*2)); [s,s]");
                        break;
                    case 1: // Slide opacity
                        H.expr(pOpa, "var d=" + delay + "; var t=time%1.2; t>(d) && t<(d+0.4) ? 100 : 30");
                        break;
                    case 2: // Bounce Y
                        H.expr(pPos, "var d=" + delay + "; var b=Math.sin((time-d)*Math.PI*3)*8; value+[0,b]");
                        break;
                    case 3: // Scale pulse sequential
                        H.expr(pScl, "var d=" + delay + "; var s=80+60*Math.max(0,Math.sin((time-d)*Math.PI*2.5)); [s,s]");
                        break;
                    case 4: // Fade sequential
                        H.expr(pOpa, "var d=" + delay + "; 30+70*Math.max(0,Math.sin((time-d)*Math.PI*2))");
                        break;
                    case 5: // Move apart
                        H.expr(pPos, "var d=" + delay + "; var spread=Math.sin(time*Math.PI*1.5)*8; value+[spread*("+dj+"==0?-1:1),0]");
                        break;
                    case 6: // Vertical bounce alternating
                        H.expr(pPos, "var d=" + delay + "; var b=Math.sin((time-d)*Math.PI*2)*10; value+[0,b]");
                        break;
                    case 7: // Slide right with trail
                        H.expr(pPos, "var d=" + delay + "; var slide=Math.sin((time-d)*Math.PI)*12; value+[slide,0]");
                        H.expr(pOpa, "var d=" + delay + "; 40+60*Math.abs(Math.cos((time-d)*Math.PI*2))");
                        break;
                }
            }
        }

        // ╔══════════════════════════════════════════════════════════╗
        // ║  ROW 2: FADE CIRCLES — 8 Pulsing Circle Animations       ║
        // ╚══════════════════════════════════════════════════════════╝

        // FC1: Dot pequeno pulsando
        var fc1 = mkDot(2, 0, 5, 0, 0, "FC1_DotPulse");
        H.expr(H.scl(fc1.layer), "var s=60+40*Math.sin(time*Math.PI*2.5); [s,s]");
        H.expr(H.opa(fc1.layer), "50+50*Math.sin(time*Math.PI*2.5)");

        // FC2: Círculo grande pulsando
        var fc2 = mkDot(2, 1, 18, 0, 0, "FC2_BigPulse");
        H.expr(H.scl(fc2.layer), "var s=40+80*Math.abs(Math.sin(time*Math.PI*1.5)); [s,s]");
        H.expr(H.opa(fc2.layer), "30+70*Math.abs(Math.sin(time*Math.PI*1.5))");

        // FC3: Outline aparecendo/desaparecendo
        var fc3 = mkCircleOutline(2, 2, 16, 2.5, "FC3_OutlinePulse");
        H.expr(H.opa(fc3.layer), "20+80*Math.abs(Math.sin(time*Math.PI*2))");
        H.expr(H.scl(fc3.layer), "var s=70+30*Math.sin(time*Math.PI*2); [s,s]");

        // FC4: Filled circle pulsando escuro→branco
        var fc4 = mkDot(2, 3, 14, 0, 0, "FC4_FilledPulse");
        H.expr(H.scl(fc4.layer), "var s=50+70*Math.abs(Math.sin(time*Math.PI*1.8)); [s,s]");
        H.expr(H.opa(fc4.layer), "20+80*Math.abs(Math.sin(time*Math.PI*1.8))");

        // FC5: Dot com glow ring expandindo
        var fc5d = mkDot(2, 4, 6, 0, 0, "FC5_CoreDot");
        var fc5r = mkCircleOutline(2, 4, 10, 2, "FC5_GlowRing");
        H.expr(H.scl(fc5r.layer), "var s=80+100*Math.abs(Math.sin(time*Math.PI*1.5)); [s,s]");
        H.expr(H.opa(fc5r.layer), "100-80*Math.abs(Math.sin(time*Math.PI*1.5))");

        // FC6: Dot crescendo para círculo médio
        var fc6 = mkDot(2, 5, 12, 0, 0, "FC6_GrowDot");
        H.expr(H.scl(fc6.layer), "var t=time%2; var s=t<1 ? 30+70*t : 100-70*(t-1); [s,s]");
        H.expr(H.opa(fc6.layer), "var t=time%2; t<1 ? 30+70*t : 100-70*(t-1)");

        // FC7: Circle outline pulsando escala
        var fc7 = mkCircleOutline(2, 6, 18, 2.5, "FC7_RingPulse");
        H.expr(H.scl(fc7.layer), "var s=60+40*Math.sin(time*Math.PI*3); [s,s]");

        // FC8: Target/concentric
        var fc8a = mkCircleOutline(2, 7, 18, 2, "FC8_OuterRing");
        var fc8b = mkCircleOutline(2, 7, 10, 2, "FC8_InnerRing");
        var fc8c = mkDot(2, 7, 3, 0, 0, "FC8_CenterDot");
        H.expr(H.scl(fc8a.layer), "var s=70+30*Math.sin(time*Math.PI*2); [s,s]");
        H.expr(H.scl(fc8b.layer), "var s=70+30*Math.sin(time*Math.PI*2+1); [s,s]");
        H.expr(H.opa(fc8a.layer), "50+50*Math.sin(time*Math.PI*2)");

        // ╔══════════════════════════════════════════════════════════╗
        // ║  ROW 3: BALL — 8 Bouncing Ball Animations                 ║
        // ╚══════════════════════════════════════════════════════════╝

        // B1: Ball bounce vertical
        var b1 = mkDot(3, 0, 4, 0, 0, "Ball1_Bounce");
        H.expr(H.pos(b1.layer), "var cy=" + cellY(3) + "; var bx=" + cellX(0) + "; var b=Math.abs(Math.sin(time*Math.PI*2.5))*18; [bx, cy-b]");

        // B2: Ball bounce com deslocamento
        var b2 = mkDot(3, 1, 4, 0, 0, "Ball2_ShiftBounce");
        H.expr(H.pos(b2.layer), "var cy=" + cellY(3) + "; var bx=" + cellX(1) + "; var b=Math.abs(Math.sin(time*Math.PI*2))*16; var sx=Math.sin(time*Math.PI)*6; [bx+sx, cy-b+8]");

        // B3: Ball horizontal
        var b3 = mkDot(3, 2, 4, 0, 0, "Ball3_Horiz");
        H.expr(H.pos(b3.layer), "var cy=" + cellY(3) + "; var bx=" + cellX(2) + "; var sx=Math.sin(time*Math.PI*2)*16; [bx+sx, cy]");

        // B4: Ball drop (gravity sim)
        var b4 = mkDot(3, 3, 4, 0, 0, "Ball4_Drop");
        H.expr(H.pos(b4.layer), "var cy=" + cellY(3) + "; var bx=" + cellX(3) + "; var t=time%1.5; var g=t*t*80; var y=Math.min(g,20); [bx, cy-10+y]");

        // B5: Ball → Square morph (escala squash)
        var b5 = mkDot(3, 4, 5, 0, 0, "Ball5_Morph");
        H.expr(H.pos(b5.layer), "var cy=" + cellY(3) + "; var bx=" + cellX(4) + "; var b=Math.abs(Math.sin(time*Math.PI*2))*15; [bx, cy+10-b]");
        H.expr(H.scl(b5.layer), "var t=time*2.5; var sq=Math.abs(Math.sin(t*Math.PI)); var sx=80+40*sq; var sy=120-40*sq; [sx,sy]");

        // B6: Ball com eclipse (meia lua)
        var b6 = mkDot(3, 5, 12, 0, 0, "Ball6_Eclipse");
        var b6s = mkDot(3, 5, 11, 0, 0, "Ball6_Shadow");
        var pFC6 = H.gc(b6s.layer, ["ADBE Root Vectors Group", "Dot", "ADBE Vectors Group", "ADBE Vector Graphic - Fill", "ADBE Vector Fill Color"]);
        H.sv(pFC6, cCard);
        H.expr(H.pos(b6s.layer), "var cx=" + cellX(5) + "; var cy=" + cellY(3) + "; var ox=Math.sin(time*Math.PI)*12; [cx+ox, cy]");

        // B7: Ball + satellite
        var b7 = mkDot(3, 6, 8, 0, 0, "Ball7_Main");
        var b7s = mkDot(3, 6, 3, 0, 0, "Ball7_Sat");
        H.expr(H.pos(b7s.layer), "var cx=" + cellX(6) + "; var cy=" + cellY(3) + "; var a=time*Math.PI*3; [cx+Math.cos(a)*16, cy+Math.sin(a)*16]");

        // B8: Dois dots orbitando
        var b8a = mkDot(3, 7, 3.5, 0, 0, "Ball8_A");
        var b8b = mkDot(3, 7, 3.5, 0, 0, "Ball8_B");
        H.expr(H.pos(b8a.layer), "var cx=" + cellX(7) + "; var cy=" + cellY(3) + "; var a=time*Math.PI*2.5; [cx+Math.cos(a)*12, cy+Math.sin(a)*8]");
        H.expr(H.pos(b8b.layer), "var cx=" + cellX(7) + "; var cy=" + cellY(3) + "; var a=time*Math.PI*2.5+Math.PI; [cx+Math.cos(a)*12, cy+Math.sin(a)*8]");

        // ╔══════════════════════════════════════════════════════════╗
        // ║  ROW 4: TIME — 8 Clock/Time Animations                    ║
        // ╚══════════════════════════════════════════════════════════╝

        // T1: Relógio com ponteiro minuto
        mkCircleOutline(4, 0, 20, 2, "Time1_Face");
        var t1h = mkPath(4, 0, [[0, 2], [0, -12]], null, null, false, 2.5, 0, 0, "Time1_Hand");
        H.expr(H.rot(t1h.layer), "time * 180");

        // T2: Relógio com ponteiro hora
        mkCircleOutline(4, 1, 20, 2, "Time2_Face");
        var t2h = mkPath(4, 1, [[0, 2], [0, -10]], null, null, false, 2.5, 0, 0, "Time2_Hand");
        H.expr(H.rot(t2h.layer), "time * 60");
        var t2m = mkPath(4, 1, [[0, 2], [0, -15]], null, null, false, 1.5, 0, 0, "Time2_Min");
        H.expr(H.rot(t2m.layer), "time * 360");

        // T3: Relógio pequeno
        mkCircleOutline(4, 2, 16, 2, "Time3_Face");
        var t3h = mkPath(4, 2, [[0, 1], [0, -10]], null, null, false, 2, 0, 0, "Time3_Hand");
        H.expr(H.rot(t3h.layer), "time * 120");

        // T4: Pêndulo
        var t4b = mkPath(4, 3, [[0, -22], [0, 10]], null, null, false, 1.5, 0, 0, "Time4_Stick");
        H.expr(H.rot(t4b.layer), "30*Math.sin(time*Math.PI*2)");
        var t4d = mkDot(4, 3, 4, 0, 10, "Time4_Bob");
        H.expr(H.pos(t4d.layer), "var cx=" + cellX(3) + "; var cy=" + cellY(4) + "; var a=30*Math.sin(time*Math.PI*2)*Math.PI/180; [cx+Math.sin(a)*32, cy-22+Math.cos(a)*32]");

        // T5: Cuco (casinha)
        mkRect(4, 4, 20, 22, 2, 2, 0, 2, "Time5_House");
        mkPath(4, 4, [[-14, -7], [0, -18], [14, -7]], null, null, false, 2, 0, 2, "Time5_Roof");
        var t5d = mkDot(4, 4, 2, 0, 5, "Time5_Dot");
        H.expr(H.scl(t5d.layer), "var s=80+40*Math.abs(Math.sin(time*Math.PI*3)); [s,s]");

        // T6: Cuco com pêndulo
        mkRect(4, 5, 20, 22, 2, 2, 0, 2, "Time6_House");
        mkPath(4, 5, [[-14, -7], [0, -18], [14, -7]], null, null, false, 2, 0, 2, "Time6_Roof");
        var t6p = mkPath(4, 5, [[0, 13], [0, 24]], null, null, false, 1.5, 0, 2, "Time6_Pend");
        H.expr(H.rot(t6p.layer), "15*Math.sin(time*Math.PI*3)");

        // T7: Dia/Noite (círculo metade)
        mkCircleOutline(4, 6, 18, 2.5, "Time7_Circle");
        var t7h = mkDot(4, 6, 17, 0, 0, "Time7_Half");
        // Mascara com rotação para simular dia/noite
        H.expr(H.rot(t7h.layer), "time * 90");
        H.sv(H.opa(t7h.layer), 60);

        // T8: Ampulheta
        var t8 = mkPath(4, 7, [[-10, -14], [10, -14], [0, 0], [10, 14], [-10, 14], [0, 0]], null, null, true, 2, 0, 0, "Time8_HourG");
        H.expr(H.rot(t8.layer), "var t=time%3; t<1.5 ? 0 : 180");

        // ╔══════════════════════════════════════════════════════════╗
        // ║  ROW 5: WIFI — 8 Signal Animations                        ║
        // ╚══════════════════════════════════════════════════════════╝

        // WiFi arcs helper
        function mkWifiArc(row, col, radius, delay, nome) {
            var a = mkArc(row, col, radius, 2.5, nome);
            H.sv(a.trimStart, 12.5);
            H.sv(a.trimEnd, 37.5);
            H.sv(a.trimOffset, -90);
            H.expr(H.opa(a.layer), "var d=" + delay + "; var t=(time-d)%1.5; t>0&&t<0.8 ? 100 : 20");
            return a;
        }

        // W1: Wifi crescendo 1-2-3
        mkDot(5, 0, 3, 0, 8, "Wifi1_Dot");
        mkWifiArc(5, 0, 12, 0.0, "Wifi1_Arc1");
        mkWifiArc(5, 0, 20, 0.2, "Wifi1_Arc2");
        mkWifiArc(5, 0, 28, 0.4, "Wifi1_Arc3");

        // W2: Wifi pulsando
        mkDot(5, 1, 3, 0, 8, "Wifi2_Dot");
        var w2a = mkWifiArc(5, 1, 12, 0.0, "Wifi2_Arc1");
        var w2b = mkWifiArc(5, 1, 20, 0.15, "Wifi2_Arc2");
        var w2c = mkWifiArc(5, 1, 28, 0.3, "Wifi2_Arc3");

        // W3: Wifi completo com pulse
        mkDot(5, 2, 3, 0, 8, "Wifi3_Dot");
        for (var wi = 0; wi < 3; wi++) {
            var wa = mkArc(5, 2, 12 + wi * 8, 2.5, "Wifi3_Arc" + wi);
            H.sv(wa.trimStart, 12.5); H.sv(wa.trimEnd, 37.5); H.sv(wa.trimOffset, -90);
            H.expr(H.opa(wa.layer), "50+50*Math.sin(time*Math.PI*3+" + (wi * 0.5) + ")");
        }

        // W4: Dots verticais (loading)
        for (var vdi = 0; vdi < 5; vdi++) {
            var vd = mkDot(5, 3, 2.5, 0, -16 + vdi * 8, "Wifi4_VDot" + vdi);
            H.expr(H.opa(vd.layer), "var d=" + (vdi * 0.15) + "; 20+80*Math.max(0,Math.sin((time-d)*Math.PI*2.5))");
        }

        // W5: Wifi full signal
        mkDot(5, 4, 3, 0, 8, "Wifi5_Dot");
        for (var w5i = 0; w5i < 3; w5i++) {
            var w5a = mkArc(5, 4, 12 + w5i * 8, 2.5, "Wifi5_Arc" + w5i);
            H.sv(w5a.trimStart, 12.5); H.sv(w5a.trimEnd, 37.5); H.sv(w5a.trimOffset, -90);
            H.expr(H.scl(w5a.layer), "var s=90+10*Math.sin(time*Math.PI*4+" + (w5i * 0.7) + "); [s,s]");
        }

        // W6: Antena com parênteses
        mkPath(5, 5, [[0, 20], [0, -5]], null, null, false, 2, 0, 0, "Wifi6_Pole");
        mkDot(5, 5, 3, 0, -8, "Wifi6_Top");
        var w6l = mkArc(5, 5, 14, 2, "Wifi6_WaveL");
        H.sv(w6l.trimStart, 20); H.sv(w6l.trimEnd, 30); H.sv(w6l.trimOffset, -90);
        H.expr(H.opa(w6l.layer), "40+60*Math.abs(Math.sin(time*Math.PI*3))");
        var w6r = mkArc(5, 5, 14, 2, "Wifi6_WaveR");
        H.sv(w6r.trimStart, 70); H.sv(w6r.trimEnd, 80); H.sv(w6r.trimOffset, -90);
        H.expr(H.opa(w6r.layer), "40+60*Math.abs(Math.sin(time*Math.PI*3))");

        // W7: Antena com onda simples
        mkPath(5, 6, [[0, 20], [0, -5]], null, null, false, 2, 0, 0, "Wifi7_Pole");
        mkDot(5, 6, 3, 0, -8, "Wifi7_Top");
        var w7w = mkArc(5, 6, 16, 2, "Wifi7_Wave");
        H.sv(w7w.trimStart, 18); H.sv(w7w.trimEnd, 32); H.sv(w7w.trimOffset, -90);
        H.expr(H.scl(w7w.layer), "var s=80+40*Math.abs(Math.sin(time*Math.PI*2.5)); [s,s]");
        H.expr(H.opa(w7w.layer), "30+70*Math.abs(Math.sin(time*Math.PI*2.5))");

        // W8: Antena com ondas duplas
        mkPath(5, 7, [[0, 20], [0, -5]], null, null, false, 2, 0, 0, "Wifi8_Pole");
        mkDot(5, 7, 3, 0, -8, "Wifi8_Top");
        for (var w8i = 0; w8i < 2; w8i++) {
            var w8a = mkArc(5, 7, 12 + w8i * 8, 2, "Wifi8_WL" + w8i);
            H.sv(w8a.trimStart, 18); H.sv(w8a.trimEnd, 32); H.sv(w8a.trimOffset, -90);
            H.expr(H.opa(w8a.layer), "var d=" + (w8i * 0.2) + "; 30+70*Math.abs(Math.sin((time-d)*Math.PI*2.5))");
            var w8b = mkArc(5, 7, 12 + w8i * 8, 2, "Wifi8_WR" + w8i);
            H.sv(w8b.trimStart, 68); H.sv(w8b.trimEnd, 82); H.sv(w8b.trimOffset, -90);
            H.expr(H.opa(w8b.layer), "var d=" + (w8i * 0.2) + "; 30+70*Math.abs(Math.sin((time-d)*Math.PI*2.5))");
        }

        // ╔══════════════════════════════════════════════════════════╗
        // ║  ROW 6: ICONS — 8 Animated Icons                          ║
        // ╚══════════════════════════════════════════════════════════╝

        // I1: Magnifying glass (lupa)
        mkCircleOutline(6, 0, 10, 2.5, "Icon1_Lens");
        H.sv(H.pos(mkCircleOutline(6, 0, 10, 2.5, "I1_L").layer), [cellX(0) - 3, cellY(6) - 3]);
        mkPath(6, 0, [[5, 5], [14, 14]], null, null, false, 2.5, -3, -3, "Icon1_Handle");
        var i1main = comp.layers.byName("I1_L");
        if (i1main) H.expr(H.scl(i1main), "var s=95+5*Math.sin(time*Math.PI*3); [s,s]");

        // I2: Envelope (carta)
        mkRect(6, 1, 30, 22, 3, 2, 0, 2, "Icon2_Env");
        mkPath(6, 1, [[-15, -9], [0, 3], [15, -9]], null, null, false, 2, 0, 2, "Icon2_Flap");
        var i2f = comp.layers.byName("Icon2_Flap");
        if (i2f) H.expr(H.scl(i2f), "var sy=80+20*Math.abs(Math.sin(time*Math.PI*2)); [100,sy]");

        // I3: Image (foto)
        mkRect(6, 2, 28, 22, 3, 2, 0, 0, "Icon3_Frame");
        mkPath(6, 2, [[-10, 6], [-4, -2], [2, 4], [8, -4], [12, 6]], null, null, false, 1.5, 0, 0, "Icon3_Mount");
        var i3 = comp.layers.byName("Icon3_Frame");
        if (i3) H.expr(H.rot(i3), "5*Math.sin(time*Math.PI*2)");

        // I4: House (casa)
        mkRect(6, 3, 22, 18, 2, 2, 0, 6, "Icon4_Body");
        mkPath(6, 3, [[-16, -2], [0, -16], [16, -2]], null, null, false, 2, 0, 6, "Icon4_Roof");
        var i4r = comp.layers.byName("Icon4_Roof");
        if (i4r) H.expr(H.pos(i4r), "var cy=" + cellY(6) + "; var cx=" + cellX(3) + "; var b=Math.abs(Math.sin(time*Math.PI*2))*2; [cx, cy+6-b]");

        // I5: Download (seta para baixo)
        mkPath(6, 4, [[0, -14], [0, 8]], null, null, false, 2.5, 0, -2, "Icon5_Arrow");
        mkPath(6, 4, [[-8, 2], [0, 12], [8, 2]], null, null, false, 2.5, 0, -2, "Icon5_Head");
        mkPath(6, 4, [[-10, 14], [10, 14]], null, null, false, 2.5, 0, -2, "Icon5_Base");
        var i5a = comp.layers.byName("Icon5_Arrow");
        var i5h = comp.layers.byName("Icon5_Head");
        if (i5a) H.expr(H.pos(i5a), "var cx=" + cellX(4) + "; var cy=" + cellY(6) + "; var b=Math.sin(time*Math.PI*3)*4; [cx, cy-2+b]");
        if (i5h) H.expr(H.pos(i5h), "var cx=" + cellX(4) + "; var cy=" + cellY(6) + "; var b=Math.sin(time*Math.PI*3)*4; [cx, cy-2+b]");

        // I6: Dollar (moeda)
        mkCircleOutline(6, 5, 14, 2, "Icon6_Coin");
        var i6t = comp.layers.addText("$");
        i6t.name = "Icon6_Dollar";
        var i6doc = i6t.property("ADBE Text Properties").property("ADBE Text Document");
        var i6td = i6doc.value;
        i6td.fontSize = 18;
        i6td.fillColor = cWhite;
        try { i6td.font = "Helvetica-Bold"; } catch(e) {}
        i6td.justification = ParagraphJustification.CENTER_JUSTIFY;
        i6doc.setValue(i6td);
        H.sv(H.pos(i6t), [cellX(5), cellY(6) + 6]);
        H.expr(H.scl(comp.layers.byName("Icon6_Coin")), "var s=95+8*Math.sin(time*Math.PI*3); [s,s]");

        // I7: Truck (caminhão)
        mkRect(6, 6, 18, 14, 2, 2, -4, 0, "Icon7_Body");
        mkRect(6, 6, 10, 10, 2, 2, 10, 2, "Icon7_Cab");
        var i7 = comp.layers.byName("Icon7_Body");
        var i7c = comp.layers.byName("Icon7_Cab");
        if (i7) H.expr(H.pos(i7), "var cx=" + (cellX(6) - 4) + "; var cy=" + cellY(6) + "; var b=Math.sin(time*Math.PI*4)*1.5; [cx+b, cy]");
        if (i7c) H.expr(H.pos(i7c), "var cx=" + (cellX(6) + 10) + "; var cy=" + (cellY(6) + 2) + "; var b=Math.sin(time*Math.PI*4)*1.5; [cx+b, cy]");

        // I8: Book (livro)
        mkRect(6, 7, 12, 24, 2, 2, -8, 0, "Icon8_Left");
        mkRect(6, 7, 12, 24, 2, 2, 8, 0, "Icon8_Right");
        mkPath(6, 7, [[0, -12], [0, 12]], null, null, false, 1.5, 0, 0, "Icon8_Spine");
        var i8l = comp.layers.byName("Icon8_Left");
        var i8r = comp.layers.byName("Icon8_Right");
        if (i8l) H.expr(H.rot(i8l), "3*Math.sin(time*Math.PI*2)");
        if (i8r) H.expr(H.rot(i8r), "-3*Math.sin(time*Math.PI*2)");

        // ═══════════════════════════════════════════════════════════
        //  MOVER CARD BACKGROUNDS PARA O FUNDO
        // ═══════════════════════════════════════════════════════════
        for (var li = comp.numLayers; li >= 1; li--) {
            try {
                var ln = comp.layer(li).name;
                if (ln.indexOf("CardBg_") === 0 || ln === "BG_Dark") {
                    comp.layer(li).moveToEnd();
                }
            } catch(e) {}
        }

        alert("56 Micro-Animações criadas com sucesso!\n\n" +
              "Composição: MicroAnimations_56 (702x884, 30fps, 10s)\n\n" +
              "7 Categorias × 8 animações:\n" +
              "• CIRCLE — 8 spinners com arcos\n" +
              "• DOTS — 8 loading dots\n" +
              "• FADE CIRCLES — 8 círculos pulsantes\n" +
              "• BALL — 8 bolas quicando\n" +
              "• TIME — 8 relógios/pêndulos\n" +
              "• WIFI — 8 sinais de wifi\n" +
              "• ICONS — 8 ícones animados\n\n" +
              "Todas usam Expressions para loop infinito.\n" +
              "Dê Play para assistir!");

    } catch(e) {
        alert("Erro: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();
