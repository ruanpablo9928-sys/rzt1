(function() {
    // ╔═══════════════════════════════════════════════════════════════╗
    // ║  "JUST ASK" — SAHIB.AEP STYLE RECREATION                     ║
    // ║  1080x1920 @ 30fps @ 38.5s                                   ║
    // ║  Morphing transitions · Complex shapes · Motion-blur text    ║
    // ║  SAFE MARGINS · NO CORNER WATERMARK                          ║
    // ╚═══════════════════════════════════════════════════════════════╝

    // ─── AE HELPERS ───────────────────────────────────────────────
    var AE = {};
    AE.gc = function(p, ns) { var c = p; for (var i=0;i<ns.length;i++) { try { c = c.property(ns[i]); } catch(e) { return null; } if (!c) return null; } return c; };
    AE.pos = function(l) { return l ? AE.gc(l, ["ADBE Transform Group","ADBE Position"]) : null; };
    AE.scl = function(l) { return l ? AE.gc(l, ["ADBE Transform Group","ADBE Scale"]) : null; };
    AE.opa = function(l) { return l ? AE.gc(l, ["ADBE Transform Group","ADBE Opacity"]) : null; };
    AE.rot = function(l) { return l ? AE.gc(l, ["ADBE Transform Group","ADBE Rotate Z"]) : null; };
    AE.rX  = function(l) { return l ? AE.gc(l, ["ADBE Transform Group","ADBE Rotate X"]) : null; };
    AE.rY  = function(l) { return l ? AE.gc(l, ["ADBE Transform Group","ADBE Rotate Y"]) : null; };
    AE.anc = function(l) { return l ? AE.gc(l, ["ADBE Transform Group","ADBE Anchor Point"]) : null; };
    AE.sv  = function(p, v) { if (!p) return; try { p.setValue(v); } catch(e) {} };
    AE.sa  = function(p, t, v) { if (!p) return; try { p.setValueAtTime(t, v); } catch(e) {} };
    AE.gv  = function(p) { if (!p) return null; try { return p.value; } catch(e) { return null; } };
    AE.hex = function(h) { h = h.replace("#",""); return [parseInt(h.substr(0,2),16)/255, parseInt(h.substr(2,2),16)/255, parseInt(h.substr(4,2),16)/255]; };
    AE.fx  = function(l, mn) { if (!l) return null; try { return l.property("ADBE Effect Parade").addProperty(mn); } catch(e) { return null; } };

    // Temporal ease (influence-based butter curve)
    AE.ease = function(p, inf) {
        if (!p || p.numKeys === 0) return;
        inf = inf || 85;
        try {
            var d = 1, v = p.propertyValueType;
            if (v === PropertyValueType.TwoD || v === PropertyValueType.TwoD_SPATIAL) d = 2;
            if (v === PropertyValueType.ThreeD || v === PropertyValueType.ThreeD_SPATIAL) d = 3;
            for (var k = 1; k <= p.numKeys; k++) {
                var ei = [], eo = [];
                for (var j = 0; j < d; j++) { ei.push(new KeyframeEase(0, inf)); eo.push(new KeyframeEase(0, inf)); }
                p.setTemporalEaseAtKey(k, ei, eo);
            }
        } catch(e) {}
    };

    // Center anchor point at text bounding box center
    function centerAnc(layer) {
        if (!layer || !layer.sourceRectAtTime) return;
        try {
            var r = layer.sourceRectAtTime(layer.inPoint || 0, false);
            AE.sv(AE.anc(layer), [r.left + r.width/2, r.top + r.height/2]);
        } catch(e) {}
    }

    // ─── EFFECT HELPERS ───────────────────────────────────────────
    function addBlur(layer, amount) {
        if (!layer) return null;
        var b = AE.fx(layer, "ADBE Gaussian Blur 2");
        if (b) {
            AE.sv(AE.gc(b, ["ADBE Gaussian Blur 2-0001"]), amount || 0);
            AE.sv(AE.gc(b, ["ADBE Gaussian Blur 2-0002"]), 1); // both dimensions
            AE.sv(AE.gc(b, ["ADBE Gaussian Blur 2-0003"]), 0); // repeat edge pixels OFF — fixes square glows
        }
        return b;
    }
    function getBlurProp(layer) {
        if (!layer) return null;
        var ep = layer.property("ADBE Effect Parade");
        if (!ep) return null;
        for (var i = 1; i <= ep.numProperties; i++) {
            try { if (ep.property(i).matchName === "ADBE Gaussian Blur 2") return AE.gc(ep.property(i), ["ADBE Gaussian Blur 2-0001"]); } catch(e) {}
        }
        var b = addBlur(layer, 0);
        return b ? AE.gc(b, ["ADBE Gaussian Blur 2-0001"]) : null;
    }
    function addDirBlur(layer, dir, len) {
        var b = AE.fx(layer, "ADBE Motion Blur");
        if (b) {
            AE.sv(AE.gc(b, ["ADBE Motion Blur-0001"]), dir || 90);
            AE.sv(AE.gc(b, ["ADBE Motion Blur-0002"]), len || 0);
        }
        return b;
    }
    function addGlow(layer, color, intensity, radius) {
        // Soft round glow via AE Glow — uses alpha channel + big radius to avoid square edges
        var g = AE.fx(layer, "ADBE Glo2");
        if (g) {
            try { AE.sv(AE.gc(g, ["ADBE Glo2-0002"]), 0); } catch(e) {}  // Based on alpha channels (round)
            AE.sv(AE.gc(g, ["ADBE Glo2-0003"]), 0);                       // Threshold 0
            AE.sv(AE.gc(g, ["ADBE Glo2-0004"]), (radius || 40) * 2.4);    // Bigger radius for softness
            AE.sv(AE.gc(g, ["ADBE Glo2-0005"]), (intensity || 100) * 0.85);
            try { AE.sv(AE.gc(g, ["ADBE Glo2-0007"]), 1); } catch(e) {}   // Glow colors: A & B colors
            try { AE.sv(AE.gc(g, ["ADBE Glo2-0010"]), color || [1,1,1]); } catch(e) {}
            try { AE.sv(AE.gc(g, ["ADBE Glo2-0011"]), color || [1,1,1]); } catch(e) {}
        }
        return g;
    }
    function addShadow(layer, opa, dist, soft) {
        var s = AE.fx(layer, "ADBE Drop Shadow");
        if (s) {
            AE.sv(AE.gc(s, ["ADBE Drop Shadow-0002"]), opa || 25);
            AE.sv(AE.gc(s, ["ADBE Drop Shadow-0003"]), 135);
            AE.sv(AE.gc(s, ["ADBE Drop Shadow-0004"]), dist || 8);
            AE.sv(AE.gc(s, ["ADBE Drop Shadow-0005"]), soft || 20);
        }
        return s;
    }

    // ─── SHAPE BUILDERS ───────────────────────────────────────────
    function SLD(comp, color, name) {
        try { return comp.layers.addSolid(color, name || "Solid", comp.width, comp.height, 1); } catch(e) { return null; }
    }

    function RC(comp, o) {
        try {
            var s = comp.layers.addShape();
            s.name = o.n || "Rect";
            var root = s.property("ADBE Root Vectors Group");
            var grp = root.addProperty("ADBE Vector Group");
            var vec = grp.property("ADBE Vectors Group");
            var r = vec.addProperty("ADBE Vector Shape - Rect");
            r.property("ADBE Vector Rect Size").setValue(o.sz);
            r.property("ADBE Vector Rect Roundness").setValue(o.rn || 0);
            if (o.fc) {
                var f = vec.addProperty("ADBE Vector Graphic - Fill");
                f.property("ADBE Vector Fill Color").setValue(o.fc);
            }
            if (o.sc) {
                var st = vec.addProperty("ADBE Vector Graphic - Stroke");
                st.property("ADBE Vector Stroke Color").setValue(o.sc);
                st.property("ADBE Vector Stroke Width").setValue(o.sw || 4);
            }
            AE.sv(AE.pos(s), o.p);
            return s;
        } catch(e) { return null; }
    }

    function EL(comp, o) {
        try {
            var s = comp.layers.addShape();
            s.name = o.n || "Ell";
            var root = s.property("ADBE Root Vectors Group");
            var grp = root.addProperty("ADBE Vector Group");
            var vec = grp.property("ADBE Vectors Group");
            var e = vec.addProperty("ADBE Vector Shape - Ellipse");
            e.property("ADBE Vector Ellipse Size").setValue([o.r*2, o.r*2]);
            if (o.fc) {
                var f = vec.addProperty("ADBE Vector Graphic - Fill");
                f.property("ADBE Vector Fill Color").setValue(o.fc);
            }
            if (o.sc) {
                var st = vec.addProperty("ADBE Vector Graphic - Stroke");
                st.property("ADBE Vector Stroke Color").setValue(o.sc);
                st.property("ADBE Vector Stroke Width").setValue(o.sw || 4);
            }
            AE.sv(AE.pos(s), o.p);
            return s;
        } catch(e) { return null; }
    }

    // Arc (open stroke arc — uses custom path)
    function ARC(comp, o) {
        try {
            var s = comp.layers.addShape();
            s.name = o.n || "Arc";
            var root = s.property("ADBE Root Vectors Group");
            var grp = root.addProperty("ADBE Vector Group");
            var vec = grp.property("ADBE Vectors Group");
            var p = vec.addProperty("ADBE Vector Shape - Group");
            var pathProp = p.property("ADBE Vector Shape");
            var r = o.r || 50;
            var startA = (o.start || 0) * Math.PI / 180;
            var endA = (o.end || 90) * Math.PI / 180;
            var segs = 12;
            var verts = [], inT = [], outT = [];
            for (var i = 0; i <= segs; i++) {
                var a = startA + (endA - startA) * (i/segs);
                verts.push([Math.cos(a)*r, Math.sin(a)*r]);
                inT.push([0,0]);
                outT.push([0,0]);
            }
            var shape = new Shape();
            shape.vertices = verts;
            shape.inTangents = inT;
            shape.outTangents = outT;
            shape.closed = false;
            pathProp.setValue(shape);
            var st = vec.addProperty("ADBE Vector Graphic - Stroke");
            st.property("ADBE Vector Stroke Color").setValue(o.sc || [1,1,1]);
            st.property("ADBE Vector Stroke Width").setValue(o.sw || 6);
            st.property("ADBE Vector Stroke Line Cap").setValue(2); // round
            AE.sv(AE.pos(s), o.p);
            return s;
        } catch(e) { return null; }
    }

    // Text builder with safe centered anchor
    function TX(comp, text, o) {
        try {
            var l = comp.layers.addText(text);
            l.name = o.n || "Txt";
            var tp = AE.gc(l, ["ADBE Text Properties","ADBE Text Document"]);
            if (tp) {
                var d = tp.value;
                d.font = o.f || "Arial-BoldMT";
                d.fontSize = o.s || 60;
                d.fillColor = o.c || [1,1,1];
                if (o.al === "c") d.justification = ParagraphJustification.CENTER_JUSTIFY;
                else if (o.al === "l") d.justification = ParagraphJustification.LEFT_JUSTIFY;
                else if (o.al === "r") d.justification = ParagraphJustification.RIGHT_JUSTIFY;
                if (o.tr !== undefined) d.tracking = o.tr;
                if (o.ld !== undefined) d.leading = o.ld;
                tp.setValue(d);
            }
            if (o.al === "c") centerAnc(l);
            AE.sv(AE.pos(l), o.p);
            return l;
        } catch(e) { return null; }
    }

    function NULL_(comp, pos, name) {
        try {
            var n = comp.layers.addNull();
            n.name = name || "Null";
            AE.sv(AE.pos(n), pos || [540, 960]);
            return n;
        } catch(e) { return null; }
    }

    // ─── MOTION HELPERS ───────────────────────────────────────────
    // Butter morph in: blur + gentle scale + fade  (SOFT)
    function morphIn(layer, tIn, dur) {
        if (!layer) return;
        dur = dur || 1.1;
        var s = AE.scl(layer), o = AE.opa(layer);
        var bP = getBlurProp(layer);
        if (bP) {
            AE.sa(bP, tIn, 55);
            AE.sa(bP, tIn + dur*0.5, 14);
            AE.sa(bP, tIn + dur, 0);
            AE.ease(bP, 92);
        }
        AE.sa(s, tIn, [106,106]);
        AE.sa(s, tIn + dur*0.55, [98.5,98.5]);
        AE.sa(s, tIn + dur, [100,100]);
        AE.ease(s, 92);
        AE.sa(o, tIn, 0);
        AE.sa(o, tIn + dur*0.5, 100);
        AE.ease(o, 90);
    }

    // Bloom outward morph out (dissolves softly outward)
    function morphOut(layer, tOut, dur) {
        if (!layer) return;
        dur = dur || 0.95;
        var s = AE.scl(layer), o = AE.opa(layer);
        var cur = AE.gv(s) || [100,100];
        var bP = getBlurProp(layer);
        if (bP) {
            AE.sa(bP, tOut, 0);
            AE.sa(bP, tOut + dur*0.5, 16);
            AE.sa(bP, tOut + dur, 45);
            AE.ease(bP, 90);
        }
        AE.sa(s, tOut, cur);
        AE.sa(s, tOut + dur*0.55, [cur[0]*1.035, cur[1]*1.035]);
        AE.sa(s, tOut + dur, [cur[0]*1.08, cur[1]*1.08]);
        AE.ease(s, 90);
        AE.sa(o, tOut, 100);
        AE.sa(o, tOut + dur*0.4, 90);
        AE.sa(o, tOut + dur*0.75, 45);
        AE.sa(o, tOut + dur, 0);
        AE.ease(o, 92);
    }

    // Apple-style gentle in: light blur + 103→99→100 (very soft)
    function appleIn(layer, tIn, dur) {
        if (!layer) return;
        dur = dur || 0.95;
        var s = AE.scl(layer), o = AE.opa(layer);
        var bP = getBlurProp(layer);
        if (bP) {
            AE.sa(bP, tIn, 24);
            AE.sa(bP, tIn + dur*0.5, 4);
            AE.sa(bP, tIn + dur, 0);
            AE.ease(bP, 90);
        }
        AE.sa(s, tIn, [103,103]);
        AE.sa(s, tIn + dur*0.6, [99,99]);
        AE.sa(s, tIn + dur, [100,100]);
        AE.ease(s, 92);
        AE.sa(o, tIn, 0);
        AE.sa(o, tIn + dur*0.55, 100);
        AE.ease(o, 90);
    }

    // Bounce with overshoot — extra soft, no escaping containers
    function bouncePop(layer, tIn, dur) {
        if (!layer) return;
        dur = dur || 1.15;
        var s = AE.scl(layer), o = AE.opa(layer);
        AE.sa(s, tIn, [0,0]);
        AE.sa(s, tIn + dur*0.30, [108,108]);
        AE.sa(s, tIn + dur*0.50, [96.5,96.5]);
        AE.sa(s, tIn + dur*0.70, [102,102]);
        AE.sa(s, tIn + dur*0.87, [99,99]);
        AE.sa(s, tIn + dur, [100,100]);
        AE.ease(s, 88);
        AE.sa(o, tIn, 0);
        AE.sa(o, tIn + dur*0.22, 100);
        AE.ease(o, 85);
    }

    function fadeIn(layer, tIn, dur) {
        if (!layer) return;
        dur = dur || 0.7;
        var o = AE.opa(layer);
        AE.sa(o, tIn, 0);
        AE.sa(o, tIn + dur, 100);
        AE.ease(o, 88);
    }

    function fadeOut(layer, tOut, dur) {
        if (!layer) return;
        dur = dur || 0.85;
        var o = AE.opa(layer);
        AE.sa(o, tOut, 100);
        AE.sa(o, tOut + dur*0.45, 85);
        AE.sa(o, tOut + dur, 0);
        AE.ease(o, 92);
    }

    // Heavy motion-blur text reveal — horizontal blur sweeping in
    function blurInText(layer, tIn, dur) {
        if (!layer) return;
        dur = dur || 0.9;
        var s = AE.scl(layer), o = AE.opa(layer), p = AE.pos(layer);
        var cur = AE.gv(p) || [540,960];
        var bP = getBlurProp(layer);
        if (bP) {
            AE.sa(bP, tIn, 90);
            AE.sa(bP, tIn + dur*0.5, 18);
            AE.sa(bP, tIn + dur, 0);
            AE.ease(bP, 92);
        }
        AE.sa(p, tIn, [cur[0] - 90, cur[1]]);
        AE.sa(p, tIn + dur, cur);
        AE.ease(p, 90);
        AE.sa(s, tIn, [103,103]);
        AE.sa(s, tIn + dur, [100,100]);
        AE.ease(s, 88);
        AE.sa(o, tIn, 0);
        AE.sa(o, tIn + dur*0.4, 100);
        AE.ease(o, 88);
    }

    function blurOutText(layer, tOut, dur) {
        if (!layer) return;
        dur = dur || 0.75;
        var o = AE.opa(layer), p = AE.pos(layer);
        var cur = AE.gv(p) || [540,960];
        var bP = getBlurProp(layer);
        if (bP) {
            AE.sa(bP, tOut, 0);
            AE.sa(bP, tOut + dur, 75);
            AE.ease(bP, 90);
        }
        AE.sa(p, tOut, cur);
        AE.sa(p, tOut + dur, [cur[0] + 90, cur[1]]);
        AE.ease(p, 90);
        AE.sa(o, tOut, 100);
        AE.sa(o, tOut + dur*0.5, 85);
        AE.sa(o, tOut + dur*0.8, 40);
        AE.sa(o, tOut + dur, 0);
        AE.ease(o, 92);
    }

    // ─── COMPLEX SHAPE BUILDERS ───────────────────────────────────
    // ChatGPT-style flower logo (6 petal loops approximation)
    function flowerLogo(comp, pos, radius, color, name) {
        var root = NULL_(comp, pos, name || "Flower");
        // 6 petals as small rotated rounded rects
        for (var i = 0; i < 6; i++) {
            var ang = i * 60;
            var rad = ang * Math.PI / 180;
            var px = pos[0] + Math.cos(rad) * radius * 0.45;
            var py = pos[1] + Math.sin(rad) * radius * 0.45;
            var petal = RC(comp, {
                p:[px, py],
                sz:[radius*0.45, radius*1.35],
                rn:radius*0.22,
                fc:false, sc:color, sw:radius*0.12,
                n:(name||"Flower") + "_P" + i
            });
            if (petal) {
                petal.parent = root;
                AE.sv(AE.pos(petal), [Math.cos(rad)*radius*0.45, Math.sin(rad)*radius*0.45]);
                AE.sv(AE.rot(petal), ang + 30);
            }
        }
        // Center knot (subtle)
        var core = EL(comp, {p:pos, r:radius*0.18, fc:false, sc:color, sw:radius*0.12, n:(name||"Flower") + "_Core"});
        if (core) { core.parent = root; AE.sv(AE.pos(core), [0,0]); }
        return root;
    }

    // Instagram gradient logo (camera square) — NO watermark version kept for END CARD ONLY
    function igCameraLogo(comp, pos, size, name) {
        var root = NULL_(comp, pos, name || "IG");
        // Rounded square stroke
        var box = RC(comp, {p:pos, sz:[size, size], rn:size*0.25, fc:false, sc:AE.hex("#FFFFFF"), sw:size*0.075, n:(name||"IG")+"_Box"});
        if (box) { box.parent = root; AE.sv(AE.pos(box), [0,0]); }
        // Center circle stroke
        var circ = EL(comp, {p:pos, r:size*0.28, fc:false, sc:AE.hex("#FFFFFF"), sw:size*0.075, n:(name||"IG")+"_Circ"});
        if (circ) { circ.parent = root; AE.sv(AE.pos(circ), [0,0]); }
        // Top-right dot
        var dot = EL(comp, {p:[pos[0]+size*0.27, pos[1]-size*0.27], r:size*0.04, fc:AE.hex("#FFFFFF"), n:(name||"IG")+"_Dot"});
        if (dot) { dot.parent = root; AE.sv(AE.pos(dot), [size*0.27, -size*0.27]); }
        return root;
    }

    // Cursor arrow (pointer)
    function cursorArrow(comp, pos, size, color, name) {
        var s = comp.layers.addShape();
        s.name = name || "Cursor";
        var root = s.property("ADBE Root Vectors Group");
        var grp = root.addProperty("ADBE Vector Group");
        var vec = grp.property("ADBE Vectors Group");
        var p = vec.addProperty("ADBE Vector Shape - Group");
        var ph = p.property("ADBE Vector Shape");
        var sc = size / 20;
        var shape = new Shape();
        shape.vertices = [[0,0],[0,22*sc],[6*sc,17*sc],[11*sc,22*sc],[14*sc,20*sc],[9*sc,14*sc],[16*sc,14*sc]];
        shape.inTangents = [[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]];
        shape.outTangents = [[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]];
        shape.closed = true;
        ph.setValue(shape);
        var f = vec.addProperty("ADBE Vector Graphic - Fill");
        f.property("ADBE Vector Fill Color").setValue(color || [0,0,0]);
        var st = vec.addProperty("ADBE Vector Graphic - Stroke");
        st.property("ADBE Vector Stroke Color").setValue([1,1,1]);
        st.property("ADBE Vector Stroke Width").setValue(3);
        AE.sv(AE.pos(s), pos);
        return s;
    }

    // ═══════════════════════════════════════════════════════════════
    app.beginUndoGroup("SAHIB Just Ask Recreation");

    try {
        var W = 1080, H = 1920, DUR = 38.5, FPS = 30;
        var CX = W/2, CY = H/2;
        var comp = app.project.items.addComp("SAHIB_JustAsk", W, H, 1, DUR, FPS);
        comp.motionBlur = true;

        // ─── COLORS ───
        var cBlack      = AE.hex("#0A0A0A");
        var cDarkGray   = AE.hex("#1C1C1E");
        var cDark       = AE.hex("#2D2D35");
        var cWhite      = AE.hex("#FAFAFA");
        var cOffWhite   = AE.hex("#F4F4F4");
        var cTxt        = AE.hex("#222226");
        var cMuted      = AE.hex("#6B6B6B");
        var cMuted2     = AE.hex("#9B9B9B");
        var cBorder     = AE.hex("#D5D5D8");
        var cBlueAccent = AE.hex("#3B82F6");
        var cBlueSoft   = AE.hex("#BFDCFC");
        var cBlueSky    = AE.hex("#6AB4F0");
        var cBlueDeep   = AE.hex("#2A6FB5");
        var cPillBg     = AE.hex("#EDEDED");
        var cRedAccent  = AE.hex("#D94A4A");
        var cHighlight  = AE.hex("#F2F2F2");
        var cNewBadge   = AE.hex("#D5D5E0");

        var fBold = "Arial-BoldMT";
        var fReg  = "ArialMT";
        var fBlack = "Arial-BlackMT";

        // Render order: later scenes built FIRST so earlier scenes sit on top.
        // This ensures scene-1 opener composites above everything else.

        // ═══════════════════════════════════════════════════════════
        // SCENE 22 (36.5-38.5s): IG END CARD  [dark gray bg]
        // ═══════════════════════════════════════════════════════════
        var bgEnd = SLD(comp, cDarkGray, "BG_EndCard");
        bgEnd.inPoint = 36.0; bgEnd.outPoint = 38.5;
        fadeIn(bgEnd, 36.0, 0.6);

        var endIG = igCameraLogo(comp, [CX, CY - 60], 240, "End_IG");
        if (endIG) {
            endIG.inPoint = 36.5; endIG.outPoint = 38.5;
            bouncePop(endIG, 36.5, 0.9);
        }
        var endHandle = TX(comp, "@SAHIB.AEP", {p:[CX, CY + 220], s:72, c:cWhite, f:fBold, al:"c", tr:80, n:"End_Handle"});
        if (endHandle) {
            endHandle.inPoint = 36.75; endHandle.outPoint = 38.5;
            appleIn(endHandle, 36.75, 0.8);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 21 (35.0-36.5s): Cursor + Spray-can icon (transitional)
        // ═══════════════════════════════════════════════════════════
        // BG handled by persistent BASE_BG (cWhite) below

        // "Spray can / object" icon as a stylized circle with X inside
        var sprayCirc = EL(comp, {p:[CX, CY], r:70, fc:false, sc:cTxt, sw:10, n:"Spray_Circ"});
        if (sprayCirc) {
            sprayCirc.inPoint = 35.0; sprayCirc.outPoint = 37.05;
            bouncePop(sprayCirc, 35.0, 0.7);
            morphOut(sprayCirc, 36.05, 0.75);
        }
        // Abstract "X" / object shape inside
        var sprayIcon = TX(comp, "X", {p:[CX, CY + 20], s:72, c:cTxt, f:fBlack, al:"c", n:"Spray_X"});
        if (sprayIcon) {
            sprayIcon.inPoint = 35.05; sprayIcon.outPoint = 37.05;
            appleIn(sprayIcon, 35.05, 0.6);
            morphOut(sprayIcon, 36.05, 0.75);
        }
        // Cursor pointing to it
        var cur21 = cursorArrow(comp, [CX - 40, CY - 80], 36, cTxt, "Cur_S21");
        if (cur21) {
            cur21.inPoint = 35.15; cur21.outPoint = 37.05;
            fadeIn(cur21, 35.15, 0.3);
            var curP = AE.pos(cur21);
            AE.sa(curP, 35.15, [CX - 140, CY - 160]);
            AE.sa(curP, 35.8, [CX - 30, CY - 60]);
            AE.ease(curP, 85);
            fadeOut(cur21, 36.05, 0.7);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 20 (33.0-35.0s): "Just ask" + flower logo
        // ═══════════════════════════════════════════════════════════
        // BG: persistent BASE_BG

        var justAskTxt = TX(comp, "Just ask", {p:[CX - 100, CY], s:125, c:cTxt, f:fBlack, al:"c", n:"JustAsk_Txt"});
        if (justAskTxt) {
            justAskTxt.inPoint = 33.0; justAskTxt.outPoint = 35.55;
            bouncePop(justAskTxt, 33.0, 0.85);
            morphOut(justAskTxt, 34.4, 0.8);
        }
        var justAskLogo = flowerLogo(comp, [CX + 210, CY], 90, cTxt, "JA_Logo");
        if (justAskLogo) {
            justAskLogo.inPoint = 33.15; justAskLogo.outPoint = 35.55;
            appleIn(justAskLogo, 33.15, 0.8);
            var jaR = AE.rot(justAskLogo);
            AE.sa(jaR, 33.15, -30);
            AE.sa(jaR, 33.95, 0);
            AE.ease(jaR, 85);
            morphOut(justAskLogo, 34.4, 0.8);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 19 (31.0-33.0s): Clean flower logo breath
        // ═══════════════════════════════════════════════════════════
        // BG: persistent BASE_BG

        var cleanLogo = flowerLogo(comp, [CX, CY], 160, cTxt, "Clean_Logo");
        if (cleanLogo) {
            cleanLogo.inPoint = 31.0; cleanLogo.outPoint = 33.55;
            bouncePop(cleanLogo, 31.0, 0.9);
            var clS = AE.scl(cleanLogo);
            AE.sa(clS, 31.9, [100,100]);
            AE.sa(clS, 32.4, [108,108]);
            AE.sa(clS, 32.8, [104,104]);
            AE.ease(clS, 80);
            morphOut(cleanLogo, 32.55, 0.75);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 18 (28.5-31.0s): Blue planet orb on dark bg
        // ═══════════════════════════════════════════════════════════
        // Dark BG specifically for the planet scene (fades over light base)
        var bgS18 = SLD(comp, cBlack, "BG_S18_Planet");
        bgS18.inPoint = 28.1; bgS18.outPoint = 31.7;
        fadeIn(bgS18, 28.1, 0.8);
        fadeOut(bgS18, 30.85, 0.8);

        // Outer glow halo
        var planetGlow = EL(comp, {p:[CX, CY], r:340, fc:cBlueSoft, n:"Planet_Glow"});
        if (planetGlow) {
            planetGlow.inPoint = 28.5; planetGlow.outPoint = 31.55;
            AE.sv(AE.opa(planetGlow), 0);
            addBlur(planetGlow, 180);
            var pgO = AE.opa(planetGlow);
            AE.sa(pgO, 28.5, 0);
            AE.sa(pgO, 29.3, 60);
            AE.sa(pgO, 30.5, 55);
            AE.sa(pgO, 31.45, 0);
            AE.ease(pgO, 92);
            var pgS = AE.scl(planetGlow);
            AE.sa(pgS, 28.5, [70,70]);
            AE.sa(pgS, 31.45, [140,140]);
            AE.ease(pgS, 92);
        }
        // The moon-like planet (blue gradient via stacked circles)
        var planetBase = EL(comp, {p:[CX, CY], r:180, fc:cBlueDeep, n:"Planet_Base"});
        if (planetBase) {
            planetBase.inPoint = 28.5; planetBase.outPoint = 31.55;
            bouncePop(planetBase, 28.5, 0.9);
            morphOut(planetBase, 30.5, 0.8);
        }
        var planetMid = EL(comp, {p:[CX - 20, CY - 30], r:150, fc:cBlueSky, n:"Planet_Mid"});
        if (planetMid) {
            planetMid.inPoint = 28.55; planetMid.outPoint = 31.55;
            addBlur(planetMid, 12);
            appleIn(planetMid, 28.55, 0.85);
            fadeOut(planetMid, 30.5, 0.8);
        }
        var planetHi = EL(comp, {p:[CX - 50, CY - 80], r:80, fc:cBlueSoft, n:"Planet_Hi"});
        if (planetHi) {
            planetHi.inPoint = 28.6; planetHi.outPoint = 31.55;
            addBlur(planetHi, 26);
            appleIn(planetHi, 28.6, 0.9);
            fadeOut(planetHi, 30.5, 0.8);
        }
        // Tiny stars scattered
        var starPts = [[CX-380, CY-520],[CX+420, CY-400],[CX-300, CY+550],[CX+380, CY+480],[CX-460, CY-100],[CX+470, CY+120],[CX+100, CY-620],[CX-120, CY+640]];
        for (var si = 0; si < starPts.length; si++) {
            var star = EL(comp, {p:starPts[si], r:3, fc:cWhite, n:"Star_"+si});
            if (star) {
                star.inPoint = 28.7 + si*0.04;
                star.outPoint = 31.55;
                addGlow(star, cWhite, 200, 15);
                var stO = AE.opa(star);
                AE.sa(stO, 28.7 + si*0.04, 0);
                AE.sa(stO, 29.3 + si*0.04, 90);
                AE.sa(stO, 29.95 + si*0.04, 45);
                AE.sa(stO, 30.55, 90);
                AE.sa(stO, 31.45, 0);
                AE.ease(stO, 92);
            }
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 17 (26.0-28.5s): Stylized waffle result card
        // ═══════════════════════════════════════════════════════════
        // BG: persistent BASE_BG

        // Small ChatGPT avatar circle upper-left area
        var avTinyFlower = flowerLogo(comp, [CX - 340, CY - 120], 22, cTxt, "Av_Tiny");
        if (avTinyFlower) {
            avTinyFlower.inPoint = 26.0; avTinyFlower.outPoint = 29.1;
            fadeIn(avTinyFlower, 26.0, 0.65);
            fadeOut(avTinyFlower, 28.05, 0.7);
        }

        // Result image frame — large rounded square with cosmic gradient feel
        var resultFrame = RC(comp, {p:[CX, CY], sz:[620, 620], rn:50, fc:AE.hex("#2B1E3C"), n:"Result_Frame"});
        if (resultFrame) {
            resultFrame.inPoint = 26.0; resultFrame.outPoint = 29.1;
            addShadow(resultFrame, 40, 20, 60);
            bouncePop(resultFrame, 26.0, 0.95);
            morphOut(resultFrame, 28.0, 0.8);
        }
        // Cosmic bg layers inside the frame (children)
        var nebulaRed = EL(comp, {p:[CX-120, CY-90], r:260, fc:AE.hex("#C23B2E"), n:"Nebula_Red"});
        if (nebulaRed) {
            nebulaRed.inPoint = 26.05; nebulaRed.outPoint = 29.1;
            if (resultFrame) { nebulaRed.parent = resultFrame; AE.sv(AE.pos(nebulaRed), [-120, -90]); }
            addBlur(nebulaRed, 110);
            AE.sv(AE.opa(nebulaRed), 0);
            fadeIn(nebulaRed, 26.1, 0.8);
            var nrO = AE.opa(nebulaRed); AE.sa(nrO, 26.65, 80);
            fadeOut(nebulaRed, 27.95, 0.75);
        }
        var nebulaBlue = EL(comp, {p:[CX+140, CY+80], r:230, fc:AE.hex("#2D4B8C"), n:"Nebula_Blue"});
        if (nebulaBlue) {
            nebulaBlue.inPoint = 26.1; nebulaBlue.outPoint = 29.1;
            if (resultFrame) { nebulaBlue.parent = resultFrame; AE.sv(AE.pos(nebulaBlue), [140, 80]); }
            addBlur(nebulaBlue, 120);
            AE.sv(AE.opa(nebulaBlue), 0);
            fadeIn(nebulaBlue, 26.15, 0.8);
            var nbO = AE.opa(nebulaBlue); AE.sa(nbO, 26.7, 70);
            fadeOut(nebulaBlue, 27.95, 0.75);
        }
        // Abstract "waffle" — stack of rounded bars
        var waffle1 = EL(comp, {p:[CX, CY+30], r:210, fc:AE.hex("#D19A55"), n:"Waffle_Base"});
        if (waffle1) {
            waffle1.inPoint = 26.15; waffle1.outPoint = 29.1;
            if (resultFrame) { waffle1.parent = resultFrame; AE.sv(AE.pos(waffle1), [0, 30]); }
            addShadow(waffle1, 50, 8, 15);
            appleIn(waffle1, 26.15, 0.85);
            fadeOut(waffle1, 27.95, 0.75);
        }
        // Waffle grid lines (crisscross effect)
        for (var wgv = 0; wgv < 4; wgv++) {
            var wvert = RC(comp, {p:[CX + (wgv-1.5)*70, CY+30], sz:[10, 320], rn:2, fc:AE.hex("#8E5D24"), n:"Waffle_V"+wgv});
            if (wvert) {
                wvert.inPoint = 26.2; wvert.outPoint = 29.1;
                if (resultFrame) { wvert.parent = resultFrame; AE.sv(AE.pos(wvert), [(wgv-1.5)*70, 30]); }
                fadeIn(wvert, 26.2, 0.65);
                fadeOut(wvert, 27.95, 0.75);
            }
        }
        for (var wgh = 0; wgh < 4; wgh++) {
            var whoriz = RC(comp, {p:[CX, CY+30 + (wgh-1.5)*70], sz:[320, 10], rn:2, fc:AE.hex("#8E5D24"), n:"Waffle_H"+wgh});
            if (whoriz) {
                whoriz.inPoint = 26.22; whoriz.outPoint = 29.1;
                if (resultFrame) { whoriz.parent = resultFrame; AE.sv(AE.pos(whoriz), [0, (wgh-1.5)*70]); }
                fadeIn(whoriz, 26.22, 0.65);
                fadeOut(whoriz, 27.95, 0.75);
            }
        }
        // Cream dollop
        var cream = EL(comp, {p:[CX, CY-20], r:50, fc:AE.hex("#F5F1EB"), n:"Cream"});
        if (cream) {
            cream.inPoint = 26.3; cream.outPoint = 29.1;
            if (resultFrame) { cream.parent = resultFrame; AE.sv(AE.pos(cream), [0, -20]); }
            addBlur(cream, 8);
            appleIn(cream, 26.3, 0.7);
            fadeOut(cream, 27.95, 0.75);
        }
        // Chocolate chips
        var chipPts = [[-40,-30],[-10,-50],[25,-35],[50,-15],[-55,-5],[35,-55]];
        for (var ch = 0; ch < chipPts.length; ch++) {
            var chip = EL(comp, {p:[CX+chipPts[ch][0], CY+chipPts[ch][1]], r:10, fc:AE.hex("#4A2A1C"), n:"Chip_"+ch});
            if (chip) {
                chip.inPoint = 26.35 + ch*0.03; chip.outPoint = 29.1;
                if (resultFrame) { chip.parent = resultFrame; AE.sv(AE.pos(chip), chipPts[ch]); }
                fadeIn(chip, 26.35 + ch*0.03, 0.3);
                fadeOut(chip, 27.95, 0.75);
            }
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 16 (25.0-26.0s): "Creating image" pill
        // ═══════════════════════════════════════════════════════════
        // BG: persistent BASE_BG

        var createPill = RC(comp, {p:[CX, CY], sz:[480, 110], rn:55, fc:cPillBg, n:"Create_Pill"});
        if (createPill) {
            createPill.inPoint = 25.0; createPill.outPoint = 26.6;
            addShadow(createPill, 15, 5, 20);
            bouncePop(createPill, 25.0, 0.75);
            morphOut(createPill, 25.6, 0.7);
        }
        var createTxt = TX(comp, "Creating image", {p:[CX, CY + 15], s:46, c:cTxt, f:fReg, al:"c", n:"Create_Txt"});
        if (createTxt) {
            createTxt.inPoint = 25.05; createTxt.outPoint = 26.6;
            if (createPill) { createTxt.parent = createPill; AE.sv(AE.pos(createTxt), [0, 15]); }
            fadeIn(createTxt, 25.1, 0.6);
            fadeOut(createTxt, 25.6, 0.65);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 15 (24.0-25.0s): "Analyz..." red-tint pill
        // ═══════════════════════════════════════════════════════════
        // BG: persistent BASE_BG

        var analyzPill = RC(comp, {p:[CX, CY], sz:[420, 105], rn:52, fc:cPillBg, n:"Analyz_Pill"});
        if (analyzPill) {
            analyzPill.inPoint = 24.0; analyzPill.outPoint = 25.6;
            addShadow(analyzPill, 20, 6, 25);
            bouncePop(analyzPill, 24.0, 0.75);
            morphOut(analyzPill, 24.6, 0.7);
        }
        // Red glow ring on right (like the video)
        var analyzGlow = EL(comp, {p:[CX + 90, CY + 5], r:55, fc:cRedAccent, n:"Analyz_Glow"});
        if (analyzGlow) {
            analyzGlow.inPoint = 24.05; analyzGlow.outPoint = 25.6;
            if (analyzPill) { analyzGlow.parent = analyzPill; AE.sv(AE.pos(analyzGlow), [90, 5]); }
            addBlur(analyzGlow, 55);
            AE.sv(AE.opa(analyzGlow), 70);
            fadeIn(analyzGlow, 24.1, 0.6);
            fadeOut(analyzGlow, 24.6, 0.65);
        }
        var analyzTxt = TX(comp, "Analyz", {p:[CX - 30, CY + 15], s:46, c:cTxt, f:fReg, al:"c", n:"Analyz_Txt"});
        if (analyzTxt) {
            analyzTxt.inPoint = 24.05; analyzTxt.outPoint = 25.6;
            if (analyzPill) { analyzTxt.parent = analyzPill; AE.sv(AE.pos(analyzTxt), [-30, 15]); }
            fadeIn(analyzTxt, 24.1, 0.6);
            fadeOut(analyzTxt, 24.6, 0.65);
        }
        var analyzE = TX(comp, "e", {p:[CX + 62, CY + 15], s:46, c:cRedAccent, f:fReg, al:"c", n:"Analyz_E"});
        if (analyzE) {
            analyzE.inPoint = 24.1; analyzE.outPoint = 25.6;
            if (analyzPill) { analyzE.parent = analyzPill; AE.sv(AE.pos(analyzE), [62, 15]); }
            fadeIn(analyzE, 24.15, 0.6);
            fadeOut(analyzE, 24.6, 0.65);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 14 (22.5-24.0s): Waffle image thumbnail + prompt text
        // ═══════════════════════════════════════════════════════════
        // BG: persistent BASE_BG

        // Waffle thumbnail
        var wThumb = RC(comp, {p:[CX, CY - 250], sz:[360, 360], rn:28, fc:AE.hex("#E8C58C"), n:"W_Thumb"});
        if (wThumb) {
            wThumb.inPoint = 22.5; wThumb.outPoint = 24.6;
            addShadow(wThumb, 25, 10, 30);
            bouncePop(wThumb, 22.5, 0.85);
            morphOut(wThumb, 23.5, 0.75);
        }
        // Simple waffle pattern overlay on thumb
        var wCenter = EL(comp, {p:[CX, CY - 260], r:120, fc:AE.hex("#D19A55"), n:"W_Cen"});
        if (wCenter) {
            wCenter.inPoint = 22.55; wCenter.outPoint = 24.6;
            if (wThumb) { wCenter.parent = wThumb; AE.sv(AE.pos(wCenter), [0, -10]); }
            appleIn(wCenter, 22.55, 0.7);
            fadeOut(wCenter, 23.5, 0.7);
        }
        var wCream = EL(comp, {p:[CX, CY - 280], r:40, fc:AE.hex("#F5F1EB"), n:"W_Cream"});
        if (wCream) {
            wCream.inPoint = 22.6; wCream.outPoint = 24.6;
            if (wThumb) { wCream.parent = wThumb; AE.sv(AE.pos(wCream), [0, -30]); }
            addBlur(wCream, 6);
            appleIn(wCream, 22.6, 0.65);
            fadeOut(wCream, 23.5, 0.7);
        }

        // Prompt caption below thumb
        var wPrompt1 = TX(comp, "Place this object in a", {p:[CX, CY + 40], s:34, c:cMuted, f:fReg, al:"c", n:"W_Prompt1"});
        if (wPrompt1) {
            wPrompt1.inPoint = 22.6; wPrompt1.outPoint = 24.6;
            fadeIn(wPrompt1, 22.6, 0.6);
            fadeOut(wPrompt1, 23.5, 0.7);
        }
        var wPrompt2 = TX(comp, "Stranger Things-inspired sci-fi environment", {p:[CX, CY + 90], s:32, c:cMuted, f:fReg, al:"c", n:"W_Prompt2"});
        if (wPrompt2) {
            wPrompt2.inPoint = 22.65; wPrompt2.outPoint = 24.6;
            fadeIn(wPrompt2, 22.65, 0.6);
            fadeOut(wPrompt2, 23.5, 0.7);
        }

        // Input bar at bottom area
        var wInputBar = RC(comp, {p:[CX, CY + 310], sz:[820, 120], rn:60, fc:false, sc:cBorder, sw:4, n:"W_InputBar"});
        if (wInputBar) {
            wInputBar.inPoint = 22.4; wInputBar.outPoint = 24.6;
            bouncePop(wInputBar, 22.4, 0.7);
            morphOut(wInputBar, 23.5, 0.75);
        }
        var wInputTxt = TX(comp, "Ask anything", {p:[CX - 270, CY + 325], s:36, c:cMuted2, f:fReg, al:"l", n:"W_InputTxt"});
        if (wInputTxt) {
            wInputTxt.inPoint = 22.5; wInputTxt.outPoint = 24.6;
            if (wInputBar) { wInputTxt.parent = wInputBar; AE.sv(AE.pos(wInputTxt), [-270, 15]); }
            fadeIn(wInputTxt, 22.55, 0.3);
            fadeOut(wInputTxt, 23.5, 0.7);
        }
        var wSend = EL(comp, {p:[CX + 340, CY + 310], r:34, fc:cTxt, n:"W_Send"});
        if (wSend) {
            wSend.inPoint = 22.5; wSend.outPoint = 24.6;
            if (wInputBar) { wSend.parent = wInputBar; AE.sv(AE.pos(wSend), [340, 0]); }
            bouncePop(wSend, 22.55, 0.6);
            fadeOut(wSend, 23.5, 0.7);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 13 (21.0-22.5s): Typing sci-fi prompt in input
        // ═══════════════════════════════════════════════════════════
        // BG: persistent BASE_BG

        var s13Ready = TX(comp, "Ready when you are.", {p:[CX, CY - 180], s:46, c:cTxt, f:fReg, al:"c", n:"S13_Ready"});
        if (s13Ready) {
            s13Ready.inPoint = 21.0; s13Ready.outPoint = 23.1;
            fadeIn(s13Ready, 21.0, 0.65);
            fadeOut(s13Ready, 22.0, 0.75);
        }

        var s13Input = RC(comp, {p:[CX, CY], sz:[880, 130], rn:65, fc:false, sc:cBorder, sw:4, n:"S13_Input"});
        if (s13Input) {
            s13Input.inPoint = 20.9; s13Input.outPoint = 23.1;
            bouncePop(s13Input, 20.9, 0.75);
            morphOut(s13Input, 22.0, 0.75);
        }
        // Typing text (revealed progressively via slider/tracking hack — simple keyframed text document)
        var typingStages = [
            {t:21.05, txt:"Place"},
            {t:21.2, txt:"Place this"},
            {t:21.35, txt:"Place this object"},
            {t:21.5, txt:"Place this object in a"},
            {t:21.65, txt:"Place this object in a Stranger"},
            {t:21.85, txt:"Place this object in a Stranger Things"},
            {t:22.05, txt:"Place this object in a Stranger Things sci-fi environment"}
        ];
        var s13Type = TX(comp, "Place", {p:[CX - 370, CY + 18], s:36, c:cTxt, f:fReg, al:"l", n:"S13_Typing"});
        if (s13Type) {
            s13Type.inPoint = 21.05; s13Type.outPoint = 23.1;
            if (s13Input) { s13Type.parent = s13Input; AE.sv(AE.pos(s13Type), [-370, 18]); }
            var tProp = AE.gc(s13Type, ["ADBE Text Properties","ADBE Text Document"]);
            if (tProp) {
                for (var ti = 0; ti < typingStages.length; ti++) {
                    var dv = tProp.value;
                    dv.text = typingStages[ti].txt;
                    tProp.setValueAtTime(typingStages[ti].t, dv);
                }
            }
            fadeIn(s13Type, 21.05, 0.25);
            fadeOut(s13Type, 22.0, 0.7);
        }
        var s13Cur = RC(comp, {p:[CX + 380, CY + 18], sz:[4, 50], rn:1, fc:cTxt, n:"S13_Cur"});
        if (s13Cur) {
            s13Cur.inPoint = 21.05; s13Cur.outPoint = 23.1;
            if (s13Input) { s13Cur.parent = s13Input; AE.sv(AE.pos(s13Cur), [380, 18]); }
            // Blink
            var scO = AE.opa(s13Cur);
            for (var bk = 0; bk < 5; bk++) {
                AE.sa(scO, 21.1 + bk*0.3, 100);
                AE.sa(scO, 21.25 + bk*0.3, 0);
            }
            AE.sa(scO, 22.0, 0);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 12 (18.5-21.0s): "Ready when you are" + options menu
        // ═══════════════════════════════════════════════════════════
        // BG: persistent BASE_BG

        var s12Ready = TX(comp, "Ready when you are.", {p:[CX, CY - 180], s:46, c:cTxt, f:fReg, al:"c", n:"S12_Ready"});
        if (s12Ready) {
            s12Ready.inPoint = 18.5; s12Ready.outPoint = 21.6;
            appleIn(s12Ready, 18.5, 0.6);
            fadeOut(s12Ready, 20.5, 0.75);
        }

        // Options popup card (positioned above the input)
        var optsCard = RC(comp, {p:[CX - 200, CY + 200], sz:[560, 580], rn:40, fc:cWhite, n:"Opts_Card"});
        if (optsCard) {
            optsCard.inPoint = 18.6; optsCard.outPoint = 21.6;
            addShadow(optsCard, 25, 12, 45);
            bouncePop(optsCard, 18.6, 0.85);
            morphOut(optsCard, 20.5, 0.75);
        }

        var optItems = [
            {icon:"+", label:"Add photos & files"},
            {icon:">", label:"Create image"},
            {icon:">", label:"Deep research"},
            {icon:">", label:"Shopping research"},
            {icon:">", label:"Thinking"},
            {icon:">", label:"More"}
        ];
        for (var oi = 0; oi < optItems.length; oi++) {
            var oy = -220 + oi*80;
            var oIco = EL(comp, {p:[CX - 420, CY + 200 + oy], r:18, fc:false, sc:cTxt, sw:3, n:"Opt_Ico_"+oi});
            if (oIco) {
                oIco.inPoint = 18.7 + oi*0.05; oIco.outPoint = 21.6;
                if (optsCard) { oIco.parent = optsCard; AE.sv(AE.pos(oIco), [-220, oy]); }
                appleIn(oIco, 18.7 + oi*0.05, 0.8);
                fadeOut(oIco, 20.5, 0.75);
            }
            var oLbl = TX(comp, optItems[oi].label, {p:[CX - 380, CY + 215 + oy], s:36, c:cTxt, f:fReg, al:"l", n:"Opt_Lbl_"+oi});
            if (oLbl) {
                oLbl.inPoint = 18.75 + oi*0.05; oLbl.outPoint = 21.6;
                if (optsCard) { oLbl.parent = optsCard; AE.sv(AE.pos(oLbl), [-180, oy + 15]); }
                fadeIn(oLbl, 18.78 + oi*0.05, 0.65);
                fadeOut(oLbl, 20.5, 0.75);
            }
        }

        // Cursor
        var s12Cur = cursorArrow(comp, [CX + 80, CY + 80], 34, cTxt, "S12_Cur");
        if (s12Cur) {
            s12Cur.inPoint = 18.55; s12Cur.outPoint = 21.6;
            fadeIn(s12Cur, 18.55, 0.3);
            var cp = AE.pos(s12Cur);
            AE.sa(cp, 18.55, [CX + 200, CY - 50]);
            AE.sa(cp, 19.5, [CX - 250, CY + 150]);
            AE.sa(cp, 20.3, [CX + 50, CY + 100]);
            AE.ease(cp, 85);
            fadeOut(s12Cur, 20.5, 0.7);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 11 (16.0-18.5s): "Ready when you are" intro
        // ═══════════════════════════════════════════════════════════
        // BG: persistent BASE_BG

        var s11Ready = TX(comp, "Ready when you are.", {p:[CX, CY - 60], s:50, c:cTxt, f:fReg, al:"c", n:"S11_Ready"});
        if (s11Ready) {
            s11Ready.inPoint = 16.0; s11Ready.outPoint = 19.1;
            blurInText(s11Ready, 16.0, 0.7);
            fadeOut(s11Ready, 18.0, 0.75);
        }

        // Input pill
        var s11Input = RC(comp, {p:[CX, CY + 80], sz:[880, 130], rn:65, fc:false, sc:cBorder, sw:4, n:"S11_Input"});
        if (s11Input) {
            s11Input.inPoint = 16.15; s11Input.outPoint = 19.1;
            bouncePop(s11Input, 16.15, 0.8);
            morphOut(s11Input, 18.0, 0.75);
        }
        var s11Plus = TX(comp, "+", {p:[CX - 390, CY + 105], s:50, c:cMuted, f:fReg, al:"l", n:"S11_Plus"});
        if (s11Plus) {
            s11Plus.inPoint = 16.25; s11Plus.outPoint = 19.1;
            if (s11Input) { s11Plus.parent = s11Input; AE.sv(AE.pos(s11Plus), [-390, 25]); }
            fadeIn(s11Plus, 16.3, 0.3);
            fadeOut(s11Plus, 18.0, 0.7);
        }
        var s11Ask = TX(comp, "Ask anything", {p:[CX - 320, CY + 100], s:38, c:cMuted2, f:fReg, al:"l", n:"S11_Ask"});
        if (s11Ask) {
            s11Ask.inPoint = 16.3; s11Ask.outPoint = 19.1;
            if (s11Input) { s11Ask.parent = s11Input; AE.sv(AE.pos(s11Ask), [-320, 20]); }
            fadeIn(s11Ask, 16.35, 0.3);
            fadeOut(s11Ask, 18.0, 0.7);
        }
        var s11Send = EL(comp, {p:[CX + 345, CY + 80], r:38, fc:cTxt, n:"S11_Send"});
        if (s11Send) {
            s11Send.inPoint = 16.25; s11Send.outPoint = 19.1;
            if (s11Input) { s11Send.parent = s11Input; AE.sv(AE.pos(s11Send), [345, 0]); }
            bouncePop(s11Send, 16.3, 0.65);
            fadeOut(s11Send, 18.0, 0.7);
        }

        // Cursor hovering
        var s11Cur = cursorArrow(comp, [CX + 80, CY + 80], 34, cTxt, "S11_Cur");
        if (s11Cur) {
            s11Cur.inPoint = 16.6; s11Cur.outPoint = 19.1;
            fadeIn(s11Cur, 16.6, 0.3);
            var scp = AE.pos(s11Cur);
            AE.sa(scp, 16.6, [CX + 200, CY - 100]);
            AE.sa(scp, 17.8, [CX - 300, CY + 90]);
            AE.ease(scp, 85);
            fadeOut(s11Cur, 18.0, 0.7);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 10 (13.5-16.0s): Sidebar menu slides in
        // ═══════════════════════════════════════════════════════════
        // BG: persistent BASE_BG

        // Sidebar card
        var sideBar = RC(comp, {p:[CX - 180, CY], sz:[620, 900], rn:30, fc:cOffWhite, n:"Side_Bar"});
        if (sideBar) {
            sideBar.inPoint = 13.5; sideBar.outPoint = 16.6;
            addShadow(sideBar, 18, 15, 40);
            // Slide in from left
            var sbP = AE.pos(sideBar);
            AE.sa(sbP, 13.5, [CX - 600, CY]);
            AE.sa(sbP, 14.0, [CX - 180, CY]);
            AE.ease(sbP, 85);
            bouncePop(sideBar, 13.5, 0.9);
            morphOut(sideBar, 15.5, 0.75);
        }

        // Flower logo at top of sidebar
        var sbLogo = flowerLogo(comp, [CX - 400, CY - 380], 28, cTxt, "SB_Logo");
        if (sbLogo) {
            sbLogo.inPoint = 13.7; sbLogo.outPoint = 16.6;
            if (sideBar) { sbLogo.parent = sideBar; AE.sv(AE.pos(sbLogo), [-220, -380]); }
            fadeIn(sbLogo, 13.85, 0.65);
            fadeOut(sbLogo, 15.5, 0.7);
        }

        var sbItems = [
            {icon:"N", label:"New chat", highlight:true},
            {icon:"Q", label:"Search chats"},
            {icon:"Y", label:"Your Year With ChatGPT"},
            {icon:"I", label:"Images", badge:"NEW"},
            {icon:"A", label:"Apps"},
            {icon:"G", label:"GPTs"},
            {icon:"P", label:"Projects"}
        ];
        for (var si2 = 0; si2 < sbItems.length; si2++) {
            var syy = -220 + si2*90;
            // Highlight bar for "New chat"
            if (sbItems[si2].highlight) {
                var hl = RC(comp, {p:[CX - 180, CY + syy], sz:[560, 76], rn:18, fc:cHighlight, n:"SB_HL"});
                if (hl) {
                    hl.inPoint = 13.8; hl.outPoint = 16.6;
                    if (sideBar) { hl.parent = sideBar; AE.sv(AE.pos(hl), [0, syy]); }
                    fadeIn(hl, 13.85, 0.6);
                    fadeOut(hl, 15.5, 0.7);
                }
            }
            // Item icon (simple circle with letter)
            var sbIco = EL(comp, {p:[CX - 400, CY + syy], r:20, fc:false, sc:cTxt, sw:3, n:"SB_Ico_"+si2});
            if (sbIco) {
                sbIco.inPoint = 13.85 + si2*0.05; sbIco.outPoint = 16.6;
                if (sideBar) { sbIco.parent = sideBar; AE.sv(AE.pos(sbIco), [-220, syy]); }
                appleIn(sbIco, 13.85 + si2*0.05, 0.75);
                fadeOut(sbIco, 15.5, 0.7);
            }
            // Item label
            var sbLbl = TX(comp, sbItems[si2].label, {p:[CX - 360, CY + syy + 15], s:36, c:cTxt, f:fReg, al:"l", n:"SB_Lbl_"+si2});
            if (sbLbl) {
                sbLbl.inPoint = 13.9 + si2*0.05; sbLbl.outPoint = 16.6;
                if (sideBar) { sbLbl.parent = sideBar; AE.sv(AE.pos(sbLbl), [-180, syy + 15]); }
                fadeIn(sbLbl, 13.95 + si2*0.05, 0.6);
                fadeOut(sbLbl, 15.5, 0.7);
            }
            // NEW badge
            if (sbItems[si2].badge) {
                var bdg = RC(comp, {p:[CX - 150, CY + syy], sz:[80, 36], rn:18, fc:cNewBadge, n:"SB_Badge_"+si2});
                if (bdg) {
                    bdg.inPoint = 14.0 + si2*0.05; bdg.outPoint = 16.6;
                    if (sideBar) { bdg.parent = sideBar; AE.sv(AE.pos(bdg), [30, syy]); }
                    fadeIn(bdg, 14.05 + si2*0.05, 0.6);
                    fadeOut(bdg, 15.5, 0.7);
                }
                var bdgT = TX(comp, "NEW", {p:[CX - 150, CY + syy + 10], s:22, c:cMuted, f:fBold, al:"c", tr:40, n:"SB_BadgeT_"+si2});
                if (bdgT) {
                    bdgT.inPoint = 14.05 + si2*0.05; bdgT.outPoint = 16.6;
                    if (bdg) { bdgT.parent = bdg; AE.sv(AE.pos(bdgT), [0, 10]); }
                    fadeIn(bdgT, 14.1 + si2*0.05, 0.3);
                    fadeOut(bdgT, 15.5, 0.65);
                }
            }
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 9 (12.2-13.5s): "NOT ONLY THAT" — big bold
        // ═══════════════════════════════════════════════════════════
        // BG: persistent BASE_BG

        // Outline echoes (stroke-only text ghosts left & right)
        var notLeft = TX(comp, "NOT ONLY THAT", {p:[CX - 700, CY], s:150, c:[0.85,0.85,0.87], f:fBlack, al:"c", tr:30, n:"Not_Left"});
        if (notLeft) {
            notLeft.inPoint = 12.2; notLeft.outPoint = 14.05;
            fadeIn(notLeft, 12.25, 0.65);
            var nlP = AE.pos(notLeft);
            AE.sa(nlP, 12.2, [CX - 400, CY]);
            AE.sa(nlP, 13.0, [CX - 700, CY]);
            AE.ease(nlP, 80);
            fadeOut(notLeft, 13.05, 0.7);
        }
        var notRight = TX(comp, "NOT ONLY THAT", {p:[CX + 700, CY], s:150, c:[0.85,0.85,0.87], f:fBlack, al:"c", tr:30, n:"Not_Right"});
        if (notRight) {
            notRight.inPoint = 12.2; notRight.outPoint = 14.05;
            fadeIn(notRight, 12.25, 0.65);
            var nrP = AE.pos(notRight);
            AE.sa(nrP, 12.2, [CX + 400, CY]);
            AE.sa(nrP, 13.0, [CX + 700, CY]);
            AE.ease(nrP, 80);
            fadeOut(notRight, 13.05, 0.7);
        }
        // Main center text
        var notCenter = TX(comp, "NOT ONLY THAT", {p:[CX, CY], s:130, c:cTxt, f:fBlack, al:"c", tr:30, n:"Not_Center"});
        if (notCenter) {
            notCenter.inPoint = 12.2; notCenter.outPoint = 14.05;
            bouncePop(notCenter, 12.2, 0.8);
            morphOut(notCenter, 13.05, 0.7);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 8 (9.0-12.2s): Calories response bullet list
        // ═══════════════════════════════════════════════════════════
        // BG: persistent BASE_BG

        // User message pill (food image + text)
        var s8Msg = RC(comp, {p:[CX, CY - 520], sz:[800, 220], rn:40, fc:cOffWhite, n:"S8_Msg"});
        if (s8Msg) {
            s8Msg.inPoint = 8.95; s8Msg.outPoint = 12.75;
            bouncePop(s8Msg, 8.95, 0.8);
            morphOut(s8Msg, 11.7, 0.75);
        }
        var s8Thumb = RC(comp, {p:[CX - 280, CY - 520], sz:[160, 160], rn:22, fc:AE.hex("#8FB85A"), n:"S8_Thumb"});
        if (s8Thumb) {
            s8Thumb.inPoint = 9.0; s8Thumb.outPoint = 12.75;
            if (s8Msg) { s8Thumb.parent = s8Msg; AE.sv(AE.pos(s8Thumb), [-280, 0]); }
            appleIn(s8Thumb, 9.0, 0.7);
            fadeOut(s8Thumb, 11.7, 0.75);
        }
        var s8MsgTxt = TX(comp, "How many Calories", {p:[CX + 50, CY - 550], s:36, c:cTxt, f:fReg, al:"c", n:"S8_MsgT1"});
        if (s8MsgTxt) {
            s8MsgTxt.inPoint = 9.05; s8MsgTxt.outPoint = 12.75;
            if (s8Msg) { s8MsgTxt.parent = s8Msg; AE.sv(AE.pos(s8MsgTxt), [50, -30]); }
            fadeIn(s8MsgTxt, 9.1, 0.6);
            fadeOut(s8MsgTxt, 11.7, 0.75);
        }
        var s8MsgTxt2 = TX(comp, "are in this meal?", {p:[CX + 50, CY - 500], s:36, c:cTxt, f:fReg, al:"c", n:"S8_MsgT2"});
        if (s8MsgTxt2) {
            s8MsgTxt2.inPoint = 9.07; s8MsgTxt2.outPoint = 12.75;
            if (s8Msg) { s8MsgTxt2.parent = s8Msg; AE.sv(AE.pos(s8MsgTxt2), [50, 20]); }
            fadeIn(s8MsgTxt2, 9.12, 0.6);
            fadeOut(s8MsgTxt2, 11.7, 0.75);
        }

        // AI response header
        var s8Head = TX(comp, "Estimated calories (approx.)", {p:[CX, CY - 250], s:42, c:cTxt, f:fBold, al:"c", n:"S8_Head"});
        if (s8Head) {
            s8Head.inPoint = 9.4; s8Head.outPoint = 12.75;
            appleIn(s8Head, 9.4, 0.6);
            fadeOut(s8Head, 11.7, 0.75);
        }

        var s8Items = [
            "Grilled chicken (120-150 g): 180-220 kcal",
            "Brown rice (1 cup cooked): 210-220 kcal",
            "Lentils (1/2 cup cooked): 110-130 kcal",
            "Broccoli + bell peppers: 50-70 kcal",
            "Cooking oil / seasoning: 40-60 kcal"
        ];
        for (var li = 0; li < s8Items.length; li++) {
            var ly = -130 + li*85;
            var bullet = EL(comp, {p:[CX - 420, CY + ly], r:8, fc:cTxt, n:"S8_Bul_"+li});
            if (bullet) {
                bullet.inPoint = 9.7 + li*0.2; bullet.outPoint = 12.75;
                appleIn(bullet, 9.7 + li*0.2, 0.75);
                fadeOut(bullet, 11.7, 0.75);
            }
            var item = TX(comp, s8Items[li], {p:[CX - 400, CY + ly + 10], s:32, c:cTxt, f:fReg, al:"l", n:"S8_Item_"+li});
            if (item) {
                item.inPoint = 9.75 + li*0.2; item.outPoint = 12.75;
                blurInText(item, 9.75 + li*0.2, 0.8);
                fadeOut(item, 11.7, 0.75);
            }
        }

        // Total line
        var s8Total = TX(comp, "Total: ~600 to 700 kcal", {p:[CX, CY + 360], s:38, c:cTxt, f:fBold, al:"c", n:"S8_Total"});
        if (s8Total) {
            s8Total.inPoint = 10.9; s8Total.outPoint = 12.75;
            bouncePop(s8Total, 10.9, 0.8);
            fadeOut(s8Total, 11.7, 0.75);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 7 (6.8-9.0s): Food image drag + type "How many Calories"
        // ═══════════════════════════════════════════════════════════
        // BG: persistent BASE_BG

        // Food image (dropping in from top-left)
        var foodFrame = RC(comp, {p:[CX + 180, CY - 250], sz:[340, 340], rn:28, fc:AE.hex("#8FB85A"), n:"Food_Frame"});
        if (foodFrame) {
            foodFrame.inPoint = 6.8; foodFrame.outPoint = 9.55;
            addShadow(foodFrame, 30, 12, 35);
            var ffP = AE.pos(foodFrame);
            AE.sa(ffP, 6.8, [CX - 250, CY - 700]);
            AE.sa(ffP, 7.4, [CX + 180, CY - 250]);
            AE.ease(ffP, 85);
            var ffR = AE.rot(foodFrame);
            AE.sa(ffR, 6.8, -15);
            AE.sa(ffR, 7.4, 0);
            AE.ease(ffR, 85);
            bouncePop(foodFrame, 6.8, 0.7);
            morphOut(foodFrame, 8.5, 0.75);
        }
        // Food image details (circles representing food)
        var foodCenter = EL(comp, {p:[CX + 180, CY - 240], r:120, fc:AE.hex("#D5B86A"), n:"Food_Cen"});
        if (foodCenter) {
            foodCenter.inPoint = 6.85; foodCenter.outPoint = 9.55;
            if (foodFrame) { foodCenter.parent = foodFrame; AE.sv(AE.pos(foodCenter), [0, 10]); }
            appleIn(foodCenter, 6.85, 0.65);
            fadeOut(foodCenter, 8.5, 0.75);
        }
        var foodGreen1 = EL(comp, {p:[CX + 120, CY - 300], r:40, fc:AE.hex("#68B04F"), n:"Food_G1"});
        if (foodGreen1) {
            foodGreen1.inPoint = 6.9; foodGreen1.outPoint = 9.55;
            if (foodFrame) { foodGreen1.parent = foodFrame; AE.sv(AE.pos(foodGreen1), [-60, -50]); }
            fadeIn(foodGreen1, 6.95, 0.3);
            fadeOut(foodGreen1, 8.5, 0.75);
        }
        var foodRed1 = EL(comp, {p:[CX + 240, CY - 200], r:35, fc:AE.hex("#D54A3B"), n:"Food_R1"});
        if (foodRed1) {
            foodRed1.inPoint = 6.9; foodRed1.outPoint = 9.55;
            if (foodFrame) { foodRed1.parent = foodFrame; AE.sv(AE.pos(foodRed1), [60, 40]); }
            fadeIn(foodRed1, 6.95, 0.3);
            fadeOut(foodRed1, 8.5, 0.75);
        }
        var foodGreen2 = EL(comp, {p:[CX + 230, CY - 310], r:30, fc:AE.hex("#83C05A"), n:"Food_G2"});
        if (foodGreen2) {
            foodGreen2.inPoint = 6.92; foodGreen2.outPoint = 9.55;
            if (foodFrame) { foodGreen2.parent = foodFrame; AE.sv(AE.pos(foodGreen2), [50, -60]); }
            fadeIn(foodGreen2, 6.97, 0.3);
            fadeOut(foodGreen2, 8.5, 0.75);
        }

        // Input pill
        var s7Input = RC(comp, {p:[CX, CY + 250], sz:[900, 130], rn:65, fc:false, sc:cBorder, sw:4, n:"S7_Input"});
        if (s7Input) {
            s7Input.inPoint = 6.7; s7Input.outPoint = 9.55;
            bouncePop(s7Input, 6.7, 0.75);
            morphOut(s7Input, 8.5, 0.75);
        }
        // Typing text
        var s7Stages = [
            {t:7.45, txt:"How"},
            {t:7.6, txt:"How many"},
            {t:7.8, txt:"How many Calories"},
            {t:8.0, txt:"How many Calories are"},
            {t:8.2, txt:"How many Calories are in this"},
            {t:8.35, txt:"How many Calories are in this meal"}
        ];
        var s7Type = TX(comp, "How", {p:[CX - 360, CY + 270], s:36, c:cTxt, f:fReg, al:"l", n:"S7_Type"});
        if (s7Type) {
            s7Type.inPoint = 7.45; s7Type.outPoint = 9.55;
            if (s7Input) { s7Type.parent = s7Input; AE.sv(AE.pos(s7Type), [-360, 20]); }
            var s7tp = AE.gc(s7Type, ["ADBE Text Properties","ADBE Text Document"]);
            if (s7tp) {
                for (var tj = 0; tj < s7Stages.length; tj++) {
                    var dvv = s7tp.value; dvv.text = s7Stages[tj].txt;
                    s7tp.setValueAtTime(s7Stages[tj].t, dvv);
                }
            }
            fadeIn(s7Type, 7.45, 0.25);
            fadeOut(s7Type, 8.5, 0.7);
        }
        // Send button
        var s7Send = EL(comp, {p:[CX + 360, CY + 250], r:38, fc:cTxt, n:"S7_Send"});
        if (s7Send) {
            s7Send.inPoint = 6.75; s7Send.outPoint = 9.55;
            if (s7Input) { s7Send.parent = s7Input; AE.sv(AE.pos(s7Send), [360, 0]); }
            bouncePop(s7Send, 6.8, 0.65);
            fadeOut(s7Send, 8.5, 0.7);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 6 (5.2-6.8s): ChatGPT "Where should we begin?" homepage
        // ═══════════════════════════════════════════════════════════
        // BG: persistent BASE_BG

        // Flower logo at top
        var s6Logo = flowerLogo(comp, [CX, CY - 320], 70, cTxt, "S6_Logo");
        if (s6Logo) {
            s6Logo.inPoint = 5.2; s6Logo.outPoint = 7.35;
            bouncePop(s6Logo, 5.2, 0.85);
            morphOut(s6Logo, 6.3, 0.75);
        }
        // Heading
        var s6Head = TX(comp, "Where should we begin?", {p:[CX, CY - 130], s:54, c:cTxt, f:fReg, al:"c", n:"S6_Head"});
        if (s6Head) {
            s6Head.inPoint = 5.35; s6Head.outPoint = 7.35;
            blurInText(s6Head, 5.35, 0.7);
            fadeOut(s6Head, 6.3, 0.75);
        }
        // Search pill
        var s6Pill = RC(comp, {p:[CX, CY + 40], sz:[880, 130], rn:65, fc:false, sc:cBorder, sw:4, n:"S6_Pill"});
        if (s6Pill) {
            s6Pill.inPoint = 5.45; s6Pill.outPoint = 7.35;
            bouncePop(s6Pill, 5.45, 0.85);
            morphOut(s6Pill, 6.3, 0.75);
        }
        var s6Plus = TX(comp, "+", {p:[CX - 390, CY + 65], s:55, c:cMuted, f:fReg, al:"l", n:"S6_Plus"});
        if (s6Plus) {
            s6Plus.inPoint = 5.6; s6Plus.outPoint = 7.35;
            if (s6Pill) { s6Plus.parent = s6Pill; AE.sv(AE.pos(s6Plus), [-390, 25]); }
            fadeIn(s6Plus, 5.65, 0.3);
            fadeOut(s6Plus, 6.3, 0.7);
        }
        var s6Send = EL(comp, {p:[CX + 345, CY + 40], r:38, fc:cTxt, n:"S6_Send"});
        if (s6Send) {
            s6Send.inPoint = 5.55; s6Send.outPoint = 7.35;
            if (s6Pill) { s6Send.parent = s6Pill; AE.sv(AE.pos(s6Send), [345, 0]); }
            bouncePop(s6Send, 5.6, 0.7);
            fadeOut(s6Send, 6.3, 0.7);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 5 (4.2-5.2s): Spinning arc-flower loader (dark bg)
        // ═══════════════════════════════════════════════════════════
        // Dark intro BG handled by continuous bgIntro at bottom of script

        // Central circle
        var spinNull = NULL_(comp, [CX, CY], "Spin_Null");
        spinNull.inPoint = 4.2; spinNull.outPoint = 5.75;
        var snR = AE.rot(spinNull);
        AE.sa(snR, 4.2, 0);
        AE.sa(snR, 5.2, 420);
        AE.ease(snR, 70);

        var spinCenter = EL(comp, {p:[CX, CY], r:28, fc:false, sc:cWhite, sw:6, n:"Spin_Cen"});
        if (spinCenter) {
            spinCenter.inPoint = 4.2; spinCenter.outPoint = 5.75;
            spinCenter.parent = spinNull;
            AE.sv(AE.pos(spinCenter), [0, 0]);
            bouncePop(spinCenter, 4.2, 0.75);
            morphOut(spinCenter, 4.85, 0.65);
        }
        // 6 arcs around the center
        for (var sa2 = 0; sa2 < 6; sa2++) {
            var ang2 = sa2 * 60;
            var rad2 = ang2 * Math.PI / 180;
            var ax = CX + Math.cos(rad2) * 110;
            var ay = CY + Math.sin(rad2) * 110;
            var arc = ARC(comp, {p:[ax, ay], r:30, start:ang2-60, end:ang2+20, sc:cWhite, sw:10, n:"Spin_Arc_"+sa2});
            if (arc) {
                arc.inPoint = 4.2 + sa2*0.03; arc.outPoint = 5.75;
                arc.parent = spinNull;
                AE.sv(AE.pos(arc), [Math.cos(rad2)*110, Math.sin(rad2)*110]);
                bouncePop(arc, 4.2 + sa2*0.03, 0.8);
                addBlur(arc, 0);
                var abP = getBlurProp(arc);
                if (abP) {
                    AE.sa(abP, 4.2, 25);
                    AE.sa(abP, 4.5, 3);
                    AE.sa(abP, 4.85, 0);
                    AE.sa(abP, 5.25, 35);
                    AE.ease(abP, 82);
                }
                fadeOut(arc, 4.85, 0.65);
            }
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 4 (3.2-4.2s): "Just Ask" completion + tiny loader
        // ═══════════════════════════════════════════════════════════
        // Dark intro BG: continuous bgIntro

        var s4JustAsk = TX(comp, "Just Ask", {p:[CX, CY], s:140, c:cWhite, f:fBold, al:"c", n:"S4_JA"});
        if (s4JustAsk) {
            s4JustAsk.inPoint = 3.2; s4JustAsk.outPoint = 4.75;
            addGlow(s4JustAsk, cWhite, 90, 50);
            blurInText(s4JustAsk, 3.2, 0.65);
            fadeOut(s4JustAsk, 3.95, 0.6);
        }
        // Small inline loader mark
        var s4Dot = EL(comp, {p:[CX + 320, CY - 20], r:15, fc:false, sc:cWhite, sw:5, n:"S4_Dot"});
        if (s4Dot) {
            s4Dot.inPoint = 3.45; s4Dot.outPoint = 4.75;
            bouncePop(s4Dot, 3.45, 0.8);
            addGlow(s4Dot, cWhite, 85, 30);
            fadeOut(s4Dot, 3.95, 0.6);
        }
        var s4Arc = ARC(comp, {p:[CX + 280, CY + 10], r:35, start:30, end:320, sc:cWhite, sw:8, n:"S4_Arc"});
        if (s4Arc) {
            s4Arc.inPoint = 3.55; s4Arc.outPoint = 4.75;
            bouncePop(s4Arc, 3.55, 0.6);
            var s4ar = AE.rot(s4Arc);
            AE.sa(s4ar, 3.55, 0);
            AE.sa(s4ar, 4.2, 360);
            AE.ease(s4ar, 75);
            addGlow(s4Arc, cWhite, 85, 25);
            fadeOut(s4Arc, 3.95, 0.6);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 3 (2.3-3.2s): "Just A" with glow
        // ═══════════════════════════════════════════════════════════
        // Dark intro BG: continuous bgIntro

        // Soft radial glow behind
        var s3Glow = EL(comp, {p:[CX, CY], r:400, fc:cWhite, n:"S3_Glow"});
        if (s3Glow) {
            s3Glow.inPoint = 2.3; s3Glow.outPoint = 3.75;
            AE.sv(AE.opa(s3Glow), 0);
            addBlur(s3Glow, 280);
            var s3gO = AE.opa(s3Glow);
            AE.sa(s3gO, 2.3, 0);
            AE.sa(s3gO, 2.75, 22);
            AE.sa(s3gO, 3.1, 14);
            AE.sa(s3gO, 3.7, 0);
            AE.ease(s3gO, 92);
        }
        var s3Txt = TX(comp, "Just A", {p:[CX, CY], s:140, c:cWhite, f:fBold, al:"c", n:"S3_Txt"});
        if (s3Txt) {
            s3Txt.inPoint = 2.3; s3Txt.outPoint = 3.75;
            addGlow(s3Txt, cWhite, 100, 55);
            blurInText(s3Txt, 2.3, 0.8);
            blurOutText(s3Txt, 2.85, 0.65);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 2 (1.2-2.3s): "on Thinking" horizontal motion blur
        // ═══════════════════════════════════════════════════════════
        // Dark intro BG: continuous bgIntro

        var s2Txt = TX(comp, "on Thinking", {p:[CX, CY], s:130, c:cWhite, f:fBold, al:"c", n:"S2_Txt"});
        if (s2Txt) {
            s2Txt.inPoint = 1.2; s2Txt.outPoint = 2.85;
            addGlow(s2Txt, cWhite, 70, 40);
            // Strong horizontal motion blur sweep
            var s2bP = getBlurProp(s2Txt);
            if (s2bP) {
                AE.sa(s2bP, 1.2, 120);
                AE.sa(s2bP, 1.7, 18);
                AE.sa(s2bP, 2.0, 0);
                AE.sa(s2bP, 2.8, 95);
                AE.ease(s2bP, 92);
            }
            var s2O = AE.opa(s2Txt);
            AE.sa(s2O, 1.2, 0);
            AE.sa(s2O, 1.6, 100);
            AE.sa(s2O, 2.05, 100);
            AE.sa(s2O, 2.8, 0);
            AE.ease(s2O, 92);
            var s2P = AE.pos(s2Txt);
            AE.sa(s2P, 1.2, [CX - 200, CY]);
            AE.sa(s2P, 2.0, [CX, CY]);
            AE.sa(s2P, 2.8, [CX + 160, CY]);
            AE.ease(s2P, 92);
            var s2S = AE.scl(s2Txt);
            AE.sa(s2S, 1.2, [105,105]);
            AE.sa(s2S, 2.0, [100,100]);
            AE.ease(s2S, 90);
        }

        // ═══════════════════════════════════════════════════════════
        // SCENE 1 (0.0-1.2s): "Still wastin" opener
        // ═══════════════════════════════════════════════════════════
        // Dark intro BG: continuous bgIntro

        // Soft vignette glow upper-left
        var s1Bokeh = EL(comp, {p:[CX - 250, CY - 200], r:380, fc:AE.hex("#3A3A45"), n:"S1_Bokeh"});
        if (s1Bokeh) {
            s1Bokeh.inPoint = 0; s1Bokeh.outPoint = 1.75;
            addBlur(s1Bokeh, 260);
            AE.sv(AE.opa(s1Bokeh), 55);
            var s1bO = AE.opa(s1Bokeh);
            AE.sa(s1bO, 0, 0);
            AE.sa(s1bO, 0.45, 55);
            AE.sa(s1bO, 1.05, 35);
            AE.sa(s1bO, 1.65, 0);
            AE.ease(s1bO, 92);
        }
        var s1Txt = TX(comp, "Still wastin", {p:[CX, CY], s:135, c:cWhite, f:fBold, al:"c", n:"S1_Txt"});
        if (s1Txt) {
            s1Txt.inPoint = 0.05; s1Txt.outPoint = 1.75;
            addGlow(s1Txt, cWhite, 80, 45);
            // Heavy blur-in from left
            var s1bP = getBlurProp(s1Txt);
            if (s1bP) {
                AE.sa(s1bP, 0.05, 140);
                AE.sa(s1bP, 0.55, 22);
                AE.sa(s1bP, 0.95, 0);
                AE.sa(s1bP, 1.7, 85);
                AE.ease(s1bP, 92);
            }
            var s1O = AE.opa(s1Txt);
            AE.sa(s1O, 0.05, 0);
            AE.sa(s1O, 0.5, 100);
            AE.sa(s1O, 1.0, 100);
            AE.sa(s1O, 1.7, 0);
            AE.ease(s1O, 92);
            var s1P = AE.pos(s1Txt);
            AE.sa(s1P, 0.05, [CX - 180, CY + 20]);
            AE.sa(s1P, 0.9, [CX, CY]);
            AE.sa(s1P, 1.7, [CX + 150, CY - 15]);
            AE.ease(s1P, 92);
            var s1S = AE.scl(s1Txt);
            AE.sa(s1S, 0.05, [107,107]);
            AE.sa(s1S, 0.9, [100,100]);
            AE.ease(s1S, 90);
        }

        // ═══════════════════════════════════════════════════════════
        // CONTINUOUS BACKGROUNDS (built LAST so they sit at the bottom of the layer stack)
        // ═══════════════════════════════════════════════════════════

        // Dark intro BG — covers scenes 1..5 continuously with soft fade-out into scene 6
        var bgIntro = SLD(comp, cBlack, "BG_Intro_Dark");
        bgIntro.inPoint = 0; bgIntro.outPoint = 5.7;
        var biO = AE.opa(bgIntro);
        AE.sa(biO, 0, 100);
        AE.sa(biO, 5.15, 100);
        AE.sa(biO, 5.7, 0);
        AE.ease(biO, 92);

        // Persistent white base — ALWAYS on, so there is never a gap → no black flash ever
        var baseBG = SLD(comp, cWhite, "BASE_BG_White");
        baseBG.inPoint = 0; baseBG.outPoint = DUR;

        alert("SAHIB 'Just Ask' recriado com sucesso!\n\n" +
              "Composicao: 1080x1920 @ 30fps @ 38.5s\n" +
              "22 cenas com morphing, bounce e shapes complexos\n" +
              "Sem watermark de canto @SAHIB.AEP\n" +
              "Margens seguras (nada cortado)\n\n" +
              "Copie o audio original para sincronia.");

    } catch(e) {
        alert("Erro: " + e.toString() + "\nLinha: " + (e.line || "?"));
    } finally {
        app.endUndoGroup();
    }
})();
