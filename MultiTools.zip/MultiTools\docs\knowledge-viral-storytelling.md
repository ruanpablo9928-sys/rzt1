# ADDON — ESTILO VIRAL REEL STORYTELLING (Carrossel 3D + Narrativa)

Este addon ensina como criar Reels virais no estilo "storytelling cinematografico" — fundo limpo, texto narrativo sincronizado, imagens importadas, aneis orbitais 3D, carrossel de logos/icones girando em 3D, e camera com zoom cinematico.

---

## 1. CONCEITO DO ESTILO

Este estilo de Reel viral segue um padrao:
- Fundo CLARO, limpo, minimalista (branco ou cinza muito claro)
- Gradiente radial sutil no centro (tipo spotlight)
- Paleta monocromatica: preto/cinza + UMA cor de destaque (verde neon, azul, etc)
- Texto narrativo aparecendo frase por frase (como legendas de narrador)
- Imagem principal no centro (pessoa, produto, objeto) — importada como PNG
- Elementos orbitais 3D (aneis com bolinhas girando ao redor do sujeito)
- Carrossel 3D de logos/icones girando com perspectiva
- Camera com zoom lento e sutil pra frente — efeito cinematico
- Transicoes suaves entre "capitulos" da historia

---

## 2. COMPOSICAO BASE

```javascript
// Vertical 9:16 para Reels
var comp = AE.comp("Viral_Reel", 1080, 1920, 15, 30);
var CX = 540, CY = 960;

// Camera com zoom cinematico lento
var cam = AE.cam(comp, "CineCam", 2000);
if (cam) {
    var camPos = AE.pos(cam);
    if (camPos) {
        // Zoom lento: camera vai se aproximando de z=-2000 ate z=-1800
        AE.sa(camPos, 0, [CX, CY, -2000]);
        AE.sa(camPos, comp.duration, [CX, CY, -1750]);
        AE.ease(camPos, 50); // ease muito suave, quase linear
    }
}

// Luz ambiente suave
AE.light(comp, "Amb", 60);
// Luz spot de cima
var spot = AE.light(comp, "Spot", 100);
if (spot) AE.sv(AE.pos(spot), [CX, 200, -800]);
```

---

## 3. FUNDO CLARO MINIMALISTA

```javascript
// Fundo branco/cinza claro
var bg = AE.solid(comp, [0.94, 0.94, 0.95], "BG", 1080, 1920);
if (bg) {
    bg.moveToEnd();
    // Gradiente radial sutil — spotlight no centro
    var ramp = AE.fx(bg, "ADBE Ramp");
    if (ramp) {
        AE.sv(AE.gp(ramp, "ADBE Ramp-0001"), [CX, CY]);        // centro
        AE.sv(AE.gp(ramp, "ADBE Ramp-0002"), [1, 1, 1]);        // branco puro no centro
        AE.sv(AE.gp(ramp, "ADBE Ramp-0003"), [CX, 1920]);       // borda
        AE.sv(AE.gp(ramp, "ADBE Ramp-0004"), [0.88, 0.88, 0.90]); // cinza sutil na borda
        AE.sv(AE.gp(ramp, "ADBE Ramp-0005"), 2);                 // radial
    }
}
```

---

## 4. IMPORTAR IMAGENS (PLACEHOLDERS)

A IA NAO gera imagens, mas cria placeholders que o usuario substitui depois.

### 4.1 Placeholder de Pessoa (silhueta)
```javascript
// Criar placeholder para imagem da pessoa
// O usuario vai substituir por uma PNG recortada
function criarPlaceholderPessoa(comp, config) {
    config = config || {};
    var posX = config.x || 540;
    var posY = config.y || 1050;
    var altura = config.altura || 900;
    var largura = config.largura || 500;

    // Retangulo como placeholder
    var ph = AE.rect(comp, {
        p: [posX, posY],
        sz: [largura, altura],
        rn: 20,
        fc: [0.7, 0.7, 0.72],
        nome: config.nome || "PLACEHOLDER_Pessoa"
    });

    if (ph) {
        // Texto instrucao
        var instrucao = AE.txt(comp, "SUBSTITUIR POR\nIMAGEM PNG", {
            p: [posX, posY],
            f: "Arial-BoldMT", s: 28,
            c: [0.4, 0.4, 0.42],
            al: "c",
            nome: "INSTRUCAO_Pessoa"
        });

        // Se o usuario quiser usar como esta, aplicar tint monocromatico
        // (imagens em P&B com destaque colorido eh o estilo)
    }

    return ph;
}

// Uso:
var pessoa = criarPlaceholderPessoa(comp, { x: 540, y: 1050, altura: 900 });
```

### 4.2 Placeholder de Logo/Icone
```javascript
function criarPlaceholderLogo(comp, config) {
    config = config || {};
    // Circulo branco com borda
    var logo = AE.ell(comp, {
        p: config.p || [540, 960],
        r: config.r || 100,
        fc: [1, 1, 1],
        sc: [0.82, 0.82, 0.84],
        sw: 2,
        nome: config.nome || "PLACEHOLDER_Logo",
        d3: config.d3 || false
    });

    if (logo && config.label) {
        var lbl = AE.txt(comp, config.label, {
            p: [config.p[0], config.p[1] + 8],
            f: "Arial-BoldMT", s: config.labelSize || 30,
            c: [0.15, 0.15, 0.18],
            al: "c",
            nome: "LogoLabel_" + config.label
        });
        if (lbl && config.d3) lbl.threeDLayer = true;
        return { circle: logo, label: lbl };
    }
    return { circle: logo, label: null };
}
```

### 4.3 Importar arquivo real (quando o usuario tiver o arquivo)
```javascript
// Funcao para importar PNG/JPG
function importarImagem(caminhoArquivo, comp, config) {
    config = config || {};
    try {
        var arquivo = new File(caminhoArquivo);
        if (!arquivo.exists) { alert("Arquivo nao encontrado: " + caminhoArquivo); return null; }

        var importOpts = new ImportOptions(arquivo);
        if (importOpts.canImportAs(ImportAsType.FOOTAGE)) {
            importOpts.importAs = ImportAsType.FOOTAGE;
        }
        var footage = app.project.importFile(importOpts);
        var layer = comp.layers.add(footage);

        layer.name = config.nome || "Imagem";
        if (config.p) AE.sv(AE.pos(layer), config.p);
        if (config.escala) AE.sv(AE.scl(layer), [config.escala, config.escala]);
        if (config.d3) layer.threeDLayer = true;

        // Aplicar tint preto e branco (estilo do video)
        if (config.pb) {
            var tint = AE.fx(layer, "ADBE Tint");
            if (tint) {
                AE.sv(AE.gp(tint, "ADBE Tint-0001"), [0, 0, 0]);      // Map Black To
                AE.sv(AE.gp(tint, "ADBE Tint-0002"), [1, 1, 1]);      // Map White To
                AE.sv(AE.gp(tint, "ADBE Tint-0003"), 100);            // Amount
            }
        }

        return layer;
    } catch(e) {
        return null;
    }
}

// Uso:
// var pessoa = importarImagem("~/Desktop/pessoa.png", comp, { p: [540, 1050], escala: 80, pb: true, nome: "Pessoa" });
```

---

## 5. TEXTO NARRATIVO (STORYTELLING)

O texto aparece sincronizado como se alguem estivesse narrando. Cada frase tem timing exato.

### 5.1 Sistema de Narracoes
```javascript
function criarNarracao(comp, frases, config) {
    /*
        frases = [
            { texto: "ELON MUSK", tempo: 0, duracao: 2, tamanho: 72, bold: true, cor: null },
            { texto: "isn't just a CEO", tempo: 0.8, duracao: 2, tamanho: 32, bold: false, cor: null },
            { texto: "he's a business", tempo: 2.5, duracao: 2, tamanho: 32, bold: false, cor: null },
            { texto: "empire", tempo: 3.0, duracao: 2, tamanho: 32, bold: false, cor: [0.5, 1, 0.3] }
        ]
        config = {
            posY: 350,           // Y base do bloco de texto
            espacamento: 50,     // espaco entre linhas
            animacao: "slide",   // "slide", "fade", "type", "pop"
            corPadrao: [0.25, 0.25, 0.28],
            corDestaque: [0.5, 1, 0.3]
        }
    */
    config = config || {};
    var posY = config.posY || 350;
    var espaco = config.espacamento || 50;
    var animTipo = config.animacao || "slide";
    var corPad = config.corPadrao || [0.25, 0.25, 0.28];
    var layers = [];

    for (var i = 0; i < frases.length; i++) {
        var fr = frases[i];
        var yPos = posY + (i * espaco);

        var layer = AE.txt(comp, fr.texto, {
            p: [540, yPos],
            f: fr.bold ? "Arial-BoldMT" : "ArialMT",
            s: fr.tamanho || 32,
            c: fr.cor || corPad,
            al: "c",
            tr: fr.tracking || 0,
            nome: "Narr_" + i + "_" + fr.texto.substring(0, 10),
            d3: true
        });

        if (layer) {
            layer.inPoint = fr.tempo;
            layer.outPoint = fr.tempo + (fr.duracao || 3);

            // Animacao de entrada
            switch(animTipo) {
                case "slide":
                    AE.sli(layer, fr.tempo, "b", 40, 0.3);
                    break;
                case "fade":
                    AE.fsi(layer, fr.tempo, 0.25);
                    break;
                case "type":
                    // Simular typewriter com opacity do text animator
                    AE.fi(layer, fr.tempo, 0.15);
                    break;
                case "pop":
                    AE.pop(layer, fr.tempo);
                    break;
            }

            // Fade out no final
            AE.fo(layer, fr.tempo + fr.duracao - 0.3, 0.25);

            layers.push(layer);
        }
    }
    return layers;
}
```

### 5.2 Palavra com destaque colorido
```javascript
// Para destacar UMA palavra em cor diferente, crie duas layers de texto:
// Linha completa em cinza + palavra isolada em cor, sobreposta na posicao exata

function textoComDestaque(comp, textoCompleto, palavraDestaque, config) {
    config = config || {};
    var posY = config.posY || 400;
    var tempo = config.tempo || 0;

    // Texto base (cinza)
    var base = AE.txt(comp, textoCompleto, {
        p: [540, posY],
        f: "ArialMT", s: config.tamanho || 32,
        c: config.corBase || [0.4, 0.4, 0.42],
        al: "c", nome: "NarrBase",
        d3: true
    });

    // Palavra destaque (cor) — posicionada manualmente sobre a palavra
    // O usuario ajusta a posicao X se necessario
    var dest = AE.txt(comp, palavraDestaque, {
        p: [config.destaqueX || 540, posY],
        f: "Arial-BoldMT", s: config.tamanho || 32,
        c: config.corDestaque || [0.5, 1, 0.3],
        al: "c", nome: "NarrDestaque",
        d3: true
    });

    return { base: base, destaque: dest };
}
```

---

## 6. ANEL ORBITAL 3D (com bolinhas)

O efeito mais marcante do video: um anel com bolinhas coloridas girando ao redor do sujeito em 3D.

```javascript
function criarAnelOrbital(comp, config) {
    /*
        config = {
            centroX: 540,
            centroY: 900,
            raio: 300,
            numBolas: 5,
            raioBola: 18,
            corBola: [0.5, 1, 0.3],   // verde neon
            corLinha: [0.5, 1, 0.3],
            espessuraLinha: 2,
            velocidade: 1,             // rotacoes por segundo (negativo = anti-horario)
            inclinacaoX: 70,           // graus de inclinacao do anel (perspectiva)
            tempoInicio: 0,
            tempoFim: 5,
            nome: "Orbital"
        }
    */
    config = config || {};
    var cx = config.centroX || 540;
    var cy = config.centroY || 900;
    var raio = config.raio || 300;
    var nBolas = config.numBolas || 5;
    var rBola = config.raioBola || 18;
    var corB = config.corBola || [0.5, 1, 0.3];
    var corL = config.corLinha || [0.5, 1, 0.3];
    var espL = config.espessuraLinha || 2;
    var vel = config.velocidade || 1;
    var incX = config.inclinacaoX || 70;
    var tIni = config.tempoInicio || 0;
    var tFim = config.tempoFim || 5;
    var nome = config.nome || "Orbital";

    var layers = [];

    // Null controlador 3D — tudo parenta aqui
    var ctrl = AE.nul(comp, nome + "_Ctrl");
    if (!ctrl) return layers;
    ctrl.threeDLayer = true;
    AE.sv(AE.pos(ctrl), [cx, cy, 0]);
    // Inclinacao no eixo X para dar perspectiva
    AE.sv(AE.rX(ctrl), incX);
    // Rotacao continua no eixo Z
    var ctrlRot = AE.rot(ctrl);
    if (ctrlRot) {
        ctrlRot.expression = "time * " + (vel * 360) + ";";
    }
    ctrl.inPoint = tIni;
    ctrl.outPoint = tFim;
    layers.push(ctrl);

    // Anel (elipse com stroke, sem fill) — parentada ao null
    var anel = AE.ell(comp, {
        p: [cx, cy],
        r: raio,
        fc: false,
        sc: corL,
        sw: espL,
        nome: nome + "_Ring",
        d3: true
    });
    if (anel) {
        anel.parent = ctrl;
        AE.sv(AE.pos(anel), [0, 0, 0]); // posicao relativa ao parent
        AE.sv(AE.opacity(anel), 60);
        anel.inPoint = tIni;
        anel.outPoint = tFim;
        layers.push(anel);
    }

    // Bolinhas distribuidas ao longo do anel
    for (var bi = 0; bi < nBolas; bi++) {
        var angulo = (bi / nBolas) * 360;
        var bola = AE.ell(comp, {
            p: [cx, cy],
            r: rBola,
            fc: corB,
            nome: nome + "_Bola_" + bi,
            d3: true
        });
        if (bola) {
            bola.parent = ctrl;
            // Posicao no circulo usando expression
            var bolaPosExpr = [
                "var ang = " + angulo + ";",
                "var r = " + raio + ";",
                "var rad = ang * Math.PI / 180;",
                "[Math.cos(rad) * r, Math.sin(rad) * r, 0];"
            ].join("\n");
            var bolaPos = AE.pos(bola);
            if (bolaPos) bolaPos.expression = bolaPosExpr;

            // Glow sutil nas bolas
            var gBlur = AE.fx(bola, "ADBE Gaussian Blur 2");
            if (gBlur) AE.sv(AE.gp(gBlur, "ADBE Gaussian Blur 2-0001"), 2);

            bola.inPoint = tIni;
            bola.outPoint = tFim;
            layers.push(bola);
        }
    }

    // Fade in do conjunto
    AE.fsi(ctrl, tIni + 0.2, 0.5);

    return layers;
}

// Uso:
// var orbital = criarAnelOrbital(comp, {
//     centroX: 540, centroY: 900, raio: 300,
//     numBolas: 5, raioBola: 18,
//     corBola: [0.5, 1, 0.3], corLinha: [0.5, 1, 0.3],
//     inclinacaoX: 70, velocidade: 0.3,
//     tempoInicio: 1.5, tempoFim: 5
// });
```

---

## 7. CARROSSEL 3D DE LOGOS

Logos/icones giram em circulo ao redor do centro, cada um com perspectiva 3D. Conforme giram, os labels (Tesla, SpaceX, etc) aparecem ao lado.

```javascript
function criarCarrossel3D(comp, itens, config) {
    /*
        itens = [
            { label: "Tesla", icone: "T" },
            { label: "SpaceX", icone: "X" },
            { label: "Neuralink", icone: "N" },
            { label: "X", icone: "X" },
            { label: "TBC", icone: "B" }
        ]
        config = {
            centroX: 540,
            centroY: 700,
            raio: 250,
            raioCirculo: 80,        // tamanho de cada circulo de logo
            velocidade: -0.15,      // rotacoes por segundo (negativo = anti-horario)
            inclinacaoX: 15,        // inclinacao 3D
            inclinacaoY: 0,
            corCirculo: [1, 1, 1],
            corBordaCirculo: [0.82, 0.82, 0.84],
            corTexto: [0.15, 0.15, 0.18],
            corLabel: [0.4, 0.4, 0.42],
            tempoInicio: 3,
            tempoFim: 8,
            labelPosX: 130,         // X dos labels (lado esquerdo)
            nome: "Carrossel"
        }
    */
    config = config || {};
    var cx = config.centroX || 540;
    var cy = config.centroY || 700;
    var raio = config.raio || 250;
    var rCirc = config.raioCirculo || 80;
    var vel = config.velocidade || -0.15;
    var incX = config.inclinacaoX || 15;
    var tIni = config.tempoInicio || 3;
    var tFim = config.tempoFim || 8;
    var nome = config.nome || "Carr";

    var allLayers = [];

    // Null controlador rotativo
    var ctrl = AE.nul(comp, nome + "_Ctrl");
    if (!ctrl) return allLayers;
    ctrl.threeDLayer = true;
    AE.sv(AE.pos(ctrl), [cx, cy, 0]);
    AE.sv(AE.rX(ctrl), incX);
    var ctrlRot = AE.rot(ctrl);
    if (ctrlRot) ctrlRot.expression = "time * " + (vel * 360) + ";";
    ctrl.inPoint = tIni;
    ctrl.outPoint = tFim;
    allLayers.push(ctrl);

    // Circulo anel guia (invisivel ou sutil)
    var guia = AE.ell(comp, {
        p: [cx, cy], r: raio,
        fc: false, sc: [0.82, 0.82, 0.84], sw: 1,
        nome: nome + "_Guia", d3: true
    });
    if (guia) {
        guia.parent = ctrl;
        AE.sv(AE.pos(guia), [0, 0, 0]);
        AE.sv(AE.opacity(guia), 30);
        guia.inPoint = tIni; guia.outPoint = tFim;
        allLayers.push(guia);
    }

    // Cada item do carrossel
    for (var i = 0; i < itens.length; i++) {
        var item = itens[i];
        var angBase = (i / itens.length) * 360;

        // Circulo do logo — parentado ao ctrl
        var circ = AE.ell(comp, {
            p: [cx, cy],
            r: rCirc,
            fc: config.corCirculo || [1, 1, 1],
            sc: config.corBordaCirculo || [0.82, 0.82, 0.84],
            sw: 2,
            nome: nome + "_Circ_" + i,
            d3: true
        });
        if (circ) {
            circ.parent = ctrl;
            var circPosExpr = [
                "var ang = " + angBase + ";",
                "var r = " + raio + ";",
                "var rad = ang * Math.PI / 180;",
                "[Math.cos(rad) * r, Math.sin(rad) * r, 0];"
            ].join("\n");
            var circPos = AE.pos(circ);
            if (circPos) circPos.expression = circPosExpr;
            // Contra-rotacao para manter o circulo "reto"
            var circRot = AE.rot(circ);
            if (circRot) circRot.expression = "-(thisParent.rotation);";
            circ.inPoint = tIni; circ.outPoint = tFim;

            // Sombra sutil
            var shad = AE.fx(circ, "ADBE Drop Shadow");
            if (shad) {
                AE.sv(AE.gp(shad, "ADBE Drop Shadow-0002"), 12);
                AE.sv(AE.gp(shad, "ADBE Drop Shadow-0005"), 6);
                AE.sv(AE.gp(shad, "ADBE Drop Shadow-0006"), 20);
            }
            allLayers.push(circ);
        }

        // Icone/Texto dentro do circulo
        var icone = AE.txt(comp, item.icone || "?", {
            p: [cx, cy + 10],
            f: "Arial-BoldMT", s: rCirc * 0.6,
            c: config.corTexto || [0.15, 0.15, 0.18],
            al: "c",
            nome: nome + "_Ico_" + i,
            d3: true
        });
        if (icone) {
            icone.parent = ctrl;
            var iconePosExpr = [
                "var ang = " + angBase + ";",
                "var r = " + raio + ";",
                "var rad = ang * Math.PI / 180;",
                "[Math.cos(rad) * r, Math.sin(rad) * r, 0];"
            ].join("\n");
            var iconePos = AE.pos(icone);
            if (iconePos) iconePos.expression = iconePosExpr;
            var iconeRot = AE.rot(icone);
            if (iconeRot) iconeRot.expression = "-(thisParent.rotation);";
            icone.inPoint = tIni; icone.outPoint = tFim;
            allLayers.push(icone);
        }

        // Label do lado esquerdo (empilhado)
        var labelX = config.labelPosX || 130;
        var labelYBase = cy - ((itens.length - 1) * 35) / 2;
        var labelY = labelYBase + (i * 70);

        var label = AE.txt(comp, item.label, {
            p: [labelX, labelY],
            f: "Arial-BoldMT", s: 28,
            c: config.corLabel || [0.4, 0.4, 0.42],
            al: "l",
            nome: nome + "_Lbl_" + i
        });
        if (label) {
            label.inPoint = tIni + 0.5 + (i * 0.15);
            label.outPoint = tFim;
            AE.sli(label, label.inPoint, "e", 80, 0.3);
            allLayers.push(label);
        }
    }

    // Fade in geral
    AE.fsi(ctrl, tIni + 0.1, 0.5);

    return allLayers;
}
```

---

## 8. TIMING NARRATIVO — ESTRUTURA DE SCRIPT

Quando o usuario pedir um Reel estilo storytelling/viral, SEMPRE organize por "falas" com tempos exatos:

```javascript
// ═══ ESTRUTURA NARRATIVA ═══
// Cada "beat" eh um momento da historia

var historia = {
    beats: [
        // BEAT 1: Hook (0-2s) — prender atencao
        { tempo: 0, textos: [
            { texto: "ELON MUSK", tamanho: 72, bold: true },
        ]},

        // BEAT 2: Setup (1-3s) — contextualizar
        { tempo: 0.8, textos: [
            { texto: "isn't just a CEO", tamanho: 32, bold: false }
        ]},

        // BEAT 3: Reveal (2.5-4s) — revelar a tese
        { tempo: 2.5, textos: [
            { texto: "he's a business", tamanho: 32 },
            { texto: "empire", tamanho: 32, cor: [0.5, 1, 0.3] } // destaque
        ]},

        // BEAT 4: Visual (3-6s) — imagem + elemento orbital
        // (aqui entra a pessoa + anel orbital + skyline)

        // BEAT 5-8: Detalhes (6-12s) — carrossel de logos
        // (aqui entra o carrossel 3D girando)

        // BEAT 9: Conclusao (12-15s) — call to action ou statement final
        { tempo: 12, textos: [
            { texto: "Follow for more", tamanho: 36, bold: true }
        ]}
    ]
};
```

---

## 9. TEMPLATE COMPLETO DE SCRIPT VIRAL REEL

Quando o usuario pedir um Reel viral estilo storytelling, use esta estrutura:

```javascript
(function() {
    // [BIBLIOTECA AE AQUI]

    app.beginUndoGroup("Viral Reel");
    try {
        var comp = AE.comp("Viral_Reel", 1080, 1920, 15, 30);
        if (!comp) return;
        var CX = 540, CY = 960;

        // ── COR DE DESTAQUE (1 cor apenas) ──
        var destaque = [0.5, 1, 0.3]; // verde neon
        var cinza = [0.3, 0.3, 0.32];
        var cinzaC = [0.5, 0.5, 0.52];

        // ── CAMERA CINEMATICA ──
        // (zoom lento pra frente)

        // ── FUNDO CLARO ──
        // (branco + gradiente radial sutil)

        // ── BEAT 1: HOOK (0-2s) ──
        // Titulo grande, bold, centralizado
        // Slide de baixo, rapido

        // ── BEAT 2: CONTEXTO (1-3s) ──
        // Subtexto menor, fade in
        // Palavra-chave em cor destaque

        // ── BEAT 3: IMAGEM + ORBITAL (2-6s) ──
        // Placeholder de pessoa (PNG)
        // Anel orbital 3D girando ao redor
        // Skyline/cidade atras (placeholder)

        // ── BEAT 4-7: CARROSSEL DE LOGOS (5-10s) ──
        // Carrossel 3D girando
        // Labels aparecendo um por um do lado esquerdo
        // Cada logo/circulo gira em perspectiva

        // ── BEAT 8: STATEMENT FINAL (10-13s) ──
        // Frase de impacto grande
        // Cor destaque na palavra-chave

        // ── BEAT 9: CTA (13-15s) ──
        // "Follow for more" ou equivalente
        // Icone de seta/like

        // ── ORGANIZAR ──
        // bg.moveToEnd()

        alert("Reel criado!");
    } catch(e) {
        alert("Erro: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();
```

---

## 10. REGRAS ESPECIFICAS DESTE ESTILO

1. **FUNDO SEMPRE CLARO** — branco ou cinza muito claro. Nunca escuro.
2. **MONOCROMATICO + 1 COR** — todo o video eh preto/cinza/branco, com APENAS 1 cor de destaque (verde neon, azul, laranja, etc).
3. **IMAGENS EM P&B** — se importar imagens, aplicar Tint (preto e branco). So a cor de destaque tem saturacao.
4. **TEXTO GRANDE + BOLD** — titulos usam no minimo 64px, bold, centralizado.
5. **TIMING DE NARRACAO** — cada frase aparece como se alguem estivesse falando. 0.8-1.5s por frase.
6. **CAMERA LENTA** — zoom suave de 5-10% ao longo de toda a comp. Nunca brusco.
7. **TUDO 3D** — shapes, textos, elementos orbitais, tudo com threeDLayer = true para responder a camera e luzes.
8. **SOMBRAS SUTIS** — Drop Shadow com opacity 10-15%, distance 5-8, softness 15-25.
9. **SEM TRANSICOES BRUSCAS** — nada de wipes coloridos. Tudo fade suave ou scale.
10. **PLACEHOLDERS** — sempre criar retangulos/circulos como placeholders para imagens que o usuario vai adicionar depois. Incluir texto "SUBSTITUIR POR IMAGEM" dentro.
