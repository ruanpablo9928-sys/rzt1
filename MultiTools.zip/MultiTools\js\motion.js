/**
 * MultiTools — motion.js
 * Aba MOTION: palco onde o usuário compõe shapes/UIs (glow, glass, templates, fundo)
 * e exporta como layers no After Effects.
 */
(function () {
    'use strict';
    var cs = new CSInterface();
    function $(id) { return document.getElementById(id); }

    // ─────────── Estado ───────────
    var els = [];
    var sel = null;
    var idc = 0;
    var compAspect = 16 / 9;
    var bg = { type: 'none', c1: '#2a0b3a', c2: '#0b0b10' };
    var palette = ['#bcbcc2', '#e2e2e6', '#5b8cff', '#34d399', '#fbbf24', '#fb7185', '#a78bfa', '#22d3ee', '#f472b6', '#94a3b8', '#111316', '#ffffff'];
    var _glowOk = true;

    function defFor(type) {
        var d = { rect: [120, 80], round: [120, 80], card: [150, 100], circle: [90, 90], ellipse: [120, 80],
            triangle: [100, 90], star: [100, 100], polygon: [100, 100], line: [140, 6], text: [120, 40],
            button: [130, 46], pill: [110, 36], bar: [160, 14], avatar: [70, 70], phone: [120, 220] };
        return d[type] || [100, 80];
    }

    function newEl(type, opts) {
        opts = opts || {};
        var dim = defFor(type);
        var el = {
            id: ++idc, type: type,
            x: opts.x != null ? opts.x : canvasCenter().x,
            y: opts.y != null ? opts.y : canvasCenter().y,
            w: opts.w != null ? opts.w : dim[0],
            h: opts.h != null ? opts.h : dim[1],
            rot: opts.rot || 0,
            color: opts.color || palette[idc % 6],
            radius: opts.radius != null ? opts.radius : ((type === 'round' || type === 'card' || type === 'button') ? 12 : (type === 'phone' ? 26 : 0)),
            opacity: opts.opacity != null ? opts.opacity : 100,
            points: opts.points != null ? opts.points : (type === 'triangle' ? 3 : 5),
            text: opts.text != null ? opts.text : 'Texto',
            glow: opts.glow != null ? opts.glow : 0,
            glass: !!opts.glass,
            neon: !!opts.neon,
            glowColor: opts.glowColor || null
        };
        return el;
    }

    function add(type) {
        var el = newEl(type, { x: canvasCenter().x + ((idc % 5) * 10 - 20), y: canvasCenter().y + ((idc % 3) * 10 - 10) });
        if (type === 'phone') el.color = '#e2e2e6';
        els.push(el); sel = el; render(); syncProps();
    }

    function canvasCenter() {
        var cv = $('motion-canvas');
        return { x: cv ? cv.width / 2 : 140, y: cv ? cv.height / 2 : 100 };
    }

    // ─────────── Helpers de cor/forma ───────────
    function hexRgba(hex, a) {
        var h = (hex || '#000').replace('#', '');
        if (h.length === 3) h = h.replace(/(.)/g, '$1$1');
        var r = parseInt(h.substr(0, 2), 16), g = parseInt(h.substr(2, 2), 16), b = parseInt(h.substr(4, 2), 16);
        return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
    }
    function pickContrast(hex) {
        var h = hex.replace('#', ''); if (h.length === 3) h = h.replace(/(.)/g, '$1$1');
        var r = parseInt(h.substr(0, 2), 16), g = parseInt(h.substr(2, 2), 16), b = parseInt(h.substr(4, 2), 16);
        return (r * 0.299 + g * 0.587 + b * 0.114) > 150 ? '#111316' : '#f1f1f1';
    }
    function rr(ctx, x, y, w, h, r) {
        r = Math.max(0, Math.min(r, w / 2, h / 2));
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.arcTo(x + w, y, x + w, y + h, r);
        ctx.arcTo(x + w, y + h, x, y + h, r);
        ctx.arcTo(x, y + h, x, y, r);
        ctx.arcTo(x, y, x + w, y, r);
        ctx.closePath();
    }
    function polyPath(ctx, cx, cy, R, n, star) {
        ctx.beginPath();
        var steps = star ? n * 2 : n;
        for (var i = 0; i < steps; i++) {
            var ang = -Math.PI / 2 + (i / steps) * Math.PI * 2;
            var rad = star ? (i % 2 === 0 ? R : R * 0.5) : R;
            var px = cx + Math.cos(ang) * rad, py = cy + Math.sin(ang) * rad;
            if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.closePath();
    }

    // Constroi o path geométrico (retorna false para tipos especiais)
    function buildPath(ctx, el, w, h) {
        var x = -w / 2, y = -h / 2;
        switch (el.type) {
            case 'rect': rr(ctx, x, y, w, h, el.radius || 0); return true;
            case 'round': case 'card': rr(ctx, x, y, w, h, el.radius || 12); return true;
            case 'pill': case 'bar': rr(ctx, x, y, w, h, h / 2); return true;
            case 'circle': case 'avatar': ctx.beginPath(); ctx.arc(0, 0, Math.min(w, h) / 2, 0, Math.PI * 2); return true;
            case 'ellipse': ctx.beginPath(); ctx.ellipse(0, 0, w / 2, h / 2, 0, 0, Math.PI * 2); return true;
            case 'triangle': polyPath(ctx, 0, 0, Math.min(w, h) / 2, 3, false); return true;
            case 'polygon': polyPath(ctx, 0, 0, Math.min(w, h) / 2, el.points || 5, false); return true;
            case 'star': polyPath(ctx, 0, 0, Math.min(w, h) / 2, el.points || 5, true); return true;
        }
        return false;
    }

    function drawEl(ctx, el) {
        ctx.save();
        ctx.globalAlpha = (el.opacity == null ? 100 : el.opacity) / 100;
        ctx.translate(el.x, el.y);
        ctx.rotate((el.rot || 0) * Math.PI / 180);
        var w = el.w, h = el.h, x = -w / 2, y = -h / 2;
        var glassFill = el.glass ? hexRgba(el.color, 0.16) : el.color;
        var glowC = el.glowColor || el.color;
        var glowAmt = (el.neon && !el.glow) ? 45 : (el.glow || 0);

        // Glow (neon) via sombra — desligado em cenas enormes p/ performance
        if (glowAmt > 0 && _glowOk) {
            ctx.shadowColor = glowC;
            ctx.shadowBlur = glowAmt * 0.55;
        }

        // Tipos especiais
        if (el.type === 'line') {
            ctx.strokeStyle = el.color; ctx.lineWidth = Math.max(2, h); ctx.lineCap = 'round';
            ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x + w, 0); ctx.stroke();
            ctx.restore(); return;
        }
        if (el.type === 'phone') {
            ctx.strokeStyle = el.color; ctx.lineWidth = 3;
            rr(ctx, x, y, w, h, el.radius || 26); ctx.stroke();
            ctx.shadowBlur = 0;
            ctx.fillStyle = el.glass ? hexRgba(el.color, 0.10) : hexRgba(el.color, 0.06);
            rr(ctx, x, y, w, h, el.radius || 26); ctx.fill();
            ctx.fillStyle = el.color; rr(ctx, -w * 0.14, y + 6, w * 0.28, 5, 2.5); ctx.fill();
            ctx.restore(); return;
        }
        if (el.type === 'text') {
            ctx.fillStyle = el.color; ctx.font = '800 ' + Math.max(12, h) + 'px "Segoe UI"';
            ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            ctx.fillText(el.text || 'Texto', 0, 0);
            ctx.restore(); return;
        }
        if (el.type === 'button') {
            var br = el.radius || 12;
            if (el.neon) { ctx.fillStyle = 'rgba(10,10,14,0.55)'; } else { ctx.fillStyle = glassFill; }
            rr(ctx, x, y, w, h, br); ctx.fill();
            if (el.neon) { ctx.strokeStyle = glowC; ctx.lineWidth = 2.4; rr(ctx, x, y, w, h, br); ctx.stroke(); }
            else if (el.glass) { ctx.shadowBlur = 0; ctx.strokeStyle = 'rgba(255,255,255,0.30)'; ctx.lineWidth = 1.2; rr(ctx, x, y, w, h, br); ctx.stroke(); }
            ctx.shadowBlur = 0;
            ctx.fillStyle = el.neon ? glowC : (el.glass ? (el.glowColor || '#f1f1f1') : pickContrast(el.color));
            ctx.font = '700 ' + Math.min(15, h * 0.4) + 'px "Segoe UI"';
            ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(el.text || 'Botão', 0, 1);
            ctx.restore(); return;
        }

        // Geométricos
        if (buildPath(ctx, el, w, h)) {
            if (el.neon) {
                ctx.fillStyle = 'rgba(10,10,14,0.5)'; ctx.fill();
                ctx.strokeStyle = glowC; ctx.lineWidth = 2.4;
                buildPath(ctx, el, w, h); ctx.stroke();
            } else {
                ctx.fillStyle = glassFill; ctx.fill();
                if (el.glass) {
                    ctx.shadowBlur = 0;
                    ctx.strokeStyle = 'rgba(255,255,255,0.28)'; ctx.lineWidth = 1.2;
                    buildPath(ctx, el, w, h); ctx.stroke();
                    ctx.save(); ctx.clip(); var grd = ctx.createLinearGradient(0, y, 0, y + h * 0.5);
                    grd.addColorStop(0, 'rgba(255,255,255,0.12)'); grd.addColorStop(1, 'rgba(255,255,255,0)');
                    ctx.fillStyle = grd; ctx.fillRect(x, y, w, h * 0.5); ctx.restore();
                }
            }
        }
        ctx.restore();
    }

    // ─────────── Fundo da cena ───────────
    function drawBackground(ctx, W, H) {
        if (bg.type === 'radial') {
            var g = ctx.createRadialGradient(W / 2, H * 0.5, 0, W / 2, H * 0.5, Math.max(W, H) * 0.75);
            g.addColorStop(0, bg.c1); g.addColorStop(1, bg.c2);
            ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
        } else if (bg.type === 'aurora') {
            ctx.fillStyle = bg.c2; ctx.fillRect(0, 0, W, H);
            var blobs = [[0.32, 0.62, bg.c1], [0.7, 0.4, bg.c1], [0.5, 0.85, bg.c1]];
            for (var i = 0; i < blobs.length; i++) {
                var b = blobs[i];
                var gr = ctx.createRadialGradient(W * b[0], H * b[1], 0, W * b[0], H * b[1], W * 0.45);
                gr.addColorStop(0, hexRgba(b[2], 0.55)); gr.addColorStop(1, hexRgba(b[2], 0));
                ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);
            }
        } else {
            ctx.fillStyle = '#0c0c0c'; ctx.fillRect(0, 0, W, H);
        }
    }

    function render() {
        var cv = $('motion-canvas'); if (!cv) return;
        var ctx = cv.getContext('2d');
        var W = cv.width, H = cv.height;
        _glowOk = els.length <= 350;
        ctx.clearRect(0, 0, W, H);
        drawBackground(ctx, W, H);
        // grid leve
        ctx.strokeStyle = 'rgba(255,255,255,0.035)'; ctx.lineWidth = 1;
        for (var gx = 0; gx < W; gx += 24) { ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke(); }
        for (var gy = 0; gy < H; gy += 24) { ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke(); }
        for (var i = 0; i < els.length; i++) drawEl(ctx, els[i]);
        if (sel) {
            ctx.save();
            ctx.translate(sel.x, sel.y); ctx.rotate((sel.rot || 0) * Math.PI / 180);
            ctx.strokeStyle = '#5b8cff'; ctx.lineWidth = 1.5; ctx.setLineDash([4, 3]);
            ctx.strokeRect(-sel.w / 2 - 3, -sel.h / 2 - 3, sel.w + 6, sel.h + 6);
            ctx.setLineDash([]); ctx.fillStyle = '#5b8cff';
            var hx = sel.w / 2 + 3, hy = sel.h / 2 + 3;
            [[-hx, -hy], [hx, -hy], [hx, hy], [-hx, hy]].forEach(function (c) { ctx.beginPath(); ctx.arc(c[0], c[1], 3, 0, Math.PI * 2); ctx.fill(); });
            ctx.restore();
        }
        var cnt = $('motion-count'); if (cnt) cnt.textContent = els.length + ' elemento' + (els.length === 1 ? '' : 's');
    }

    // ─────────── Hit-test + arraste ───────────
    function hit(px, py) {
        for (var i = els.length - 1; i >= 0; i--) {
            var el = els[i];
            var dx = px - el.x, dy = py - el.y;
            var a = -(el.rot || 0) * Math.PI / 180;
            var rx = dx * Math.cos(a) - dy * Math.sin(a);
            var ry = dx * Math.sin(a) + dy * Math.cos(a);
            if (Math.abs(rx) <= el.w / 2 + 4 && Math.abs(ry) <= el.h / 2 + 4) return el;
        }
        return null;
    }
    var dragging = false, dox = 0, doy = 0;
    function pos(e, cv) {
        var r = cv.getBoundingClientRect();
        return { x: (e.clientX - r.left) * (cv.width / r.width), y: (e.clientY - r.top) * (cv.height / r.height) };
    }

    // ─────────── Propriedades ───────────
    function syncProps() {
        var box = $('motion-props'); if (!box) return;
        if (!sel) { box.style.display = 'none'; return; }
        box.style.display = 'block';
        set('mp-w', Math.round(sel.w)); set('mp-h', Math.round(sel.h));
        set('mp-radius', Math.round(sel.radius || 0));
        set('mp-rot', Math.round(sel.rot || 0));
        set('mp-op', Math.round(sel.opacity == null ? 100 : sel.opacity));
        set('mp-points', sel.points || 5);
        set('mp-text', sel.text || '');
        set('mp-glow', Math.round(sel.glow || 0));
        var gl = $('mp-glass'); if (gl) gl.checked = !!sel.glass;
        var nn = $('mp-neon'); if (nn) nn.checked = !!sel.neon;
        var gc = $('mp-glowcolor'); if (gc) gc.value = sel.glowColor || (sel.color && sel.color.charAt(0) === '#' && sel.color.length >= 7 ? sel.color : '#22a8ff');
        showRow('row-radius', ['rect', 'round', 'card', 'phone'].indexOf(sel.type) >= 0);
        showRow('row-points', ['star', 'polygon'].indexOf(sel.type) >= 0);
        showRow('row-text', ['text', 'button'].indexOf(sel.type) >= 0);
        renderSwatches();
    }
    function set(id, v) { var e = $(id); if (e) e.value = v; }
    function showRow(id, on) { var e = $(id); if (e) e.style.display = on ? '' : 'none'; }
    function renderSwatches() {
        var wrap = $('mp-swatches'); if (!wrap) return;
        if (!wrap.childElementCount) {
            palette.forEach(function (c) {
                var b = document.createElement('button');
                b.className = 'mp-sw'; b.setAttribute('data-c', c); b.style.background = c;
                b.addEventListener('click', function () { if (sel) { sel.color = c; render(); syncProps(); } });
                wrap.appendChild(b);
            });
        }
        var bs = wrap.querySelectorAll('.mp-sw');
        for (var i = 0; i < bs.length; i++) bs[i].classList.toggle('active', sel && bs[i].getAttribute('data-c') === sel.color);
    }

    // ─────────── Templates ───────────
    function buildTemplate(name) {
        var cv = $('motion-canvas'); var W = cv.width, H = cv.height;
        var out = [];
        function E(t, o) { o = o || {}; var e = newEl(t, o); out.push(e); return e; }
        if (name === 'rating') {
            bg = { type: 'aurora', c1: '#c026d3', c2: '#15030f' };
            E('card', { x: W * 0.5, y: H * 0.5, w: W * 0.74, h: H * 0.5, color: '#d426c8', radius: 22, opacity: 100, glass: true, glow: 30 });
            E('avatar', { x: W * 0.32, y: H * 0.4, w: 26, h: 26, color: '#ffffff' });
            E('text', { x: W * 0.5, y: H * 0.42, w: 200, h: 22, color: '#ffffff', text: 'How was your experience?', glow: 25 });
            var faces = 5;
            for (var i = 0; i < faces; i++) {
                E('circle', { x: W * (0.34 + i * 0.08), y: H * 0.6, w: 34, h: 34, color: i === 3 ? '#ffffff' : '#e9b6f0', opacity: i === 3 ? 100 : 55, glow: i === 3 ? 40 : 0 });
            }
            E('avatar', { x: W * 0.66, y: H * 0.3, w: 22, h: 22, color: '#ffffff', opacity: 70 });
        } else if (name === 'glowicons') {
            bg = { type: 'radial', c1: '#1a0a22', c2: '#050507' };
            var cols = ['#5b8cff', '#fb7185', '#a78bfa', '#34d399', '#fbbf24', '#22d3ee', '#f472b6', '#fb923c', '#60a5fa', '#e879f9'];
            var n = cols.length, cx = W * 0.5, cy = H * 0.58, R = Math.min(W, H) * 0.42;
            for (var k = 0; k < n; k++) {
                var ang = Math.PI * (1.15 + (k / (n - 1)) * 0.7);
                E('round', { x: cx + Math.cos(ang) * R, y: cy + Math.sin(ang) * R, w: 46, h: 46, color: cols[k], radius: 12, glow: 55 });
            }
            E('text', { x: cx, y: cy - 6, w: 220, h: 26, color: '#ffffff', text: 'Glow In The Dark', glow: 20 });
            E('text', { x: cx, y: cy + 26, w: 220, h: 12, color: '#aaaaaa', text: 'Aku tidak lagi membuang energy', opacity: 80 });
            E('pill', { x: cx, y: cy + 64, w: 110, h: 36, color: '#ffffff', text: 'Follow Me' });
        } else if (name === 'phone') {
            bg = { type: 'radial', c1: '#072a12', c2: '#030604' };
            E('phone', { x: W * 0.5, y: H * 0.5, w: H * 0.42, h: H * 0.78, color: '#34d399', radius: 30, glow: 60, glass: true });
            E('card', { x: W * 0.5, y: H * 0.42, w: H * 0.3, h: H * 0.22, color: '#34d399', radius: 14, glass: true, glow: 30 });
            E('bar', { x: W * 0.5, y: H * 0.38, w: H * 0.2, h: 8, color: '#a7f3d0', opacity: 80 });
            E('bar', { x: W * 0.44, y: H * 0.45, w: H * 0.1, h: 14, color: '#a7f3d0', opacity: 70 });
            E('bar', { x: W * 0.57, y: H * 0.45, w: H * 0.1, h: 14, color: '#a7f3d0', opacity: 70 });
            E('round', { x: W * 0.38, y: H * 0.36, w: 30, h: 30, color: '#34d399', radius: 8, glow: 60, glass: true });
            E('round', { x: W * 0.63, y: H * 0.34, w: 30, h: 30, color: '#34d399', radius: 8, glow: 60, glass: true });
            E('text', { x: W * 0.5, y: H * 0.62, w: 120, h: 20, color: '#ffffff', text: 'UI UX', glow: 25 });
        } else if (name === 'cmdbar') {
            bg = { type: 'radial', c1: '#0e0e16', c2: '#040406' };
            E('ellipse', { x: W * 0.30, y: H * 0.40, w: W * 0.5, h: 110, color: '#ff6a2a', glow: 95, opacity: 45 });
            E('ellipse', { x: W * 0.70, y: H * 0.40, w: W * 0.5, h: 110, color: '#3b74ff', glow: 95, opacity: 45 });
            E('round', { x: W * 0.5, y: H * 0.34, w: W * 0.74, h: 60, color: '#16161d', radius: 18, neon: true, glowColor: '#9aa3ff', glow: 22 });
            E('text', { x: W * 0.27, y: H * 0.31, w: 150, h: 15, color: '#c7c7cf', text: 'Ask anything...', opacity: 90 });
            E('circle', { x: W * 0.175, y: H * 0.40, w: 26, h: 26, color: '#2a2a33' });
            E('button', { x: W * 0.30, y: H * 0.40, w: 80, h: 28, color: '#23232c', radius: 14, glass: true, glowColor: '#cfcfd6', text: 'Normal' });
            E('button', { x: W * 0.43, y: H * 0.40, w: 94, h: 28, color: '#23232c', radius: 14, glass: true, glowColor: '#cfcfd6', text: 'DeepThink' });
            E('button', { x: W * 0.73, y: H * 0.40, w: 72, h: 28, color: '#23232c', radius: 14, glass: true, glowColor: '#cfcfd6', text: 'Voice' });
            E('circle', { x: W * 0.82, y: H * 0.40, w: 32, h: 32, color: '#8b3bff', glow: 55 });
            var mx = W * 0.43, my0 = H * 0.55, dy = H * 0.058;
            E('card', { x: mx, y: my0 + 1.5 * dy, w: W * 0.34, h: dy * 4 + 18, color: '#15151c', radius: 12, glass: true, glow: 10 });
            var items = ['Quick answer', 'Balanced', 'DeepThink', 'Research'];
            E('round', { x: mx, y: my0 + 2 * dy, w: W * 0.30, h: 26, color: '#2b2b38', radius: 8, opacity: 95 });
            for (var ci = 0; ci < items.length; ci++) {
                E('text', { x: mx, y: my0 + ci * dy, w: 120, h: 12, color: ci === 2 ? '#ffffff' : '#b9b9c2', text: items[ci], opacity: ci === 2 ? 100 : 82 });
            }
        } else if (name === 'neonselect') {
            bg = { type: 'radial', c1: '#05121f', c2: '#020308' };
            E('round', { x: W * 0.5, y: H * 0.2, w: W * 0.7, h: 52, color: '#0a1018', radius: 14, neon: true, glowColor: '#22a8ff', glow: 55 });
            E('text', { x: W * 0.5, y: H * 0.2, w: 120, h: 17, color: '#ffffff', text: 'Select...', glow: 8 });
            E('round', { x: W * 0.5, y: H * 0.42, w: W * 0.7, h: 52, color: '#0a1018', radius: 14, neon: true, glowColor: '#22a8ff', glow: 55 });
            E('text', { x: W * 0.5, y: H * 0.42, w: 120, h: 17, color: '#ffffff', text: 'Select...', glow: 8 });
            E('card', { x: W * 0.5, y: H * 0.69, w: W * 0.7, h: H * 0.34, color: '#0e2536', radius: 12, glass: true, glow: 22 });
            for (var r = 0; r < 4; r++) {
                var ry = H * (0.57 + r * 0.06);
                E('circle', { x: W * 0.26, y: ry, w: 14, h: 14, color: '#22a8ff', glow: 25 });
                E('text', { x: W * 0.52, y: ry, w: 100, h: 13, color: '#ffffff', text: 'Select...', opacity: 90 });
            }
        } else if (name === 'statuspills') {
            bg = { type: 'radial', c1: '#0a0a0f', c2: '#000000' };
            var defs = [['In progress', '#2dd4bf'], ['To-do', '#6366f1'], ['In Review', '#eab308'], ['Design Review', '#a855f7'], ['Rework', '#ef4444'], ['Done', '#22c55e'], ['Not Started', '#fb7185'], ['Blocked', '#f43f5e'], ['On Hold', '#3b82f6'], ['Archived', '#9ca3af']];
            var rows = [[0, 1, 2], [3, 4, 5, 6], [7, 8, 9]];
            for (var ri = 0; ri < rows.length; ri++) {
                var idxs = rows[ri], ry2 = H * (0.34 + ri * 0.13);
                var ws = [], total = 0, gap = W * 0.018;
                for (var a = 0; a < idxs.length; a++) { var wd = defs[idxs[a]][0].length * (W * 0.0072) + W * 0.05; ws.push(wd); total += wd; }
                total += gap * (idxs.length - 1);
                var px = W * 0.5 - total / 2;
                for (var b = 0; b < idxs.length; b++) {
                    var dI = defs[idxs[b]], wd2 = ws[b], cxp = px + wd2 / 2;
                    E('button', { x: cxp, y: ry2, w: wd2, h: 34, color: dI[1], radius: 17, glass: true, glow: 38, glowColor: dI[1], text: dI[0] });
                    E('circle', { x: cxp - wd2 / 2 + 16, y: ry2, w: 13, h: 13, color: dI[1], glow: 18 });
                    px += wd2 + gap;
                }
            }
        } else { // hero
            bg = { type: 'aurora', c1: '#4338ca', c2: '#0a0a14' };
            E('text', { x: W * 0.5, y: H * 0.42, w: 260, h: 34, color: '#ffffff', text: 'Seu Título Aqui', glow: 30 });
            E('text', { x: W * 0.5, y: H * 0.55, w: 240, h: 13, color: '#b8b8c0', text: 'Subtítulo da sua cena premium', opacity: 85 });
            E('button', { x: W * 0.5, y: H * 0.68, w: 130, h: 44, color: '#5b8cff', radius: 22, text: 'Começar', glow: 45 });
        }
        return out;
    }

    // ─────────── elemento → primitivas (pro AE) ───────────
    function toPrims(el) {
        var base = { cx: el.x, cy: el.y, w: el.w, h: el.h, rot: el.rot || 0, color: el.color,
            opacity: el.opacity == null ? 100 : el.opacity, glow: el.glow || 0, glass: !!el.glass,
            neon: !!el.neon, glowColor: el.glowColor || null };
        function P(extra) { var o = {}; for (var k in base) o[k] = base[k]; for (var j in extra) o[j] = extra[j]; return o; }
        function T(extra) { var o = P(extra); o.glow = 0; o.glass = false; return o; }
        switch (el.type) {
            case 'rect': return [P({ kind: 'rect', radius: el.radius || 0 })];
            case 'round': case 'card': return [P({ kind: 'rect', radius: el.radius || 12 })];
            case 'pill': case 'bar': return [P({ kind: 'rect', radius: 'pill' })];
            case 'circle': case 'avatar': return [P({ kind: 'ellipse', w: Math.min(el.w, el.h), h: Math.min(el.w, el.h) })];
            case 'ellipse': return [P({ kind: 'ellipse' })];
            case 'triangle': return [P({ kind: 'star', polygon: true, points: 3 })];
            case 'polygon': return [P({ kind: 'star', polygon: true, points: el.points || 5 })];
            case 'star': return [P({ kind: 'star', polygon: false, points: el.points || 5 })];
            case 'line': return [P({ kind: 'line' })];
            case 'text': return [T({ kind: 'text', text: el.text || 'Texto', fontSize: el.h })];
            case 'button': return [P({ kind: 'rect', radius: el.radius || 12 }), T({ kind: 'text', text: el.text || 'Botão', fontSize: Math.min(15, el.h * 0.4), color: el.neon ? (el.glowColor || el.color) : (el.glass ? (el.glowColor || '#f1f1f1') : pickContrast(el.color)) })];
            case 'phone': return [P({ kind: 'rect', radius: el.radius || 26, stroke: true, strokeWidth: 3 })];
            default: return [P({ kind: 'rect', radius: el.radius || 0 })];
        }
    }

    // ─────────── API pública ───────────
    function install() {
        if (typeof window.MT === 'undefined') window.MT = {};
        var MT = window.MT;

        MT.motionAdd = function (type) { add(type); };
        MT.motionClear = function () { els = []; sel = null; render(); syncProps(); };
        MT.motionDelete = function () { if (!sel) return; els = els.filter(function (e) { return e !== sel; }); sel = null; render(); syncProps(); };
        MT.motionDup = function () { if (!sel) return; var c = JSON.parse(JSON.stringify(sel)); c.id = ++idc; c.x += 14; c.y += 14; els.push(c); sel = c; render(); syncProps(); };
        MT.motionOrder = function (dir) {
            if (!sel) return; var i = els.indexOf(sel); if (i < 0) return;
            els.splice(i, 1); if (dir === 'front') els.push(sel); else els.unshift(sel); render();
        };
        MT.motionMultiply = function () {
            if (!sel) { if (MT.toast) MT.toast('Selecione um elemento', true); return; }
            var n = parseInt($('motion-mult').value) || 10;
            var cv = $('motion-canvas'); var W = cv.width, H = cv.height;
            for (var i = 0; i < n; i++) {
                var c = JSON.parse(JSON.stringify(sel)); c.id = ++idc;
                c.x = 20 + Math.random() * (W - 40); c.y = 20 + Math.random() * (H - 40);
                c.rot = Math.random() * 360; var sc = 0.5 + Math.random() * 1.1; c.w *= sc; c.h *= sc;
                els.push(c);
            }
            render(); if (MT.toast) MT.toast(n + ' cópias adicionadas', false);
        };
        MT.motionGlow = function (v) { if (sel) { sel.glow = parseFloat(v) || 0; render(); } };
        MT.motionGlass = function (on) { if (sel) { sel.glass = !!on; render(); } };
        MT.motionBg = function () {
            var t = $('motion-bg-type'); var c1 = $('motion-bg-c1'); var c2 = $('motion-bg-c2');
            if (t) bg.type = t.value;
            if (c1) bg.c1 = c1.value;
            if (c2) bg.c2 = c2.value;
            render();
        };
        MT.motionTemplate = function (name) {
            els = buildTemplate(name); sel = null;
            var t = $('motion-bg-type'), c1 = $('motion-bg-c1'), c2 = $('motion-bg-c2');
            if (t) t.value = bg.type; if (c1) c1.value = bg.c1; if (c2) c2.value = bg.c2;
            render(); syncProps();
            if (MT.toast) MT.toast('Template "' + name + '" carregado', false);
        };
        MT.motionResize = function () {
            var cv = $('motion-canvas'); if (!cv) return;
            var wrap = cv.parentElement; var availW = wrap.clientWidth;
            if (availW < 20) return;
            cv.width = Math.round(availW); cv.height = Math.round(availW / compAspect);
            render();
        };
        MT.motionToAE = function () {
            if (els.length === 0 && bg.type === 'none') { if (MT.toast) MT.toast('Monte a cena primeiro', true); return; }
            var cv = $('motion-canvas');
            var prims = [];
            if (bg.type !== 'none') prims.push({ kind: 'bg', bgType: bg.type, c1: bg.c1, c2: bg.c2 });
            for (var i = 0; i < els.length; i++) prims = prims.concat(toPrims(els[i]));
            var data = { prims: prims, canvasW: cv.width, canvasH: cv.height };
            var btn = $('motion-toae'); if (btn) { btn.disabled = true; btn.textContent = 'CRIANDO...'; }
            var json = JSON.stringify(data).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
            cs.evalScript("buildMotionScene('" + json + "')", function (r) {
                if (btn) { btn.disabled = false; btn.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20,6 9,17 4,12"/></svg> ADICIONAR AO AE'; }
                if (r === 'true') { if (MT.toast) MT.toast('Cena criada no AE!', false); }
                else { if (MT.toast) MT.toast(r || 'Erro ao criar', true); }
            });
        };
    }

    // ─────────── Wiring ───────────
    function wire() {
        var cv = $('motion-canvas'); if (!cv) return;
        cv.addEventListener('pointerdown', function (e) {
            e.preventDefault(); try { cv.setPointerCapture(e.pointerId); } catch (_) {}
            var p = pos(e, cv); var h = hit(p.x, p.y);
            sel = h; render(); syncProps();
            if (h) { dragging = true; dox = p.x - h.x; doy = p.y - h.y; }
        });
        cv.addEventListener('pointermove', function (e) {
            if (!dragging || !sel) return;
            var p = pos(e, cv); sel.x = p.x - dox; sel.y = p.y - doy; render();
        });
        cv.addEventListener('pointerup', function (e) { try { cv.releasePointerCapture(e.pointerId); } catch (_) {} dragging = false; });
        cv.addEventListener('pointercancel', function () { dragging = false; });

        bindNum('mp-w', function (v) { sel.w = Math.max(2, v); });
        bindNum('mp-h', function (v) { sel.h = Math.max(2, v); });
        bindNum('mp-radius', function (v) { sel.radius = Math.max(0, v); });
        bindNum('mp-rot', function (v) { sel.rot = v; });
        bindNum('mp-op', function (v) { sel.opacity = Math.max(0, Math.min(100, v)); });
        bindNum('mp-points', function (v) { sel.points = Math.max(3, Math.min(20, v)); });
        var tx = $('mp-text'); if (tx) tx.addEventListener('input', function () { if (sel) { sel.text = this.value; render(); } });
        var gw = $('mp-glow'); if (gw) gw.addEventListener('input', function () { if (sel) { sel.glow = parseFloat(this.value) || 0; render(); } });
        var gl = $('mp-glass'); if (gl) gl.addEventListener('change', function () { if (sel) { sel.glass = this.checked; render(); } });
        var nn = $('mp-neon'); if (nn) nn.addEventListener('change', function () { if (sel) { sel.neon = this.checked; render(); } });
        var gc = $('mp-glowcolor'); if (gc) gc.addEventListener('input', function () { if (sel) { sel.glowColor = this.value; render(); } });

        document.addEventListener('keydown', function (e) {
            var pane = document.querySelector('.tabpane[data-pane="motion"]');
            if (!pane || !pane.classList.contains('active')) return;
            if ((e.key === 'Delete' || e.key === 'Backspace') && sel && document.activeElement.tagName !== 'INPUT') window.MT.motionDelete();
        });
        window.addEventListener('resize', function () {
            var pane = document.querySelector('.tabpane[data-pane="motion"]');
            if (pane && pane.classList.contains('active')) window.MT.motionResize();
        });
    }
    function bindNum(id, fn) {
        var e = $(id); if (!e) return;
        e.addEventListener('input', function () { if (!sel) return; var v = parseFloat(this.value); if (isNaN(v)) return; fn(v); render(); });
    }

    install();
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire);
    else wire();
})();
