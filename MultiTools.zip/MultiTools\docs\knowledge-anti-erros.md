# ADDON CRÍTICO — PROTEÇÃO ANTI-ERROS (OBRIGATÓRIO)

## ⚠️ INSTRUÇÃO ABSOLUTA

Você AINDA está gerando erros como "null is not an object". Isso é INACEITÁVEL.
A partir de agora, você NÃO vai mais escrever código "direto". Você vai usar OBRIGATORIAMENTE a biblioteca de segurança abaixo em TODOS os scripts. Essa biblioteca IMPEDE que erros aconteçam porque ela verifica tudo automaticamente.

**REGRA: Copie SEMPRE o bloco de funções de segurança no INÍCIO de cada script. NUNCA pule isso. NUNCA escreva código sem essas funções.**

---

## 1. BIBLIOTECA DE SEGURANÇA (COPIAR EM TODO SCRIPT)

```javascript
// ╔══════════════════════════════════════════════════════════════╗
// ║  BIBLIOTECA DE SEGURANÇA — AE EXTENDSCRIPT                  ║
// ║  Copie este bloco inteiro no início de CADA script           ║
// ╚══════════════════════════════════════════════════════════════╝

var AE = {};

// ── Obter composição ativa (NUNCA use app.project.activeItem direto) ──
AE.getComp = function() {
    var item = app.project.activeItem;
    if (item === null || item === undefined) return null;
    if (!(item instanceof CompItem)) return null;
    return item;
};

// ── Obter composição ativa COM ERRO se não existir ──
AE.requireComp = function(msg) {
    var comp = AE.getComp();
    if (comp === null) {
        alert(msg || "Abra uma composição primeiro.");
        return null;
    }
    return comp;
};

// ── Obter camadas selecionadas (NUNCA use comp.selectedLayers direto) ──
AE.getSelectedLayers = function(comp) {
    if (comp === null || comp === undefined) return [];
    if (!(comp instanceof CompItem)) return [];
    var sel = comp.selectedLayers;
    if (sel === null || sel === undefined) return [];
    return sel;
};

// ── Obter camadas selecionadas COM ERRO se não existirem ──
AE.requireSelectedLayers = function(comp, msg) {
    var sel = AE.getSelectedLayers(comp);
    if (sel.length === 0) {
        alert(msg || "Selecione pelo menos uma camada.");
        return null;
    }
    return sel;
};

// ── Obter camada por índice SEGURO ──
AE.getLayer = function(comp, index) {
    if (comp === null || comp === undefined) return null;
    if (index < 1 || index > comp.numLayers) return null;
    var layer = comp.layers[index];
    if (layer === null || layer === undefined) return null;
    return layer;
};

// ── Obter camada por nome SEGURO ──
AE.getLayerByName = function(comp, name) {
    if (comp === null || comp === undefined) return null;
    for (var i = 1; i <= comp.numLayers; i++) {
        if (comp.layers[i].name === name) {
            return comp.layers[i];
        }
    }
    return null;
};

// ── Obter propriedade SEGURO (NUNCA use layer.property() direto) ──
AE.getProp = function(parent, propName) {
    if (parent === null || parent === undefined) return null;
    try {
        var p = parent.property(propName);
        if (p === null || p === undefined) return null;
        return p;
    } catch(e) {
        return null;
    }
};

// ── Encadear propriedades SEGURO ──
// Uso: AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Position"])
AE.getPropChain = function(parent, propNames) {
    var current = parent;
    for (var i = 0; i < propNames.length; i++) {
        current = AE.getProp(current, propNames[i]);
        if (current === null) return null;
    }
    return current;
};

// ── Acessar Transform SEGURO ──
AE.transform = function(layer, propName) {
    // propName: "Position", "Scale", "Opacity", "Rotation", "Anchor Point"
    if (layer === null || layer === undefined) return null;
    try {
        var t = layer.transform;
        if (t === null || t === undefined) return null;
        var p = t[propName.toLowerCase().replace(/ /g, "")];
        if (p !== null && p !== undefined) return p;
        // Fallback por property name
        return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE " + propName]);
    } catch(e) {
        return null;
    }
};

// ── Atalhos diretos de Transform ──
AE.position = function(layer) {
    if (layer === null || layer === undefined) return null;
    return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Position"]);
};

AE.scale = function(layer) {
    if (layer === null || layer === undefined) return null;
    return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Scale"]);
};

AE.opacity = function(layer) {
    if (layer === null || layer === undefined) return null;
    return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Opacity"]);
};

AE.rotation = function(layer) {
    if (layer === null || layer === undefined) return null;
    return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Rotate Z"]);
};

AE.anchorPoint = function(layer) {
    if (layer === null || layer === undefined) return null;
    return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Anchor Point"]);
};

// ── Setar valor SEGURO (verifica tudo antes) ──
AE.setValue = function(prop, value) {
    if (prop === null || prop === undefined) return false;
    try {
        if (prop.numKeys > 0) {
            // Se tem keyframes, usa setValueAtTime no tempo atual
            prop.setValueAtTime(prop.containingComp ? prop.containingComp.time : 0, value);
        } else {
            prop.setValue(value);
        }
        return true;
    } catch(e) {
        return false;
    }
};

// ── Setar valor no tempo SEGURO ──
AE.setValueAt = function(prop, time, value) {
    if (prop === null || prop === undefined) return false;
    try {
        prop.setValueAtTime(time, value);
        return true;
    } catch(e) {
        return false;
    }
};

// ── Obter valor SEGURO ──
AE.getValue = function(prop) {
    if (prop === null || prop === undefined) return null;
    try {
        return prop.value;
    } catch(e) {
        return null;
    }
};

// ── Adicionar efeito SEGURO ──
AE.addEffect = function(layer, effectMatchName) {
    if (layer === null || layer === undefined) return null;
    try {
        var effects = layer.property("ADBE Effect Parade");
        if (effects === null || effects === undefined) return null;
        var fx = effects.addProperty(effectMatchName);
        return fx;
    } catch(e) {
        return null;
    }
};

// ── Obter propriedade de efeito SEGURO ──
AE.getEffectProp = function(layer, effectName, propName) {
    if (layer === null || layer === undefined) return null;
    try {
        var effects = layer.property("ADBE Effect Parade");
        if (effects === null || effects === undefined) return null;
        var fx = effects.property(effectName);
        if (fx === null || fx === undefined) return null;
        var p = fx.property(propName);
        return p;
    } catch(e) {
        return null;
    }
};

// ── Criar sólido SEGURO ──
AE.addSolid = function(comp, cor, nome, largura, altura) {
    if (comp === null || comp === undefined) return null;
    try {
        largura = largura || comp.width;
        altura = altura || comp.height;
        cor = cor || [0, 0, 0];
        nome = nome || "Solido";
        return comp.layers.addSolid(cor, nome, largura, altura, 1);
    } catch(e) {
        return null;
    }
};

// ── Criar texto SEGURO ──
AE.addText = function(comp, texto, config) {
    if (comp === null || comp === undefined) return null;
    try {
        texto = texto || "";
        config = config || {};
        var layer = comp.layers.addText(texto);
        if (layer === null) return null;

        layer.name = config.nome || texto.substring(0, 20);

        var textProp = AE.getPropChain(layer, ["ADBE Text Properties", "ADBE Text Document"]);
        if (textProp !== null) {
            var doc = textProp.value;
            if (config.fonte) doc.font = config.fonte;
            if (config.tamanho) doc.fontSize = config.tamanho;
            if (config.cor) doc.fillColor = config.cor;
            if (config.tracking !== undefined) doc.tracking = config.tracking;
            if (config.alinhamento) {
                switch(config.alinhamento) {
                    case "center":
                        doc.justification = ParagraphJustification.CENTER_JUSTIFY;
                        break;
                    case "left":
                        doc.justification = ParagraphJustification.LEFT_JUSTIFY;
                        break;
                    case "right":
                        doc.justification = ParagraphJustification.RIGHT_JUSTIFY;
                        break;
                }
            }
            textProp.setValue(doc);
        }

        if (config.posicao) {
            var pos = AE.position(layer);
            if (pos !== null) AE.setValue(pos, config.posicao);
        }

        return layer;
    } catch(e) {
        return null;
    }
};

// ── Criar null SEGURO ──
AE.addNull = function(comp, nome) {
    if (comp === null || comp === undefined) return null;
    try {
        var n = comp.layers.addNull();
        if (n !== null && nome) n.name = nome;
        return n;
    } catch(e) {
        return null;
    }
};

// ── Criar shape layer SEGURO ──
AE.addShape = function(comp, nome) {
    if (comp === null || comp === undefined) return null;
    try {
        var s = comp.layers.addShape();
        if (s !== null && nome) s.name = nome;
        return s;
    } catch(e) {
        return null;
    }
};

// ── Criar composição SEGURO ──
AE.addComp = function(nome, largura, altura, duracao, fps) {
    try {
        nome = nome || "Comp";
        largura = largura || 1080;
        altura = altura || 1920;
        duracao = duracao || 15;
        fps = fps || 30;
        return app.project.items.addComp(nome, largura, altura, 1, duracao, fps);
    } catch(e) {
        return null;
    }
};

// ── Aplicar Easy Ease SEGURO ──
AE.easyEase = function(prop, influence) {
    if (prop === null || prop === undefined) return;
    if (prop.numKeys === 0) return;
    influence = influence || 66;

    try {
        // Detectar dimensão
        var dim = 1;
        var pvt = prop.propertyValueType;
        if (pvt === PropertyValueType.TwoD || pvt === PropertyValueType.TwoD_SPATIAL) dim = 2;
        if (pvt === PropertyValueType.ThreeD || pvt === PropertyValueType.ThreeD_SPATIAL) dim = 3;

        for (var k = 1; k <= prop.numKeys; k++) {
            var eIn = [], eOut = [];
            for (var d = 0; d < dim; d++) {
                eIn.push(new KeyframeEase(0, influence));
                eOut.push(new KeyframeEase(0, influence));
            }
            prop.setTemporalEaseAtKey(k, eIn, eOut);
        }
    } catch(e) {
        // Silenciar erro de ease — não é crítico
    }
};

// ── Aplicar expression SEGURO ──
AE.setExpression = function(prop, expr) {
    if (prop === null || prop === undefined) return false;
    try {
        prop.expression = expr;
        return true;
    } catch(e) {
        return false;
    }
};

// ── Loop seguro por camadas (1-based automaticamente) ──
AE.forEachLayer = function(comp, callback) {
    if (comp === null || comp === undefined) return;
    for (var i = 1; i <= comp.numLayers; i++) {
        var layer = comp.layers[i];
        if (layer !== null && layer !== undefined) {
            callback(layer, i);
        }
    }
};

// ── Loop seguro por propriedades ──
AE.forEachProp = function(propGroup, callback) {
    if (propGroup === null || propGroup === undefined) return;
    try {
        for (var i = 1; i <= propGroup.numProperties; i++) {
            var p = propGroup.property(i);
            if (p !== null && p !== undefined) {
                callback(p, i);
            }
        }
    } catch(e) {}
};

// ── Remover todos os keyframes SEGURO ──
AE.removeAllKeys = function(prop) {
    if (prop === null || prop === undefined) return;
    try {
        while (prop.numKeys > 0) {
            prop.removeKey(1);
        }
    } catch(e) {}
};

// ── Verificar se camada é de um tipo ──
AE.isText = function(layer) {
    if (layer === null || layer === undefined) return false;
    return (layer instanceof TextLayer);
};

AE.isShape = function(layer) {
    if (layer === null || layer === undefined) return false;
    return (layer instanceof ShapeLayer);
};

AE.isCamera = function(layer) {
    if (layer === null || layer === undefined) return false;
    return (layer instanceof CameraLayer);
};

AE.isLight = function(layer) {
    if (layer === null || layer === undefined) return false;
    return (layer instanceof LightLayer);
};

AE.isAV = function(layer) {
    if (layer === null || layer === undefined) return false;
    return (layer instanceof AVLayer);
};

AE.isComp = function(item) {
    if (item === null || item === undefined) return false;
    return (item instanceof CompItem);
};

// ── Hex para RGB [0-1] ──
AE.hex = function(h) {
    h = h.replace("#", "");
    return [
        parseInt(h.substr(0,2), 16) / 255,
        parseInt(h.substr(2,2), 16) / 255,
        parseInt(h.substr(4,2), 16) / 255
    ];
};

// ── Criar retângulo shape SEGURO ──
AE.addRect = function(comp, config) {
    config = config || {};
    var shape = AE.addShape(comp, config.nome || "Rect");
    if (shape === null) return null;

    try {
        var contents = shape.property("ADBE Root Vectors Group");
        var group = contents.addProperty("ADBE Vector Group");
        var vectors = group.property("ADBE Vectors Group");

        var rect = vectors.addProperty("ADBE Vector Shape - Rect");
        rect.property("ADBE Vector Rect Size").setValue(config.tamanho || [200, 200]);
        rect.property("ADBE Vector Rect Roundness").setValue(config.roundness || 0);

        if (config.corFill !== false) {
            var fill = vectors.addProperty("ADBE Vector Graphic - Fill");
            var c = config.corFill || [1, 1, 1];
            fill.property("ADBE Vector Fill Color").setValue([c[0], c[1], c[2], 1]);
        }

        if (config.corStroke) {
            var stroke = vectors.addProperty("ADBE Vector Graphic - Stroke");
            var cs = config.corStroke;
            stroke.property("ADBE Vector Stroke Color").setValue([cs[0], cs[1], cs[2], 1]);
            stroke.property("ADBE Vector Stroke Width").setValue(config.strokeWidth || 2);
        }

        if (config.posicao) AE.setValue(AE.position(shape), config.posicao);

        return shape;
    } catch(e) {
        return null;
    }
};

// ── Criar elipse shape SEGURO ──
AE.addEllipse = function(comp, config) {
    config = config || {};
    var shape = AE.addShape(comp, config.nome || "Ellipse");
    if (shape === null) return null;

    try {
        var contents = shape.property("ADBE Root Vectors Group");
        var group = contents.addProperty("ADBE Vector Group");
        var vectors = group.property("ADBE Vectors Group");

        var ellipse = vectors.addProperty("ADBE Vector Shape - Ellipse");
        var r = config.raio || 50;
        ellipse.property("ADBE Vector Ellipse Size").setValue([r * 2, r * 2]);

        if (config.corFill !== false) {
            var fill = vectors.addProperty("ADBE Vector Graphic - Fill");
            var c = config.corFill || [1, 1, 1];
            fill.property("ADBE Vector Fill Color").setValue([c[0], c[1], c[2], 1]);
        }

        if (config.corStroke) {
            var stroke = vectors.addProperty("ADBE Vector Graphic - Stroke");
            var cs = config.corStroke;
            stroke.property("ADBE Vector Stroke Color").setValue([cs[0], cs[1], cs[2], 1]);
            stroke.property("ADBE Vector Stroke Width").setValue(config.strokeWidth || 2);
        }

        if (config.posicao) AE.setValue(AE.position(shape), config.posicao);

        return shape;
    } catch(e) {
        return null;
    }
};

// ── Animação: Fade In SEGURO ──
AE.animFadeIn = function(layer, tInicio, duracao) {
    if (layer === null) return;
    duracao = duracao || 0.3;
    var op = AE.opacity(layer);
    AE.setValueAt(op, tInicio, 0);
    AE.setValueAt(op, tInicio + duracao, 100);
    AE.easyEase(op);
};

// ── Animação: Fade Out SEGURO ──
AE.animFadeOut = function(layer, tInicio, duracao) {
    if (layer === null) return;
    duracao = duracao || 0.2;
    var op = AE.opacity(layer);
    AE.setValueAt(op, tInicio, 100);
    AE.setValueAt(op, tInicio + duracao, 0);
    AE.easyEase(op);
};

// ── Animação: Fade + Scale In SEGURO ──
AE.animFadeScaleIn = function(layer, tInicio, duracao) {
    if (layer === null) return;
    duracao = duracao || 0.3;
    var op = AE.opacity(layer);
    var sc = AE.scale(layer);
    AE.setValueAt(op, tInicio, 0);
    AE.setValueAt(op, tInicio + duracao, 100);
    AE.setValueAt(sc, tInicio, [85, 85]);
    AE.setValueAt(sc, tInicio + duracao, [100, 100]);
    AE.easyEase(op);
    AE.easyEase(sc);
};

// ── Animação: Slide In SEGURO ──
AE.animSlideIn = function(layer, tInicio, direcao, distancia, duracao) {
    if (layer === null) return;
    duracao = duracao || 0.35;
    distancia = distancia || 200;
    direcao = direcao || "esquerda";

    var pos = AE.position(layer);
    if (pos === null) return;
    var posAtual = AE.getValue(pos);
    if (posAtual === null) return;

    var posInicial;
    switch (direcao) {
        case "esquerda": posInicial = [posAtual[0] - distancia, posAtual[1]]; break;
        case "direita":  posInicial = [posAtual[0] + distancia, posAtual[1]]; break;
        case "cima":     posInicial = [posAtual[0], posAtual[1] - distancia]; break;
        case "baixo":    posInicial = [posAtual[0], posAtual[1] + distancia]; break;
        default:         posInicial = [posAtual[0] - distancia, posAtual[1]];
    }

    AE.setValueAt(pos, tInicio, posInicial);
    AE.setValueAt(pos, tInicio + duracao, posAtual);
    AE.easyEase(pos, 80);

    // Fade junto
    AE.animFadeIn(layer, tInicio, duracao * 0.5);
};

// ── Animação: Pop In (overshoot) SEGURO ──
AE.animPopIn = function(layer, tInicio) {
    if (layer === null) return;
    var sc = AE.scale(layer);
    var op = AE.opacity(layer);
    AE.setValueAt(op, tInicio, 0);
    AE.setValueAt(op, tInicio + 0.1, 100);
    AE.setValueAt(sc, tInicio, [0, 0]);
    AE.setValueAt(sc, tInicio + 0.25, [108, 108]);
    AE.setValueAt(sc, tInicio + 0.4, [100, 100]);
    AE.easyEase(sc);
    AE.easyEase(op);
};

// ── Animação: Stagger (lista de layers) SEGURO ──
AE.animStagger = function(layers, tInicio, intervalo, tipo) {
    if (layers === null || layers === undefined) return;
    intervalo = intervalo || 0.08;
    tipo = tipo || "fadeScale";

    for (var i = 0; i < layers.length; i++) {
        if (layers[i] === null) continue;
        var t = tInicio + (i * intervalo);

        // Esconder antes
        var opPre = AE.opacity(layers[i]);
        if (opPre !== null) {
            AE.setValueAt(opPre, 0, 0);
            if (t > 0.02) AE.setValueAt(opPre, t - 0.01, 0);
        }

        switch (tipo) {
            case "fadeScale":
                AE.animFadeScaleIn(layers[i], t, 0.3);
                break;
            case "slideEsquerda":
                AE.animSlideIn(layers[i], t, "esquerda", 150, 0.35);
                break;
            case "slideDireita":
                AE.animSlideIn(layers[i], t, "direita", 150, 0.35);
                break;
            case "slideBaixo":
                AE.animSlideIn(layers[i], t, "baixo", 100, 0.3);
                break;
            case "slideCima":
                AE.animSlideIn(layers[i], t, "cima", 100, 0.3);
                break;
            case "pop":
                AE.animPopIn(layers[i], t);
                break;
        }
    }
};
```

---

## 2. COMO USAR A BIBLIOTECA (EXEMPLOS)

### Antes (código que QUEBRA):
```javascript
// ❌ TUDO ISSO PODE DAR "null is not an object"
var comp = app.project.activeItem;
var layer = comp.layers[1];
layer.transform.position.setValue([540, 960]);
layer.transform.opacity.setValueAtTime(0, 0);
layer.property("ADBE Effect Parade").addProperty("ADBE Gaussian Blur 2");
```

### Depois (código que NUNCA QUEBRA):
```javascript
// ✅ IMPOSSÍVEL dar null error
var comp = AE.requireComp();
if (comp === null) return;

var layer = AE.getLayer(comp, 1);
if (layer === null) { alert("Camada não encontrada."); return; }

AE.setValue(AE.position(layer), [540, 960]);
AE.setValueAt(AE.opacity(layer), 0, 0);
AE.addEffect(layer, "ADBE Gaussian Blur 2");
```

---

## 3. TEMPLATE OBRIGATÓRIO DE SCRIPT

A partir de agora, TODO script que você gerar DEVE seguir exatamente esta estrutura:

```javascript
(function() {
    // ╔══════════════════════════════════════╗
    // ║  [NOME DO SCRIPT]                    ║
    // ║  [Descrição breve]                   ║
    // ╚══════════════════════════════════════╝

    // ════════════════════════════════════════
    // BIBLIOTECA DE SEGURANÇA
    // ════════════════════════════════════════
    var AE = {};
    // ... (COLE A BIBLIOTECA COMPLETA AQUI) ...

    // ════════════════════════════════════════
    // INÍCIO DO SCRIPT
    // ════════════════════════════════════════
    app.beginUndoGroup("Nome da Operação");

    try {
        // Se precisa de composição existente:
        var comp = AE.requireComp();
        if (comp === null) return;

        // OU se cria composição nova:
        // var comp = AE.addComp("Minha Comp", 1080, 1920, 15, 30);
        // if (comp === null) { alert("Erro ao criar composição."); return; }

        // ── Cores ──
        var cores = {
            fundo: AE.hex("#0D1117"),
            primaria: AE.hex("#58A6FF"),
            texto: AE.hex("#FFFFFF")
        };

        // ── Seu código aqui usando APENAS funções AE.xxx ──

    } catch (e) {
        alert("Erro: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();
```

---

## 4. REGRAS ABSOLUTAS (NÃO NEGOCE)

### NUNCA FAÇA:
```javascript
// ❌ PROIBIDO — Acesso direto sem verificação
comp.layers[1].transform.position.setValue(...)
layer.property("ADBE Transform Group").property("ADBE Position")
app.project.activeItem.selectedLayers
layer.property("ADBE Effect Parade").addProperty(...)
```

### SEMPRE FAÇA:
```javascript
// ✅ OBRIGATÓRIO — Usar funções AE.xxx
AE.setValue(AE.position(layer), [...])
AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Position"])
AE.getSelectedLayers(comp)
AE.addEffect(layer, "...")
```

### CHECKLIST MENTAL ANTES DE CADA LINHA:

1. Estou acessando uma propriedade? → Use `AE.getProp()` ou `AE.getPropChain()`
2. Estou setando um valor? → Use `AE.setValue()` ou `AE.setValueAt()`
3. Estou lendo um valor? → Use `AE.getValue()`
4. Estou pegando uma camada? → Use `AE.getLayer()` ou `AE.getLayerByName()`
5. Estou criando algo? → Use `AE.addText()`, `AE.addSolid()`, `AE.addRect()`, etc.
6. Estou animando? → Use `AE.animFadeIn()`, `AE.animSlideIn()`, `AE.animStagger()`, etc.
7. Estou adicionando efeito? → Use `AE.addEffect()`
8. Estou aplicando ease? → Use `AE.easyEase()`

### SE NÃO EXISTE UMA FUNÇÃO AE.xxx PARA O QUE VOCÊ PRECISA:
Antes de escrever código direto, CRIE uma nova função AE.xxx que faz a verificação null internamente. NUNCA escreva código "solto" que acessa propriedades diretamente.

---

## 5. POR QUE ISSO FUNCIONA

Cada função `AE.xxx` faz internamente:
1. Verifica se o `parent` é null → retorna null em vez de dar erro
2. Usa try/catch → captura erros inesperados silenciosamente
3. Verifica tipos → garante que o objeto é do tipo correto
4. Retorna null em vez de lançar exceção → o código continua rodando

Isso significa que MESMO se o modelo cometer um erro de lógica (tentar acessar algo que não existe), o script NÃO vai quebrar com "null is not an object". No máximo, a operação simplesmente não vai funcionar — mas o script continua rodando e mostra um alert limpo no final se algo der errado.
