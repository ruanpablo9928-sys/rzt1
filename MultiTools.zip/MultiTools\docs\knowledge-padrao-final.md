# ADDON FINAL — PADRAO DE QUALIDADE OBRIGATORIO

Este addon substitui e consolida TODOS os anteriores. Ele define o padrao UNICO que a IA deve seguir para gerar scripts de After Effects. Baseado no script "SaaS Product Demo UI" que funcionou PERFEITAMENTE sem nenhum bug.

## REGRA ABSOLUTA: TODO SCRIPT DEVE SEGUIR ESTE PADRAO

---

## 1. ESTRUTURA OBRIGATORIA DO SCRIPT

Todo script DEVE seguir exatamente esta estrutura. Sem excecoes.

```javascript
(function() {
    // ╔═══════════════════════════════════════════╗
    // ║  [NOME DO PROJETO] (WxH @ fps — duracaos) ║
    // ╚═══════════════════════════════════════════╝

    // === BIBLIOTECA (copiar SEMPRE) ===
    var AE={};
    AE.gc=function(p,ns){var c=p;for(var i=0;i<ns.length;i++){try{c=c.property(ns[i])}catch(e){return null}if(!c)return null}return c};
    AE.pos=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Position"]):null};
    AE.scl=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Scale"]):null};
    AE.opa=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Opacity"]):null};
    AE.rot=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Rotate Z"]):null};
    AE.rX=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Rotate X"]):null};
    AE.rY=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Rotate Y"]):null};
    AE.sv=function(p,v){if(!p)return;try{p.setValue(v)}catch(e){}};
    AE.sa=function(p,t,v){if(!p)return;try{p.setValueAtTime(t,v)}catch(e){}};
    AE.gv=function(p){if(!p)return null;try{return p.value}catch(e){return null}};
    AE.hex=function(h){h=h.replace("#","");return[parseInt(h.substr(0,2),16)/255,parseInt(h.substr(2,2),16)/255,parseInt(h.substr(4,2),16)/255]};
    AE.ease=function(p,inf){if(!p||p.numKeys===0)return;inf=inf||80;try{var d=1,v=p.propertyValueType;if(v===PropertyValueType.TwoD||v===PropertyValueType.TwoD_SPATIAL)d=2;if(v===PropertyValueType.ThreeD||v===PropertyValueType.ThreeD_SPATIAL)d=3;for(var k=1;k<=p.numKeys;k++){var ei=[],eo=[];for(var j=0;j<d;j++){ei.push(new KeyframeEase(0,inf));eo.push(new KeyframeEase(0,inf))}p.setTemporalEaseAtKey(k,ei,eo)}}catch(e){}};
    AE.snap=function(p){AE.ease(p,90)};
    AE.fx=function(l,mn){if(!l)return null;try{return l.property("ADBE Effect Parade").addProperty(mn)}catch(e){return null}};

    // === CRIADORES (copiar SEMPRE) ===
    function SH(comp,n){try{var s=comp.layers.addShape();if(s&&n)s.name=n;return s}catch(e){return null}}

    function EL(comp,cfg){
        cfg=cfg||{};var s=SH(comp,cfg.n||"E");if(!s)return null;
        try{var v=s.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group").property("ADBE Vectors Group");
        var el=v.addProperty("ADBE Vector Shape - Ellipse");var r=cfg.r||50;el.property("ADBE Vector Ellipse Size").setValue([r*2,r*2]);
        if(cfg.fc!==false){var f=v.addProperty("ADBE Vector Graphic - Fill");var c=cfg.fc||[1,1,1];f.property("ADBE Vector Fill Color").setValue([c[0],c[1],c[2],1])}
        if(cfg.sc){var st=v.addProperty("ADBE Vector Graphic - Stroke");st.property("ADBE Vector Stroke Color").setValue([cfg.sc[0],cfg.sc[1],cfg.sc[2],1]);st.property("ADBE Vector Stroke Width").setValue(cfg.sw||2)}
        if(cfg.p)AE.sv(AE.pos(s),cfg.p);if(cfg.d3)s.threeDLayer=true;return s}catch(e){return null}
    }

    function RC(comp,cfg){
        cfg=cfg||{};var s=SH(comp,cfg.n||"R");if(!s)return null;
        try{var v=s.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group").property("ADBE Vectors Group");
        var r=v.addProperty("ADBE Vector Shape - Rect");r.property("ADBE Vector Rect Size").setValue(cfg.sz||[200,200]);
        r.property("ADBE Vector Rect Roundness").setValue(cfg.rn||0);
        if(cfg.fc!==false){var f=v.addProperty("ADBE Vector Graphic - Fill");var c=cfg.fc||[1,1,1];f.property("ADBE Vector Fill Color").setValue([c[0],c[1],c[2],1])}
        if(cfg.sc){var st=v.addProperty("ADBE Vector Graphic - Stroke");st.property("ADBE Vector Stroke Color").setValue([cfg.sc[0],cfg.sc[1],cfg.sc[2],1]);st.property("ADBE Vector Stroke Width").setValue(cfg.sw||2)}
        if(cfg.p)AE.sv(AE.pos(s),cfg.p);if(cfg.d3)s.threeDLayer=true;return s}catch(e){return null}
    }

    function TX(comp,t,cfg){
        if(!comp)return null;try{cfg=cfg||{};var l=comp.layers.addText(t||"");if(!l)return null;
        l.name=cfg.n||"T";var tp=AE.gc(l,["ADBE Text Properties","ADBE Text Document"]);
        if(tp){var d=tp.value;d.font=cfg.f||"Arial-BoldMT";d.fontSize=cfg.s||30;d.fillColor=cfg.c||[0,0,0];
        d.tracking=cfg.tr!==undefined?cfg.tr:0;
        if(cfg.al==="c")d.justification=ParagraphJustification.CENTER_JUSTIFY;
        if(cfg.al==="l")d.justification=ParagraphJustification.LEFT_JUSTIFY;
        if(cfg.al==="r")d.justification=ParagraphJustification.RIGHT_JUSTIFY;
        tp.setValue(d)}if(cfg.p)AE.sv(AE.pos(l),cfg.p);return l}catch(e){return null}
    }

    function SLD(comp,cor,n,w,h){try{return comp.layers.addSolid(cor||[0,0,0],n||"S",w||comp.width,h||comp.height,1)}catch(e){return null}}

    // === SPRING EXPRESSION (copiar SEMPRE) ===
    function springExpr(tStart, destVal, tension, friction) {
        return [
            "var t = time - " + tStart + ";",
            "if (t < 0) [0,0];",
            "else {",
            "  var dest = " + destVal + ";",
            "  var tens = " + (tension||14) + ";",
            "  var fric = " + (friction||7) + ";",
            "  var amp = 1;",
            "  var spring = amp * Math.exp(-fric * t) * Math.cos(tens * t);",
            "  var v = dest * (1 - spring);",
            "  [v, v];",
            "}"
        ].join("\n");
    }

    // === INICIO ===
    app.beginUndoGroup("[Nome]");
    try {
        var comp = app.project.items.addComp("[Nome]", 1080, 1920, 1, 10, 30);
        if (!comp) { alert("Erro."); return; }
        var CX = 540, CY = 960;

        // ... CENAS AQUI ...

        alert("Criado com sucesso!");
    } catch(e) {
        alert("Erro: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();
```

---

## 2. COMO CRIAR ELEMENTOS — PADRAO EXATO

### Retangulo arredondado (Card, Botao, Pill)
```javascript
var card = RC(comp, {p:[540,960], sz:[600,200], rn:30, fc:[1,1,1], n:"MeuCard"});
// Com stroke:
var card = RC(comp, {p:[540,960], sz:[600,200], rn:30, fc:[1,1,1], sc:[0.9,0.9,0.9], sw:2, n:"MeuCard"});
```

### Circulo/Elipse
```javascript
var circ = EL(comp, {p:[540,960], r:50, fc:AE.hex("#FF0000"), n:"MeuCirc"});
// Com stroke:
var circ = EL(comp, {p:[540,960], r:50, fc:false, sc:AE.hex("#00FF00"), sw:3, n:"MeuCirc"});
```

### Texto
```javascript
var txt = TX(comp, "Meu Texto", {p:[540,960], s:40, c:[0,0,0], f:"Arial-BoldMT", al:"c", n:"MeuTxt"});
// al: "c"=center, "l"=left, "r"=right
// f: "Arial-BoldMT", "ArialMT", "Courier", "Helvetica-Bold"
```

### Solido (Fundo)
```javascript
var bg = SLD(comp, AE.hex("#FFFFFF"), "BG");
```

---

## 3. COMO ANIMAR — SPRING BOUNCE EXPRESSION

Este eh o padrao que funcionou perfeitamente. SEMPRE usar springExpr para pop in.

```javascript
// Pop in com spring (aparece de scale 0 com bounce)
var meuLayer = RC(comp, {p:[540,960], sz:[400,100], rn:50, fc:[1,1,1], n:"Btn"});
if (meuLayer) {
    meuLayer.inPoint = 2.0;
    meuLayer.outPoint = 5.0;
    var sc = AE.scl(meuLayer);
    if (sc) sc.expression = springExpr(2.0, 100, 14, 6);
    // tension 14, friction 6 = bounce padrao
    // tension 16, friction 7 = bounce mais rapido e agressivo
    // tension 12, friction 5 = bounce mais suave e lento
}
```

### Fade in simples (pra textos secundarios)
```javascript
AE.sa(AE.opa(layer), 2.0, 0);
AE.sa(AE.opa(layer), 2.3, 100);
// SEM ease — fade linear rapido eh melhor pra textos que acompanham
```

### Spring Scale Out (saida)
```javascript
AE.sa(AE.scl(layer), 5.0, [100,100]);
AE.sa(AE.scl(layer), 5.3, [0,0]);
AE.ease(AE.scl(layer), 80);
```

---

## 4. SOMBRAS — PADRAO EXATO

SEMPRE adicionar sombra em cards, botoes e icones.

```javascript
var sh = AE.fx(layer, "ADBE Drop Shadow");
if (sh) {
    AE.sv(AE.gc(sh,["ADBE Drop Shadow-0002"]), 15);   // Opacity (10-20)
    AE.sv(AE.gc(sh,["ADBE Drop Shadow-0005"]), 4);    // Distance (2-8)
    AE.sv(AE.gc(sh,["ADBE Drop Shadow-0006"]), 20);   // Softness (15-35)
}
```

---

## 5. FUNDOS — GRADIENTE COM RAMP

```javascript
var bg = SLD(comp, [1,1,1], "BG");
if (bg) {
    bg.moveToEnd(); // SEMPRE mover pro final
    var ramp = AE.fx(bg, "ADBE Ramp");
    if (ramp) {
        AE.sv(AE.gc(ramp,["ADBE Ramp-0001"]), [540, 0]);       // start point
        AE.sv(AE.gc(ramp,["ADBE Ramp-0002"]), AE.hex("ED886B")); // start color
        AE.sv(AE.gc(ramp,["ADBE Ramp-0003"]), [540, 1920]);    // end point
        AE.sv(AE.gc(ramp,["ADBE Ramp-0004"]), AE.hex("8793D6")); // end color
        AE.sv(AE.gc(ramp,["ADBE Ramp-0005"]), 2);               // 1=linear, 2=radial
    }
}
```

---

## 6. GLOW — ELIPSE COM BLUR

```javascript
var glow = EL(comp, {p:[540,500], r:400, fc:AE.hex("#70E0F8"), n:"Glow"});
if (glow) {
    AE.sv(AE.opa(glow), 10);  // opacidade baixa (5-15)
    var gb = AE.fx(glow, "ADBE Gaussian Blur 2");
    if (gb) AE.sv(AE.gc(gb,["ADBE Gaussian Blur 2-0001"]), 150);  // blur alto (100-200)
    glow.moveToEnd(); // SEMPRE atras de tudo
}
```

---

## 7. TYPEWRITER EXPRESSION

```javascript
// Normal (40 chars/seg)
var typeExpr = "var str = value.toString(); var spd = 40; var t = Math.max(0, time - inPoint); var chars = Math.floor(t * spd); str.substring(0, chars);";

// Rapido (80 chars/seg)
var fastTypeExpr = "var str = value.toString(); var spd = 80; var t = Math.max(0, time - inPoint); var chars = Math.floor(t * spd); str.substring(0, chars);";

// Aplicar:
var txtLayer = TX(comp, "Meu texto que aparece digitando", {p:[540,960], s:35, c:[0,0,0], al:"l", n:"Type"});
if (txtLayer) {
    var tp = AE.gc(txtLayer, ["ADBE Text Properties", "ADBE Text Document"]);
    if (tp) tp.expression = typeExpr;
}
```

---

## 8. ORGANIZACAO POR CENAS

SEMPRE organizar o script por cenas com comentarios claros e separadores visuais.

```javascript
// ═══════════════════════════════════════════════
// CENA 1: [Nome da Cena] (0.0s - 2.0s)
// ═══════════════════════════════════════════════

// ... elementos da cena 1 ...


// ═══════════════════════════════════════════════
// CENA 2: [Nome da Cena] (2.0s - 4.0s)
// ═══════════════════════════════════════════════

// Se tem fundo diferente nesta cena:
var bgCena2 = SLD(comp, [1,1,1], "BG_Cena2");
if (bgCena2) {
    bgCena2.inPoint = 2.0;
    bgCena2.outPoint = 4.0;
    bgCena2.moveToEnd();  // mover ATRAS de tudo
    bgAnterior.moveToEnd(); // mover fundo anterior ATRAS deste
}

// ... elementos da cena 2 ...
```

---

## 9. ORDEM DE LAYERS — REGRA CRITICA

Quando multiplos fundos existem, a ORDEM de moveToEnd() importa. O ULTIMO moveToEnd() fica MAIS atras.

```javascript
// Cena 1 tem fundo gradiente
// Cena 2 tem fundo branco
// Cena 3 tem fundo azul

// Na cena 2:
bgBranco.moveToEnd();      // vai pro fundo
bgGradiente.moveToEnd();   // vai ATRAS do branco

// Na cena 3:
bgAzul.moveToEnd();        // vai pro fundo
bgBranco.moveToEnd();      // vai ATRAS do azul
bgGradiente.moveToEnd();   // vai ATRAS de todos
```

Isso garante que o fundo da cena atual fique VISIVEL e os anteriores ficam atras.

---

## 10. STAGGER — DELAY ENTRE ELEMENTOS

Quando multiplos cards/itens aparecem em sequencia, usar delay incremental.

```javascript
var items = [
    {y:CY-200, texto:"Item 1", cor:AE.hex("#FF0000")},
    {y:CY,     texto:"Item 2", cor:AE.hex("#00FF00")},
    {y:CY+200, texto:"Item 3", cor:AE.hex("#0000FF")}
];

for (var i = 0; i < items.length; i++) {
    var delay = 3.0 + (i * 0.15);  // 0.15s entre cada item

    var card = RC(comp, {p:[CX, items[i].y], sz:[600,140], rn:25, fc:[1,1,1], n:"Card_"+i});
    if (card) {
        card.inPoint = delay;
        card.outPoint = 5.0;
        var sc = AE.scl(card);
        if (sc) sc.expression = springExpr(delay, 100, 14, 6);
    }

    var icon = RC(comp, {p:[CX-220, items[i].y], sz:[70,70], rn:18, fc:items[i].cor, n:"Icon_"+i});
    if (icon) {
        icon.inPoint = delay;
        icon.outPoint = 5.0;
        var isc = AE.scl(icon);
        if (isc) isc.expression = springExpr(delay+0.1, 100, 14, 6);
    }

    var txt = TX(comp, items[i].texto, {p:[CX-140, items[i].y+8], s:30, c:[0,0,0], al:"l", n:"Txt_"+i});
    if (txt) {
        txt.inPoint = delay;
        txt.outPoint = 5.0;
        var tsc = AE.scl(txt);
        if (tsc) tsc.expression = springExpr(delay+0.15, 100, 14, 6);
    }
}
```

---

## 11. CHECKLIST ANTES DE ENTREGAR

Antes de entregar QUALQUER script, verificar mentalmente:

- [ ] Todos os layers tem inPoint e outPoint definidos?
- [ ] Todos os fundos usam moveToEnd() na ordem correta?
- [ ] Todos os cards/botoes tem Drop Shadow?
- [ ] Todas as animacoes usam springExpr ou keyframes com ease?
- [ ] Nenhum texto tem caractere acentuado (a,e,i,o,u com acento)?
- [ ] Todas as strings usam aspas duplas, sem template literals?
- [ ] O script esta envolvido em (function(){...})() ?
- [ ] app.beginUndoGroup e endUndoGroup estao presentes?
- [ ] try/catch/finally esta presente?
- [ ] Os nomes das funcoes sao EXATAMENTE: SH, EL, RC, TX, SLD?
- [ ] As propriedades sao acessadas EXATAMENTE com AE.gc e matchNames corretos?
- [ ] Nenhum let/const/template literal/arrow function/for-of?

---

## 12. ESTILOS DE ANIMACAO DISPONIVEIS

Quando o usuario pedir uma animacao, escolha o estilo adequado:

### UI ANIMATION (Apps, Fintech, SaaS)
- Fundo claro (branco/cinza) com gradiente suave
- Cards brancos arredondados com sombra
- Spring bounce em tudo
- Icones coloridos em quadrados arredondados
- Typewriter em textos de busca/chat
- Transicoes entre cenas via troca de fundo

### KINETIC TYPOGRAPHY (Motivacional, Ads)
- Fundo escuro (preto/cinza escuro)
- Texto enorme centralizado
- Mask reveal (texto sobe de baixo com fade rapido)
- Exit scale (texto cresce e some)
- Gradiente no texto (Ramp)
- Uma palavra por vez, ritmo rapido

### BRUTALISTA (Agressivo, Editorial)
- Fundo preto puro
- Texto ENORME que corta nas bordas
- Posicoes assimetricas (nao centralizado)
- Cortes secos (sem fade, sem ease)
- 3 cores max (preto, branco, vermelho)
- Rotacoes desconfortaveis (-3 a +4 graus)

### STORYTELLING (Viral Reels)
- Fundo claro OU escuro
- Texto narrativo frase por frase
- Anel orbital 3D com bolinhas
- Carrossel 3D de logos/icones
- Placeholders para imagens PNG
- Camera com zoom cinematico

### MOTION GRAPHICS FLAT (Anuncios de marca)
- Cores da marca como paleta
- Cards com informacoes + icones
- Barras de progresso animadas
- Contadores numericos (expression)
- Wipe transitions entre cenas
- CTA final com botao pulsante

### APPLE AD STYLE (Premium, Minimalista)
- Fundo preto > branco > preto (inversoes)
- Mask reveal + exit scale em cada texto
- Brand dot (ponto colorido apos palavras)
- Gradiente no texto (laranja > roxo)
- Circulo expandindo como transicao
- Uma palavra ENORME por vez

---

## 13. EXPRESSOES UTEIS PRONTAS

```javascript
// Wiggle suave (flutuacao)
"wiggle(1, 10)"

// Bounce after keyframes
"var n=0;if(numKeys>0){n=nearestKey(time).index;if(key(n).time>time)n--}if(n==0){t=0}else{t=time-key(n).time}if(n>0&&t<1){var v=velocityAtTime(key(n).time-thisComp.frameDuration/10);value+v*0.06*Math.sin(3*t*2*Math.PI)/Math.exp(5*t)}else{value}"

// Loop de keyframes
"loopOut('cycle')"

// Pulso no botao (scale oscila)
"var t=time-8.0;if(t<0)value;else{var p=Math.sin(t*4)*3;[100+p,100+p]}"

// Cursor piscando
"Math.sin(time*8)>0?100:0"

// Rotacao continua
"time * 30"

// Flutuacao senoidal
"var p=value;[p[0],p[1]+Math.sin(time*2)*8]"

// Contador (0 ate N)
"var i=2.0;var d=1.5;var t=(time-i)/d;t=Math.max(0,Math.min(1,t));t=1-Math.pow(1-t,3);Math.round(100*t)+'%'"

// Typewriter
"var str=value.toString();var spd=40;var t=Math.max(0,time-inPoint);var chars=Math.floor(t*spd);str.substring(0,chars)"
```

---

## 14. NUNCA FACA ISSO

1. NUNCA use `let`, `const`, template literals, arrow functions, `for...of`, `class`
2. NUNCA escreva caracteres acentuados em strings (use ASCII puro)
3. NUNCA crie layers sem definir inPoint/outPoint quando eles nao devem ficar o video todo
4. NUNCA esqueca moveToEnd() nos fundos
5. NUNCA use fade generico (opacity 0>100 com ease) como animacao principal — use spring
6. NUNCA empilhe elementos no mesmo Y sem calcular espacamento
7. NUNCA crie mais de 3 tipos diferentes de animacao no mesmo video — mantenha consistencia
8. NUNCA esqueca Drop Shadow em cards e botoes
9. NUNCA use nomes genericos nos layers ("Shape Layer 1") — nomeie tudo
10. NUNCA gere o script em partes — SEMPRE gere COMPLETO de uma vez
