/**
 * MultiTools — fx-extra.js
 * Novas animações (Wiggle / Fade / Pop / Slide) com preview em tempo real.
 * Estende o objeto global MT sem tocar no main.js.
 */
(function () {
    'use strict';
    var cs = new CSInterface();

    function $(id) { return document.getElementById(id); }
    function setTxt(id, v) { var e = $(id); if (e) e.textContent = v; }

    // ─────────── Metadados dos sliders por efeito ───────────
    var META = {
        wiggle: {
            sliders: [
                { k: 'freq', def: 2, fmt: function (v) { return v.toFixed(1); } },
                { k: 'amp', def: 30, fmt: function (v) { return Math.round(v) + 'px'; } },
                { k: 'rot', def: 0, fmt: function (v) { return Math.round(v) + '°'; } }
            ]
        },
        fade: {
            mode: 'in',
            sliders: [{ k: 'dur', def: 0.8, fmt: function (v) { return v.toFixed(1) + 's'; } }]
        },
        pop: {
            sliders: [
                { k: 'dur', def: 0.6, fmt: function (v) { return v.toFixed(1) + 's'; } },
                { k: 'overshoot', def: 20, fmt: function (v) { return Math.round(v) + '%'; } }
            ]
        },
        slide: {
            mode: 'left',
            sliders: [
                { k: 'dur', def: 0.7, fmt: function (v) { return v.toFixed(1) + 's'; } },
                { k: 'dist', def: 300, fmt: function (v) { return Math.round(v) + 'px'; } }
            ]
        }
    };

    // ─────────── Definição dos efeitos (params, draw, script) ───────────
    var FX = {
        wiggle: {
            params: {},
            draw: function (ctx, W, H, p, prog, time) {
                var amp = p.amp * 0.32;
                var wx = Math.sin(time * p.freq * 1.7) * amp * 0.6 + Math.sin(time * p.freq * 0.9 + 1) * amp * 0.4;
                var wy = Math.cos(time * p.freq * 1.3) * amp * 0.6 + Math.cos(time * p.freq * 0.6 + 2) * amp * 0.4;
                var rot = Math.sin(time * p.freq * 1.1) * (p.rot * Math.PI / 180) * 0.5;
                drawBox(ctx, W / 2 + wx, H / 2 + wy, 70, 46, rot, 1, 1);
            },
            script: function (p) { return 'applyWiggleEffect(' + p.freq + ',' + p.amp + ',' + p.rot + ')'; }
        },
        fade: {
            params: {},
            draw: function (ctx, W, H, p, prog) {
                var a;
                if (FX.fade.mode === 'in') a = prog;
                else if (FX.fade.mode === 'out') a = 1 - prog;
                else a = prog < 0.5 ? prog * 2 : (1 - (prog - 0.5) * 2);
                drawBox(ctx, W / 2, H / 2, 70, 46, 0, a, 1);
            },
            script: function (p, mode) { return 'applyFadeIn(' + p.dur + ',"' + mode + '")'; }
        },
        pop: {
            params: {},
            draw: function (ctx, W, H, p, prog) {
                var s = popScale(prog, p.overshoot);
                drawBox(ctx, W / 2, H / 2, 70, 46, 0, Math.min(1, prog * 3), s);
            },
            script: function (p) { return 'applyPopIn(' + p.dur + ',' + p.overshoot + ')'; }
        },
        slide: {
            params: {},
            draw: function (ctx, W, H, p, prog) {
                var e = 1 - Math.pow(1 - prog, 3);
                var off = (1 - e) * (p.dist * 0.16);
                var dx = 0, dy = 0, dir = FX.slide.mode;
                if (dir === 'left') dx = -off; else if (dir === 'right') dx = off;
                else if (dir === 'top') dy = -off; else dy = off;
                drawBox(ctx, W / 2 + dx, H / 2 + dy, 70, 46, 0, Math.min(1, e + 0.2), 1);
            },
            script: function (p, mode) { return 'applySlideIn(' + p.dur + ',' + p.dist + ',"' + mode + '")'; }
        }
    };

    function popScale(prog, os) {
        if (prog >= 1) return 1;
        var o = 1 + os / 100;
        if (prog < 0.6) return (prog / 0.6) * o;
        return o + (1 - o) * ((prog - 0.6) / 0.4);
    }

    // ─────────── Helpers de desenho (monocromático) ───────────
    function roundRect(ctx, x, y, w, h, r) {
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.arcTo(x + w, y, x + w, y + h, r);
        ctx.arcTo(x + w, y + h, x, y + h, r);
        ctx.arcTo(x, y + h, x, y, r);
        ctx.arcTo(x, y, x + w, y, r);
        ctx.closePath();
    }
    function drawStage(ctx, W, H) {
        ctx.strokeStyle = 'rgba(255,255,255,0.035)'; ctx.lineWidth = 1;
        for (var gx = 0; gx < W; gx += 26) { ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke(); }
        for (var gy = 0; gy < H; gy += 26) { ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke(); }
        ctx.strokeStyle = 'rgba(255,255,255,0.06)'; ctx.setLineDash([3, 3]);
        ctx.beginPath(); ctx.moveTo(W / 2, 0); ctx.lineTo(W / 2, H); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, H / 2); ctx.lineTo(W, H / 2); ctx.stroke();
        ctx.setLineDash([]);
    }
    function drawBox(ctx, cx, cy, w, h, rot, alpha, scale) {
        rot = rot || 0; alpha = (alpha == null ? 1 : alpha); scale = (scale == null ? 1 : scale);
        if (scale <= 0.001 || alpha <= 0.001) return;
        ctx.save();
        ctx.translate(cx, cy); ctx.rotate(rot); ctx.scale(scale, scale);
        ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
        ctx.shadowColor = 'rgba(226,226,230,0.45)'; ctx.shadowBlur = 16;
        ctx.fillStyle = '#e2e2e6';
        roundRect(ctx, -w / 2, -h / 2, w, h, 4); ctx.fill();
        ctx.shadowBlur = 0;
        ctx.fillStyle = 'rgba(18,18,18,0.85)';
        ctx.font = '700 14px "Segoe UI", sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('Aa', 0, 1);
        ctx.restore();
    }

    // ─────────── Loop de preview ───────────
    var rafId = null, t0 = 0, curFx = null;
    function loop() {
        if (curFx) {
            var fx = FX[curFx];
            var canvas = $(curFx + '-canvas');
            if (canvas && fx) {
                var ctx = canvas.getContext('2d');
                var W = canvas.width, H = canvas.height;
                var time = (performance.now() - t0) / 1000;
                var dur = (fx.params && fx.params.dur) ? fx.params.dur : 2;
                var loopT = dur + 0.6;
                var prog = Math.min((time % loopT) / dur, 1);
                ctx.clearRect(0, 0, W, H);
                drawStage(ctx, W, H);
                fx.draw(ctx, W, H, fx.params, prog, time);
            }
        }
        rafId = requestAnimationFrame(loop);
    }
    function start() { stop(); t0 = performance.now(); rafId = requestAnimationFrame(loop); }
    function stop() { if (rafId) { cancelAnimationFrame(rafId); rafId = null; } }
    function restart() { t0 = performance.now(); }

    // ─────────── API pública em MT ───────────
    function ensureMT() { if (typeof window.MT === 'undefined') window.MT = {}; return window.MT; }

    function install() {
        var MT = ensureMT();

        MT.openFx = function (name) {
            curFx = name;
            var ov = $(name + '-overlay');
            if (ov) ov.classList.add('open');
            start();
        };
        MT.closeFx = function (name) {
            var ov = $(name + '-overlay');
            if (ov) ov.classList.remove('open');
            curFx = null;
            stop();
        };
        MT.fxMode = function (name, val) {
            FX[name].mode = val;
            var grp = $(name + '-modes');
            if (grp) {
                var bs = grp.querySelectorAll('.mode-btn');
                for (var i = 0; i < bs.length; i++) {
                    bs[i].classList.toggle('active', bs[i].getAttribute('data-val') === val);
                }
            }
            restart();
        };
        MT.fxPreset = function (name, vals, ev) {
            var m = META[name], fx = FX[name];
            m.sliders.forEach(function (s) {
                if (vals[s.k] != null) {
                    fx.params[s.k] = vals[s.k];
                    var el = $('sl-' + name + '-' + s.k);
                    if (el) el.value = vals[s.k];
                    setTxt('v-' + name + '-' + s.k, s.fmt(vals[s.k]));
                }
            });
            var ov = $(name + '-overlay');
            if (ov) { var pbs = ov.querySelectorAll('.pre'); for (var i = 0; i < pbs.length; i++) pbs[i].classList.remove('active'); }
            var tgt = (ev && ev.currentTarget) || (window.event && window.event.currentTarget);
            if (tgt) tgt.classList.add('active');
            restart();
        };
        MT.applyFx = function (name) {
            var fx = FX[name];
            var script = fx.script(fx.params, fx.mode);
            cs.evalScript(script, function (r) {
                if (r === 'true') {
                    if (MT.toast) MT.toast('Animação aplicada!', false);
                    MT.closeFx(name);
                } else {
                    if (MT.toast) MT.toast('Selecione uma camada', true);
                }
            });
        };
    }

    // ─────────── Wiring (sliders, close, backdrop) ───────────
    function wire() {
        Object.keys(META).forEach(function (name) {
            var m = META[name];
            FX[name].params = FX[name].params || {};
            if (m.mode !== undefined) FX[name].mode = m.mode;

            m.sliders.forEach(function (s) {
                FX[name].params[s.k] = s.def;
                var el = $('sl-' + name + '-' + s.k);
                if (el) {
                    el.value = s.def;
                    setTxt('v-' + name + '-' + s.k, s.fmt(s.def));
                    el.addEventListener('input', function () {
                        var v = parseFloat(this.value);
                        FX[name].params[s.k] = v;
                        setTxt('v-' + name + '-' + s.k, s.fmt(v));
                        restart();
                    });
                }
            });

            var cb = $('close-' + name);
            if (cb) cb.addEventListener('click', function () { window.MT.closeFx(name); });
            var ov = $(name + '-overlay');
            if (ov) ov.addEventListener('click', function (e) { if (e.target === this) window.MT.closeFx(name); });
        });
    }

    install();
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', wire);
    } else {
        wire();
    }
})();
