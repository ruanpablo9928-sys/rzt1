(function() {
    // ╔═════════════════════════════════════════════════════════════╗
    // ║  VIRAL KINETIC TYPOGRAPHY — ESTILO RETENÇÃO ABSOLUTA        ║
    // ║  1080x1920 @ 30fps — 10.0s                                  ║
    // ║  Overshoot Pop-ins, Serif vs Sans, Grid Background Final    ║
    // ╚═════════════════════════════════════════════════════════════╝

    var AE = {};
    AE.gc = function(p, ns) { var c = p; for (var i=0; i<ns.length; i++) { try { c = c.property(ns[i]); } catch(e) { return null; } if (!c) return null; } return c; };
    AE.pos = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Position"]) : null; };
    AE.scl = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Scale"]) : null; };
    AE.opa = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Opacity"]) : null; };
    AE.rot = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Rotate Z"]) : null; };
    AE.rX = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Rotate X"]) : null; };
    AE.sv = function(p, v) { if (!p) return; try { p.setValue(v); } catch(e) {} };
    AE.sa = function(p, t, v) { if (!p) return; try { p.setValueAtTime(t, v); } catch(e) {} };
    AE.hex = function(h) { h = h.replace("#", ""); return [parseInt(h.substr(0,2),16)/255, parseInt(h.substr(2,2),16)/255, parseInt(h.substr(4,2),16)/255]; };
    AE.fx = function(l, mn) { if (!l) return null; try { return l.property("ADBE Effect Parade").addProperty(mn); } catch(e) { return null; } };

    // --- CURVA MANTEIGA MAX (100% INFLUÊNCIA) ---
    AE.maxEase = function(p) {
        if (!p || p.numKeys === 0) return;
        try {
            var d = 1, v = p.propertyValueType;
            if (v === PropertyValueType.TwoD || v === PropertyValueType.TwoD_SPATIAL) d = 2;
            if (v === PropertyValueType.ThreeD || v === PropertyValueType.ThreeD_SPATIAL) d = 3;
            for (var k = 1; k <= p.numKeys; k++) {
                var ei = [], eo = [];
                for (var j = 0; j < d; j++) { ei.push(new KeyframeEase(0, 100)); eo.push(new KeyframeEase(0, 100)); }
                p.setTemporalEaseAtKey(k, ei, eo);
            }
        } catch(e) {}
    };

    function mkSolid(comp, cor, nome) { try { return comp.layers.addSolid(cor, nome, comp.width, comp.height, 1); } catch(e) { return null; } }
    
    function mkRect(comp, pos, tamanho, roundness, corFill, nome) {
        try {
            var s = comp.layers.addShape(); s.name = nome || "Rect";
            var grp = s.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
            var vec = grp.property("ADBE Vectors Group");
            var r = vec.addProperty("ADBE Vector Shape - Rect");
            r.property("ADBE Vector Rect Size").setValue(tamanho);
            r.property("ADBE Vector Rect Roundness").setValue(roundness || 0);
            if (corFill) {
                var f = vec.addProperty("ADBE Vector Graphic - Fill");
                f.property("ADBE Vector Fill Color").setValue(corFill);
            }
            AE.sv(AE.pos(s), pos); return s;
        } catch(e) { return null; }
    }

    function mkText(comp, texto, pos, tamanho, cor, fonte, alinhamento, nome) {
        try {
            var l = comp.layers.addText(texto); l.name = nome || "Txt";
            var tp = AE.gc(l, ["ADBE Text Properties", "ADBE Text Document"]);
            if (tp) {
                var d = tp.value; 
                d.font = fonte; 
                d.fontSize = tamanho; 
                d.fillColor = cor;
                if (alinhamento === "c") d.justification = ParagraphJustification.CENTER_JUSTIFY;
                if (alinhamento === "l") d.justification = ParagraphJustification.LEFT_JUSTIFY;
                tp.setValue(d);
            }
            AE.sv(AE.pos(l), pos); 
            
            // Adiciona sombra brutal para dar leitura no fundo
            var drop = AE.fx(l, "ADBE Drop Shadow");
            if(drop){
                AE.sv(AE.gc(drop, ["ADBE Drop Shadow-0002"]), 50); // Opacity
                AE.sv(AE.gc(drop, ["ADBE Drop Shadow-0005"]), 8);  // Distance
                AE.sv(AE.gc(drop, ["ADBE Drop Shadow-0006"]), 15); // Softness
            }
            return l;
        } catch(e) { return null; }
    }

    // Efeito de Mola Extrema (Jelly Pop-in)
    function springPop(layer, tIn) {
        if(!layer) return;
        var s = AE.scl(layer);
        AE.sa(s, tIn, [0,0]); 
        AE.sa(s, tIn + 0.15, [115,115]); 
        AE.sa(s, tIn + 0.25, [95,95]);
        AE.sa(s, tIn + 0.4, [100,100]);
        AE.maxEase(s);
    }
    
    // Sumiço em corte seco (como no vídeo)
    function cutOut(layer, tOut) {
        if(!layer) return;
        layer.outPoint = tOut;
    }

    app.beginUndoGroup("Viral Typography Generator");

    try {
        var comp = app.project.items.addComp("Edicao_Viral_Retencao", 1080, 1920, 1, 10.0, 30);
        
        var cWhite = AE.hex("#FFFFFF");
        var cYellow = AE.hex("#F4D03F"); // O amarelo característico do vídeo
        var cDark = AE.hex("#111111");
        
        var fSerif = "TimesNewRomanPS-BoldMT"; // Fonte elegante
        var fSans = "Arial-BoldMT"; // Fonte de impacto
        var fItalic = "TimesNewRomanPS-BoldItalicMT"; // Serifada itálica

        // 1. Fundo Escuro Base
        var bg = mkSolid(comp, cDark, "Fundo_Escuro");

        // ─────────────────────────────────────
        // CENA 1 (0.0s - 2.0s): Ponto fora da curva
        // ─────────────────────────────────────
        var t1_1 = mkText(comp, "PONTO", [540, 850], 120, cWhite, fSerif, "c", "T1_Ponto");
        var t1_2 = mkText(comp, "FORA DA CURVA", [540, 1000], 90, cWhite, fSans, "c", "T1_Curva");
        
        springPop(t1_1, 0.2); 
        springPop(t1_2, 0.6);
        cutOut(t1_1, 1.8); cutOut(t1_2, 1.8);

        // ─────────────────────────────────────
        // CENA 2 (2.0s - 4.0s): Não é bom suficiente
        // ─────────────────────────────────────
        var t2_1 = mkText(comp, "NÃO É", [540, 880], 100, cWhite, fSerif, "c", "T2_NaoE");
        var t2_2 = mkText(comp, "BOM SUFICIENTE", [540, 1050], 130, cWhite, fSans, "c", "T2_BomSuficiente");
        
        springPop(t2_1, 2.0);
        springPop(t2_2, 2.3);
        cutOut(t2_1, 3.8); cutOut(t2_2, 3.8);

        // ─────────────────────────────────────
        // CENA 3 (4.0s - 6.0s): Chora? Não. (Com Rotação 3D)
        // ─────────────────────────────────────
        var t3_1 = mkText(comp, "CHORA?", [540, 960], 150, cWhite, fSerif, "c", "T3_Chora");
        t3_1.threeDLayer = true;
        var rX = AE.rX(t3_1);
        AE.sa(rX, 4.0, 90); AE.sa(rX, 4.4, 0); AE.maxEase(rX);
        springPop(t3_1, 4.0);
        cutOut(t3_1, 4.9);

        var t3_2 = mkText(comp, "NÃO.", [540, 960], 200, cYellow, fSans, "c", "T3_Nao");
        springPop(t3_2, 5.0);
        cutOut(t3_2, 5.8);

        // ─────────────────────────────────────
        // CENA 4 (6.0s - 7.5s): que você SE TORNA
        // ─────────────────────────────────────
        var t4_1 = mkText(comp, "que você", [350, 850], 70, cWhite, fItalic, "l", "T4_QueVoce");
        var t4_2 = mkText(comp, "SE TORNA", [540, 1020], 160, cYellow, fSans, "c", "T4_SeTorna");
        
        springPop(t4_1, 6.0);
        springPop(t4_2, 6.2);
        cutOut(t4_1, 7.4); cutOut(t4_2, 7.4);

        // ─────────────────────────────────────
        // CENA 5 (7.5s - 10.0s): PONTO FINAL (Grid Branco)
        // ─────────────────────────────────────
        // Criação do Grid Branco Dinâmico
        var gridBg = mkSolid(comp, AE.hex("#F5F5F5"), "Grid_BG");
        gridBg.inPoint = 7.5;
        
        for(var x = 1; x < 6; x++) {
            var vLine = mkRect(comp, [x * 180, 960], [4, 1920], 0, AE.hex("#D0D0D0"), "VLine_" + x);
            vLine.inPoint = 7.5;
        }
        for(var y = 1; y < 10; y++) {
            var hLine = mkRect(comp, [540, y * 192], [1080, 4], 0, AE.hex("#D0D0D0"), "HLine_" + y);
            hLine.inPoint = 7.5;
        }

        var t5_1 = mkText(comp, "PONTO", [540, 800], 180, cDark, fSans, "c", "T5_Ponto");
        var t5_2 = mkText(comp, "FINAL", [540, 1050], 250, cYellow, fSerif, "c", "T5_Final");
        
        t5_1.inPoint = 7.5; t5_2.inPoint = 7.5;
        springPop(t5_1, 7.5);
        springPop(t5_2, 7.7);

        alert("Pronto! Edição Dinâmica construída.\n\nEste script gerou toda a sequência de tipografia misturando Serifas, Cores de Alto Contraste, Overshoots (Efeito Mola) e terminou com a quebra de padrão visual criando um Grid Branco matemático no fundo.\n\nÉ só encaixar o áudio por baixo!");

    } catch(e) {
        alert("Erro fatal: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();