/**
 * ═══════════════════════════════════════════════════════════════════
 *  CEP AI INTEGRATION — Groq + GPT-OSS-120B (131K context)
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Modelo: openai/gpt-oss-120b via Groq
 *  Context: 131,072 tokens | Max Output: 65,536 tokens | ~500 tps
 *  API: https://api.groq.com/openai/v1/chat/completions (OpenAI-compatible)
 *
 *  COMO USAR:
 *
 *    const ai = new CEPAI("SUA_GROQ_API_KEY");
 *    await ai.loadKnowledge("./knowledge-chunks.json");
 *    const result = await ai.generateScript("cria um video motivacional 10s");
 *    csInterface.evalScript(result.script);
 *
 * ═══════════════════════════════════════════════════════════════════
 */

class CEPAI {
    /**
     * @param {string} apiKey - Chave da API Groq (https://console.groq.com/keys)
     * @param {Object} options - Configuracoes
     */
    constructor(apiKey, options) {
        options = options || {};
        this.apiKey = apiKey;
        this.apiUrl = options.apiUrl || "https://api.groq.com/openai/v1/chat/completions";
        this.model = options.model || "openai/gpt-oss-120b";
        this.maxChunks = options.maxChunks || 3;
        this.maxTokens = Math.min(options.maxTokens || 65536, 65536);
        this.temperature = options.temperature !== undefined ? options.temperature : 0.7;
        this.contextWindow = 131072;

        this.kb = null;
        this.router = null;
        this.builder = null;

        this.onStatus = options.onStatus || function() {};
    }

    /**
     * Carrega o knowledge base
     * @param {string|Object} source - URL do JSON ou objeto direto
     */
    async loadKnowledge(source) {
        this.onStatus("loading", "Carregando base de conhecimento...");

        if (typeof source === "string") {
            var response = await fetch(source);
            this.kb = await response.json();
        } else {
            this.kb = source;
        }

        this.router = new _RAGRouter(this.kb);
        this.builder = new _PromptBuilder(this.kb, this.contextWindow);

        var chunkCount = 0;
        for (var k in this.kb) { if (this.kb[k].tags) chunkCount++; }
        this.onStatus("ready", "Pronto! " + chunkCount + " modulos disponiveis.");
        return this;
    }

    /**
     * ════════════════════════════════════════════
     *  METODO PRINCIPAL — Gera o script completo
     * ════════════════════════════════════════════
     */
    async generateScript(userPrompt) {
        if (!this.kb) throw new Error("loadKnowledge() nao foi chamado!");

        // 1. Classificar prompt e selecionar chunks
        this.onStatus("routing", "Analisando prompt...");
        var route = this.router.route(userPrompt, this.maxChunks);

        // 2. Montar system prompt otimizado
        this.onStatus("building", "Montando contexto (" + route.selectedIds.length + " modulos)...");
        var build = this.builder.build(route.selectedIds, userPrompt);

        // 3. Verificar se cabe no contexto
        if (build.estimatedTokens.total > this.contextWindow * 0.85) {
            this.onStatus("warning", "Prompt grande! Reduzindo chunks...");
            route = this.router.route(userPrompt, 2);
            build = this.builder.build(route.selectedIds, userPrompt);
        }

        this.onStatus("calling", "Gerando via Groq GPT-OSS-120B (~" + build.estimatedTokens.total + " tokens)...");

        // 4. Chamar API Groq
        var rawResponse = await this._callGroq(build.systemPrompt, userPrompt);

        // 5. Extrair script limpo
        this.onStatus("parsing", "Extraindo script...");
        var script = this._extractScript(rawResponse);

        this.onStatus("done", "Script gerado com sucesso!");

        return {
            script: script,
            raw: rawResponse,
            debug: {
                model: this.model,
                chunksUsed: route.selectedIds,
                scores: route.debug.scores.filter(function(s) { return s.score > 0; }),
                tokens: build.estimatedTokens
            }
        };
    }

    /**
     * Gera e roda direto no AE
     */
    async generateAndRun(userPrompt, csInterface) {
        var result = await this.generateScript(userPrompt);
        if (result.script && csInterface && csInterface.evalScript) {
            csInterface.evalScript(result.script, function(res) {
                console.log("AE:", res);
            });
        }
        return result;
    }

    /**
     * Chama a API Groq (OpenAI-compatible)
     */
    async _callGroq(systemPrompt, userMessage) {
        var body = {
            model: this.model,
            messages: [
                { role: "system", content: systemPrompt },
                { role: "user", content: userMessage }
            ],
            max_tokens: this.maxTokens,
            temperature: this.temperature,
            top_p: 0.9,
            stream: false
        };

        var response = await fetch(this.apiUrl, {
            method: "POST",
            headers: {
                "Authorization": "Bearer " + this.apiKey,
                "Content-Type": "application/json"
            },
            body: JSON.stringify(body)
        });

        if (!response.ok) {
            var errText = await response.text();
            throw new Error("Groq API " + response.status + ": " + errText);
        }

        var data = await response.json();

        if (data.choices && data.choices[0] && data.choices[0].message) {
            return data.choices[0].message.content;
        }

        throw new Error("Resposta inesperada: " + JSON.stringify(data));
    }

    /**
     * Extrai script JSX limpo da resposta
     */
    _extractScript(raw) {
        var text = raw || "";

        // Extrair de code block
        var match = text.match(/```(?:jsx|javascript|js)?\s*\n?([\s\S]*?)```/);
        if (match && match[1]) text = match[1].trim();

        // Já é script?
        if (text.indexOf("(function") === 0) return text;

        // Procurar (function...})()
        var start = text.indexOf("(function");
        if (start !== -1) {
            var depth = 0, inStr = false, strCh = "", end = start;
            for (var i = start; i < text.length; i++) {
                var ch = text[i];
                if (inStr) { if (ch === strCh && text[i - 1] !== "\\") inStr = false; continue; }
                if (ch === '"' || ch === "'") { inStr = true; strCh = ch; continue; }
                if (ch === "(") depth++;
                if (ch === ")") { depth--; if (depth === 0) { end = i + 1; if (text[end] === ";") end++; break; } }
            }
            text = text.substring(start, end);
        }

        return text.trim();
    }
}

// ═══════════════════════════════════════════════════
//  RAG ROUTER
// ═══════════════════════════════════════════════════

class _RAGRouter {
    constructor(kb) {
        this.kb = kb;
        this.chunks = [];
        for (var key in kb) {
            if (kb[key].tags) {
                this.chunks.push({ id: kb[key].id, tags: kb[key].tags, priority: kb[key].priority || 1 });
            }
        }
    }

    _normalize(text) {
        return text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
            .replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
    }

    _score(prompt, chunk) {
        var words = prompt.split(" "), score = 0, matched = [];
        for (var t = 0; t < chunk.tags.length; t++) {
            var tag = this._normalize(chunk.tags[t]), parts = tag.split(" ");
            if (parts.length > 1 && prompt.indexOf(tag) !== -1) { score += 3; matched.push(chunk.tags[t]); continue; }
            for (var w = 0; w < words.length; w++) {
                if (words[w].length < 3) continue;
                if (tag === words[w]) { score += 2; matched.push(chunk.tags[t]); }
                else if (tag.indexOf(words[w]) !== -1 || words[w].indexOf(tag) !== -1) { score += 1; matched.push(chunk.tags[t]); }
            }
        }
        return { score: score, matchedTags: matched };
    }

    route(userPrompt, maxChunks) {
        maxChunks = maxChunks || 3;
        var normalized = this._normalize(userPrompt);
        var alwaysInclude = [];
        for (var key in this.kb) { if (this.kb[key].always_include) alwaysInclude.push(this.kb[key].id); }

        var scored = [];
        for (var i = 0; i < this.chunks.length; i++) {
            var r = this._score(normalized, this.chunks[i]);
            scored.push({ id: this.chunks[i].id, score: r.score, matchedTags: r.matchedTags, priority: this.chunks[i].priority });
        }
        scored.sort(function(a, b) { return b.score !== a.score ? b.score - a.score : a.priority - b.priority; });

        var selected = [];
        for (var j = 0; j < scored.length && selected.length < maxChunks; j++) {
            if (scored[j].score > 0) selected.push(scored[j]);
        }
        if (selected.length === 0) {
            for (var k = 0; k < scored.length; k++) { if (scored[k].id === "chunk_creativity") { selected.push(scored[k]); break; } }
            for (var m = 0; m < scored.length; m++) { if (scored[m].id === "chunk_kinetic_typo") { selected.push(scored[m]); break; } }
        }

        var ids = alwaysInclude.slice();
        for (var s = 0; s < selected.length; s++) ids.push(selected[s].id);

        return { selectedIds: ids, debug: { normalizedPrompt: normalized, scores: scored } };
    }
}

// ═══════════════════════════════════════════════════
//  SYSTEM PROMPT BUILDER
// ═══════════════════════════════════════════════════

class _PromptBuilder {
    constructor(kb, contextWindow) {
        this.kb = kb;
        this.contextWindow = contextWindow || 131072;
    }

    build(chunkIds, userPrompt) {
        var parts = [];
        parts.push(this._header());

        var ordered = this._order(chunkIds);
        for (var i = 0; i < ordered.length; i++) {
            if (ordered[i].content) parts.push(ordered[i].content);
        }
        parts.push(this._footer());

        var sys = parts.join("\n\n---\n\n");
        var sT = Math.ceil(sys.length / 4);
        var uT = Math.ceil(userPrompt.length / 4);

        return {
            systemPrompt: sys,
            estimatedTokens: {
                system: sT,
                user: uT,
                total: sT + uT,
                remaining: this.contextWindow - sT - uT - 500,
                maxOutput: Math.min(65536, this.contextWindow - sT - uT - 500)
            },
            chunkCount: ordered.length
        };
    }

    _header() {
        return "# GERADOR DE SCRIPTS EXTENDSCRIPT PARA AFTER EFFECTS\n\nVoce gera scripts .jsx COMPLETOS e FUNCIONAIS (AE 2019+/ExtendScript ES3).\nNUNCA explique — GERE o codigo completo pronto pra rodar.\nSEMPRE responda com um unico bloco (function(){...})().\n\nCOMPORTAMENTO: Leia pedido > Planeje cenas mentalmente > Gere script COMPLETO.\n\nREGRAS: Vertical 1080x1920 30fps (Reels). Use APENAS biblioteca AE e criadores abaixo. NUNCA let/const/arrow/template. NUNCA acentos. SEMPRE nomeie layers. SEMPRE Drop Shadow em cards. SEMPRE try/catch/finally + beginUndoGroup.";
    }

    _footer() {
        return "## SAIDA\nResponda APENAS com codigo .jsx. Sem explicacao. Comeca com (function(){ termina com })();";
    }

    _order(ids) {
        var chunks = [];
        for (var i = 0; i < ids.length; i++) {
            for (var k in this.kb) { if (this.kb[k].id === ids[i]) { chunks.push(this.kb[k]); break; } }
        }
        chunks.sort(function(a, b) { return (a.priority || 0) - (b.priority || 0); });
        return chunks;
    }
}

// ═══════════════════════════════════════════════════
if (typeof module !== "undefined") module.exports = { CEPAI: CEPAI };
