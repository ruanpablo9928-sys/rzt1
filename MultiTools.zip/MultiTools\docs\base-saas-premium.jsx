(function() {
    // ╔═════════════════════════════════════════════════════════════╗
    // ║  PINDOWN.IO STYLE — PREMIUM SAAS MOTION (PT-BR) [CORRIGIDO] ║
    // ║  1080x1920 @ 30fps — 10.0s                                  ║
    // ║  Alinhamento Central Perfeito e Leading Reduzido            ║
    // ╚═════════════════════════════════════════════════════════════╝

    var AE = {};
    AE.gc = function(p, ns) { var c = p; for (var i=0; i<ns.length; i++) { try { c = c.property(ns[i]); } catch(e) { return null; } if (!c) return null; } return c; };
    AE.pos = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Position"]) : null; };
    AE.scl = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Scale"]) : null; };
    AE.opa = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Opacity"]) : null; };
    AE.rot = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Rotate Z"]) : null; };
    AE.anc = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Anchor Point"]) : null; };
    AE.sv = function(p, v) { if (!p) return; try { p.setValue(v); } catch(e) {} };
    AE.sa = function(p, t, v) { if (!p) return; try { p.setValueAtTime(t, v); } catch(e) {} };
    AE.gv = function(p) { if (!p) return null; try { return p.value; } catch(e) { return null; } };
    AE.hex = function(h) { h = h.replace("#", ""); return [parseInt(h.substr(0,2),16)/255, parseInt(h.substr(2,2),16)/255, parseInt(h.substr(4,2),16)/255]; };
    AE.fx = function(l, mn) { if (!l) return null; try { return l.property("ADBE Effect Parade").addProperty(mn); } catch(e) { return null; } };

    // --- CURVA MANTEIGA EXTREMA (100%) ---
    AE.maxEase = function(p) {
        if (!p || p.numKeys === 0) return;
        try {
            var d = 1, v = p.propertyValueType;
            if (v === PropertyValueType.TwoD || v === PropertyValueType.TwoD_SPATIAL) d = 2;
            if (v === PropertyValueType.ThreeD || v === PropertyValueType.ThreeD_SPATIAL) d = 3;
            for (var k = 1; k <= p.numKeys; k++) {
                var ei = [], eo = [];
                for (var j = 0; j < d; j++) { ei.push(new KeyframeEase(0, 100)); eo.push(new KeyframeEase(0, 100)); }
                p.setTemporalEaseAtKey(k, ei, eo);
            }
        } catch(e) {}
    };

    // --- CORREÇÃO DE ALINHAMENTO E ESPAÇAMENTO (LEADING) ---
    function centerAnchor(layer) {
        if(!layer || !layer.sourceRectAtTime) return;
        try {
            var rect = layer.sourceRectAtTime(0, false);
            // Calcula o centro matemático da caixa de texto
            AE.sv(AE.anc(layer), [rect.left + rect.width / 2, rect.top + rect.height / 2]);
        } catch(e) {}
    }

    function mkText(comp, texto, pos, tamanho, cor, leading, nome) {
        try {
            var l = comp.layers.addText(texto); l.name = nome || "Txt";
            var tp = AE.gc(l, ["ADBE Text Properties", "ADBE Text Document"]);
            if (tp) {
                var d = tp.value; 
                d.font = "Arial-BoldMT"; 
                d.fontSize = tamanho || 30; 
                d.fillColor = cor || [1, 1, 1];
                d.justification = ParagraphJustification.CENTER_JUSTIFY; // Alinha os parágrafos
                d.leading = leading || tamanho * 1.1; // Força o Leading reduzido (colado)
                tp.setValue(d);
            }
            centerAnchor(l); // Centraliza a âncora no centro matemático
            AE.sv(AE.pos(l), pos); return l;
        } catch(e) { return null; }
    }

    // --- OUTRAS FERRAMENTAS ---
    function applyShadow(layer, opac, dist, blur) {
        var drop = AE.fx(layer, "ADBE Drop Shadow");
        if(drop) { AE.sv(AE.gc(drop, ["ADBE Drop Shadow-0002"]), opac || 15); AE.sv(AE.gc(drop, ["ADBE Drop Shadow-0005"]), dist || 10); AE.sv(AE.gc(drop, ["ADBE Drop Shadow-0006"]), blur || 40); }
    }

    function applyBlur(layer, amount) {
        var blurFx = AE.fx(layer, "ADBE Gaussian Blur 2");
        if(blurFx) AE.sv(AE.gc(blurFx, ["ADBE Gaussian Blur 2-0001"]), amount || 200); 
    }

    function smoothPopIn(layer, tIn, dur, so) {
        if(!layer) return;
        var s = AE.scl(layer), o = AE.opa(layer);
        var scale = so || 100;
        var d = dur || 0.8;
        AE.sa(s, tIn, [scale * 0.8, scale * 0.8]); AE.sa(s, tIn + d, [scale, scale]); AE.maxEase(s);
        AE.sa(o, tIn, 0); AE.sa(o, tIn + (d*0.6), 100); AE.maxEase(o);
    }

    function smoothFadeOut(layer, tOut) {
        if(!layer) return;
        var o = AE.opa(layer), s = AE.scl(layer);
        var so = AE.gv(s);
        AE.sa(o, tOut, 100); AE.sa(o, tOut + 0.5, 0); AE.maxEase(o);
        AE.sa(s, tOut, so); AE.sa(s, tOut + 0.5, [so[0]*1.1, so[1]*1.1]); AE.maxEase(s);
    }

    function mkSolid(comp, cor, nome) { try { return comp.layers.addSolid(cor, nome, comp.width, comp.height, 1); } catch(e) { return null; } }
    function mkRect(comp, pos, tamanho, roundness, corFill, nome) {
        try {
            var s = comp.layers.addShape(); s.name = nome || "Rect";
            var vec = s.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group").property("ADBE Vectors Group");
            var r = vec.addProperty("ADBE Vector Shape - Rect");
            r.property("ADBE Vector Rect Size").setValue(tamanho);
            r.property("ADBE Vector Rect Roundness").setValue(roundness || 0);
            if (corFill) { var f = vec.addProperty("ADBE Vector Graphic - Fill"); f.property("ADBE Vector Fill Color").setValue(corFill); }
            AE.sv(AE.pos(s), pos); return s;
        } catch(e) { return null; }
    }
    function mkEllipse(comp, pos, raio, corFill, nome) {
        try {
            var s = comp.layers.addShape(); s.name = nome || "Ell";
            var vec = s.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group").property("ADBE Vectors Group");
            var el = vec.addProperty("ADBE Vector Shape - Ellipse");
            el.property("ADBE Vector Ellipse Size").setValue([raio * 2, raio * 2]);
            if (corFill) { var f = vec.addProperty("ADBE Vector Graphic - Fill"); f.property("ADBE Vector Fill Color").setValue(corFill); }
            AE.sv(AE.pos(s), pos); return s;
        } catch(e) { return null; }
    }

    app.beginUndoGroup("PinDown Style [Alinhado]");

    try {
        var comp = app.project.items.addComp("PinDown_Alinhado", 1080, 1920, 1, 10.0, 30);
        
        // Cores
        var cWhite = AE.hex("#FAFAFA"), cDarkText = AE.hex("#2D2D35"), cMagenta = AE.hex("#E81CFF"), cPurple = AE.hex("#7A00FF"), cLightPurple = AE.hex("#E6D4FF");

        // 1. Fundo e Aurora
        mkSolid(comp, cWhite, "BG_Branco");
        var blob1 = mkEllipse(comp, [200, 400], 400, cMagenta, "Blob1"); applyBlur(blob1, 350); AE.sa(AE.pos(blob1), 0, [200, 400]); AE.sa(AE.pos(blob1), 10, [800, 900]); AE.maxEase(AE.pos(blob1)); AE.sv(AE.opa(blob1), 50);
        var blob2 = mkEllipse(comp, [800, 1400], 500, cPurple, "Blob2"); applyBlur(blob2, 450); AE.sa(AE.pos(blob2), 0, [800, 1400]); AE.sa(AE.pos(blob2), 10, [200, 600]); AE.maxEase(AE.pos(blob2)); AE.sv(AE.opa(blob2), 40);

        // ─────────────────────────────────────
        // CENA 1: Centralizado e Colado
        // ─────────────────────────────────────
        // Reduzi o Leading para 60 e 100 respectivamente, deixando as linhas coladas.
        var t1 = mkText(comp, "Dê a sua equipe\nsuperpoderes", [540, 960], 65, cDarkText, 60, "T1_Team");
        // Substituindo a segunda linha por uma nova cor e tamanho no After Effects (simulando via script)
        var t1b = mkText(comp, "Dê a sua equipe", [540, 930], 65, cDarkText, 0, "T1_1");
        var t1c = mkText(comp, "superpoderes", [540, 1030], 110, cMagenta, 0, "T1_2");
        l1 = comp.layer("T1_Team"); l1.remove(); // Remove o original quebrado

        smoothPopIn(t1b, 0.5); smoothPopIn(t1c, 0.8);
        smoothFadeOut(t1b, 3.2); smoothFadeOut(t1c, 3.3);

        // Cursor
        var cursor = mkText(comp, "↖", [800, 1400], 100, cDarkText, 0, "Cursor"); applyShadow(cursor, 30, 10, 20);
        AE.sa(AE.opa(cursor), 1.2, 0); AE.sa(AE.opa(cursor), 1.5, 100);
        AE.sa(AE.pos(cursor), 1.2, [800, 1400]); AE.sa(AE.pos(cursor), 2.2, [650, 1000]); AE.maxEase(AE.pos(cursor));
        AE.sa(AE.scl(cursor), 2.2, [100,100]); AE.sa(AE.scl(cursor), 2.3, [80,80]); AE.sa(AE.scl(cursor), 2.4, [100,100]);
        smoothFadeOut(cursor, 3.0);

        // ─────────────────────────────────────
        // CENA 2: "Help them unlock their" (3.5s)
        // ─────────────────────────────────────
        var blob3 = mkEllipse(comp, [540, 960], 600, cPurple, "Blob3"); applyBlur(blob3, 200);
        AE.sa(AE.opa(blob3), 3.2, 0); AE.sa(AE.opa(blob3), 3.6, 90); AE.sa(AE.opa(blob3), 6.5, 0); AE.maxEase(AE.opa(blob3));
        AE.sa(AE.scl(blob3), 3.2, [0,0]); AE.sa(AE.scl(blob3), 6.5, [250,250]); AE.maxEase(AE.scl(blob3));

        // Leading reduzido para 85 (colado)
        var t2 = mkText(comp, "Ajude-os a\ndesbloquear o", [540, 960], 90, cWhite, 85, "T2_Help");
        smoothPopIn(t2, 3.6);
        smoothFadeOut(t2, 5.8);

        // ─────────────────────────────────────
        // CENA 3: O Botão "9x better" (6.5s)
        // ─────────────────────────────────────
        var t3 = mkText(comp, "potencial com", [540, 750], 45, cDarkText, 0, "T3_Potencial");
        smoothPopIn(t3, 6.2);

        // Ripples
        for(var r=0; r<3; r++) {
            var rip = mkRect(comp, [540, 960], [450, 140], 70, null, "Rip_" + r);
            var ripGrp = rip.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group");
            ripGrp.addProperty("ADBE Vector Graphic - Stroke").property("ADBE Vector Stroke Color").setValue(cLightPurple);
            AE.sa(AE.opa(rip), 6.8 + (r*0.4), 0); AE.sa(AE.opa(rip), 6.9 + (r*0.4), 80); AE.sa(AE.opa(rip), 8.3 + (r*0.4), 0); AE.maxEase(AE.opa(rip));
            AE.sa(AE.scl(rip), 6.8 + (r*0.4), [90,90]); AE.sa(AE.scl(rip), 8.3 + (r*0.4), [160,160]); AE.maxEase(AE.scl(rip));
        }

        var btn = mkRect(comp, [540, 960], [400, 120], 60, cLightPurple, "Btn"); applyShadow(btn);
        var btnT = mkText(comp, "9x melhor", [540, 975], 45, cPurple, 0, "BtnT");
        smoothPopIn(btn, 6.5); smoothPopIn(btnT, 6.6);

        alert("SUCESSO! Alinhamento e espaçamento corrigidos. ✅\n\nPrincipais mudanças:\n1. Nova função `centerAnchor` que força o ponto de ancoragem para o centro matemático exato da caixa de texto, garantindo que `Justification.CENTER_JUSTIFY` centralize o bloco inteiro na tela.\n2.leading (Espaçamento entre linhas) reduzido para os valores oficiais modernos (ex: 60px Leading para 65px de fonte), deixando as palavras coladas.");

    } catch(e) {
        alert("Erro fatal: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();