(function() {
    // ╔═══════════════════════════════════════════════════════╗
    // ║  ANUNCIO PICPAY - 15 SEGUNDOS - REELS/SHORTS         ║
    // ║  Motion Graphics Flat Design - 1080x1920 - 30fps     ║
    // ╚═══════════════════════════════════════════════════════╝

    // ════════════════════════════════════════════════════════
    // BIBLIOTECA DE SEGURANCA AE
    // ════════════════════════════════════════════════════════
    var AE = {};
    AE.getProp = function(parent, propName) { if (parent === null || parent === undefined) return null; try { var p = parent.property(propName); if (p === null || p === undefined) return null; return p; } catch(e) { return null; } };
    AE.getPropChain = function(parent, propNames) { var current = parent; for (var i = 0; i < propNames.length; i++) { current = AE.getProp(current, propNames[i]); if (current === null) return null; } return current; };
    AE.position = function(layer) { if (!layer) return null; return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Position"]); };
    AE.scale = function(layer) { if (!layer) return null; return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Scale"]); };
    AE.opacity = function(layer) { if (!layer) return null; return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Opacity"]); };
    AE.rotation = function(layer) { if (!layer) return null; return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Rotate Z"]); };
    AE.anchorPoint = function(layer) { if (!layer) return null; return AE.getPropChain(layer, ["ADBE Transform Group", "ADBE Anchor Point"]); };
    AE.setValue = function(prop, value) { if (!prop) return false; try { prop.setValue(value); return true; } catch(e) { return false; } };
    AE.setValueAt = function(prop, time, value) { if (!prop) return false; try { prop.setValueAtTime(time, value); return true; } catch(e) { return false; } };
    AE.getValue = function(prop) { if (!prop) return null; try { return prop.value; } catch(e) { return null; } };
    AE.hex = function(h) { h = h.replace("#", ""); return [parseInt(h.substr(0,2), 16) / 255, parseInt(h.substr(2,2), 16) / 255, parseInt(h.substr(4,2), 16) / 255]; };
    AE.easyEase = function(prop, influence) {
        if (!prop) return; if (prop.numKeys === 0) return; influence = influence || 66;
        try {
            var dim = 1; var pvt = prop.propertyValueType;
            if (pvt === PropertyValueType.TwoD || pvt === PropertyValueType.TwoD_SPATIAL) dim = 2;
            if (pvt === PropertyValueType.ThreeD || pvt === PropertyValueType.ThreeD_SPATIAL) dim = 3;
            for (var k = 1; k <= prop.numKeys; k++) {
                var eIn = [], eOut = [];
                for (var d = 0; d < dim; d++) { eIn.push(new KeyframeEase(0, influence)); eOut.push(new KeyframeEase(0, influence)); }
                prop.setTemporalEaseAtKey(k, eIn, eOut);
            }
        } catch(e) {}
    };
    AE.snappyEase = function(prop) { AE.easyEase(prop, 85); };

    // -- Funcoes de criacao --
    AE.addComp = function(nome, largura, altura, duracao, fps) { try { return app.project.items.addComp(nome || "Comp", largura || 1080, altura || 1920, 1, duracao || 15, fps || 30); } catch(e) { return null; } };
    AE.addSolid = function(comp, cor, nome, w, h) { if (!comp) return null; try { return comp.layers.addSolid(cor || [0,0,0], nome || "Solido", w || comp.width, h || comp.height, 1); } catch(e) { return null; } };
    AE.addShape = function(comp, nome) { if (!comp) return null; try { var s = comp.layers.addShape(); if (s && nome) s.name = nome; return s; } catch(e) { return null; } };
    AE.addNull = function(comp, nome) { if (!comp) return null; try { var n = comp.layers.addNull(); if (n && nome) n.name = nome; return n; } catch(e) { return null; } };
    AE.addText = function(comp, texto, cfg) {
        if (!comp) return null;
        try {
            cfg = cfg || {};
            var layer = comp.layers.addText(texto || "");
            if (!layer) return null;
            layer.name = cfg.nome || "Texto";
            var tp = AE.getPropChain(layer, ["ADBE Text Properties", "ADBE Text Document"]);
            if (tp) {
                var doc = tp.value;
                if (cfg.fonte) doc.font = cfg.fonte;
                if (cfg.tamanho) doc.fontSize = cfg.tamanho;
                if (cfg.cor) doc.fillColor = cfg.cor;
                if (cfg.strokeCor) { doc.applyStroke = true; doc.strokeColor = cfg.strokeCor; doc.strokeWidth = cfg.strokeWidth || 2; }
                if (cfg.tracking !== undefined) doc.tracking = cfg.tracking;
                if (cfg.alinhamento === "center") doc.justification = ParagraphJustification.CENTER_JUSTIFY;
                if (cfg.alinhamento === "left") doc.justification = ParagraphJustification.LEFT_JUSTIFY;
                if (cfg.alinhamento === "right") doc.justification = ParagraphJustification.RIGHT_JUSTIFY;
                tp.setValue(doc);
            }
            if (cfg.posicao) AE.setValue(AE.position(layer), cfg.posicao);
            return layer;
        } catch(e) { return null; }
    };
    AE.addEffect = function(layer, matchName) { if (!layer) return null; try { var fx = layer.property("ADBE Effect Parade"); if (!fx) return null; return fx.addProperty(matchName); } catch(e) { return null; } };

    // -- Funcoes de shape --
    AE.addRect = function(comp, cfg) {
        cfg = cfg || {};
        var shape = AE.addShape(comp, cfg.nome || "Rect");
        if (!shape) return null;
        try {
            var contents = shape.property("ADBE Root Vectors Group");
            var group = contents.addProperty("ADBE Vector Group");
            var vectors = group.property("ADBE Vectors Group");
            var rect = vectors.addProperty("ADBE Vector Shape - Rect");
            rect.property("ADBE Vector Rect Size").setValue(cfg.tamanho || [200, 200]);
            rect.property("ADBE Vector Rect Roundness").setValue(cfg.roundness || 0);
            if (cfg.corFill !== false) {
                var fill = vectors.addProperty("ADBE Vector Graphic - Fill");
                var c = cfg.corFill || [1,1,1];
                fill.property("ADBE Vector Fill Color").setValue([c[0], c[1], c[2], 1]);
            }
            if (cfg.corStroke) {
                var stroke = vectors.addProperty("ADBE Vector Graphic - Stroke");
                stroke.property("ADBE Vector Stroke Color").setValue([cfg.corStroke[0], cfg.corStroke[1], cfg.corStroke[2], 1]);
                stroke.property("ADBE Vector Stroke Width").setValue(cfg.strokeWidth || 2);
            }
            if (cfg.posicao) AE.setValue(AE.position(shape), cfg.posicao);
            return shape;
        } catch(e) { return null; }
    };

    AE.addEllipse = function(comp, cfg) {
        cfg = cfg || {};
        var shape = AE.addShape(comp, cfg.nome || "Ellipse");
        if (!shape) return null;
        try {
            var contents = shape.property("ADBE Root Vectors Group");
            var group = contents.addProperty("ADBE Vector Group");
            var vectors = group.property("ADBE Vectors Group");
            var ellipse = vectors.addProperty("ADBE Vector Shape - Ellipse");
            var r = cfg.raio || 50;
            ellipse.property("ADBE Vector Ellipse Size").setValue([r * 2, r * 2]);
            if (cfg.corFill !== false) {
                var fill = vectors.addProperty("ADBE Vector Graphic - Fill");
                var c = cfg.corFill || [1,1,1];
                fill.property("ADBE Vector Fill Color").setValue([c[0], c[1], c[2], 1]);
            }
            if (cfg.posicao) AE.setValue(AE.position(shape), cfg.posicao);
            return shape;
        } catch(e) { return null; }
    };

    AE.addLine = function(comp, cfg) {
        cfg = cfg || {};
        var shape = AE.addShape(comp, cfg.nome || "Linha");
        if (!shape) return null;
        try {
            var contents = shape.property("ADBE Root Vectors Group");
            var group = contents.addProperty("ADBE Vector Group");
            var vectors = group.property("ADBE Vectors Group");
            var path = vectors.addProperty("ADBE Vector Shape - Group");
            var sd = new Shape();
            var w = cfg.largura || 200;
            sd.vertices = [[-w/2, 0], [w/2, 0]];
            sd.closed = false;
            path.property("ADBE Vector Shape").setValue(sd);
            var stroke = vectors.addProperty("ADBE Vector Graphic - Stroke");
            var c = cfg.cor || [1,1,1];
            stroke.property("ADBE Vector Stroke Color").setValue([c[0], c[1], c[2], 1]);
            stroke.property("ADBE Vector Stroke Width").setValue(cfg.espessura || 3);
            stroke.property("ADBE Vector Stroke Line Cap").setValue(2);
            if (cfg.posicao) AE.setValue(AE.position(shape), cfg.posicao);
            return { shape: shape, vectors: vectors };
        } catch(e) { return null; }
    };

    // -- Funcoes de animacao --
    AE.animFadeIn = function(layer, t, dur) { if (!layer) return; dur = dur || 0.25; var op = AE.opacity(layer); AE.setValueAt(op, t, 0); AE.setValueAt(op, t + dur, 100); AE.snappyEase(op); };
    AE.animFadeOut = function(layer, t, dur) { if (!layer) return; dur = dur || 0.2; var op = AE.opacity(layer); AE.setValueAt(op, t, 100); AE.setValueAt(op, t + dur, 0); AE.snappyEase(op); };
    AE.animFadeScaleIn = function(layer, t, dur) { if (!layer) return; dur = dur || 0.3; AE.setValueAt(AE.opacity(layer), t, 0); AE.setValueAt(AE.opacity(layer), t + dur, 100); AE.setValueAt(AE.scale(layer), t, [80, 80]); AE.setValueAt(AE.scale(layer), t + dur, [100, 100]); AE.snappyEase(AE.opacity(layer)); AE.snappyEase(AE.scale(layer)); };
    AE.animPopIn = function(layer, t) { if (!layer) return; AE.setValueAt(AE.opacity(layer), t, 0); AE.setValueAt(AE.opacity(layer), t + 0.08, 100); AE.setValueAt(AE.scale(layer), t, [0, 0]); AE.setValueAt(AE.scale(layer), t + 0.2, [112, 112]); AE.setValueAt(AE.scale(layer), t + 0.35, [100, 100]); AE.snappyEase(AE.scale(layer)); AE.snappyEase(AE.opacity(layer)); };
    AE.animSlideIn = function(layer, t, dir, dist, dur) {
        if (!layer) return; dur = dur || 0.35; dist = dist || 200; dir = dir || "esquerda";
        var pos = AE.position(layer); if (!pos) return;
        var cur = AE.getValue(pos); if (!cur) return;
        var ini;
        switch(dir) {
            case "esquerda": ini = [cur[0] - dist, cur[1]]; break;
            case "direita":  ini = [cur[0] + dist, cur[1]]; break;
            case "cima":     ini = [cur[0], cur[1] - dist]; break;
            case "baixo":    ini = [cur[0], cur[1] + dist]; break;
            default: ini = [cur[0] - dist, cur[1]];
        }
        AE.setValueAt(pos, t, ini);
        AE.setValueAt(pos, t + dur, cur);
        AE.snappyEase(pos);
        AE.animFadeIn(layer, t, dur * 0.4);
    };
    AE.animSlideOut = function(layer, t, dir, dist, dur) {
        if (!layer) return; dur = dur || 0.25; dist = dist || 200; dir = dir || "esquerda";
        var pos = AE.position(layer); if (!pos) return;
        var cur = AE.getValue(pos); if (!cur) return;
        var fim;
        switch(dir) {
            case "esquerda": fim = [cur[0] - dist, cur[1]]; break;
            case "direita":  fim = [cur[0] + dist, cur[1]]; break;
            case "cima":     fim = [cur[0], cur[1] - dist]; break;
            case "baixo":    fim = [cur[0], cur[1] + dist]; break;
            default: fim = [cur[0] + dist, cur[1]];
        }
        AE.setValueAt(pos, t, cur);
        AE.setValueAt(pos, t + dur, fim);
        AE.snappyEase(pos);
        AE.animFadeOut(layer, t + dur * 0.5, dur * 0.5);
    };
    AE.animStagger = function(layers, t, intervalo, tipo) {
        if (!layers) return; intervalo = intervalo || 0.08; tipo = tipo || "fadeScale";
        for (var i = 0; i < layers.length; i++) {
            if (!layers[i]) continue;
            var ti = t + (i * intervalo);
            AE.setValueAt(AE.opacity(layers[i]), 0, 0);
            if (ti > 0.02) AE.setValueAt(AE.opacity(layers[i]), ti - 0.01, 0);
            switch(tipo) {
                case "fadeScale": AE.animFadeScaleIn(layers[i], ti, 0.3); break;
                case "slideEsquerda": AE.animSlideIn(layers[i], ti, "esquerda", 150, 0.35); break;
                case "slideDireita": AE.animSlideIn(layers[i], ti, "direita", 150, 0.35); break;
                case "slideBaixo": AE.animSlideIn(layers[i], ti, "baixo", 100, 0.3); break;
                case "pop": AE.animPopIn(layers[i], ti); break;
            }
        }
    };
    AE.animTrimIn = function(vectors, t, dur) {
        if (!vectors) return;
        try {
            var trim = vectors.addProperty("ADBE Vector Filter - Trim");
            var trimEnd = trim.property("ADBE Vector Trim End");
            AE.setValueAt(trimEnd, t, 0);
            AE.setValueAt(trimEnd, t + (dur || 0.5), 100);
            AE.snappyEase(trimEnd);
        } catch(e) {}
    };

    // ════════════════════════════════════════════════════════
    // INICIO DO SCRIPT — ANUNCIO PICPAY 15s
    // ════════════════════════════════════════════════════════
    app.beginUndoGroup("Anuncio PicPay 15s");

    try {
        // ──────────────────────────────────
        // CORES PICPAY
        // ──────────────────────────────────
        var cor = {
            verde:      AE.hex("#21C25E"),   // verde PicPay principal
            verdeEscuro:AE.hex("#1A9E4B"),   // verde escuro
            verdeBg:    AE.hex("#0D3320"),    // fundo verde profundo
            fundo:      AE.hex("#0A0A0F"),   // preto quase puro
            branco:     [1, 1, 1],
            cinza:      AE.hex("#8A8A9A"),
            cinzaClaro: AE.hex("#C0C0CC"),
            card:       AE.hex("#141420"),    // card escuro
            amarelo:    AE.hex("#FFD600"),    // destaque
            destaque:   AE.hex("#21C25E")     // = verde principal
        };

        // ──────────────────────────────────
        // COMPOSICAO
        // ──────────────────────────────────
        var comp = AE.addComp("PicPay_Anuncio_15s", 1080, 1920, 15, 30);
        if (!comp) { alert("Erro ao criar composicao."); return; }

        var CX = 540;  // centro X
        var CY = 960;  // centro Y


        // ══════════════════════════════════════════════════
        // CAMADA DE FUNDO — Gradiente escuro
        // ══════════════════════════════════════════════════
        var bg = AE.addSolid(comp, cor.fundo, "BG_Principal", 1080, 1920);
        if (bg) {
            bg.moveToEnd();
            // Gradiente sutil verde
            var ramp = AE.addEffect(bg, "ADBE Ramp");
            if (ramp) {
                AE.setValue(AE.getProp(ramp, "ADBE Ramp-0001"), [CX, 0]);
                AE.setValue(AE.getProp(ramp, "ADBE Ramp-0002"), cor.verdeBg);
                AE.setValue(AE.getProp(ramp, "ADBE Ramp-0003"), [CX, 1920]);
                AE.setValue(AE.getProp(ramp, "ADBE Ramp-0004"), cor.fundo);
                AE.setValue(AE.getProp(ramp, "ADBE Ramp-0005"), 1);
            }
        }


        // ══════════════════════════════════════════════════
        // PARTICULAS DECORATIVAS (bolinhas flutuantes)
        // ══════════════════════════════════════════════════
        for (var pi = 0; pi < 12; pi++) {
            var px = 80 + Math.round(Math.random() * 920);
            var py = 100 + Math.round(Math.random() * 1720);
            var pr = 3 + Math.round(Math.random() * 8);
            var pOp = 8 + Math.round(Math.random() * 18);
            var dot = AE.addEllipse(comp, {
                posicao: [px, py],
                raio: pr,
                corFill: cor.verde,
                nome: "Particula_" + pi
            });
            if (dot) {
                AE.setValue(AE.opacity(dot), pOp);
                var freq = (0.5 + Math.random() * 2).toFixed(2);
                var ampX = (8 + Math.random() * 25).toFixed(0);
                var ampY = (8 + Math.random() * 25).toFixed(0);
                var posP = AE.position(dot);
                if (posP) {
                    posP.expression =
                        "var s = " + pi + ";\n" +
                        "var p = value;\n" +
                        "[p[0] + Math.sin(time * " + freq + " + s) * " + ampX + ", " +
                        "p[1] + Math.cos(time * " + freq + " * 0.7 + s) * " + ampY + "];";
                }
                dot.moveToEnd();
            }
        }


        // ══════════════════════════════════════════════════
        // CENA 1 — ABERTURA (0s - 3.5s)
        // "Seu dinheiro rende mais"
        // ══════════════════════════════════════════════════

        // -- Icone PicPay (quadrado verde arredondado simulando o logo) --
        var logoBox = AE.addRect(comp, {
            posicao: [CX, 700],
            tamanho: [180, 180],
            roundness: 44,
            corFill: cor.verde,
            nome: "Logo_PicPay_Box"
        });
        if (logoBox) {
            logoBox.inPoint = 0;
            logoBox.outPoint = 3.5;
        }

        // -- Letra "P" dentro do logo --
        var logoP = AE.addText(comp, "P", {
            posicao: [CX, 718],
            fonte: "Arial-BoldMT",
            tamanho: 120,
            cor: cor.branco,
            alinhamento: "center",
            nome: "Logo_P"
        });
        if (logoP) {
            logoP.inPoint = 0;
            logoP.outPoint = 3.5;
        }

        // -- Titulo principal --
        var tituloCena1 = AE.addText(comp, "Seu dinheiro", {
            posicao: [CX, 920],
            fonte: "Arial-BoldMT",
            tamanho: 76,
            cor: cor.branco,
            alinhamento: "center",
            tracking: 10,
            nome: "Cena1_Titulo1"
        });
        if (tituloCena1) {
            tituloCena1.inPoint = 0;
            tituloCena1.outPoint = 3.5;
        }

        var tituloCena1b = AE.addText(comp, "rende mais", {
            posicao: [CX, 1010],
            fonte: "Arial-BoldMT",
            tamanho: 76,
            cor: cor.verde,
            alinhamento: "center",
            tracking: 10,
            nome: "Cena1_Titulo2"
        });
        if (tituloCena1b) {
            tituloCena1b.inPoint = 0;
            tituloCena1b.outPoint = 3.5;
        }

        // -- Sublinha decorativa --
        var lineCena1 = AE.addLine(comp, {
            posicao: [CX, 1070],
            largura: 250,
            cor: cor.verde,
            espessura: 4,
            nome: "Cena1_Linha"
        });
        if (lineCena1 && lineCena1.shape) {
            lineCena1.shape.inPoint = 0;
            lineCena1.shape.outPoint = 3.5;
            AE.animTrimIn(lineCena1.vectors, 0.6, 0.4);
        }

        // -- Subtexto --
        var subCena1 = AE.addText(comp, "Rendimento acima da poupanca", {
            posicao: [CX, 1140],
            fonte: "ArialMT",
            tamanho: 30,
            cor: cor.cinzaClaro,
            alinhamento: "center",
            tracking: 40,
            nome: "Cena1_Sub"
        });
        if (subCena1) {
            subCena1.inPoint = 0;
            subCena1.outPoint = 3.5;
        }

        // -- Animacoes Cena 1 --
        AE.animPopIn(logoBox, 0.1);
        AE.animPopIn(logoP, 0.15);
        AE.animSlideIn(tituloCena1, 0.35, "baixo", 80, 0.4);
        AE.animSlideIn(tituloCena1b, 0.5, "baixo", 80, 0.4);
        AE.animFadeIn(subCena1, 0.9, 0.35);

        // -- Saida Cena 1 --
        AE.animFadeOut(logoBox, 3.0, 0.3);
        AE.animFadeOut(logoP, 3.0, 0.3);
        AE.animSlideOut(tituloCena1, 3.0, "cima", 120, 0.35);
        AE.animSlideOut(tituloCena1b, 3.05, "cima", 120, 0.35);
        AE.animFadeOut(subCena1, 3.0, 0.3);


        // ══════════════════════════════════════════════════
        // TRANSICAO WIPE 1 (3.3s)
        // ══════════════════════════════════════════════════
        var wipe1 = AE.addSolid(comp, cor.verde, "Wipe_1", 1080, 1920);
        if (wipe1) {
            wipe1.inPoint = 3.1;
            wipe1.outPoint = 3.9;
            var wipe1Pos = AE.position(wipe1);
            AE.setValueAt(wipe1Pos, 3.1, [CX, CY + 1920]);
            AE.setValueAt(wipe1Pos, 3.35, [CX, CY]);
            AE.setValueAt(wipe1Pos, 3.5, [CX, CY]);
            AE.setValueAt(wipe1Pos, 3.75, [CX, CY - 1920]);
            AE.snappyEase(wipe1Pos);
        }


        // ══════════════════════════════════════════════════
        // CENA 2 — BENEFICIOS (3.5s - 7.5s)
        // Cards com funcionalidades
        // ══════════════════════════════════════════════════

        // -- Titulo cena 2 --
        var titCena2 = AE.addText(comp, "Tudo em um so app", {
            posicao: [CX, 340],
            fonte: "Arial-BoldMT",
            tamanho: 56,
            cor: cor.branco,
            alinhamento: "center",
            tracking: 20,
            nome: "Cena2_Titulo"
        });
        if (titCena2) {
            titCena2.inPoint = 3.5;
            titCena2.outPoint = 7.5;
        }

        // -- Linha abaixo do titulo --
        var lineCena2 = AE.addLine(comp, {
            posicao: [CX, 395],
            largura: 160,
            cor: cor.verde,
            espessura: 3,
            nome: "Cena2_Linha"
        });
        if (lineCena2 && lineCena2.shape) {
            lineCena2.shape.inPoint = 3.5;
            lineCena2.shape.outPoint = 7.5;
            AE.animTrimIn(lineCena2.vectors, 3.8, 0.35);
        }

        // -- Cards de funcionalidades --
        var cardData = [
            { icone: "$",  titulo: "Pix Gratis",       desc: "Envie e receba\nsem taxas" },
            { icone: "%",  titulo: "Rendimento CDI",    desc: "Seu saldo rende\nautomaticamente" },
            { icone: "+",  titulo: "Cartao sem anuidade", desc: "Credito e debito\nsem custo" }
        ];

        var cardLayers = [];
        var cardStartY = 500;
        var cardSpacing = 330;

        for (var ci = 0; ci < cardData.length; ci++) {
            var cd = cardData[ci];
            var cardY = cardStartY + (ci * cardSpacing);

            // Card background
            var cardBg = AE.addRect(comp, {
                posicao: [CX, cardY + 40],
                tamanho: [900, 260],
                roundness: 28,
                corFill: cor.card,
                corStroke: cor.verde,
                strokeWidth: 1.5,
                nome: "Card_BG_" + ci
            });
            if (cardBg) {
                cardBg.inPoint = 3.5;
                cardBg.outPoint = 7.5;
                cardLayers.push(cardBg);
            }

            // Icone circular
            var cardIcon = AE.addEllipse(comp, {
                posicao: [180, cardY + 40],
                raio: 40,
                corFill: cor.verde,
                nome: "Card_Icon_" + ci
            });
            if (cardIcon) {
                cardIcon.inPoint = 3.5;
                cardIcon.outPoint = 7.5;
                cardLayers.push(cardIcon);
            }

            // Texto icone
            var cardIconTxt = AE.addText(comp, cd.icone, {
                posicao: [180, cardY + 55],
                fonte: "Arial-BoldMT",
                tamanho: 40,
                cor: cor.branco,
                alinhamento: "center",
                nome: "Card_IconTxt_" + ci
            });
            if (cardIconTxt) {
                cardIconTxt.inPoint = 3.5;
                cardIconTxt.outPoint = 7.5;
                cardLayers.push(cardIconTxt);
            }

            // Titulo do card
            var cardTit = AE.addText(comp, cd.titulo, {
                posicao: [560, cardY - 5],
                fonte: "Arial-BoldMT",
                tamanho: 38,
                cor: cor.branco,
                alinhamento: "left",
                nome: "Card_Titulo_" + ci
            });
            if (cardTit) {
                cardTit.inPoint = 3.5;
                cardTit.outPoint = 7.5;
                cardLayers.push(cardTit);
            }

            // Descricao do card
            var cardDesc = AE.addText(comp, cd.desc, {
                posicao: [560, cardY + 55],
                fonte: "ArialMT",
                tamanho: 26,
                cor: cor.cinza,
                alinhamento: "left",
                nome: "Card_Desc_" + ci
            });
            if (cardDesc) {
                cardDesc.inPoint = 3.5;
                cardDesc.outPoint = 7.5;
                cardLayers.push(cardDesc);
            }
        }

        // -- Animacoes Cena 2 --
        AE.animSlideIn(titCena2, 3.5, "cima", 80, 0.35);
        AE.animStagger(cardLayers, 3.8, 0.05, "slideDireita" );

        // -- Saida Cena 2 --
        AE.animFadeOut(titCena2, 7.0, 0.3);
        for (var co = 0; co < cardLayers.length; co++) {
            AE.animFadeOut(cardLayers[co], 7.0 + (co * 0.02), 0.25);
        }


        // ══════════════════════════════════════════════════
        // TRANSICAO WIPE 2 (7.3s)
        // ══════════════════════════════════════════════════
        var wipe2 = AE.addSolid(comp, cor.verde, "Wipe_2", 1080, 1920);
        if (wipe2) {
            wipe2.inPoint = 7.1;
            wipe2.outPoint = 7.9;
            var wipe2Pos = AE.position(wipe2);
            AE.setValueAt(wipe2Pos, 7.1, [CX - 1080, CY]);
            AE.setValueAt(wipe2Pos, 7.35, [CX, CY]);
            AE.setValueAt(wipe2Pos, 7.5, [CX, CY]);
            AE.setValueAt(wipe2Pos, 7.75, [CX + 1080, CY]);
            AE.snappyEase(wipe2Pos);
        }


        // ══════════════════════════════════════════════════
        // CENA 3 — NUMERO DESTAQUE (7.5s - 11.5s)
        // "102% do CDI"
        // ══════════════════════════════════════════════════

        // -- Numero grande --
        var numGrande = AE.addText(comp, "102%", {
            posicao: [CX, 820],
            fonte: "Arial-BoldMT",
            tamanho: 180,
            cor: cor.verde,
            alinhamento: "center",
            nome: "Cena3_Numero"
        });
        if (numGrande) {
            numGrande.inPoint = 7.5;
            numGrande.outPoint = 11.5;

            // Expression contador
            var numTP = AE.getPropChain(numGrande, ["ADBE Text Properties", "ADBE Text Document"]);
            if (numTP) {
                numTP.expression = [
                    "var inicio = 7.5;",
                    "var duracao = 1.5;",
                    "var de = 0;",
                    "var ate = 102;",
                    "var t = (time - inicio) / duracao;",
                    "t = Math.max(0, Math.min(1, t));",
                    "t = 1 - Math.pow(1 - t, 3);",
                    "var val = Math.round(de + (ate - de) * t);",
                    "val + '%';"
                ].join("\n");
            }
        }

        // -- Label "do CDI" --
        var labelCDI = AE.addText(comp, "do CDI", {
            posicao: [CX, 930],
            fonte: "Arial-BoldMT",
            tamanho: 52,
            cor: cor.branco,
            alinhamento: "center",
            tracking: 60,
            nome: "Cena3_CDI"
        });
        if (labelCDI) {
            labelCDI.inPoint = 7.5;
            labelCDI.outPoint = 11.5;
        }

        // -- Sublabel --
        var subCDI = AE.addText(comp, "Rendimento que supera a poupanca", {
            posicao: [CX, 1020],
            fonte: "ArialMT",
            tamanho: 28,
            cor: cor.cinza,
            alinhamento: "center",
            tracking: 20,
            nome: "Cena3_SubCDI"
        });
        if (subCDI) {
            subCDI.inPoint = 7.5;
            subCDI.outPoint = 11.5;
        }

        // -- Linha acento embaixo --
        var lineCena3 = AE.addLine(comp, {
            posicao: [CX, 1080],
            largura: 300,
            cor: cor.verde,
            espessura: 4,
            nome: "Cena3_Linha"
        });
        if (lineCena3 && lineCena3.shape) {
            lineCena3.shape.inPoint = 7.5;
            lineCena3.shape.outPoint = 11.5;
            AE.animTrimIn(lineCena3.vectors, 8.5, 0.4);
        }

        // -- Circulo decorativo atras do numero --
        var circDeco = AE.addEllipse(comp, {
            posicao: [CX, 820],
            raio: 200,
            corFill: false,
            nome: "Cena3_CircDeco"
        });
        if (circDeco) {
            circDeco.inPoint = 7.5;
            circDeco.outPoint = 11.5;
            AE.setValue(AE.opacity(circDeco), 15);
            // Adicionar stroke verde
            try {
                var circContents = circDeco.property("ADBE Root Vectors Group");
                var circGroup = circContents.property(1);
                var circVectors = circGroup.property("ADBE Vectors Group");
                var circStroke = circVectors.addProperty("ADBE Vector Graphic - Stroke");
                circStroke.property("ADBE Vector Stroke Color").setValue([cor.verde[0], cor.verde[1], cor.verde[2], 1]);
                circStroke.property("ADBE Vector Stroke Width").setValue(3);
            } catch(e) {}

            // Rotacao lenta
            var circRot = AE.rotation(circDeco);
            if (circRot) {
                circRot.expression = "time * 15;";
            }
        }

        // -- Animacoes Cena 3 --
        AE.animPopIn(numGrande, 7.7);
        AE.animFadeScaleIn(labelCDI, 8.2, 0.3);
        AE.animFadeIn(subCDI, 8.6, 0.35);
        AE.animFadeScaleIn(circDeco, 7.6, 0.5);

        // -- Saida Cena 3 --
        AE.animFadeOut(numGrande, 11.0, 0.3);
        AE.animFadeOut(labelCDI, 11.0, 0.3);
        AE.animFadeOut(subCDI, 11.0, 0.3);
        AE.animFadeOut(circDeco, 11.0, 0.3);


        // ══════════════════════════════════════════════════
        // TRANSICAO WIPE 3 (11.3s)
        // ══════════════════════════════════════════════════
        var wipe3 = AE.addSolid(comp, cor.verde, "Wipe_3", 1080, 1920);
        if (wipe3) {
            wipe3.inPoint = 11.1;
            wipe3.outPoint = 11.9;
            var wipe3Pos = AE.position(wipe3);
            AE.setValueAt(wipe3Pos, 11.1, [CX, CY + 1920]);
            AE.setValueAt(wipe3Pos, 11.35, [CX, CY]);
            AE.setValueAt(wipe3Pos, 11.5, [CX, CY]);
            AE.setValueAt(wipe3Pos, 11.75, [CX, CY - 1920]);
            AE.snappyEase(wipe3Pos);
        }


        // ══════════════════════════════════════════════════
        // CENA 4 — CTA FINAL (11.5s - 15s)
        // "Baixe agora"
        // ══════════════════════════════════════════════════

        // -- Logo PicPay grande --
        var logoFinal = AE.addRect(comp, {
            posicao: [CX, 650],
            tamanho: [220, 220],
            roundness: 52,
            corFill: cor.verde,
            nome: "CTA_Logo_Box"
        });
        if (logoFinal) {
            logoFinal.inPoint = 11.5;
        }

        var logoPFinal = AE.addText(comp, "P", {
            posicao: [CX, 672],
            fonte: "Arial-BoldMT",
            tamanho: 140,
            cor: cor.branco,
            alinhamento: "center",
            nome: "CTA_Logo_P"
        });
        if (logoPFinal) {
            logoPFinal.inPoint = 11.5;
        }

        // -- Texto CTA --
        var ctaTitulo = AE.addText(comp, "Baixe agora", {
            posicao: [CX, 900],
            fonte: "Arial-BoldMT",
            tamanho: 72,
            cor: cor.branco,
            alinhamento: "center",
            tracking: 20,
            nome: "CTA_Titulo"
        });
        if (ctaTitulo) {
            ctaTitulo.inPoint = 11.5;
        }

        var ctaSub = AE.addText(comp, "e faca seu dinheiro render", {
            posicao: [CX, 980],
            fonte: "ArialMT",
            tamanho: 32,
            cor: cor.cinzaClaro,
            alinhamento: "center",
            tracking: 30,
            nome: "CTA_Sub"
        });
        if (ctaSub) {
            ctaSub.inPoint = 11.5;
        }

        // -- Botao CTA (retangulo verde) --
        var btnCTA = AE.addRect(comp, {
            posicao: [CX, 1120],
            tamanho: [600, 90],
            roundness: 45,
            corFill: cor.verde,
            nome: "CTA_Botao"
        });
        if (btnCTA) {
            btnCTA.inPoint = 11.5;
        }

        var btnTexto = AE.addText(comp, "ABRA SUA CONTA GRATIS", {
            posicao: [CX, 1132],
            fonte: "Arial-BoldMT",
            tamanho: 28,
            cor: cor.branco,
            alinhamento: "center",
            tracking: 80,
            nome: "CTA_BotaoTexto"
        });
        if (btnTexto) {
            btnTexto.inPoint = 11.5;
        }

        // -- PicPay.com --
        var urlText = AE.addText(comp, "picpay.com", {
            posicao: [CX, 1240],
            fonte: "ArialMT",
            tamanho: 24,
            cor: cor.cinza,
            alinhamento: "center",
            tracking: 60,
            nome: "CTA_URL"
        });
        if (urlText) {
            urlText.inPoint = 11.5;
        }

        // -- Animacoes CTA --
        AE.animPopIn(logoFinal, 11.6);
        AE.animPopIn(logoPFinal, 11.65);
        AE.animSlideIn(ctaTitulo, 11.9, "baixo", 80, 0.35);
        AE.animFadeIn(ctaSub, 12.1, 0.3);
        AE.animPopIn(btnCTA, 12.4);
        AE.animFadeScaleIn(btnTexto, 12.5, 0.3);
        AE.animFadeIn(urlText, 12.8, 0.3);

        // -- Pulso no botao (loop) --
        var btnSc = AE.scale(btnCTA);
        if (btnSc) {
            btnSc.expression = [
                "var t = time - 12.8;",
                "if (t < 0) value;",
                "else {",
                "  var pulse = Math.sin(t * 4) * 3;",
                "  [100 + pulse, 100 + pulse];",
                "}"
            ].join("\n");
        }


        // ══════════════════════════════════════════════════
        // REORDENAR LAYERS — fundo e particulas por baixo
        // ══════════════════════════════════════════════════
        if (bg) bg.moveToEnd();

        alert("Anuncio PicPay 15s criado com sucesso!\nComp: PicPay_Anuncio_15s");

    } catch (e) {
        alert("Erro: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();
