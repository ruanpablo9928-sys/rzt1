/**
 * MultiTools — AI AGENT TOOLS (Fase 1 MVP)
 *
 * Ferramentas chamaveis via ExtendScript pelo agent-tools.js.
 * Cada tool:
 *   1. Recebe argumentos JSON (string)
 *   2. Executa a operacao no AE
 *   3. Retorna resultado em JSON (string)
 *
 * Registry global: $.global.MT_REG guarda referencias entre calls
 *   - comps[id] = CompItem
 *   - layers[id] = Layer (AVLayer, TextLayer, ShapeLayer)
 *   - next_comp_id, next_layer_id = counters
 *
 * Formato retorno: {"ok":true, "data":{...}} ou {"ok":false, "error":"..."}
 */

// ═══════════════════════════════════════════════════════════
// REGISTRY & HELPERS
// ═══════════════════════════════════════════════════════════

function MT_initRegistry() {
    if (!$.global.MT_REG) {
        $.global.MT_REG = {
            comps: {},
            layers: {},
            next_comp_id: 1,
            next_layer_id: 1,
            current_comp_id: null
        };
    }
    return $.global.MT_REG;
}

function MT_resetRegistry() {
    $.global.MT_REG = {
        comps: {},
        layers: {},
        next_comp_id: 1,
        next_layer_id: 1,
        current_comp_id: null
    };
    return '{"ok":true,"data":{"reset":true}}';
}

function MT_getComp(comp_id) {
    var reg = MT_initRegistry();
    if (comp_id === null || comp_id === undefined) {
        comp_id = reg.current_comp_id;
    }
    var c = reg.comps[comp_id];
    if (!c) return null;
    return c;
}

function MT_getLayer(layer_id) {
    var reg = MT_initRegistry();
    // Atalho: "last" ou -1 = ultima layer criada
    if (layer_id === 'last' || layer_id === -1 || layer_id === '-1') {
        var maxId = reg.next_layer_id - 1;
        if (maxId < 1) return null;
        return reg.layers[maxId] || null;
    }
    // Se for string que nao eh numero, tenta buscar por NAME
    if (typeof layer_id === 'string' && isNaN(parseInt(layer_id))) {
        for (var k in reg.layers) {
            if (reg.layers.hasOwnProperty(k) && reg.layers[k] && reg.layers[k].name === layer_id) {
                return reg.layers[k];
            }
        }
        return null;
    }
    return reg.layers[layer_id] || null;
}

function MT_hexToRGB(hex) {
    hex = String(hex).replace(/^#/, '');
    if (hex.length === 3) {
        hex = hex.charAt(0)+hex.charAt(0)+hex.charAt(1)+hex.charAt(1)+hex.charAt(2)+hex.charAt(2);
    }
    return [
        parseInt(hex.substr(0,2), 16) / 255,
        parseInt(hex.substr(2,2), 16) / 255,
        parseInt(hex.substr(4,2), 16) / 255
    ];
}

function MT_parseJSON(s) {
    try {
        return eval('(' + s + ')');
    } catch(e) {
        return null;
    }
}

function MT_stringifyValue(v) {
    // Mini JSON stringify ES3-safe
    if (v === null || v === undefined) return 'null';
    if (typeof v === 'number') return String(v);
    if (typeof v === 'boolean') return v ? 'true' : 'false';
    if (typeof v === 'string') return '"' + v.replace(/\\/g,'\\\\').replace(/"/g,'\\"').replace(/\n/g,'\\n').replace(/\r/g,'\\r').replace(/\t/g,'\\t') + '"';
    if (v instanceof Array) {
        var parts = [];
        for (var i = 0; i < v.length; i++) parts.push(MT_stringifyValue(v[i]));
        return '[' + parts.join(',') + ']';
    }
    if (typeof v === 'object') {
        var pairs = [];
        for (var k in v) {
            if (v.hasOwnProperty(k)) pairs.push('"'+k+'":'+MT_stringifyValue(v[k]));
        }
        return '{' + pairs.join(',') + '}';
    }
    return 'null';
}

function MT_ok(data) {
    return '{"ok":true,"data":' + MT_stringifyValue(data || {}) + '}';
}

function MT_err(msg) {
    return '{"ok":false,"error":' + MT_stringifyValue(String(msg)) + '}';
}

// ═══════════════════════════════════════════════════════════
// TOOL 1 — create_comp
// args: { "width": 1080, "height": 1920, "duration": 6, "fps": 30, "name": "Motion" }
// retorna: { "comp_id": 1, "name": "Motion" }
// ═══════════════════════════════════════════════════════════

function MT_tool_create_comp(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var w = args.width || 1080;
        var h = args.height || 1920;
        var dur = args.duration || 6;
        var fps = args.fps || 30;
        var name = args.name || 'AI_Motion';

        var reg = MT_initRegistry();
        app.beginUndoGroup('MT_Tool: create_comp');
        var comp = app.project.items.addComp(name, w, h, 1, dur, fps);
        comp.motionBlur = true;
        comp.openInViewer();
        app.endUndoGroup();

        var comp_id = reg.next_comp_id++;
        reg.comps[comp_id] = comp;
        reg.current_comp_id = comp_id;

        return MT_ok({ comp_id: comp_id, name: comp.name, width: w, height: h, duration: dur, fps: fps });
    } catch(e) {
        return MT_err(e.toString());
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 2 — add_text
// args: {
//   "comp_id": 1,              // opcional, default: current
//   "text": "Hello",
//   "font_size": 86,           // opcional, default: width*0.08
//   "color": "#FFFFFF",
//   "font": "Arial-BoldMT",
//   "align": "c"|"l"|"r",
//   "x": 540, "y": 960,        // position
//   "anchor": "TC"|"MC"|...,   // alternativa: pega posicao do slot no frame
//   "name": "Title",
//   "in_point": 0.0,
//   "out_point": 2.0
// }
// retorna: { "layer_id": 2, "name": "Title", "position": [540, 960] }
// ═══════════════════════════════════════════════════════════

function MT_tool_add_text(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var comp = MT_getComp(args.comp_id);
        if (!comp) return MT_err('comp nao encontrada (comp_id=' + args.comp_id + ')');

        var reg = MT_initRegistry();
        app.beginUndoGroup('MT_Tool: add_text');

        var text = String(args.text || 'Text');
        var fontSize = args.font_size || Math.round(comp.width * 0.06);
        var color = args.color ? MT_hexToRGB(args.color) : [1, 1, 1];
        var font = args.font || 'Arial-BoldMT';
        var align = args.align || 'c';
        var name = args.name || ('Text_' + reg.next_layer_id);

        var layer = comp.layers.addText(text);
        layer.name = name;

        var tp = layer.property('ADBE Text Properties').property('ADBE Text Document');
        if (tp) {
            var doc = tp.value;
            doc.font = font;
            doc.fontSize = fontSize;
            doc.fillColor = color;
            if (align === 'c') doc.justification = ParagraphJustification.CENTER_JUSTIFY;
            else if (align === 'l') doc.justification = ParagraphJustification.LEFT_JUSTIFY;
            else if (align === 'r') doc.justification = ParagraphJustification.RIGHT_JUSTIFY;
            tp.setValue(doc);
        }

        // Center anchor pra center-justify animar certo
        if (align === 'c') {
            try {
                var rect = layer.sourceRectAtTime(0.01, false);
                if (rect && rect.width > 0) {
                    layer.property('ADBE Transform Group').property('ADBE Anchor Point').setValue([
                        rect.left + rect.width/2,
                        rect.top + rect.height/2
                    ]);
                }
            } catch(eA) {}
        }

        // Position via x/y OU anchor slot
        var posX, posY;
        if (args.anchor) {
            var margin = Math.min(comp.width, comp.height) * 0.05;
            var map = {
                'TL': [margin, margin],
                'TC': [comp.width/2, margin + fontSize],
                'TR': [comp.width - margin, margin],
                'ML': [margin, comp.height/2],
                'MC': [comp.width/2, comp.height/2],
                'MR': [comp.width - margin, comp.height/2],
                'BL': [margin, comp.height - margin],
                'BC': [comp.width/2, comp.height - margin - fontSize],
                'BR': [comp.width - margin, comp.height - margin]
            };
            var p = map[args.anchor] || [comp.width/2, comp.height/2];
            posX = p[0]; posY = p[1];
        } else {
            posX = (args.x !== undefined) ? args.x : comp.width/2;
            posY = (args.y !== undefined) ? args.y : comp.height/2;
        }
        layer.property('ADBE Transform Group').property('ADBE Position').setValue([posX, posY]);

        // In/out points
        if (args.in_point !== undefined) layer.inPoint = args.in_point;
        if (args.out_point !== undefined) layer.outPoint = args.out_point;

        app.endUndoGroup();

        var layer_id = reg.next_layer_id++;
        reg.layers[layer_id] = layer;

        return MT_ok({
            layer_id: layer_id,
            name: layer.name,
            position: [posX, posY],
            font_size: fontSize,
            in_point: layer.inPoint,
            out_point: layer.outPoint
        });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 3 — add_shape_rect
// args: {
//   "comp_id": 1,              // opcional
//   "width": 800, "height": 400,
//   "color": "#FF3B30",        // fill
//   "stroke_color": null,      // opcional stroke
//   "stroke_width": 2,
//   "roundness": 20,
//   "x": 540, "y": 960,
//   "anchor": "MC",            // alternativa
//   "name": "Card",
//   "in_point": 0.0,
//   "out_point": 2.0,
//   "is_bg": false             // se true, ocupa comp inteira (override w/h/x/y)
// }
// retorna: { "layer_id": 3, "name": "Card" }
// ═══════════════════════════════════════════════════════════

function MT_tool_add_shape_rect(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var comp = MT_getComp(args.comp_id);
        if (!comp) return MT_err('comp nao encontrada');

        var reg = MT_initRegistry();
        app.beginUndoGroup('MT_Tool: add_shape_rect');

        var name = args.name || ('Rect_' + reg.next_layer_id);
        var rectW = args.width || Math.round(comp.width * 0.5);
        var rectH = args.height || Math.round(comp.height * 0.3);
        var fillColor = args.color ? MT_hexToRGB(args.color) : [1, 1, 1];
        var roundness = (args.roundness !== undefined) ? args.roundness : 0;

        if (args.is_bg) {
            // BG: shape solido com Solid Layer — mais confiavel
            var bgLayer = comp.layers.addSolid(fillColor, name, comp.width, comp.height, 1, comp.duration);
            if (args.in_point !== undefined) bgLayer.inPoint = args.in_point;
            if (args.out_point !== undefined) bgLayer.outPoint = args.out_point;
            app.endUndoGroup();
            var bg_layer_id = reg.next_layer_id++;
            reg.layers[bg_layer_id] = bgLayer;
            return MT_ok({ layer_id: bg_layer_id, name: bgLayer.name, is_bg: true });
        }

        var shape = comp.layers.addShape();
        shape.name = name;
        var vec = shape.property('ADBE Root Vectors Group').addProperty('ADBE Vector Group').property('ADBE Vectors Group');
        var rect = vec.addProperty('ADBE Vector Shape - Rect');
        rect.property('ADBE Vector Rect Size').setValue([rectW, rectH]);
        rect.property('ADBE Vector Rect Roundness').setValue(roundness);
        var fill = vec.addProperty('ADBE Vector Graphic - Fill');
        fill.property('ADBE Vector Fill Color').setValue([fillColor[0], fillColor[1], fillColor[2], 1]);

        if (args.stroke_color) {
            var stColor = MT_hexToRGB(args.stroke_color);
            var stroke = vec.addProperty('ADBE Vector Graphic - Stroke');
            stroke.property('ADBE Vector Stroke Color').setValue([stColor[0], stColor[1], stColor[2], 1]);
            stroke.property('ADBE Vector Stroke Width').setValue(args.stroke_width || 2);
        }

        // Position
        var posX, posY;
        if (args.anchor) {
            var margin = Math.min(comp.width, comp.height) * 0.05;
            var map = {
                'TL': [margin + rectW/2, margin + rectH/2],
                'TC': [comp.width/2, margin + rectH/2],
                'TR': [comp.width - margin - rectW/2, margin + rectH/2],
                'ML': [margin + rectW/2, comp.height/2],
                'MC': [comp.width/2, comp.height/2],
                'MR': [comp.width - margin - rectW/2, comp.height/2],
                'BL': [margin + rectW/2, comp.height - margin - rectH/2],
                'BC': [comp.width/2, comp.height - margin - rectH/2],
                'BR': [comp.width - margin - rectW/2, comp.height - margin - rectH/2]
            };
            var p = map[args.anchor] || [comp.width/2, comp.height/2];
            posX = p[0]; posY = p[1];
        } else {
            posX = (args.x !== undefined) ? args.x : comp.width/2;
            posY = (args.y !== undefined) ? args.y : comp.height/2;
        }
        shape.property('ADBE Transform Group').property('ADBE Position').setValue([posX, posY]);

        if (args.in_point !== undefined) shape.inPoint = args.in_point;
        if (args.out_point !== undefined) shape.outPoint = args.out_point;

        app.endUndoGroup();

        var layer_id = reg.next_layer_id++;
        reg.layers[layer_id] = shape;

        return MT_ok({
            layer_id: layer_id,
            name: shape.name,
            position: [posX, posY],
            size: [rectW, rectH]
        });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 4 — set_keyframe
// args: {
//   "layer_id": 2,
//   "property": "position"|"scale"|"opacity"|"rotation",
//   "time": 0.5,
//   "value": [100, 100] | 100 | [540, 960]
// }
// retorna: { "keyframe_count": 3 }
// ═══════════════════════════════════════════════════════════

function MT_tool_set_keyframe(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var layer = MT_getLayer(args.layer_id);
        if (!layer) {
            var reg = MT_initRegistry();
            var validIds = [];
            for (var k in reg.layers) {
                if (reg.layers.hasOwnProperty(k)) validIds.push(k + '(' + reg.layers[k].name + ')');
            }
            return MT_err('layer_id=' + args.layer_id + ' nao existe. Use "last" pra ultima, ou um desses ids existentes: ' + validIds.join(', '));
        }

        var propMap = {
            'position': 'ADBE Position',
            'scale': 'ADBE Scale',
            'opacity': 'ADBE Opacity',
            'rotation': 'ADBE Rotate Z',
            'anchor': 'ADBE Anchor Point'
        };
        var propName = propMap[args.property];
        if (!propName) return MT_err('propriedade invalida: ' + args.property + ' (use: position|scale|opacity|rotation|anchor)');

        var prop = layer.property('ADBE Transform Group').property(propName);
        if (!prop) return MT_err('propriedade nao encontrada');

        app.beginUndoGroup('MT_Tool: set_keyframe');
        prop.setValueAtTime(args.time, args.value);

        // Aplica ease forte automaticamente no keyframe recem-criado
        try {
            var numKeys = prop.numKeys;
            var d = 1;
            var v = prop.propertyValueType;
            if (v === PropertyValueType.TwoD || v === PropertyValueType.TwoD_SPATIAL) d = 2;
            if (v === PropertyValueType.ThreeD || v === PropertyValueType.ThreeD_SPATIAL) d = 3;
            for (var k = 1; k <= numKeys; k++) {
                var ei = [], eo = [];
                for (var j = 0; j < d; j++) {
                    ei.push(new KeyframeEase(0, 85));
                    eo.push(new KeyframeEase(0, 85));
                }
                prop.setTemporalEaseAtKey(k, ei, eo);
            }
        } catch(eE) {}

        app.endUndoGroup();

        return MT_ok({ keyframe_count: prop.numKeys, property: args.property });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 5 — apply_helper
// args: {
//   "layer_id": 2,
//   "helper": "pop_in"|"fade_in"|"fade_out"|"slide_in_up"|"bounce_pop"|"drop_shadow"|"glow",
//   "time_start": 0.0,     // tempo que a animacao comeca
//   "duration": 0.4,        // opcional, default por helper
//   "params": {...}         // opcional, por helper
// }
// retorna: { "helper": "pop_in", "keyframes_added": 4 }
// ═══════════════════════════════════════════════════════════

function MT_tool_apply_helper(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var layer = MT_getLayer(args.layer_id);
        if (!layer) {
            var reg = MT_initRegistry();
            var validIds = [];
            for (var k in reg.layers) {
                if (reg.layers.hasOwnProperty(k)) validIds.push(k + '(' + reg.layers[k].name + ')');
            }
            return MT_err('layer_id=' + args.layer_id + ' nao existe. Use "last" pra ultima, ou um desses ids existentes: ' + validIds.join(', '));
        }

        var helper = String(args.helper || '').toLowerCase();
        var t = args.time_start || layer.inPoint || 0;
        var dur = args.duration || 0.4;
        var params = args.params || {};

        app.beginUndoGroup('MT_Tool: apply_helper ' + helper);

        var tg = layer.property('ADBE Transform Group');
        var pos = tg.property('ADBE Position');
        var scl = tg.property('ADBE Scale');
        var opa = tg.property('ADBE Opacity');
        var rot = tg.property('ADBE Rotate Z');

        var easeIn = new KeyframeEase(0, 85);
        var easeOut = new KeyframeEase(0, 85);

        function setEaseAll(p) {
            if (!p || p.numKeys === 0) return;
            var d = 1;
            try {
                var v = p.propertyValueType;
                if (v === PropertyValueType.TwoD || v === PropertyValueType.TwoD_SPATIAL) d = 2;
                if (v === PropertyValueType.ThreeD || v === PropertyValueType.ThreeD_SPATIAL) d = 3;
            } catch(e) {}
            for (var k = 1; k <= p.numKeys; k++) {
                var ei = [], eo = [];
                for (var j = 0; j < d; j++) { ei.push(new KeyframeEase(0, 85)); eo.push(new KeyframeEase(0, 85)); }
                try { p.setTemporalEaseAtKey(k, ei, eo); } catch(e) {}
            }
        }

        var kfAdded = 0;

        switch (helper) {
            case 'pop_in':
                scl.setValueAtTime(t, [0, 0]);
                scl.setValueAtTime(t + dur*0.375, [115, 115]);
                scl.setValueAtTime(t + dur*0.625, [95, 95]);
                scl.setValueAtTime(t + dur, [100, 100]);
                setEaseAll(scl);
                kfAdded = 4;
                break;

            case 'bounce_pop':
                scl.setValueAtTime(t, [0, 0]);
                scl.setValueAtTime(t + dur*0.32, [110, 110]);
                scl.setValueAtTime(t + dur*0.52, [96, 96]);
                scl.setValueAtTime(t + dur*0.72, [103, 103]);
                scl.setValueAtTime(t + dur, [100, 100]);
                opa.setValueAtTime(t, 0);
                opa.setValueAtTime(t + dur*0.3, 100);
                setEaseAll(scl);
                setEaseAll(opa);
                kfAdded = 7;
                break;

            case 'fade_in':
                opa.setValueAtTime(t, 0);
                opa.setValueAtTime(t + dur, 100);
                setEaseAll(opa);
                kfAdded = 2;
                break;

            case 'fade_out':
                opa.setValueAtTime(t, 100);
                opa.setValueAtTime(t + dur, 0);
                setEaseAll(opa);
                kfAdded = 2;
                break;

            case 'slide_in_up':
                var curPos = pos.value;
                var offset = params.offset || 50;
                pos.setValueAtTime(t, [curPos[0], curPos[1] + offset]);
                pos.setValueAtTime(t + dur, curPos);
                opa.setValueAtTime(t, 0);
                opa.setValueAtTime(t + dur, 100);
                setEaseAll(pos);
                setEaseAll(opa);
                kfAdded = 4;
                break;

            case 'slide_in_left':
                var curPos2 = pos.value;
                var offsetL = params.offset || 80;
                pos.setValueAtTime(t, [curPos2[0] - offsetL, curPos2[1]]);
                pos.setValueAtTime(t + dur, curPos2);
                opa.setValueAtTime(t, 0);
                opa.setValueAtTime(t + dur, 100);
                setEaseAll(pos);
                setEaseAll(opa);
                kfAdded = 4;
                break;

            case 'drop_shadow':
                try {
                    var sh = layer.property('ADBE Effect Parade').addProperty('ADBE Drop Shadow');
                    sh.property('ADBE Drop Shadow-0002').setValue(params.opacity || 40);
                    sh.property('ADBE Drop Shadow-0005').setValue(params.distance || 8);
                    sh.property('ADBE Drop Shadow-0006').setValue(params.softness || 30);
                    kfAdded = 0;
                } catch(eF) { return MT_err('drop_shadow falhou: ' + eF); }
                break;

            case 'glow':
                try {
                    var gl = layer.property('ADBE Effect Parade').addProperty('ADBE Drop Shadow');
                    gl.property('ADBE Drop Shadow-0001').setValue([1,1,1,1]);
                    gl.property('ADBE Drop Shadow-0002').setValue(params.opacity || 80);
                    gl.property('ADBE Drop Shadow-0005').setValue(0);
                    gl.property('ADBE Drop Shadow-0006').setValue(params.softness || 50);
                    kfAdded = 0;
                } catch(eG) { return MT_err('glow falhou: ' + eG); }
                break;

            default:
                app.endUndoGroup();
                return MT_err('helper desconhecido: ' + helper + ' (use: pop_in|bounce_pop|fade_in|fade_out|slide_in_up|slide_in_left|drop_shadow|glow)');
        }

        app.endUndoGroup();

        return MT_ok({ helper: helper, keyframes_added: kfAdded, time_start: t, duration: dur });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 6 — set_parent
// args: { "child_id": 2, "parent_id": 1 | null }  (null = remove parent)
// ═══════════════════════════════════════════════════════════

function MT_tool_set_parent(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var child = MT_getLayer(args.child_id);
        if (!child) return MT_err('child layer_id=' + args.child_id + ' nao existe');

        app.beginUndoGroup('MT_Tool: set_parent');
        if (args.parent_id === null || args.parent_id === undefined || args.parent_id === '') {
            child.parent = null;
            app.endUndoGroup();
            return MT_ok({ child: child.name, parent: null });
        }
        var parent = MT_getLayer(args.parent_id);
        if (!parent) { app.endUndoGroup(); return MT_err('parent layer_id=' + args.parent_id + ' nao existe'); }
        if (child === parent) { app.endUndoGroup(); return MT_err('layer nao pode ser pai de si mesma'); }

        child.parent = parent;
        app.endUndoGroup();
        return MT_ok({ child: child.name, parent: parent.name });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 7 — set_expression
// args: {
//   "layer_id": 2,
//   "property": "position"|"scale"|"opacity"|"rotation"|"anchor",
//   "expression": "wiggle(3, 20)" | "time*30" | "loopOut('cycle')" | ""
// }
// ═══════════════════════════════════════════════════════════

function MT_tool_set_expression(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var layer = MT_getLayer(args.layer_id);
        if (!layer) return MT_err('layer_id=' + args.layer_id + ' nao existe');

        var propMap = {
            'position': 'ADBE Position',
            'scale': 'ADBE Scale',
            'opacity': 'ADBE Opacity',
            'rotation': 'ADBE Rotate Z',
            'anchor': 'ADBE Anchor Point'
        };
        var propName = propMap[args.property];
        if (!propName) return MT_err('propriedade invalida: ' + args.property);

        var prop = layer.property('ADBE Transform Group').property(propName);
        if (!prop) return MT_err('propriedade nao acessivel');

        app.beginUndoGroup('MT_Tool: set_expression');
        var expr = String(args.expression || '');
        prop.expression = expr;
        app.endUndoGroup();

        return MT_ok({ layer: layer.name, property: args.property, expression: expr, has_expression: expr !== '' });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 8 — apply_effect
// args: {
//   "layer_id": 2,
//   "effect": "ADBE Gaussian Blur 2" | "Gaussian Blur" | "Drop Shadow" | ...
//              (pode ser matchName OU display name — tenta ambos)
//   "params": { "nome_param_ou_matchname": valor, ... }
// }
// ═══════════════════════════════════════════════════════════

function MT_tool_apply_effect(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var layer = MT_getLayer(args.layer_id);
        if (!layer) return MT_err('layer_id=' + args.layer_id + ' nao existe');

        var effectName = String(args.effect || '');
        if (!effectName) return MT_err('parametro "effect" e obrigatorio');

        app.beginUndoGroup('MT_Tool: apply_effect');
        var effectParade = layer.property('ADBE Effect Parade');
        if (!effectParade) { app.endUndoGroup(); return MT_err('Effect Parade nao disponivel'); }

        // Tenta matchName direto, se falhar tenta mapear display names comuns
        var effect = null;
        try {
            effect = effectParade.addProperty(effectName);
        } catch(e1) {
            // Mapa de display names -> matchNames pros efeitos mais comuns
            var nameMap = {
                'gaussian blur': 'ADBE Gaussian Blur 2',
                'blur': 'ADBE Gaussian Blur 2',
                'box blur': 'ADBE Box Blur2',
                'fast blur': 'ADBE Box Blur2',
                'drop shadow': 'ADBE Drop Shadow',
                'glow': 'ADBE Glo2',
                'fill': 'ADBE Fill',
                'tint': 'ADBE Tint',
                'levels': 'ADBE Easy Levels2',
                'curves': 'ADBE CurvesCustom',
                'hue/saturation': 'ADBE HUE SATURATION',
                'brightness & contrast': 'ADBE Brightness & Contrast 2',
                'noise': 'ADBE Noise',
                'turbulent displace': 'ADBE Turbulent Displace',
                'fractal noise': 'ADBE Fractal Noise',
                'ramp': 'ADBE Ramp',
                'bevel & emboss': 'ADBE Bevel and Emboss',
                'stroke': 'ADBE Stroke',
                'posterize': 'ADBE Posterize',
                'cc rgb to hsl': 'CC RGB To HSL',
                '4-color gradient': 'ADBE 4ColorGradient',
                'grid': 'ADBE Grid',
                'cell pattern': 'ADBE Cell Pattern',
                'motion blur': 'ADBE Motion Blur',
                'directional blur': 'ADBE Motion Blur'
            };
            var mn = nameMap[effectName.toLowerCase()];
            if (mn) {
                try { effect = effectParade.addProperty(mn); } catch(e2) {}
            }
        }

        if (!effect) {
            app.endUndoGroup();
            return MT_err('efeito "' + effectName + '" nao encontrado. Use matchName exato (ex: "ADBE Gaussian Blur 2") ou display name comum (ex: "Gaussian Blur", "Drop Shadow", "Glow", "Tint", "Levels")');
        }

        // Aplica params se houver
        var appliedParams = [];
        if (args.params && typeof args.params === 'object') {
            for (var k in args.params) {
                if (!args.params.hasOwnProperty(k)) continue;
                try {
                    var p = effect.property(k);
                    if (p) {
                        p.setValue(args.params[k]);
                        appliedParams.push(k);
                    }
                } catch(eP) {}
            }
        }

        app.endUndoGroup();
        return MT_ok({
            layer: layer.name,
            effect: effect.name,
            match_name: effect.matchName,
            params_applied: appliedParams
        });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 9 — add_null
// args: { "comp_id": 1, "name": "Controller", "x": 540, "y": 960, "in_point":0, "out_point":5, "threeD": false }
// ═══════════════════════════════════════════════════════════

function MT_tool_add_null(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var comp = MT_getComp(args.comp_id);
        if (!comp) return MT_err('comp nao encontrada');

        var reg = MT_initRegistry();
        app.beginUndoGroup('MT_Tool: add_null');
        var nullLayer = comp.layers.addNull();
        nullLayer.name = args.name || ('Null_' + reg.next_layer_id);
        if (args.x !== undefined || args.y !== undefined) {
            var px = (args.x !== undefined) ? args.x : comp.width/2;
            var py = (args.y !== undefined) ? args.y : comp.height/2;
            nullLayer.property('ADBE Transform Group').property('ADBE Position').setValue([px, py]);
        }
        if (args.in_point !== undefined) nullLayer.inPoint = args.in_point;
        if (args.out_point !== undefined) nullLayer.outPoint = args.out_point;
        if (args.threeD) nullLayer.threeDLayer = true;
        app.endUndoGroup();

        var layer_id = reg.next_layer_id++;
        reg.layers[layer_id] = nullLayer;
        return MT_ok({ layer_id: layer_id, name: nullLayer.name, is_null: true });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 10 — duplicate_layer
// args: {
//   "layer_id": 2,
//   "new_name": "Copy",
//   "time_offset": 0.1,   // quanto offset no inPoint (pra stagger)
//   "in_point": 2.0,      // override total de in_point
//   "out_point": 4.0
// }
// ═══════════════════════════════════════════════════════════

function MT_tool_duplicate_layer(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var src = MT_getLayer(args.layer_id);
        if (!src) return MT_err('layer_id=' + args.layer_id + ' nao existe');

        var reg = MT_initRegistry();
        app.beginUndoGroup('MT_Tool: duplicate_layer');
        var dup = src.duplicate();
        if (args.new_name) dup.name = args.new_name;

        if (args.in_point !== undefined) {
            dup.inPoint = args.in_point;
            if (args.out_point !== undefined) dup.outPoint = args.out_point;
        } else if (args.time_offset !== undefined) {
            var off = args.time_offset;
            dup.inPoint = src.inPoint + off;
            dup.outPoint = src.outPoint + off;
        }

        app.endUndoGroup();
        var layer_id = reg.next_layer_id++;
        reg.layers[layer_id] = dup;
        return MT_ok({ layer_id: layer_id, name: dup.name, duplicated_from: src.name });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 11 — set_3d_layer
// args: { "layer_id": 2, "enabled": true }
// ═══════════════════════════════════════════════════════════

function MT_tool_set_3d_layer(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var layer = MT_getLayer(args.layer_id);
        if (!layer) return MT_err('layer_id=' + args.layer_id + ' nao existe');

        app.beginUndoGroup('MT_Tool: set_3d_layer');
        try {
            layer.threeDLayer = (args.enabled !== false);
        } catch(e3) {
            app.endUndoGroup();
            return MT_err('layer nao suporta 3D (ex: camera, light ja sao 3D)');
        }
        app.endUndoGroup();
        return MT_ok({ layer: layer.name, threeD: layer.threeDLayer });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 12 — set_blend_mode
// args: {
//   "layer_id": 2,
//   "mode": "Normal"|"Add"|"Screen"|"Multiply"|"Overlay"|"Darken"|"Lighten"|"Difference"|"Hue"|"Saturation"|"Color"|"Luminosity"
// }
// ═══════════════════════════════════════════════════════════

function MT_tool_set_blend_mode(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var layer = MT_getLayer(args.layer_id);
        if (!layer) return MT_err('layer_id=' + args.layer_id + ' nao existe');

        var modeMap = {
            'normal': BlendingMode.NORMAL,
            'add': BlendingMode.ADD,
            'screen': BlendingMode.SCREEN,
            'multiply': BlendingMode.MULTIPLY,
            'overlay': BlendingMode.OVERLAY,
            'darken': BlendingMode.DARKEN,
            'lighten': BlendingMode.LIGHTEN,
            'difference': BlendingMode.DIFFERENCE,
            'hue': BlendingMode.HUE,
            'saturation': BlendingMode.SATURATION,
            'color': BlendingMode.COLOR,
            'luminosity': BlendingMode.LUMINOSITY,
            'soft light': BlendingMode.SOFT_LIGHT,
            'hard light': BlendingMode.HARD_LIGHT,
            'color dodge': BlendingMode.COLOR_DODGE,
            'color burn': BlendingMode.COLOR_BURN,
            'linear dodge': BlendingMode.LINEAR_DODGE,
            'linear burn': BlendingMode.LINEAR_BURN
        };
        var m = modeMap[String(args.mode || '').toLowerCase()];
        if (m === undefined) return MT_err('mode invalido: ' + args.mode + '. Use: Normal, Add, Screen, Multiply, Overlay, Darken, Lighten, Difference, Hue, Saturation, Color, Luminosity, Soft Light, Hard Light, Color Dodge, Color Burn');

        app.beginUndoGroup('MT_Tool: set_blend_mode');
        layer.blendingMode = m;
        app.endUndoGroup();
        return MT_ok({ layer: layer.name, blend_mode: args.mode });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 13 — query_state (INSPECAO — nao modifica nada)
// Retorna o estado atual da comp + todas layers criadas.
// args: {} (vazio)
// ═══════════════════════════════════════════════════════════

function MT_tool_query_state(argsJSON) {
    try {
        var reg = MT_initRegistry();
        var comp = MT_getComp();
        var state = {
            has_comp: comp !== null,
            comp: null,
            layers: [],
            layer_count: 0
        };

        if (comp) {
            state.comp = {
                id: reg.current_comp_id,
                name: comp.name,
                width: comp.width,
                height: comp.height,
                duration: comp.duration,
                fps: comp.frameRate,
                num_layers: comp.numLayers
            };
        }

        for (var k in reg.layers) {
            if (!reg.layers.hasOwnProperty(k)) continue;
            var layer = reg.layers[k];
            if (!layer) continue;
            var info = { id: k, name: layer.name, in_point: layer.inPoint, out_point: layer.outPoint };
            // Tipo da layer
            try {
                if (layer instanceof TextLayer) info.type = 'text';
                else if (layer instanceof ShapeLayer) info.type = 'shape';
                else if (layer.nullLayer) info.type = 'null';
                else if (layer instanceof AVLayer) {
                    if (layer.source && layer.source.mainSource && layer.source.mainSource.color) info.type = 'solid';
                    else info.type = 'av';
                }
                else info.type = 'other';
            } catch(e) { info.type = 'unknown'; }
            // Position atual
            try {
                var p = layer.property('ADBE Transform Group').property('ADBE Position');
                if (p) {
                    var pv = p.value;
                    info.position = [Math.round(pv[0]), Math.round(pv[1])];
                    info.has_position_keys = p.numKeys > 0;
                }
            } catch(ePos) {}
            // Parent
            try { if (layer.parent) info.parent = layer.parent.name; } catch(eP) {}
            state.layers.push(info);
        }
        state.layer_count = state.layers.length;
        return MT_ok(state);
    } catch(e) {
        return MT_err(e.toString());
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 14 — set_keyframes (BATCH — multiplos keyframes numa chamada)
// args: {
//   "layer_id": "Title",
//   "property": "scale",
//   "keyframes": [
//     { "time": 0, "value": [0,0] },
//     { "time": 0.15, "value": [115,115] },
//     { "time": 0.35, "value": [100,100] }
//   ]
// }
// ═══════════════════════════════════════════════════════════

function MT_tool_set_keyframes(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var layer = MT_getLayer(args.layer_id);
        if (!layer) {
            var regKf = MT_initRegistry();
            var validIdsKf = [];
            for (var kKf in regKf.layers) { if (regKf.layers.hasOwnProperty(kKf)) validIdsKf.push(kKf + '(' + regKf.layers[kKf].name + ')'); }
            return MT_err('layer_id=' + args.layer_id + ' nao existe. Existentes: ' + validIdsKf.join(', '));
        }

        var propMapK = {
            'position': 'ADBE Position',
            'scale': 'ADBE Scale',
            'opacity': 'ADBE Opacity',
            'rotation': 'ADBE Rotate Z',
            'anchor': 'ADBE Anchor Point'
        };
        var propNameK = propMapK[args.property];
        if (!propNameK) return MT_err('propriedade invalida: ' + args.property);

        var prop = layer.property('ADBE Transform Group').property(propNameK);
        if (!prop) return MT_err('propriedade nao acessivel');

        if (!(args.keyframes instanceof Array) || args.keyframes.length === 0) {
            return MT_err('keyframes deve ser array nao-vazio com { time, value }');
        }

        app.beginUndoGroup('MT_Tool: set_keyframes');
        var added = 0;
        for (var ki = 0; ki < args.keyframes.length; ki++) {
            var kf = args.keyframes[ki];
            if (typeof kf.time === 'number' && kf.value !== undefined) {
                try { prop.setValueAtTime(kf.time, kf.value); added++; } catch(eK) {}
            }
        }
        // Ease forte em TODOS os keyframes
        try {
            var d = 1, v = prop.propertyValueType;
            if (v === PropertyValueType.TwoD || v === PropertyValueType.TwoD_SPATIAL) d = 2;
            if (v === PropertyValueType.ThreeD || v === PropertyValueType.ThreeD_SPATIAL) d = 3;
            for (var k = 1; k <= prop.numKeys; k++) {
                var ei = [], eo = [];
                for (var j = 0; j < d; j++) { ei.push(new KeyframeEase(0, 85)); eo.push(new KeyframeEase(0, 85)); }
                try { prop.setTemporalEaseAtKey(k, ei, eo); } catch(eE) {}
            }
        } catch(eEase) {}
        app.endUndoGroup();
        return MT_ok({ layer: layer.name, property: args.property, keyframes_added: added, total_keys: prop.numKeys });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 15 — set_transform (BATCH — multiplas props numa chamada)
// args: {
//   "layer_id": "Card",
//   "position": [540, 960],  // opcional
//   "scale": [100, 100],     // opcional (ou numero unico pra ambos)
//   "rotation": 0,           // opcional
//   "anchor": [0, 0],        // opcional
//   "opacity": 100           // opcional
// }
// ═══════════════════════════════════════════════════════════

function MT_tool_set_transform(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var layer = MT_getLayer(args.layer_id);
        if (!layer) return MT_err('layer_id=' + args.layer_id + ' nao existe');

        app.beginUndoGroup('MT_Tool: set_transform');
        var tg = layer.property('ADBE Transform Group');
        var applied = [];

        if (args.position !== undefined) {
            try { tg.property('ADBE Position').setValue(args.position); applied.push('position'); } catch(eP) {}
        }
        if (args.scale !== undefined) {
            var sv = (typeof args.scale === 'number') ? [args.scale, args.scale] : args.scale;
            try { tg.property('ADBE Scale').setValue(sv); applied.push('scale'); } catch(eS) {}
        }
        if (args.rotation !== undefined) {
            try { tg.property('ADBE Rotate Z').setValue(args.rotation); applied.push('rotation'); } catch(eR) {}
        }
        if (args.anchor !== undefined) {
            try { tg.property('ADBE Anchor Point').setValue(args.anchor); applied.push('anchor'); } catch(eA) {}
        }
        if (args.opacity !== undefined) {
            try { tg.property('ADBE Opacity').setValue(args.opacity); applied.push('opacity'); } catch(eO) {}
        }

        app.endUndoGroup();
        if (applied.length === 0) return MT_err('nenhuma propriedade setada. Passe position/scale/rotation/anchor/opacity');
        return MT_ok({ layer: layer.name, applied: applied });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL 16 — delete_layer (undo granular — remove uma layer especifica)
// args: { "layer_id": "Card2" }
// ═══════════════════════════════════════════════════════════

function MT_tool_delete_layer(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var layer = MT_getLayer(args.layer_id);
        if (!layer) return MT_err('layer_id=' + args.layer_id + ' nao existe');

        var name = layer.name;
        app.beginUndoGroup('MT_Tool: delete_layer');
        try { layer.remove(); } catch(eR) { app.endUndoGroup(); return MT_err('falha ao remover: ' + eR); }
        app.endUndoGroup();

        // Remove do registry
        var reg = MT_initRegistry();
        for (var rk in reg.layers) {
            if (reg.layers.hasOwnProperty(rk) && reg.layers[rk] === layer) {
                delete reg.layers[rk];
                break;
            }
        }

        return MT_ok({ deleted: name });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// FASE 6 — AUTOMATION TOOLS (trabalha com comps/layers EXISTENTES, nao registry)
// ═══════════════════════════════════════════════════════════

// Helper: pega comp ativa (do AE, nao do registry)
function MT_getActiveCompAny() {
    var a = app.project.activeItem;
    if (a instanceof CompItem) return a;
    return MT_getComp();
}

// Helper: pega layer existente da comp ativa por NAME ou INDEX (1-based)
// Tambem aceita layer_id do registry (numerico/string/last)
function MT_getLayerAny(compArg, ref) {
    if (ref === null || ref === undefined) return null;
    var comp = compArg ? MT_getComp(compArg) : MT_getActiveCompAny();
    if (!comp) return null;
    // Tenta no registry primeiro
    var regLayer = MT_getLayer(ref);
    if (regLayer) return regLayer;
    // Index 1-based
    if (typeof ref === 'number' || /^\d+$/.test(String(ref))) {
        try { return comp.layer(parseInt(ref)); } catch(e) { return null; }
    }
    // Nome
    try { return comp.layer(String(ref)); } catch(e) {}
    return null;
}

// ═══════════════════════════════════════════════════════════
// TOOL — get_selected_layers
// Retorna info das layers selecionadas pelo usuario na comp ativa.
// args: {} (vazio)
// ═══════════════════════════════════════════════════════════

function MT_tool_get_selected_layers(argsJSON) {
    try {
        var comp = MT_getActiveCompAny();
        if (!comp) return MT_err('nenhuma comp ativa');
        var sel = comp.selectedLayers;
        var out = [];
        for (var i = 0; i < sel.length; i++) {
            var l = sel[i];
            var info = { index: l.index, name: l.name, in_point: l.inPoint, out_point: l.outPoint };
            try {
                if (l instanceof TextLayer) info.type = 'text';
                else if (l instanceof ShapeLayer) info.type = 'shape';
                else if (l.nullLayer) info.type = 'null';
                else if (l instanceof AVLayer) info.type = 'av';
                else info.type = 'other';
            } catch(e) {}
            out.push(info);
        }
        return MT_ok({ comp: comp.name, count: out.length, layers: out });
    } catch(e) {
        return MT_err(e.toString());
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL — list_comps
// Lista todas as comps no projeto ativo.
// args: {} (vazio)
// ═══════════════════════════════════════════════════════════

function MT_tool_list_comps(argsJSON) {
    try {
        var comps = [];
        for (var i = 1; i <= app.project.numItems; i++) {
            try {
                var it = app.project.item(i);
                if (it instanceof CompItem) {
                    comps.push({
                        index: i,
                        name: it.name,
                        width: it.width,
                        height: it.height,
                        duration: it.duration,
                        fps: it.frameRate,
                        num_layers: it.numLayers,
                        is_active: (it === app.project.activeItem)
                    });
                }
            } catch(e) {}
        }
        return MT_ok({ count: comps.length, comps: comps });
    } catch(e) {
        return MT_err(e.toString());
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL — open_comp
// Ativa uma comp existente no project (por name ou index).
// args: { "name": "MyComp" } OU { "index": 5 }
// ═══════════════════════════════════════════════════════════

function MT_tool_open_comp(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var target = null;
        if (args.name) {
            for (var i = 1; i <= app.project.numItems; i++) {
                var it = app.project.item(i);
                if (it instanceof CompItem && it.name === args.name) { target = it; break; }
            }
        } else if (args.index) {
            try {
                var byIdx = app.project.item(args.index);
                if (byIdx instanceof CompItem) target = byIdx;
            } catch(e) {}
        }
        if (!target) return MT_err('comp nao encontrada (passe name ou index valido)');
        target.openInViewer();
        // Atualiza registry pra refletir essa comp como atual (o agente pode adicionar layers nela)
        var reg = MT_initRegistry();
        var foundId = null;
        for (var k in reg.comps) {
            if (reg.comps[k] === target) { foundId = k; break; }
        }
        if (foundId === null) {
            foundId = reg.next_comp_id++;
            reg.comps[foundId] = target;
        }
        reg.current_comp_id = foundId;
        return MT_ok({ comp: target.name, comp_id: foundId, width: target.width, height: target.height, duration: target.duration });
    } catch(e) {
        return MT_err(e.toString());
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL — pre_compose_selected
// Pre-compoe (encapsula) layers selecionadas em uma nova comp.
// args: { "name": "PreComp_Group", "move_attributes": true }
// ═══════════════════════════════════════════════════════════

function MT_tool_pre_compose_selected(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var comp = MT_getActiveCompAny();
        if (!comp) return MT_err('sem comp ativa');
        var sel = comp.selectedLayers;
        if (sel.length === 0) return MT_err('selecione ao menos 1 layer');

        var indices = [];
        for (var i = 0; i < sel.length; i++) indices.push(sel[i].index);

        app.beginUndoGroup('MT: pre_compose_selected');
        var name = args.name || ('PreComp_' + Date.now());
        var newComp = comp.layers.precompose(indices, name, args.move_attributes !== false);
        app.endUndoGroup();

        return MT_ok({ pre_comp_name: name, layers_precomposed: indices.length });
    } catch(e) {
        return MT_err(e.toString() + ' linha ' + e.line);
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL — batch_rename_selected
// Renomeia layers selecionadas com pattern (use {N} pra numero, {n} pra numero zero-padded)
// args: { "pattern": "Card_{N}", "start": 1 }
// ═══════════════════════════════════════════════════════════

function MT_tool_batch_rename_selected(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var comp = MT_getActiveCompAny();
        if (!comp) return MT_err('sem comp ativa');
        var sel = comp.selectedLayers;
        if (sel.length === 0) return MT_err('selecione ao menos 1 layer');
        var pattern = args.pattern || 'Layer_{N}';
        var start = args.start || 1;

        app.beginUndoGroup('MT: batch_rename_selected');
        var renamed = [];
        for (var i = 0; i < sel.length; i++) {
            var n = start + i;
            var nPad = (n < 10 ? '0' + n : '' + n);
            var newName = pattern.replace(/\{N\}/g, n).replace(/\{n\}/g, nPad);
            var oldName = sel[i].name;
            sel[i].name = newName;
            renamed.push({ from: oldName, to: newName });
        }
        app.endUndoGroup();
        return MT_ok({ renamed_count: renamed.length, renamed: renamed });
    } catch(e) {
        return MT_err(e.toString());
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL — align_selected
// Alinha layers selecionadas (horizontal/vertical/both) ao centro da comp.
// args: { "axis": "h"|"v"|"both", "anchor": "comp"|"first"|"last" }
// ═══════════════════════════════════════════════════════════

function MT_tool_align_selected(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var comp = MT_getActiveCompAny();
        if (!comp) return MT_err('sem comp ativa');
        var sel = comp.selectedLayers;
        if (sel.length === 0) return MT_err('selecione ao menos 1 layer');

        var axis = args.axis || 'both';
        var anchor = args.anchor || 'comp';
        var targetX = comp.width / 2;
        var targetY = comp.height / 2;

        if (anchor === 'first' && sel.length > 0) {
            var p0 = sel[0].property('ADBE Transform Group').property('ADBE Position').value;
            targetX = p0[0]; targetY = p0[1];
        } else if (anchor === 'last' && sel.length > 0) {
            var pL = sel[sel.length-1].property('ADBE Transform Group').property('ADBE Position').value;
            targetX = pL[0]; targetY = pL[1];
        }

        app.beginUndoGroup('MT: align_selected');
        var aligned = 0;
        for (var i = 0; i < sel.length; i++) {
            try {
                var pp = sel[i].property('ADBE Transform Group').property('ADBE Position');
                var v = pp.value;
                var nx = (axis === 'v') ? v[0] : targetX;
                var ny = (axis === 'h') ? v[1] : targetY;
                pp.setValue(v.length === 3 ? [nx, ny, v[2]] : [nx, ny]);
                aligned++;
            } catch(e) {}
        }
        app.endUndoGroup();
        return MT_ok({ aligned: aligned, axis: axis, anchor: anchor });
    } catch(e) {
        return MT_err(e.toString());
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL — stagger_selected
// Offset incrementalmente o inPoint/outPoint das layers selecionadas (cascade).
// args: { "offset": 0.1, "from": "first"|"last" }
// ═══════════════════════════════════════════════════════════

function MT_tool_stagger_selected(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var comp = MT_getActiveCompAny();
        if (!comp) return MT_err('sem comp ativa');
        var sel = comp.selectedLayers;
        if (sel.length < 2) return MT_err('selecione ao menos 2 layers');
        var offset = args.offset || 0.1;
        var fromLast = (args.from === 'last');

        app.beginUndoGroup('MT: stagger_selected');
        for (var i = 0; i < sel.length; i++) {
            var multiplier = fromLast ? (sel.length - 1 - i) : i;
            var shift = offset * multiplier;
            sel[i].startTime += shift;
        }
        app.endUndoGroup();
        return MT_ok({ staggered: sel.length, offset: offset, total_spread: offset * (sel.length - 1) });
    } catch(e) {
        return MT_err(e.toString());
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL — trim_selected
// Define inPoint/outPoint das layers selecionadas.
// args: { "in_point": 2.0, "out_point": 5.0 }
// ═══════════════════════════════════════════════════════════

function MT_tool_trim_selected(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var comp = MT_getActiveCompAny();
        if (!comp) return MT_err('sem comp ativa');
        var sel = comp.selectedLayers;
        if (sel.length === 0) return MT_err('selecione ao menos 1 layer');

        app.beginUndoGroup('MT: trim_selected');
        var trimmed = 0;
        for (var i = 0; i < sel.length; i++) {
            try {
                if (args.in_point !== undefined) sel[i].inPoint = args.in_point;
                if (args.out_point !== undefined) sel[i].outPoint = args.out_point;
                trimmed++;
            } catch(e) {}
        }
        app.endUndoGroup();
        return MT_ok({ trimmed: trimmed, in_point: args.in_point, out_point: args.out_point });
    } catch(e) {
        return MT_err(e.toString());
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL — toggle_layer_flag
// Liga/desliga flags da layer (solo, mute, lock, shy, threeD).
// args: { "layer_id": 2, "flag": "solo"|"enabled"|"locked"|"shy"|"threeD", "value": true }
// Se layer_id ausente, aplica em selectedLayers.
// ═══════════════════════════════════════════════════════════

function MT_tool_toggle_layer_flag(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var flag = String(args.flag || '');
        var value = args.value;
        var validFlags = { solo:1, enabled:1, locked:1, shy:1, threeD:1 };
        if (!validFlags[flag]) return MT_err('flag invalida: ' + flag + '. Use: solo|enabled|locked|shy|threeD');

        var targets = [];
        if (args.layer_id !== undefined) {
            var lay = MT_getLayerAny(null, args.layer_id);
            if (!lay) return MT_err('layer_id=' + args.layer_id + ' nao existe');
            targets = [lay];
        } else {
            var comp = MT_getActiveCompAny();
            if (!comp) return MT_err('sem comp ativa nem layer_id');
            targets = comp.selectedLayers;
            if (targets.length === 0) return MT_err('selecione ao menos 1 layer');
        }

        app.beginUndoGroup('MT: toggle_layer_flag ' + flag);
        var changed = 0;
        for (var i = 0; i < targets.length; i++) {
            try {
                var newVal = (value !== undefined) ? !!value : !targets[i][flag === 'threeD' ? 'threeDLayer' : flag];
                if (flag === 'threeD') targets[i].threeDLayer = newVal;
                else targets[i][flag] = newVal;
                changed++;
            } catch(e) {}
        }
        app.endUndoGroup();
        return MT_ok({ flag: flag, value: value, changed_count: changed });
    } catch(e) {
        return MT_err(e.toString());
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL — apply_to_selected
// Aplica apply_helper OU apply_effect em TODAS as layers selecionadas.
// Bom pra "drop shadow em todos selecionados" sem chamar 1 tool por layer.
// args: { "tool": "apply_helper"|"apply_effect", "params": { ... params normais sem layer_id } }
// ═══════════════════════════════════════════════════════════

function MT_tool_apply_to_selected(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var tool = args.tool;
        if (tool !== 'apply_helper' && tool !== 'apply_effect') return MT_err('tool invalida: use "apply_helper" ou "apply_effect"');
        var comp = MT_getActiveCompAny();
        if (!comp) return MT_err('sem comp ativa');
        var sel = comp.selectedLayers;
        if (sel.length === 0) return MT_err('selecione ao menos 1 layer');

        var reg = MT_initRegistry();
        var applied = 0;
        var errors = [];
        for (var i = 0; i < sel.length; i++) {
            // Registra a layer no registry pra poder usar tool padrao
            var layer = sel[i];
            var tempId = null;
            for (var k in reg.layers) {
                if (reg.layers[k] === layer) { tempId = k; break; }
            }
            if (tempId === null) {
                tempId = reg.next_layer_id++;
                reg.layers[tempId] = layer;
            }
            // Chama a tool
            var subArgs = {};
            for (var p in args.params) subArgs[p] = args.params[p];
            subArgs.layer_id = tempId;
            var subJSON = MT_stringifyValue(subArgs);
            var res = (tool === 'apply_helper') ? MT_tool_apply_helper(subJSON) : MT_tool_apply_effect(subJSON);
            try {
                var parsed = eval('(' + res + ')');
                if (parsed.ok) applied++;
                else errors.push({ layer: layer.name, err: parsed.error });
            } catch(eP) { errors.push({ layer: layer.name, err: 'parse fail' }); }
        }
        return MT_ok({ applied: applied, total: sel.length, errors: errors });
    } catch(e) {
        return MT_err(e.toString());
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL — save_project
// Salva o projeto AE atual (Ctrl+S programatico).
// args: {} (vazio)
// ═══════════════════════════════════════════════════════════

function MT_tool_save_project(argsJSON) {
    try {
        if (!app.project.file) return MT_err('projeto nao foi salvo ainda — usuario precisa fazer Save As primeiro');
        app.project.save();
        return MT_ok({ saved: true, path: app.project.file.fsName });
    } catch(e) {
        return MT_err(e.toString());
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL — set_work_area
// Define a work area da comp ativa (regiao de loop/render).
// args: { "in": 2.0, "out": 8.0 }
// ═══════════════════════════════════════════════════════════

function MT_tool_set_work_area(argsJSON) {
    try {
        var args = MT_parseJSON(argsJSON) || {};
        var comp = MT_getActiveCompAny();
        if (!comp) return MT_err('sem comp ativa');
        if (args['in'] !== undefined) comp.workAreaStart = args['in'];
        if (args.out !== undefined) comp.workAreaDuration = (args.out - comp.workAreaStart);
        return MT_ok({ work_in: comp.workAreaStart, work_out: comp.workAreaStart + comp.workAreaDuration });
    } catch(e) {
        return MT_err(e.toString());
    }
}

// ═══════════════════════════════════════════════════════════
// TOOL ROUTER — recebe tool_name + argsJSON e despacha
// ═══════════════════════════════════════════════════════════

function MT_tool_dispatch(tool_name, argsJSON) {
    try {
        switch (tool_name) {
            case 'create_comp':      return MT_tool_create_comp(argsJSON);
            case 'add_text':         return MT_tool_add_text(argsJSON);
            case 'add_shape_rect':   return MT_tool_add_shape_rect(argsJSON);
            case 'set_keyframe':     return MT_tool_set_keyframe(argsJSON);
            case 'apply_helper':     return MT_tool_apply_helper(argsJSON);
            // Fase 3:
            case 'set_parent':       return MT_tool_set_parent(argsJSON);
            case 'set_expression':   return MT_tool_set_expression(argsJSON);
            case 'apply_effect':     return MT_tool_apply_effect(argsJSON);
            case 'add_null':         return MT_tool_add_null(argsJSON);
            case 'duplicate_layer':  return MT_tool_duplicate_layer(argsJSON);
            case 'set_3d_layer':     return MT_tool_set_3d_layer(argsJSON);
            case 'set_blend_mode':   return MT_tool_set_blend_mode(argsJSON);
            // Fase 4:
            case 'query_state':      return MT_tool_query_state(argsJSON);
            case 'set_keyframes':    return MT_tool_set_keyframes(argsJSON);
            case 'set_transform':    return MT_tool_set_transform(argsJSON);
            case 'delete_layer':     return MT_tool_delete_layer(argsJSON);
            // Fase 6 — AUTOMATION (trabalha com layers/comps existentes do usuario):
            case 'get_selected_layers': return MT_tool_get_selected_layers(argsJSON);
            case 'list_comps':          return MT_tool_list_comps(argsJSON);
            case 'open_comp':           return MT_tool_open_comp(argsJSON);
            case 'pre_compose_selected': return MT_tool_pre_compose_selected(argsJSON);
            case 'batch_rename_selected': return MT_tool_batch_rename_selected(argsJSON);
            case 'align_selected':      return MT_tool_align_selected(argsJSON);
            case 'stagger_selected':    return MT_tool_stagger_selected(argsJSON);
            case 'trim_selected':       return MT_tool_trim_selected(argsJSON);
            case 'toggle_layer_flag':   return MT_tool_toggle_layer_flag(argsJSON);
            case 'apply_to_selected':   return MT_tool_apply_to_selected(argsJSON);
            case 'save_project':        return MT_tool_save_project(argsJSON);
            case 'set_work_area':       return MT_tool_set_work_area(argsJSON);
            // Utilitarios
            case 'reset_registry':   return MT_resetRegistry();
            default:
                return MT_err('tool desconhecida: ' + tool_name);
        }
    } catch(e) {
        return MT_err('dispatch erro: ' + e.toString());
    }
}
