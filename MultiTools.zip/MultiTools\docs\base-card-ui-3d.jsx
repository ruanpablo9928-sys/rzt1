(function() {
    // ╔═════════════════════════════════════════════════════════════╗
    // ║  AI MASKING UI RECREATION — DARK MODE (GAKU LANGE TREND)    ║
    // ║  1080x1920 @ 30fps — 10.0s                                  ║
    // ║  3D Pop-in Card, Staggered Load e Curva Manteiga Max (100%) ║
    // ╚═════════════════════════════════════════════════════════════╝

    var AE = {};
    AE.gc = function(p, ns) { var c = p; for (var i=0; i<ns.length; i++) { try { c = c.property(ns[i]); } catch(e) { return null; } if (!c) return null; } return c; };
    AE.pos = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Position"]) : null; };
    AE.scl = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Scale"]) : null; };
    AE.opa = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Opacity"]) : null; };
    AE.rY = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Rotate Y"]) : null; };
    AE.rX = function(l) { return l ? AE.gc(l, ["ADBE Transform Group", "ADBE Rotate X"]) : null; };
    AE.sv = function(p, v) { if (!p) return; try { p.setValue(v); } catch(e) {} };
    AE.sa = function(p, t, v) { if (!p) return; try { p.setValueAtTime(t, v); } catch(e) {} };
    AE.gv = function(p) { if (!p) return null; try { return p.value; } catch(e) { return null; } };
    AE.hex = function(h) { h = h.replace("#", ""); return [parseInt(h.substr(0,2),16)/255, parseInt(h.substr(2,2),16)/255, parseInt(h.substr(4,2),16)/255]; };
    AE.fx = function(l, mn) { if (!l) return null; try { return l.property("ADBE Effect Parade").addProperty(mn); } catch(e) { return null; } };

    // --- CURVA MANTEIGA MAX (100% INFLUÊNCIA) ---
    AE.maxEase = function(p) {
        if (!p || p.numKeys === 0) return;
        try {
            var d = 1, v = p.propertyValueType;
            if (v === PropertyValueType.TwoD || v === PropertyValueType.TwoD_SPATIAL) d = 2;
            if (v === PropertyValueType.ThreeD || v === PropertyValueType.ThreeD_SPATIAL) d = 3;
            for (var k = 1; k <= p.numKeys; k++) {
                var ei = [], eo = [];
                // 100% de tensão nas pontas! 
                for (var j = 0; j < d; j++) { ei.push(new KeyframeEase(0, 100)); eo.push(new KeyframeEase(0, 100)); }
                p.setTemporalEaseAtKey(k, ei, eo);
            }
        } catch(e) {}
    };

    // -- CONSTRUTORES --
    function mkSolid(comp, cor, nome) { try { return comp.layers.addSolid(cor, nome, comp.width, comp.height, 1); } catch(e) { return null; } }
    
    function mkRect(comp, pos, tamanho, roundness, corFill, corStroke, strokeW, nome) {
        try {
            var s = comp.layers.addShape(); s.name = nome || "Rect";
            var grp = s.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
            var vec = grp.property("ADBE Vectors Group");
            var r = vec.addProperty("ADBE Vector Shape - Rect");
            r.property("ADBE Vector Rect Size").setValue(tamanho);
            r.property("ADBE Vector Rect Roundness").setValue(roundness || 0);
            if (corFill) {
                var f = vec.addProperty("ADBE Vector Graphic - Fill");
                f.property("ADBE Vector Fill Color").setValue(corFill);
            }
            if (corStroke) {
                var st = vec.addProperty("ADBE Vector Graphic - Stroke");
                st.property("ADBE Vector Stroke Color").setValue(corStroke);
                st.property("ADBE Vector Stroke Width").setValue(strokeW || 2);
            }
            AE.sv(AE.pos(s), pos); return s;
        } catch(e) { return null; }
    }

    function mkText(comp, texto, pos, tamanho, cor, alinhamento, nome) {
        try {
            var l = comp.layers.addText(texto); l.name = nome || "Txt";
            var tp = AE.gc(l, ["ADBE Text Properties", "ADBE Text Document"]);
            if (tp) {
                var d = tp.value; d.font = "ArialMT"; d.fontSize = tamanho || 30; d.fillColor = cor || [1, 1, 1];
                if (alinhamento === "c") d.justification = ParagraphJustification.CENTER_JUSTIFY;
                if (alinhamento === "l") d.justification = ParagraphJustification.LEFT_JUSTIFY;
                if (alinhamento === "r") d.justification = ParagraphJustification.RIGHT_JUSTIFY;
                tp.setValue(d);
            }
            AE.sv(AE.pos(l), pos); return l;
        } catch(e) { return null; }
    }

    app.beginUndoGroup("Gaku Lange AI Prompt UI");

    try {
        var comp = app.project.items.addComp("AI_Masking_UI_Trend", 1080, 1920, 1, 10.0, 30);
        
        // Paleta Dark Mode Premium
        var cBg = AE.hex("#09090A");
        var cCard = AE.hex("#131315");
        var cCardBorder = AE.hex("#2A2A2D");
        var cImg = AE.hex("#1A1A1D");
        var cInput = AE.hex("#1F1F22");
        var cTextPrimary = AE.hex("#F0F0F2");
        var cTextSecondary = AE.hex("#9AA0A6");

        // 1. Fundo Escuro
        var bg = mkSolid(comp, cBg, "Background");
        
        // 2. Controlador Geral do Card (Para mover tudo de uma vez)
        var cc = comp.layers.addNull();
        cc.name = "Card_Controller";
        AE.sv(AE.pos(cc), [540, 960]);
        cc.threeDLayer = true;

        var children = [];

        // 3. Base do Card
        var cardBase = mkRect(comp, [540, 960], [920, 1250], 60, cCard, cCardBorder, 3, "Card_Base");
        var drop = AE.fx(cardBase, "ADBE Drop Shadow");
        if(drop) {
            AE.sv(AE.gc(drop, ["ADBE Drop Shadow-0002"]), 60);  // Opacity
            AE.sv(AE.gc(drop, ["ADBE Drop Shadow-0004"]), 180); // Angle
            AE.sv(AE.gc(drop, ["ADBE Drop Shadow-0005"]), 40);  // Distance
            AE.sv(AE.gc(drop, ["ADBE Drop Shadow-0006"]), 150); // Softness gigantesca
        }
        cardBase.parent = cc; children.push(cardBase);

        // 4. Cabeçalho (Header)
        var title = mkText(comp, "✦   Masking", [130, 420], 45, cTextPrimary, "l", "Title");
        title.parent = cc; children.push(title);

        var editIcon = mkText(comp, "✎", [800, 415], 45, cTextSecondary, "c", "Edit_Icon");
        var menuIcon = mkText(comp, "•••", [880, 415], 45, cTextSecondary, "c", "Menu_Icons");
        editIcon.parent = cc; children.push(editIcon);
        menuIcon.parent = cc; children.push(menuIcon);

        // 5. Placeholder da Imagem/Vídeo
        var imgPh = mkRect(comp, [540, 750], [820, 550], 40, cImg, cCardBorder, 2, "Image_Placeholder");
        imgPh.parent = cc; children.push(imgPh);

        // 6. Área de Textos
        var subtitle = mkText(comp, "Instructions", [130, 1080], 35, cTextPrimary, "l", "Subtitle");
        subtitle.parent = cc; children.push(subtitle);

        var descText = "Rotoscope out your subject from one frame\nand then lay it on top of another. The skill is\nplanning your two frames so they sync up\nreally nicely!";
        var desc = mkText(comp, descText, [130, 1140], 32, cTextSecondary, "l", "Description");
        desc.parent = cc; children.push(desc);

        // 7. Mini UI (Ícones de Like, Share, etc em formato de texto pra ser universal)
        var miniUI = mkText(comp, "👍   👎   🔄   ⬆️", [130, 1340], 35, cTextSecondary, "l", "Mini_UI_Icons");
        miniUI.parent = cc; children.push(miniUI);

        // 8. Barra de Input ("Ask anything")
        var inputBar = mkRect(comp, [540, 1460], [820, 100], 50, cInput, cCardBorder, 2, "Input_Bar");
        inputBar.parent = cc; children.push(inputBar);

        var plusIcon = mkText(comp, "+", [170, 1475], 50, cTextSecondary, "l", "Plus_Icon");
        var inputTxt = mkText(comp, "Ask anything", [220, 1470], 32, cTextSecondary, "l", "Input_Text");
        var micIcon = mkText(comp, "🎙", [880, 1475], 35, cTextSecondary, "c", "Mic_Icon");
        
        plusIcon.parent = cc; children.push(plusIcon);
        inputTxt.parent = cc; children.push(inputTxt);
        micIcon.parent = cc; children.push(micIcon);

        // ─────────────────────────────────────
        // ANIMAÇÕES (MÁGICA DO MOVIMENTO AQUI)
        // ─────────────────────────────────────
        
        // Entrada do Card Principal (Sobe do fundo em 3D)
        var ccPos = AE.pos(cc);
        AE.sa(ccPos, 0.5, [540, 2500, 500]); // Vem de fora da tela e de trás no eixo Z
        AE.sa(ccPos, 2.5, [540, 960, 0]); 
        AE.maxEase(ccPos);

        var ccScl = AE.scl(cc);
        AE.sa(ccScl, 0.5, [75, 75, 100]); // Escala levemente menor
        AE.sa(ccScl, 2.5, [100, 100, 100]);
        AE.maxEase(ccScl);

        var ccRX = AE.rX(cc);
        AE.sa(ccRX, 0.5, -25); // Card inclinado para frente
        AE.sa(ccRX, 2.5, 0);   // Encaixa na tela
        AE.maxEase(ccRX);

        // Entrada em Cascata (Stagger) dos elementos de dentro do Card
        for(var i = 1; i < children.length; i++) { // Pula a base (índice 0)
            var el = children[i];
            var op = AE.opa(el);
            var ep = AE.pos(el);
            var stPos = AE.gv(ep); // Grava a posição original relativa

            var delay = 1.0 + (i * 0.05); // Atraso calculado para o efeito de onda

            // Fade in Suave
            AE.sa(op, delay, 0);
            AE.sa(op, delay + 0.8, 100);
            AE.maxEase(op);

            // Deslize de baixo pra cima
            AE.sa(ep, delay, [stPos[0], stPos[1] + 40]);
            AE.sa(ep, delay + 1.2, stPos);
            AE.maxEase(ep);
        }

        alert("Sucesso!\n\nRecriei a interface 'Dark Mode' (Painel de AI Masking) que aparece como destaque na trend de edição do vídeo.\n\nTudo foi animado usando o 100% Ease (Manteiga Max), incluindo um Efeito Cascata (Stagger) nos elementos internos para dar aquela sensação premium de um aplicativo carregando na tela.");

    } catch(e) {
        alert("Erro fatal: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();