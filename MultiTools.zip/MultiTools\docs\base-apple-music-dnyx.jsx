(function() {
    // ══════════════════════════════════════════════════════════════════════
    // ║  APPLE MUSIC / DNYXSTUDIOS - RECRIACAO COMPLETA                   ║
    // ║  1080x1080 @ 30fps - 24.0s                                        ║
    // ║  Motion Apple + Bounce elastico + Morphing shapes                 ║
    // ║  10 cenas: icon > card > list > emoji > Q > orbit > phone >       ║
    // ║  transicao > dnyx pink > IG logo outro                            ║
    // ══════════════════════════════════════════════════════════════════════

    // === BIBLIOTECA AE ===
    var AE = {};
    AE.gc=function(p,ns){var c=p;for(var i=0;i<ns.length;i++){try{c=c.property(ns[i])}catch(e){return null}if(!c)return null}return c};
    AE.pos=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Position"]):null};
    AE.scl=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Scale"]):null};
    AE.opa=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Opacity"]):null};
    AE.rot=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Rotate Z"]):null};
    AE.anc=function(l){return l?AE.gc(l,["ADBE Transform Group","ADBE Anchor Point"]):null};
    AE.sv=function(p,v){if(!p)return;try{p.setValue(v)}catch(e){}};
    AE.sa=function(p,t,v){if(!p)return;try{p.setValueAtTime(t,v)}catch(e){}};
    AE.gv=function(p){if(!p)return null;try{return p.value}catch(e){return null}};
    AE.hex=function(h){h=h.replace("#","");return[parseInt(h.substr(0,2),16)/255,parseInt(h.substr(2,2),16)/255,parseInt(h.substr(4,2),16)/255]};
    AE.ease=function(p,inf){if(!p||p.numKeys===0)return;inf=inf||85;try{var d=1,v=p.propertyValueType;if(v===PropertyValueType.TwoD||v===PropertyValueType.TwoD_SPATIAL)d=2;if(v===PropertyValueType.ThreeD||v===PropertyValueType.ThreeD_SPATIAL)d=3;for(var k=1;k<=p.numKeys;k++){var ei=[],eo=[];for(var j=0;j<d;j++){ei.push(new KeyframeEase(0,inf));eo.push(new KeyframeEase(0,inf))}p.setTemporalEaseAtKey(k,ei,eo)}}catch(e){}};
    AE.fx=function(l,mn){if(!l)return null;try{return l.property("ADBE Effect Parade").addProperty(mn)}catch(e){return null}};

    // === CRIADORES ===
    function SH(comp,n){try{var s=comp.layers.addShape();if(s&&n)s.name=n;return s}catch(e){return null}}

    function EL(comp,cfg){
        cfg=cfg||{};var s=SH(comp,cfg.n||"E");if(!s)return null;
        try{var v=s.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group").property("ADBE Vectors Group");
        var el=v.addProperty("ADBE Vector Shape - Ellipse");var r=cfg.r||50;el.property("ADBE Vector Ellipse Size").setValue([r*2,r*2]);
        if(cfg.fc!==false){var f=v.addProperty("ADBE Vector Graphic - Fill");var c=cfg.fc||[1,1,1];f.property("ADBE Vector Fill Color").setValue([c[0],c[1],c[2],1])}
        if(cfg.sc){var st=v.addProperty("ADBE Vector Graphic - Stroke");st.property("ADBE Vector Stroke Color").setValue([cfg.sc[0],cfg.sc[1],cfg.sc[2],1]);st.property("ADBE Vector Stroke Width").setValue(cfg.sw||2)}
        if(cfg.p)AE.sv(AE.pos(s),cfg.p);return s}catch(e){return null}
    }

    function RC(comp,cfg){
        cfg=cfg||{};var s=SH(comp,cfg.n||"R");if(!s)return null;
        try{var v=s.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group").property("ADBE Vectors Group");
        var r=v.addProperty("ADBE Vector Shape - Rect");r.property("ADBE Vector Rect Size").setValue(cfg.sz||[200,200]);
        r.property("ADBE Vector Rect Roundness").setValue(cfg.rn||0);
        if(cfg.fc!==false){var f=v.addProperty("ADBE Vector Graphic - Fill");var c=cfg.fc||[1,1,1];f.property("ADBE Vector Fill Color").setValue([c[0],c[1],c[2],1])}
        if(cfg.sc){var st=v.addProperty("ADBE Vector Graphic - Stroke");st.property("ADBE Vector Stroke Color").setValue([cfg.sc[0],cfg.sc[1],cfg.sc[2],1]);st.property("ADBE Vector Stroke Width").setValue(cfg.sw||2)}
        if(cfg.p)AE.sv(AE.pos(s),cfg.p);return s}catch(e){return null}
    }

    function TX(comp,t,cfg){
        if(!comp)return null;try{cfg=cfg||{};var l=comp.layers.addText(t||"");if(!l)return null;
        l.name=cfg.n||"T";var tp=AE.gc(l,["ADBE Text Properties","ADBE Text Document"]);
        if(tp){var d=tp.value;d.font=cfg.f||"Arial-BoldMT";d.fontSize=cfg.s||30;d.fillColor=cfg.c||[0,0,0];
        d.tracking=cfg.tr!==undefined?cfg.tr:0;
        if(cfg.al==="c")d.justification=ParagraphJustification.CENTER_JUSTIFY;
        if(cfg.al==="l")d.justification=ParagraphJustification.LEFT_JUSTIFY;
        if(cfg.al==="r")d.justification=ParagraphJustification.RIGHT_JUSTIFY;
        tp.setValue(d)}if(cfg.p)AE.sv(AE.pos(l),cfg.p);return l}catch(e){return null}
    }

    function SLD(comp,cor,n,w,h){try{return comp.layers.addSolid(cor||[0,0,0],n||"S",w||comp.width,h||comp.height,1)}catch(e){return null}}

    // ════════════════════════════════════════════════════════
    // === MOTION HELPERS: MORPHING TOTAL ===
    // ════════════════════════════════════════════════════════

    // Get or add Gaussian Blur (evita empilhar blurs duplicados)
    function getBlur(layer) {
        if (!layer) return null;
        try {
            var ep = layer.property("ADBE Effect Parade");
            if (!ep) return null;
            for (var e = 1; e <= ep.numProperties; e++) {
                try {
                    var pp = ep.property(e);
                    if (pp && pp.matchName === "ADBE Gaussian Blur 2") {
                        return AE.gc(pp, ["ADBE Gaussian Blur 2-0001"]);
                    }
                } catch(ee) {}
            }
            var nb = ep.addProperty("ADBE Gaussian Blur 2");
            if (nb) {
                try { AE.gc(nb, ["ADBE Gaussian Blur 2-0002"]).setValue(1); } catch(ee2) {}
                return AE.gc(nb, ["ADBE Gaussian Blur 2-0001"]);
            }
        } catch(e) {}
        return null;
    }

    // MORPH IN: suave, com subtle overshoot — nao pula fora do container
    function morphIn(layer, tIn, dur) {
        if (!layer) return;
        dur = dur || 0.85;
        var s = AE.scl(layer);
        var o = AE.opa(layer);
        var bP = getBlur(layer);
        if (bP) {
            AE.sa(bP, tIn, 42);
            AE.sa(bP, tIn + dur*0.55, 10);
            AE.sa(bP, tIn + dur, 0);
            AE.ease(bP, 82);
        }
        // Gentle: 108 -> 98 -> 100 (sem overshoot selvagem)
        AE.sa(s, tIn, [108,108]);
        AE.sa(s, tIn + dur*0.6, [98,98]);
        AE.sa(s, tIn + dur, [100,100]);
        AE.ease(s, 82);
        AE.sa(o, tIn, 0);
        AE.sa(o, tIn + dur*0.5, 100);
        AE.ease(o, 78);
    }

    // MORPH OUT: BLOOM pra fora (cresce + blur + fade) — sensacao de dissolver na proxima cena
    function morphOut(layer, tOut, dur) {
        if (!layer) return;
        dur = dur || 0.7;
        var s = AE.scl(layer);
        var o = AE.opa(layer);
        var cur = AE.gv(s) || [100,100];
        var bP = getBlur(layer);
        if (bP) {
            AE.sa(bP, tOut, 0);
            AE.sa(bP, tOut + dur*0.45, 14);
            AE.sa(bP, tOut + dur, 42);
            AE.ease(bP, 78);
        }
        // Cresce em vez de encolher — feels like blooming into next scene
        AE.sa(s, tOut, cur);
        AE.sa(s, tOut + dur*0.55, [cur[0]*1.04, cur[1]*1.04]);
        AE.sa(s, tOut + dur, [cur[0]*1.09, cur[1]*1.09]);
        AE.ease(s, 78);
        AE.sa(o, tOut, 100);
        AE.sa(o, tOut + dur*0.55, 92);
        AE.sa(o, tOut + dur, 0);
        AE.ease(o, 75);
    }

    // APPLE IN: super smooth, overshoot sutil estilo iOS
    function appleIn(layer, tIn, dur) {
        if (!layer) return;
        dur = dur || 0.75;
        var s = AE.scl(layer);
        var o = AE.opa(layer);
        var bP = getBlur(layer);
        if (bP) {
            AE.sa(bP, tIn, 28);
            AE.sa(bP, tIn + dur*0.65, 5);
            AE.sa(bP, tIn + dur, 0);
            AE.ease(bP, 88);
        }
        AE.sa(s, tIn, [104,104]);
        AE.sa(s, tIn + dur*0.6, [98,98]);
        AE.sa(s, tIn + dur, [100,100]);
        AE.ease(s, 88);
        AE.sa(o, tIn, 0);
        AE.sa(o, tIn + dur*0.55, 100);
        AE.ease(o, 82);
    }

    // BOUNCE POP: bounce elastico controlado — nao estoura o container
    function bouncePop(layer, tIn, dur) {
        if (!layer) return;
        dur = dur || 0.95;
        var s = AE.scl(layer);
        var o = AE.opa(layer);
        var bP = getBlur(layer);
        if (bP) {
            AE.sa(bP, tIn, 50);
            AE.sa(bP, tIn + dur*0.35, 12);
            AE.sa(bP, tIn + dur*0.65, 0);
            AE.ease(bP, 80);
        }
        // Bounce mais contido: 0 -> 110 -> 96 -> 103 -> 100 (menos "fora da caixa")
        AE.sa(s, tIn, [0,0]);
        AE.sa(s, tIn + dur*0.32, [110,110]);
        AE.sa(s, tIn + dur*0.52, [96,96]);
        AE.sa(s, tIn + dur*0.72, [103,103]);
        AE.sa(s, tIn + dur*0.88, [98,98]);
        AE.sa(s, tIn + dur, [100,100]);
        AE.ease(s, 72);
        AE.sa(o, tIn, 0);
        AE.sa(o, tIn + dur*0.3, 100);
        AE.ease(o, 68);
    }

    // FADE IN: blur dissolve suave
    function fadeIn(layer, tIn, dur) {
        if (!layer) return;
        dur = dur || 0.55;
        var o = AE.opa(layer);
        if (!o) return;
        var bP = getBlur(layer);
        if (bP) {
            AE.sa(bP, tIn, 22);
            AE.sa(bP, tIn + dur*0.7, 5);
            AE.sa(bP, tIn + dur, 0);
            AE.ease(bP, 80);
        }
        AE.sa(o, tIn, 0);
        AE.sa(o, tIn + dur*0.6, 100);
        AE.ease(o, 78);
    }

    // FADE OUT: blur dissolve expansivo
    function fadeOut(layer, tOut, dur) {
        if (!layer) return;
        dur = dur || 0.65;
        var o = AE.opa(layer);
        if (!o) return;
        var bP = getBlur(layer);
        if (bP) {
            AE.sa(bP, tOut, 0);
            AE.sa(bP, tOut + dur*0.5, 12);
            AE.sa(bP, tOut + dur, 38);
            AE.ease(bP, 78);
        }
        AE.sa(o, tOut, 100);
        AE.sa(o, tOut + dur*0.55, 88);
        AE.sa(o, tOut + dur, 0);
        AE.ease(o, 75);
    }

    // TILT: rotation animation
    function tilt(layer, t1, a1, t2, a2) {
        if (!layer) return;
        var r = AE.rot(layer);
        if (!r) return;
        AE.sa(r, t1, a1);
        AE.sa(r, t2, a2);
        AE.ease(r, 75);
    }

    // SHADOW / GLOW / BLUR
    function addShadow(layer, opac, dist, soft) {
        if (!layer) return;
        var sh = AE.fx(layer, "ADBE Drop Shadow");
        if (sh) {
            AE.sv(AE.gc(sh, ["ADBE Drop Shadow-0002"]), opac || 22);
            AE.sv(AE.gc(sh, ["ADBE Drop Shadow-0005"]), dist || 6);
            AE.sv(AE.gc(sh, ["ADBE Drop Shadow-0006"]), soft || 28);
        }
    }
    function addGlow(layer, color, opac, soft) {
        if (!layer) return;
        var c = color || [1,1,1];
        var op = opac || 70;
        var sf = soft || 50;
        // Glow interno (tight) - primeiro Drop Shadow
        var sh1 = AE.fx(layer, "ADBE Drop Shadow");
        if (sh1) {
            AE.sv(AE.gc(sh1, ["ADBE Drop Shadow-0001"]), [c[0],c[1],c[2],1]);
            AE.sv(AE.gc(sh1, ["ADBE Drop Shadow-0002"]), Math.min(100, op * 1.4));
            AE.sv(AE.gc(sh1, ["ADBE Drop Shadow-0005"]), 0);
            AE.sv(AE.gc(sh1, ["ADBE Drop Shadow-0006"]), sf * 0.45);
        }
        // Glow externo (halo wide) - segundo Drop Shadow
        var sh2 = AE.fx(layer, "ADBE Drop Shadow");
        if (sh2) {
            AE.sv(AE.gc(sh2, ["ADBE Drop Shadow-0001"]), [c[0],c[1],c[2],1]);
            AE.sv(AE.gc(sh2, ["ADBE Drop Shadow-0002"]), Math.min(100, op * 0.85));
            AE.sv(AE.gc(sh2, ["ADBE Drop Shadow-0005"]), 0);
            AE.sv(AE.gc(sh2, ["ADBE Drop Shadow-0006"]), sf * 1.8);
        }
        // ADBE Glow real para brilho e bloom
        var gl = AE.fx(layer, "ADBE Glow");
        if (gl) {
            try { AE.sv(AE.gc(gl, ["ADBE Glow-0002"]), 40); } catch(e) {}
            try { AE.sv(AE.gc(gl, ["ADBE Glow-0003"]), sf * 1.3); } catch(e) {}
            try { AE.sv(AE.gc(gl, ["ADBE Glow-0004"]), Math.min(4.5, op / 22)); } catch(e) {}
        }
    }
    // STATIC HALO BLUR — uses Fast Box Blur so it does NOT conflict with the
    // dynamic Gaussian Blur 2 used by morphIn/morphOut/appleIn/bouncePop helpers.
    function addBlur(layer, amount) {
        if (!layer) return;
        var fb = AE.fx(layer, "ADBE Box Blur2");
        if (fb) {
            try { AE.sv(AE.gc(fb, ["ADBE Box Blur2-0001"]), amount || 20); } catch(e) {}
            try { AE.sv(AE.gc(fb, ["ADBE Box Blur2-0002"]), 3); } catch(e) {}
            try { AE.sv(AE.gc(fb, ["ADBE Box Blur2-0004"]), 1); } catch(e) {}
            return;
        }
        // Fallback: try legacy Fast Blur match name
        var fbOld = AE.fx(layer, "ADBE Fast Blur");
        if (fbOld) {
            try { AE.sv(AE.gc(fbOld, ["ADBE Fast Blur-0001"]), amount || 20); } catch(e) {}
            try { AE.sv(AE.gc(fbOld, ["ADBE Fast Blur-0003"]), 1); } catch(e) {}
        }
    }

    // MORPH ROUNDNESS: animate rect corner radius
    function morphRoundness(layer, t1, r1, t2, r2) {
        if (!layer) return;
        try {
            var rn = layer.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group").property(1).property("ADBE Vector Rect Roundness");
            if (rn) {
                AE.sa(rn, t1, r1);
                AE.sa(rn, t2, r2);
                AE.ease(rn, 80);
            }
        } catch(e) {}
    }

    // BREATHING: continuous scale pulse
    function breathe(layer, tStart, tEnd, min, max) {
        if (!layer) return;
        var s = AE.scl(layer);
        if (!s) return;
        var d = tEnd - tStart;
        var steps = 6;
        for (var b = 0; b <= steps; b++) {
            var t = tStart + (d * b / steps);
            var v = (b % 2 === 0) ? min : max;
            AE.sa(s, t, [v, v]);
        }
        AE.ease(s, 75);
    }

    // ════════════════════════════════════════════════════════
    // === INICIO ===
    // ════════════════════════════════════════════════════════
    app.beginUndoGroup("Apple_Music_DNYX_Recreation");
    try {
        var W = 1080, H = 1080;
        var comp = app.project.items.addComp("Apple_Music_Dnyx_Recreation", W, H, 1, 24.0, 30);
        if (!comp) { alert("Erro criando comp."); return; }
        comp.motionBlur = true;
        var CX = W/2, CY = H/2;

        // === CORES ===
        var cBgLight = AE.hex("#EEEFF3");
        var cBgLighter = AE.hex("#F5F5F9");
        var cDark = [0,0,0];
        var cDarkRed = AE.hex("#2D0A10");
        var cPink = AE.hex("#F83E6E");
        var cPinkHi = AE.hex("#FF5C88");
        var cPinkLo = AE.hex("#C8265A");
        var cPinkSoft = AE.hex("#FFD5E3");
        var cPinkBg = AE.hex("#E8254D");
        var cWhite = [1,1,1];
        var cText = AE.hex("#0B0B10");
        var cMuted = AE.hex("#8E8E93");
        var cLightGray = AE.hex("#D1D1D6");
        var cLightGray2 = AE.hex("#E4E4EA");
        var cBlue = AE.hex("#007AFF");
        var cBlueHi = AE.hex("#4DA6FF");
        var cGreen = AE.hex("#30C857");
        var cGreenNeon = AE.hex("#56FF6A");
        var cGreenDark = AE.hex("#0F3A1A");
        var cOrange = AE.hex("#FF9500");
        var cYellow = AE.hex("#FFCC00");
        var cRed = AE.hex("#FF3B30");
        var cPurple = AE.hex("#AF52DE");
        var cTeal = AE.hex("#5AC8FA");
        var cIgPink = AE.hex("#E4405F");
        var cIgYellow = AE.hex("#FDCB5C");
        var cIgPurple = AE.hex("#833AB4");
        var cIgOrange = AE.hex("#F77737");
        var cBubble = AE.hex("#1A1A1E");

        var fBold = "Arial-BoldMT";
        var fReg = "ArialMT";

        // ═══════════════════════════════════════════════════
        // BG BASE (criado PRIMEIRO -> fica no bottom)
        // ═══════════════════════════════════════════════════
        var bgBase = SLD(comp, cBgLight, "BG_Base");

        // ═══════════════════════════════════════════════════
        // CENA 10: IG LOGO OUTRO (20.0s - 24.0s) - dark red bg
        // ═══════════════════════════════════════════════════
        var bgIG = SLD(comp, cDarkRed, "BG_IG_Outro");
        bgIG.inPoint = 20.0;
        bgIG.outPoint = 24.0;
        fadeIn(bgIG, 20.0, 0.5);

        // Vinheta radial usando elipse com blur
        var igVin = EL(comp, {p:[CX, CY], r:520, fc:cDark, n:"IG_Vin"});
        if (igVin) {
            igVin.inPoint = 20.0;
            igVin.outPoint = 24.0;
            AE.sv(AE.opa(igVin), 40);
            addBlur(igVin, 180);
        }

        // Instagram logo controller null
        var igNull = comp.layers.addNull();
        igNull.name = "IG_Null";
        igNull.inPoint = 20.0;
        igNull.outPoint = 24.0;
        AE.sv(AE.pos(igNull), [CX, CY-40]);

        // Logo backplate (gradient simulation com stack colorido)
        // Base fill changes via multiple overlapping fill shapes
        var igBase = RC(comp, {p:[CX, CY-40], sz:[260, 260], rn:68, fc:cIgPurple, n:"IG_Base"});
        if (igBase) {
            igBase.inPoint = 20.3;
            igBase.outPoint = 24.0;
            igBase.parent = igNull;
            AE.sv(AE.pos(igBase), [0, 0]);
            morphIn(igBase, 20.3, 0.75);
            AE.sv(AE.opa(igBase), 0);
        }

        // Morph colors via stacked fills with fades
        var igColorA = RC(comp, {p:[CX, CY-40], sz:[260, 260], rn:68, fc:cIgOrange, n:"IG_ColorA"});
        if (igColorA) {
            igColorA.inPoint = 20.35;
            igColorA.outPoint = 24.0;
            igColorA.parent = igNull;
            AE.sv(AE.pos(igColorA), [0, 0]);
            AE.sv(AE.opa(igColorA), 0);
            AE.sv(AE.scl(igColorA), [113, 113]);
            var aOp = AE.opa(igColorA);
            AE.sa(aOp, 20.35, 0);
            AE.sa(aOp, 20.85, 90);
            AE.sa(aOp, 21.35, 0);
            AE.ease(aOp, 80);
            var aSc = AE.scl(igColorA);
            AE.sa(aSc, 20.35, [113,113]);
            AE.sa(aSc, 21.0, [100,100]);
            AE.ease(aSc, 85);
        }

        var igColorB = RC(comp, {p:[CX, CY-40], sz:[260, 260], rn:68, fc:cIgPink, n:"IG_ColorB"});
        if (igColorB) {
            igColorB.inPoint = 20.8;
            igColorB.outPoint = 24.0;
            igColorB.parent = igNull;
            AE.sv(AE.pos(igColorB), [0, 0]);
            AE.sv(AE.opa(igColorB), 0);
            var bOp = AE.opa(igColorB);
            AE.sa(bOp, 20.8, 0);
            AE.sa(bOp, 21.3, 95);
            AE.sa(bOp, 22.0, 0);
            AE.ease(bOp, 80);
        }

        var igColorC = RC(comp, {p:[CX, CY-40], sz:[260, 260], rn:68, fc:cIgYellow, n:"IG_ColorC"});
        if (igColorC) {
            igColorC.inPoint = 21.3;
            igColorC.outPoint = 24.0;
            igColorC.parent = igNull;
            AE.sv(AE.pos(igColorC), [0, 0]);
            AE.sv(AE.opa(igColorC), 0);
            var cOp = AE.opa(igColorC);
            AE.sa(cOp, 21.3, 0);
            AE.sa(cOp, 21.7, 90);
            AE.sa(cOp, 22.3, 0);
            AE.ease(cOp, 80);
        }

        // IG logo outline (always visible - stroke only)
        var igOutline = RC(comp, {p:[CX, CY-40], sz:[260, 260], rn:68, fc:false, sc:cWhite, sw:12, n:"IG_Outline"});
        if (igOutline) {
            igOutline.inPoint = 20.4;
            igOutline.outPoint = 24.0;
            igOutline.parent = igNull;
            AE.sv(AE.pos(igOutline), [0, 0]);
            morphIn(igOutline, 20.4, 0.7);
            addGlow(igOutline, cWhite, 70, 35);
        }

        var igCircle = EL(comp, {p:[CX, CY-40], r:72, fc:false, sc:cWhite, sw:12, n:"IG_Circle"});
        if (igCircle) {
            igCircle.inPoint = 20.5;
            igCircle.outPoint = 24.0;
            igCircle.parent = igNull;
            AE.sv(AE.pos(igCircle), [0, 0]);
            bouncePop(igCircle, 20.5, 0.6);
            addGlow(igCircle, cWhite, 65, 30);
        }

        var igDot = EL(comp, {p:[CX+75, CY-115], r:12, fc:cWhite, n:"IG_Dot"});
        if (igDot) {
            igDot.inPoint = 20.7;
            igDot.outPoint = 24.0;
            igDot.parent = igNull;
            AE.sv(AE.pos(igDot), [75, -75]);
            bouncePop(igDot, 20.7, 0.4);
            addGlow(igDot, cWhite, 80, 20);
        }

        // Handle text
        var igHandle = TX(comp, "@DNYXSTUDIOS", {p:[CX, CY+190], s:58, c:cWhite, f:fBold, al:"c", tr:120, n:"IG_Handle"});
        if (igHandle) {
            igHandle.inPoint = 21.0;
            igHandle.outPoint = 24.0;
            appleIn(igHandle, 21.0, 0.6);
            addGlow(igHandle, cWhite, 60, 28);
            fadeOut(igHandle, 23.5, 0.5);
        }

        // Breathe effect on whole logo via null
        breathe(igNull, 21.8, 23.5, 100, 104);

        // Outro fade
        var igFadeOut = SLD(comp, cDark, "Outro_FadeBlack");
        igFadeOut.inPoint = 23.5;
        igFadeOut.outPoint = 24.0;
        AE.sv(AE.opa(igFadeOut), 0);
        fadeIn(igFadeOut, 23.55, 0.4);

        // ═══════════════════════════════════════════════════
        // CENA 9: DNYXSTUDIOS PINK (17.5s - 20.0s)
        // ═══════════════════════════════════════════════════
        var bgPink = SLD(comp, cPinkBg, "BG_Pink");
        bgPink.inPoint = 17.5;
        bgPink.outPoint = 20.0;
        morphIn(bgPink, 17.5, 0.5);

        // Radial glow center
        var pinkGlow = EL(comp, {p:[CX, CY+10], r:500, fc:cPinkHi, n:"Pink_Glow"});
        if (pinkGlow) {
            pinkGlow.inPoint = 17.55;
            pinkGlow.outPoint = 20.0;
            AE.sv(AE.opa(pinkGlow), 60);
            addBlur(pinkGlow, 260);
            var pgS = AE.scl(pinkGlow);
            AE.sa(pgS, 17.55, [70,70]);
            AE.sa(pgS, 18.5, [115,115]);
            AE.sa(pgS, 19.8, [130,130]);
            AE.ease(pgS, 80);
            fadeOut(pinkGlow, 19.5, 0.5);
        }

        // dnyxstudios text with white glow
        var dnyxTxt = TX(comp, "dnyxstudios", {p:[CX, CY+25], s:120, c:cWhite, f:fBold, al:"c", tr:40, n:"Dnyx_Txt"});
        if (dnyxTxt) {
            dnyxTxt.inPoint = 17.7;
            dnyxTxt.outPoint = 20.0;
            bouncePop(dnyxTxt, 17.7, 0.75);
            addGlow(dnyxTxt, cWhite, 95, 70);
            morphOut(dnyxTxt, 19.45, 0.55);
        }

        // Small IG icon top right
        var smIG = RC(comp, {p:[CX+420, CY-420], sz:[56, 56], rn:14, fc:false, sc:cWhite, sw:4, n:"SmIG_Box"});
        if (smIG) {
            smIG.inPoint = 17.8;
            smIG.outPoint = 20.05;
            appleIn(smIG, 17.8, 0.45);
            fadeOut(smIG, 19.45, 0.55);
        }
        var smIGCirc = EL(comp, {p:[CX+420, CY-420], r:14, fc:false, sc:cWhite, sw:4, n:"SmIG_Circ"});
        if (smIGCirc) {
            smIGCirc.inPoint = 17.82;
            smIGCirc.outPoint = 20.05;
            appleIn(smIGCirc, 17.82, 0.45);
            fadeOut(smIGCirc, 19.45, 0.55);
        }
        var smIGDot = EL(comp, {p:[CX+436, CY-438], r:3, fc:cWhite, n:"SmIG_Dot"});
        if (smIGDot) {
            smIGDot.inPoint = 17.84;
            smIGDot.outPoint = 20.05;
            fadeIn(smIGDot, 17.84, 0.35);
            fadeOut(smIGDot, 19.45, 0.55);
        }

        // Handle
        var smHandle = TX(comp, "@DNYXSTUDIOS", {p:[CX+420, CY-345], s:30, c:cWhite, f:fBold, al:"c", tr:60, n:"Sm_Handle"});
        if (smHandle) {
            smHandle.inPoint = 17.9;
            smHandle.outPoint = 20.05;
            fadeIn(smHandle, 17.9, 0.35);
            fadeOut(smHandle, 19.45, 0.55);
        }

        // ═══════════════════════════════════════════════════
        // CENA 8: PHONE + CHAT BUBBLES (14.0s - 17.5s)
        // ═══════════════════════════════════════════════════
        var bgPhone = SLD(comp, cDarkRed, "BG_Phone");
        bgPhone.inPoint = 14.0;
        bgPhone.outPoint = 17.55;
        fadeIn(bgPhone, 14.0, 0.5);
        fadeOut(bgPhone, 17.0, 0.55);

        // Phone null for tilt anim
        var phNull = comp.layers.addNull();
        phNull.name = "Phone_Null";
        phNull.inPoint = 14.0;
        phNull.outPoint = 17.55;
        AE.sv(AE.pos(phNull), [CX, CY]);
        tilt(phNull, 14.0, -12, 16.9, 10);

        // Phone frame
        var phFrame = RC(comp, {p:[CX, CY], sz:[400, 820], rn:70, fc:cBubble, n:"Ph_Frame"});
        if (phFrame) {
            phFrame.inPoint = 14.0;
            phFrame.outPoint = 17.55;
            phFrame.parent = phNull;
            AE.sv(AE.pos(phFrame), [0, 0]);
            bouncePop(phFrame, 14.0, 0.9);
            addShadow(phFrame, 55, 20, 65);
            morphOut(phFrame, 16.9, 0.6);
        }

        var phScreen = RC(comp, {p:[CX, CY], sz:[370, 790], rn:58, fc:cDark, n:"Ph_Screen"});
        if (phScreen) {
            phScreen.inPoint = 14.05;
            phScreen.outPoint = 17.55;
            phScreen.parent = phNull;
            AE.sv(AE.pos(phScreen), [0, 0]);
            appleIn(phScreen, 14.05, 0.7);
            morphOut(phScreen, 16.9, 0.6);
        }

        var phNotch = RC(comp, {p:[CX, CY-380], sz:[110, 12], rn:6, fc:cDark, n:"Ph_Notch"});
        if (phNotch) {
            phNotch.inPoint = 14.1;
            phNotch.outPoint = 17.55;
            phNotch.parent = phNull;
            AE.sv(AE.pos(phNotch), [0, -380]);
            fadeIn(phNotch, 14.1, 0.4);
            fadeOut(phNotch, 16.95, 0.55);
        }

        // Time + status
        var phTime = TX(comp, "10:25", {p:[CX-140, CY-345], s:26, c:cWhite, f:fBold, al:"l", n:"Ph_Time"});
        if (phTime) {
            phTime.inPoint = 14.15;
            phTime.outPoint = 17.55;
            phTime.parent = phNull;
            AE.sv(AE.pos(phTime), [-140, -345]);
            fadeIn(phTime, 14.15, 0.4);
            fadeOut(phTime, 16.95, 0.55);
        }

        // App grid - 4 columns x 6 rows
        var appColors = [cPink, cBlue, cOrange, cGreen, cPurple, cYellow, cRed, cTeal, cPinkLo, cBlueHi, cGreen, cOrange, cPurple, cPink, cYellow, cBlue, cTeal, cRed, cGreen, cOrange, cPink, cPurple, cBlue, cYellow];
        var ag = 0;
        for (var ar = 0; ar < 6; ar++) {
            for (var ac = 0; ac < 4; ac++) {
                var ax = -135 + ac * 90;
                var ay = -260 + ar * 100;
                var appIc = RC(comp, {p:[CX+ax, CY+ay], sz:[70, 70], rn:17, fc:appColors[ag % appColors.length], n:"Ph_App_"+ag});
                if (appIc) {
                    appIc.inPoint = 14.15 + ag*0.012;
                    appIc.outPoint = 17.55;
                    appIc.parent = phNull;
                    AE.sv(AE.pos(appIc), [ax, ay]);
                    appleIn(appIc, 14.15 + ag*0.012, 0.55);
                    fadeOut(appIc, 16.95, 0.55);
                }
                ag++;
            }
        }

        // Home indicator
        var phHome = RC(comp, {p:[CX, CY+360], sz:[140, 6], rn:3, fc:cWhite, n:"Ph_Home"});
        if (phHome) {
            phHome.inPoint = 14.35;
            phHome.outPoint = 17.55;
            phHome.parent = phNull;
            AE.sv(AE.pos(phHome), [0, 360]);
            fadeIn(phHome, 14.35, 0.4);
            fadeOut(phHome, 16.95, 0.55);
        }

        // === CHAT BUBBLES floating around phone ===
        var bubbles = [
            {t:"turn it up twinenem", p:[CX+100, CY-360], rot:-8, delay:14.3, w:500},
            {t:"need it in my veins g", p:[CX-215, CY-160], rot:-11, delay:14.45, w:490},
            {t:"give me the link bro", p:[CX+320, CY-70], rot:9, delay:14.6, w:470},
            {t:"send me that song...", p:[CX-275, CY+55], rot:-6, delay:14.75, w:470},
            {t:"did you hear carti??", p:[CX+330, CY+100], rot:12, delay:14.9, w:510},
            {t:"keep playin' that shi", p:[CX+30, CY+295], rot:7, delay:15.05, w:490}
        ];

        for (var bi = 0; bi < bubbles.length; bi++) {
            var bub = bubbles[bi];
            var bubRect = RC(comp, {p:bub.p, sz:[bub.w, 82], rn:40, fc:cWhite, n:"Bub_"+bi});
            if (bubRect) {
                bubRect.inPoint = bub.delay;
                bubRect.outPoint = 17.55;
                bouncePop(bubRect, bub.delay, 0.85);
                tilt(bubRect, bub.delay, bub.rot + 3, 16.95, bub.rot - 3);
                addShadow(bubRect, 35, 8, 22);
                morphOut(bubRect, 16.85, 0.65);
            }
            var bubTxt = TX(comp, bub.t, {p:[bub.p[0], bub.p[1]+13], s:30, c:cText, f:fBold, al:"c", n:"BubT_"+bi});
            if (bubTxt) {
                bubTxt.inPoint = bub.delay + 0.08;
                bubTxt.outPoint = 17.55;
                if (bubRect) {
                    bubTxt.parent = bubRect;
                    AE.sv(AE.pos(bubTxt), [0, 13]);
                }
                fadeIn(bubTxt, bub.delay + 0.08, 0.35);
                fadeOut(bubTxt, 16.9, 0.55);
            }
        }

        // Small IG top right
        var phIG = RC(comp, {p:[CX+420, CY-420], sz:[56, 56], rn:14, fc:false, sc:cWhite, sw:4, n:"PhIG_Box"});
        if (phIG) { phIG.inPoint = 14.0; phIG.outPoint = 17.55; fadeIn(phIG, 14.0, 0.45); fadeOut(phIG, 17.0, 0.55); }
        var phIGCirc = EL(comp, {p:[CX+420, CY-420], r:14, fc:false, sc:cWhite, sw:4, n:"PhIG_Circ"});
        if (phIGCirc) { phIGCirc.inPoint = 14.02; phIGCirc.outPoint = 17.55; fadeIn(phIGCirc, 14.02, 0.45); fadeOut(phIGCirc, 17.0, 0.55); }
        var phIGDot = EL(comp, {p:[CX+436, CY-438], r:3, fc:cWhite, n:"PhIG_Dot"});
        if (phIGDot) { phIGDot.inPoint = 14.04; phIGDot.outPoint = 17.55; fadeIn(phIGDot, 14.04, 0.45); fadeOut(phIGDot, 17.0, 0.55); }
        var phHandle = TX(comp, "@DNYXSTUDIOS", {p:[CX+420, CY-345], s:30, c:cWhite, f:fBold, al:"c", tr:60, n:"Ph_Handle"});
        if (phHandle) { phHandle.inPoint = 14.1; phHandle.outPoint = 17.55; fadeIn(phHandle, 14.1, 0.45); fadeOut(phHandle, 17.0, 0.55); }

        // ═══════════════════════════════════════════════════
        // CENA 7: COMMENTS ORBIT + Q + 99 (11.0s - 14.0s)
        // ═══════════════════════════════════════════════════
        var bgComm = SLD(comp, cDark, "BG_Comments");
        bgComm.inPoint = 11.0;
        bgComm.outPoint = 14.05;
        fadeIn(bgComm, 11.0, 0.5);
        fadeOut(bgComm, 13.5, 0.55);

        // Central Q icon (ring circle + speech bubble tail)
        var qNull = comp.layers.addNull();
        qNull.name = "Q_Null";
        qNull.inPoint = 11.0;
        qNull.outPoint = 14.05;
        AE.sv(AE.pos(qNull), [CX, CY-10]);

        var qCircBg = EL(comp, {p:[CX, CY-10], r:85, fc:AE.hex("#18181B"), n:"Q_CircBg"});
        if (qCircBg) {
            qCircBg.inPoint = 11.0;
            qCircBg.outPoint = 14.05;
            qCircBg.parent = qNull;
            AE.sv(AE.pos(qCircBg), [0, 0]);
            bouncePop(qCircBg, 11.0, 0.85);
            addGlow(qCircBg, cGreenNeon, 50, 45);
            morphOut(qCircBg, 13.4, 0.6);
        }

        var qRing = EL(comp, {p:[CX, CY-10], r:42, fc:false, sc:cWhite, sw:8, n:"Q_Ring"});
        if (qRing) {
            qRing.inPoint = 11.1;
            qRing.outPoint = 14.05;
            if (qCircBg) { qRing.parent = qCircBg; AE.sv(AE.pos(qRing), [0, 0]); }
            bouncePop(qRing, 11.1, 0.7);
            fadeOut(qRing, 13.45, 0.55);
        }

        var qTail = RC(comp, {p:[CX+32, CY+24], sz:[26, 10], rn:5, fc:cWhite, n:"Q_Tail"});
        if (qTail) {
            qTail.inPoint = 11.18;
            qTail.outPoint = 14.05;
            if (qCircBg) { qTail.parent = qCircBg; AE.sv(AE.pos(qTail), [32, 34]); }
            var qtR = AE.rot(qTail);
            AE.sa(qtR, 11.18, 35);
            AE.sa(qtR, 11.4, 35);
            appleIn(qTail, 11.18, 0.5);
            fadeOut(qTail, 13.45, 0.55);
        }

        // Counter number (neon green glow)
        var counterNum = TX(comp, "0", {p:[CX, CY+170], s:110, c:cGreenNeon, f:fBold, al:"c", n:"Counter_99"});
        if (counterNum) {
            counterNum.inPoint = 11.25;
            counterNum.outPoint = 14.05;
            var cnP = AE.gc(counterNum, ["ADBE Text Properties", "ADBE Text Document"]);
            if (cnP) {
                cnP.expression = "var i=11.25;var d=1.4;var t=(time-i)/d;t=Math.max(0,Math.min(1,t));t=1-Math.pow(1-t,3);Math.round(99*t)+''";
            }
            appleIn(counterNum, 11.25, 0.65);
            addGlow(counterNum, cGreenNeon, 90, 60);
            morphOut(counterNum, 13.4, 0.6);
        }

        // Orbit comments - 5 cards around Q
        var comments = [
            {t:"this song is so peak", t2:"bruh", av:"V", off:[0, -260], delay:11.5, rot:-2},
            {t:"ts is y he is that", t2:"GOAT", av:"J", off:[340, -80], delay:11.65, rot:4},
            {t:"j put it in air bro", t2:"", av:"H", off:[340, 130], delay:11.8, rot:-3},
            {t:"holy peak", t2:"", av:"X", off:[0, 280], delay:11.95, rot:5},
            {t:"bro what am i", t2:"hearing", av:"H", off:[-340, 80], delay:12.1, rot:-5}
        ];

        for (var cci = 0; cci < comments.length; cci++) {
            var cm = comments[cci];
            var cRect = RC(comp, {p:[CX + cm.off[0], CY + cm.off[1]], sz:[cm.t2 ? 400 : 340, cm.t2 ? 120 : 90], rn:22, fc:cBubble, n:"Cm_"+cci});
            if (cRect) {
                cRect.inPoint = cm.delay;
                cRect.outPoint = 14.05;
                bouncePop(cRect, cm.delay, 0.75);
                tilt(cRect, cm.delay, cm.rot, 13.75, cm.rot - 2);
                addGlow(cRect, cGreenNeon, 18, 20);
                addShadow(cRect, 45, 6, 18);
                morphOut(cRect, 13.4, 0.65);
            }
            // Reply label
            var cLbl = TX(comp, "Reply to dnyxstudios comment", {p:[CX + cm.off[0] + 20, CY + cm.off[1] - (cm.t2 ? 42 : 22)], s:14, c:cMuted, f:fReg, al:"l", n:"CmLbl_"+cci});
            if (cLbl) {
                cLbl.inPoint = cm.delay + 0.08; cLbl.outPoint = 14.05;
                if (cRect) { cLbl.parent = cRect; AE.sv(AE.pos(cLbl), [20, -(cm.t2 ? 42 : 22)]); }
                fadeIn(cLbl, cm.delay + 0.08, 0.3);
                fadeOut(cLbl, 13.45, 0.55);
            }
            // Avatar circle
            var cAv = EL(comp, {p:[CX + cm.off[0] - 150, CY + cm.off[1] + (cm.t2 ? 5 : -5)], r:15, fc:cWhite, n:"CmAv_"+cci});
            if (cAv) {
                cAv.inPoint = cm.delay + 0.05; cAv.outPoint = 14.05;
                if (cRect) { cAv.parent = cRect; AE.sv(AE.pos(cAv), [-150, (cm.t2 ? 5 : -5)]); }
                appleIn(cAv, cm.delay + 0.05, 0.5);
                fadeOut(cAv, 13.45, 0.55);
            }
            var cAvT = TX(comp, cm.av, {p:[CX + cm.off[0] - 150, CY + cm.off[1] + (cm.t2 ? 11 : 1)], s:16, c:cText, f:fBold, al:"c", n:"CmAvT_"+cci});
            if (cAvT) {
                cAvT.inPoint = cm.delay + 0.07; cAvT.outPoint = 14.05;
                if (cRect) { cAvT.parent = cRect; AE.sv(AE.pos(cAvT), [-150, (cm.t2 ? 11 : 1)]); }
                fadeIn(cAvT, cm.delay + 0.07, 0.3);
                fadeOut(cAvT, 13.45, 0.55);
            }
            // Main text
            var cTxt = TX(comp, cm.t, {p:[CX + cm.off[0] - 125, CY + cm.off[1] + (cm.t2 ? -5 : 6)], s:22, c:cWhite, f:fBold, al:"l", n:"CmTxt_"+cci});
            if (cTxt) {
                cTxt.inPoint = cm.delay + 0.1; cTxt.outPoint = 14.05;
                if (cRect) { cTxt.parent = cRect; AE.sv(AE.pos(cTxt), [-125, (cm.t2 ? -5 : 6)]); }
                fadeIn(cTxt, cm.delay + 0.1, 0.3);
                fadeOut(cTxt, 13.45, 0.55);
            }
            if (cm.t2) {
                var cTxt2 = TX(comp, cm.t2, {p:[CX + cm.off[0] - 125, CY + cm.off[1] + 25], s:22, c:cWhite, f:fBold, al:"l", n:"CmTxt2_"+cci});
                if (cTxt2) {
                    cTxt2.inPoint = cm.delay + 0.12; cTxt2.outPoint = 14.05;
                    if (cRect) { cTxt2.parent = cRect; AE.sv(AE.pos(cTxt2), [-125, 25]); }
                    fadeIn(cTxt2, cm.delay + 0.12, 0.3);
                    fadeOut(cTxt2, 13.45, 0.55);
                }
            }
        }

        // Background breathing glow (green aura)
        var greenAura = EL(comp, {p:[CX, CY], r:400, fc:cGreenNeon, n:"Green_Aura"});
        if (greenAura) {
            greenAura.inPoint = 11.0;
            greenAura.outPoint = 14.05;
            AE.sv(AE.opa(greenAura), 22);
            addBlur(greenAura, 260);
            var gaS = AE.scl(greenAura);
            AE.sa(gaS, 11.0, [70,70]);
            AE.sa(gaS, 12.5, [110,110]);
            AE.sa(gaS, 13.95, [125,125]);
            AE.ease(gaS, 80);
            fadeOut(greenAura, 13.45, 0.55);
        }

        // Small IG top right
        var coIG = RC(comp, {p:[CX+420, CY-420], sz:[56, 56], rn:14, fc:false, sc:cWhite, sw:4, n:"CoIG_Box"});
        if (coIG) { coIG.inPoint = 11.0; coIG.outPoint = 14.05; fadeIn(coIG, 11.0, 0.45); fadeOut(coIG, 13.5, 0.55); }
        var coIGCirc = EL(comp, {p:[CX+420, CY-420], r:14, fc:false, sc:cWhite, sw:4, n:"CoIG_Circ"});
        if (coIGCirc) { coIGCirc.inPoint = 11.02; coIGCirc.outPoint = 14.05; fadeIn(coIGCirc, 11.02, 0.45); fadeOut(coIGCirc, 13.5, 0.55); }
        var coIGDot = EL(comp, {p:[CX+436, CY-438], r:3, fc:cWhite, n:"CoIG_Dot"});
        if (coIGDot) { coIGDot.inPoint = 11.04; coIGDot.outPoint = 14.05; fadeIn(coIGDot, 11.04, 0.45); fadeOut(coIGDot, 13.5, 0.55); }
        var coHandle = TX(comp, "@DNYXSTUDIOS", {p:[CX+420, CY-345], s:30, c:cWhite, f:fBold, al:"c", tr:60, n:"Co_Handle"});
        if (coHandle) { coHandle.inPoint = 11.1; coHandle.outPoint = 14.05; fadeIn(coHandle, 11.1, 0.45); fadeOut(coHandle, 13.5, 0.55); }

        // ═══════════════════════════════════════════════════
        // CENA 6: EMOJI REACTION BAR (9.0s - 11.0s)
        // ═══════════════════════════════════════════════════
        // "I AM MUSIC" album cover fragment
        var iamCard = RC(comp, {p:[CX-175, CY-180], sz:[310, 310], rn:32, fc:cWhite, n:"IAM_Card"});
        if (iamCard) {
            iamCard.inPoint = 9.0;
            iamCard.outPoint = 11.05;
            morphIn(iamCard, 9.0, 0.75);
            addShadow(iamCard, 30, 10, 35);
            morphOut(iamCard, 10.55, 0.6);
        }
        var iamTxt = TX(comp, "I AM MUSIC", {p:[CX-175, CY-160], s:60, c:cText, f:fBold, al:"c", n:"IAM_Txt"});
        if (iamTxt) {
            iamTxt.inPoint = 9.12;
            iamTxt.outPoint = 11.05;
            if (iamCard) { iamTxt.parent = iamCard; AE.sv(AE.pos(iamTxt), [0, 20]); }
            bouncePop(iamTxt, 9.12, 0.75);
            fadeOut(iamTxt, 10.55, 0.55);
        }

        // Play pill on right (dark)
        var playPill = RC(comp, {p:[CX+200, CY-180], sz:[260, 95], rn:47, fc:cBubble, n:"Play_Pill"});
        if (playPill) {
            playPill.inPoint = 9.1;
            playPill.outPoint = 11.05;
            bouncePop(playPill, 9.1, 0.75);
            addShadow(playPill, 40, 8, 25);
            morphOut(playPill, 10.55, 0.6);
        }
        var playTri = RC(comp, {p:[CX+140, CY-180], sz:[22, 22], rn:4, fc:cWhite, n:"Play_Tri"});
        if (playTri) {
            playTri.inPoint = 9.2;
            playTri.outPoint = 11.05;
            if (playPill) { playTri.parent = playPill; AE.sv(AE.pos(playTri), [-60, 0]); }
            appleIn(playTri, 9.2, 0.5);
            fadeOut(playTri, 10.55, 0.5);
            var ptR = AE.rot(playTri);
            AE.sa(ptR, 9.2, 45);
            AE.sa(ptR, 9.4, 45);
        }
        var playTxt = TX(comp, "Play", {p:[CX+225, CY-160], s:38, c:cWhite, f:fBold, al:"c", n:"Play_Txt"});
        if (playTxt) {
            playTxt.inPoint = 9.25;
            playTxt.outPoint = 11.05;
            if (playPill) { playTxt.parent = playPill; AE.sv(AE.pos(playTxt), [25, 20]); }
            fadeIn(playTxt, 9.25, 0.35);
            fadeOut(playTxt, 10.55, 0.5);
        }

        // Time label below play
        var playTime = TX(comp, "2:54", {p:[CX+200, CY-60], s:36, c:cMuted, f:fBold, al:"c", n:"Play_Time"});
        if (playTime) {
            playTime.inPoint = 9.3;
            playTime.outPoint = 11.05;
            fadeIn(playTime, 9.3, 0.35);
            fadeOut(playTime, 10.55, 0.5);
        }

        // EMOJI REACTION BAR
        var emBar = RC(comp, {p:[CX, CY+180], sz:[560, 140], rn:70, fc:cWhite, n:"Em_Bar"});
        if (emBar) {
            emBar.inPoint = 9.4;
            emBar.outPoint = 11.05;
            bouncePop(emBar, 9.4, 0.85);
            addShadow(emBar, 32, 8, 30);
            morphOut(emBar, 10.55, 0.6);
        }

        // Blue search circle (left) - child of emBar
        var emBlue = EL(comp, {p:[CX-210, CY+180], r:52, fc:cBlue, n:"Em_Blue"});
        if (emBlue) {
            emBlue.inPoint = 9.55;
            emBlue.outPoint = 11.05;
            if (emBar) { emBlue.parent = emBar; AE.sv(AE.pos(emBlue), [-210, 0]); }
            bouncePop(emBlue, 9.55, 0.7);
            addGlow(emBlue, cBlue, 50, 28);
            fadeOut(emBlue, 10.55, 0.5);
        }
        var emSearchRing = EL(comp, {p:[CX-210, CY+175], r:20, fc:false, sc:cWhite, sw:6, n:"Em_SearchRing"});
        if (emSearchRing) {
            emSearchRing.inPoint = 9.62;
            emSearchRing.outPoint = 11.05;
            if (emBar) { emSearchRing.parent = emBar; AE.sv(AE.pos(emSearchRing), [-210, -5]); }
            appleIn(emSearchRing, 9.62, 0.5);
            fadeOut(emSearchRing, 10.55, 0.5);
        }
        var emSearchTail = RC(comp, {p:[CX-192, CY+198], sz:[12, 4], rn:2, fc:cWhite, n:"Em_SearchTail"});
        if (emSearchTail) {
            emSearchTail.inPoint = 9.64;
            emSearchTail.outPoint = 11.05;
            if (emBar) { emSearchTail.parent = emBar; AE.sv(AE.pos(emSearchTail), [-192, 18]); }
            fadeIn(emSearchTail, 9.64, 0.3);
            var esR = AE.rot(emSearchTail);
            AE.sa(esR, 9.64, 45);
            AE.sa(esR, 9.8, 45);
            fadeOut(emSearchTail, 10.55, 0.5);
        }

        // Emoji placeholders: exploding head, sweat, fire - each text child of its circle
        var emojis = [
            {p:[CX-80, CY+180], localP:[-80, 0], c:AE.hex("#FCC244"), t:"X", delay:9.7},
            {p:[CX+50, CY+180], localP:[50, 0], c:AE.hex("#FCC244"), t:"~", delay:9.82},
            {p:[CX+180, CY+180], localP:[180, 0], c:AE.hex("#FF6B1C"), t:"*", delay:9.94}
        ];
        for (var ei = 0; ei < emojis.length; ei++) {
            var em = emojis[ei];
            var emCirc = EL(comp, {p:em.p, r:50, fc:em.c, n:"Emoji_"+ei});
            if (emCirc) {
                emCirc.inPoint = em.delay;
                emCirc.outPoint = 11.05;
                if (emBar) { emCirc.parent = emBar; AE.sv(AE.pos(emCirc), em.localP); }
                bouncePop(emCirc, em.delay, 0.7);
                addShadow(emCirc, 30, 4, 14);
                fadeOut(emCirc, 10.55, 0.5);
            }
            var emT = TX(comp, em.t, {p:[em.p[0], em.p[1]+14], s:56, c:cText, f:fBold, al:"c", n:"EmT_"+ei});
            if (emT) {
                emT.inPoint = em.delay + 0.05;
                emT.outPoint = 11.05;
                if (emCirc) { emT.parent = emCirc; AE.sv(AE.pos(emT), [0, 14]); }
                fadeIn(emT, em.delay + 0.05, 0.3);
                fadeOut(emT, 10.55, 0.5);
            }
        }

        // Small IG top right
        var emIG = RC(comp, {p:[CX+420, CY-420], sz:[56, 56], rn:14, fc:false, sc:cText, sw:4, n:"EmIG_Box"});
        if (emIG) { emIG.inPoint = 9.0; emIG.outPoint = 11.05; fadeIn(emIG, 9.0, 0.35); fadeOut(emIG, 10.5, 0.55); }
        var emIGCirc = EL(comp, {p:[CX+420, CY-420], r:14, fc:false, sc:cText, sw:4, n:"EmIG_Circ"});
        if (emIGCirc) { emIGCirc.inPoint = 9.02; emIGCirc.outPoint = 11.05; fadeIn(emIGCirc, 9.02, 0.35); fadeOut(emIGCirc, 10.5, 0.55); }
        var emIGDot = EL(comp, {p:[CX+436, CY-438], r:3, fc:cText, n:"EmIG_Dot"});
        if (emIGDot) { emIGDot.inPoint = 9.04; emIGDot.outPoint = 11.05; fadeIn(emIGDot, 9.04, 0.35); fadeOut(emIGDot, 10.5, 0.55); }
        var emHandle = TX(comp, "@DNYXSTUDIOS", {p:[CX+420, CY-345], s:30, c:cText, f:fBold, al:"c", tr:60, n:"Em_Handle"});
        if (emHandle) { emHandle.inPoint = 9.1; emHandle.outPoint = 11.05; fadeIn(emHandle, 9.1, 0.35); fadeOut(emHandle, 10.5, 0.55); }

        // ═══════════════════════════════════════════════════
        // CENA 5: SONG LIST - 3 TRACKS (6.0s - 9.0s)
        // ═══════════════════════════════════════════════════
        var songs = [
            {title:"Location", artist:"Playboi Carti", time:"2:48", c1:AE.hex("#7A6A4D"), c2:AE.hex("#3B2A1B"), delay:6.0, y:CY-260},
            {title:"Brian Steel", artist:"Drake", time:"1:51", c1:AE.hex("#C54A4A"), c2:AE.hex("#1F0E0E"), delay:6.3, y:CY-40},
            {title:"OLYMPIAN", artist:"Playboi Carti", time:"2:54", c1:AE.hex("#F2F2F2"), c2:AE.hex("#888888"), delay:6.6, y:CY+180}
        ];

        for (var so = 0; so < songs.length; so++) {
            var sg = songs[so];

            // Thumbnail
            var sgThumb = RC(comp, {p:[CX-280, sg.y], sz:[180, 180], rn:28, fc:sg.c1, n:"Sg_Thumb_"+so});
            if (sgThumb) {
                sgThumb.inPoint = sg.delay;
                sgThumb.outPoint = 9.05;
                bouncePop(sgThumb, sg.delay, 0.8);
                addShadow(sgThumb, 28, 6, 18);
                morphOut(sgThumb, 8.5, 0.6);
            }
            // Thumbnail accent (child of thumb)
            var sgThumb2 = RC(comp, {p:[CX-280, sg.y+40], sz:[180, 100], rn:28, fc:sg.c2, n:"Sg_Thumb2_"+so});
            if (sgThumb2) {
                sgThumb2.inPoint = sg.delay + 0.03;
                sgThumb2.outPoint = 9.05;
                if (sgThumb) { sgThumb2.parent = sgThumb; AE.sv(AE.pos(sgThumb2), [0, 40]); }
                AE.sv(AE.opa(sgThumb2), 60);
                fadeIn(sgThumb2, sg.delay + 0.03, 0.35);
                fadeOut(sgThumb2, 8.5, 0.55);
            }

            // Title
            var sgTitle = TX(comp, sg.title, {p:[CX-150, sg.y-40], s:54, c:cText, f:fBold, al:"l", n:"Sg_Title_"+so});
            if (sgTitle) {
                sgTitle.inPoint = sg.delay + 0.08;
                sgTitle.outPoint = 9.05;
                appleIn(sgTitle, sg.delay + 0.08, 0.65);
                fadeOut(sgTitle, 8.5, 0.55);
            }

            // Artist
            var sgArt = TX(comp, sg.artist, {p:[CX-150, sg.y+10], s:40, c:cText, f:fBold, al:"l", n:"Sg_Art_"+so});
            if (sgArt) {
                sgArt.inPoint = sg.delay + 0.12;
                sgArt.outPoint = 9.05;
                appleIn(sgArt, sg.delay + 0.12, 0.65);
                fadeOut(sgArt, 8.5, 0.55);
            }

            // Time
            var sgTime = TX(comp, sg.time, {p:[CX-150, sg.y+55], s:32, c:cMuted, f:fReg, al:"l", n:"Sg_Time_"+so});
            if (sgTime) {
                sgTime.inPoint = sg.delay + 0.15;
                sgTime.outPoint = 9.05;
                fadeIn(sgTime, sg.delay + 0.15, 0.45);
                fadeOut(sgTime, 8.5, 0.55);
            }

            // Play pill
            var spPill = RC(comp, {p:[CX+280, sg.y], sz:[240, 84], rn:42, fc:cBubble, n:"Sp_Pill_"+so});
            if (spPill) {
                spPill.inPoint = sg.delay + 0.1;
                spPill.outPoint = 9.05;
                bouncePop(spPill, sg.delay + 0.1, 0.7);
                addShadow(spPill, 32, 6, 18);
                morphOut(spPill, 8.5, 0.6);
            }
            var spTri = RC(comp, {p:[CX+225, sg.y], sz:[18, 18], rn:4, fc:cWhite, n:"Sp_Tri_"+so});
            if (spTri) {
                spTri.inPoint = sg.delay + 0.2;
                spTri.outPoint = 9.05;
                if (spPill) { spTri.parent = spPill; AE.sv(AE.pos(spTri), [-55, 0]); }
                var stR = AE.rot(spTri);
                AE.sa(stR, sg.delay + 0.2, 45);
                AE.sa(stR, sg.delay + 0.4, 45);
                fadeIn(spTri, sg.delay + 0.2, 0.3);
                fadeOut(spTri, 8.5, 0.5);
            }
            var spTxt = TX(comp, "Play", {p:[CX+300, sg.y+16], s:36, c:cWhite, f:fBold, al:"c", n:"Sp_Txt_"+so});
            if (spTxt) {
                spTxt.inPoint = sg.delay + 0.22;
                spTxt.outPoint = 9.05;
                if (spPill) { spTxt.parent = spPill; AE.sv(AE.pos(spTxt), [20, 16]); }
                fadeIn(spTxt, sg.delay + 0.22, 0.3);
                fadeOut(spTxt, 8.5, 0.5);
            }

            // Drag handle (left of thumbnail)
            var sgDrag = TX(comp, ":", {p:[CX-400, sg.y+5], s:44, c:cMuted, f:fBold, al:"c", n:"Sg_Drag_"+so});
            if (sgDrag) {
                sgDrag.inPoint = sg.delay + 0.02;
                sgDrag.outPoint = 9.05;
                fadeIn(sgDrag, sg.delay + 0.02, 0.3);
                fadeOut(sgDrag, 8.5, 0.5);
            }
        }

        // Top drag indicator
        var topDrag = RC(comp, {p:[CX, CY-400], sz:[80, 8], rn:4, fc:cLightGray, n:"Top_Drag"});
        if (topDrag) {
            topDrag.inPoint = 6.0;
            topDrag.outPoint = 9.05;
            fadeIn(topDrag, 6.0, 0.35);
            fadeOut(topDrag, 8.5, 0.55);
        }

        // Small IG top right
        var slIG = RC(comp, {p:[CX+420, CY-420], sz:[56, 56], rn:14, fc:false, sc:cText, sw:4, n:"SlIG_Box"});
        if (slIG) { slIG.inPoint = 6.0; slIG.outPoint = 9.05; fadeIn(slIG, 6.0, 0.35); fadeOut(slIG, 8.5, 0.55); }
        var slIGCirc = EL(comp, {p:[CX+420, CY-420], r:14, fc:false, sc:cText, sw:4, n:"SlIG_Circ"});
        if (slIGCirc) { slIGCirc.inPoint = 6.02; slIGCirc.outPoint = 9.05; fadeIn(slIGCirc, 6.02, 0.35); fadeOut(slIGCirc, 8.5, 0.55); }
        var slIGDot = EL(comp, {p:[CX+436, CY-438], r:3, fc:cText, n:"SlIG_Dot"});
        if (slIGDot) { slIGDot.inPoint = 6.04; slIGDot.outPoint = 9.05; fadeIn(slIGDot, 6.04, 0.35); fadeOut(slIGDot, 8.5, 0.55); }
        var slHandle = TX(comp, "@DNYXSTUDIOS", {p:[CX+420, CY-345], s:30, c:cText, f:fBold, al:"c", tr:60, n:"Sl_Handle"});
        if (slHandle) { slHandle.inPoint = 6.1; slHandle.outPoint = 9.05; fadeIn(slHandle, 6.1, 0.35); fadeOut(slHandle, 8.5, 0.55); }

        // ═══════════════════════════════════════════════════
        // CENA 4: APPLE MUSIC APP STORE CARD (3.5s - 6.0s)
        // ═══════════════════════════════════════════════════
        // Icon stays but smaller and on the left
        var amIcon = RC(comp, {p:[CX-330, CY], sz:[200, 200], rn:44, fc:cPink, n:"AM_Icon"});
        if (amIcon) {
            amIcon.inPoint = 3.5;
            amIcon.outPoint = 6.05;
            morphIn(amIcon, 3.5, 0.7);
            addShadow(amIcon, 35, 10, 28);
            addGlow(amIcon, cPinkHi, 35, 55);
            morphOut(amIcon, 5.55, 0.55);
        }
        var amIconHi = RC(comp, {p:[CX-330, CY-20], sz:[200, 110], rn:44, fc:cPinkHi, n:"AM_IconHi"});
        if (amIconHi) {
            amIconHi.inPoint = 3.52;
            amIconHi.outPoint = 6.05;
            if (amIcon) { amIconHi.parent = amIcon; AE.sv(AE.pos(amIconHi), [0, -20]); }
            AE.sv(AE.opa(amIconHi), 55);
            morphIn(amIconHi, 3.52, 0.7);
            morphOut(amIconHi, 5.55, 0.55);
        }

        // Music note (eighth note pair) - children of amIcon
        var amNote1 = EL(comp, {p:[CX-355, CY+30], r:18, fc:cWhite, n:"AM_Note1"});
        if (amNote1) {
            amNote1.inPoint = 3.65;
            amNote1.outPoint = 6.05;
            if (amIcon) { amNote1.parent = amIcon; AE.sv(AE.pos(amNote1), [-25, 30]); }
            bouncePop(amNote1, 3.65, 0.6);
            fadeOut(amNote1, 5.55, 0.5);
        }
        var amNote2 = EL(comp, {p:[CX-300, CY+45], r:18, fc:cWhite, n:"AM_Note2"});
        if (amNote2) {
            amNote2.inPoint = 3.68;
            amNote2.outPoint = 6.05;
            if (amIcon) { amNote2.parent = amIcon; AE.sv(AE.pos(amNote2), [30, 45]); }
            bouncePop(amNote2, 3.68, 0.6);
            fadeOut(amNote2, 5.55, 0.5);
        }
        var amStem1 = RC(comp, {p:[CX-340, CY-5], sz:[7, 75], rn:2, fc:cWhite, n:"AM_Stem1"});
        if (amStem1) {
            amStem1.inPoint = 3.66;
            amStem1.outPoint = 6.05;
            if (amIcon) { amStem1.parent = amIcon; AE.sv(AE.pos(amStem1), [-10, -5]); }
            fadeIn(amStem1, 3.66, 0.35);
            fadeOut(amStem1, 5.55, 0.5);
        }
        var amStem2 = RC(comp, {p:[CX-285, CY+10], sz:[7, 75], rn:2, fc:cWhite, n:"AM_Stem2"});
        if (amStem2) {
            amStem2.inPoint = 3.68;
            amStem2.outPoint = 6.05;
            if (amIcon) { amStem2.parent = amIcon; AE.sv(AE.pos(amStem2), [45, 10]); }
            fadeIn(amStem2, 3.68, 0.35);
            fadeOut(amStem2, 5.55, 0.5);
        }
        var amBar = RC(comp, {p:[CX-313, CY-42], sz:[70, 10], rn:2, fc:cWhite, n:"AM_Bar"});
        if (amBar) {
            amBar.inPoint = 3.7;
            amBar.outPoint = 6.05;
            if (amIcon) { amBar.parent = amIcon; AE.sv(AE.pos(amBar), [17, -42]); }
            var amBarR = AE.rot(amBar);
            AE.sa(amBarR, 3.7, -12);
            AE.sa(amBarR, 3.9, -12);
            fadeIn(amBar, 3.7, 0.35);
            fadeOut(amBar, 5.55, 0.5);
        }

        // Apple Music title
        var amTitle = TX(comp, "Apple Music", {p:[CX-170, CY-40], s:62, c:cText, f:fBold, al:"l", n:"AM_Title"});
        if (amTitle) {
            amTitle.inPoint = 3.7;
            amTitle.outPoint = 6.05;
            appleIn(amTitle, 3.7, 0.6);
            fadeOut(amTitle, 5.5, 0.55);
        }

        // Subtitle
        var amSub = TX(comp, "Over 100 million songs.", {p:[CX-170, CY+25], s:38, c:cMuted, f:fReg, al:"l", n:"AM_Sub"});
        if (amSub) {
            amSub.inPoint = 3.8;
            amSub.outPoint = 6.05;
            appleIn(amSub, 3.8, 0.6);
            fadeOut(amSub, 5.5, 0.55);
        }

        // Stars (simplified)
        var amStars = TX(comp, "*****  7.4k", {p:[CX-170, CY+100], s:36, c:cMuted, f:fReg, al:"l", tr:80, n:"AM_Stars"});
        if (amStars) {
            amStars.inPoint = 3.9;
            amStars.outPoint = 6.05;
            fadeIn(amStars, 3.9, 0.4);
            fadeOut(amStars, 5.5, 0.55);
        }

        // Apple developer label
        var amDev = TX(comp, "o Apple", {p:[CX+135, CY+100], s:36, c:cMuted, f:fReg, al:"l", n:"AM_Dev"});
        if (amDev) {
            amDev.inPoint = 3.95;
            amDev.outPoint = 6.05;
            fadeIn(amDev, 3.95, 0.4);
            fadeOut(amDev, 5.5, 0.55);
        }
        var amMusic = TX(comp, "* Music", {p:[CX+380, CY+100], s:36, c:cMuted, f:fReg, al:"l", n:"AM_Music"});
        if (amMusic) {
            amMusic.inPoint = 4.0;
            amMusic.outPoint = 6.05;
            fadeIn(amMusic, 4.0, 0.4);
            fadeOut(amMusic, 5.5, 0.55);
        }

        // OPEN button (blue pill with pulse glow)
        var amOpenGlow = EL(comp, {p:[CX+380, CY-30], r:145, fc:cBlueHi, n:"AM_OpenGlow"});
        if (amOpenGlow) {
            amOpenGlow.inPoint = 4.1;
            amOpenGlow.outPoint = 6.05;
            AE.sv(AE.opa(amOpenGlow), 35);
            addBlur(amOpenGlow, 80);
            var amgS = AE.scl(amOpenGlow);
            AE.sa(amgS, 4.1, [60,60]);
            AE.sa(amgS, 4.6, [120,120]);
            AE.sa(amgS, 5.1, [100,100]);
            AE.sa(amgS, 5.6, [120,120]);
            AE.ease(amgS, 70);
            fadeOut(amOpenGlow, 5.5, 0.55);
        }
        var amOpenBtn = RC(comp, {p:[CX+380, CY-30], sz:[220, 90], rn:45, fc:cBlue, n:"AM_OpenBtn"});
        if (amOpenBtn) {
            amOpenBtn.inPoint = 4.15;
            amOpenBtn.outPoint = 6.05;
            bouncePop(amOpenBtn, 4.15, 0.8);
            addShadow(amOpenBtn, 40, 8, 22);
            addGlow(amOpenBtn, cBlueHi, 50, 30);
            morphOut(amOpenBtn, 5.55, 0.55);
        }
        var amOpenTxt = TX(comp, "Open", {p:[CX+380, CY-10], s:50, c:cWhite, f:fBold, al:"c", n:"AM_OpenTxt"});
        if (amOpenTxt) {
            amOpenTxt.inPoint = 4.25;
            amOpenTxt.outPoint = 6.05;
            if (amOpenBtn) { amOpenTxt.parent = amOpenBtn; AE.sv(AE.pos(amOpenTxt), [0, 20]); }
            fadeIn(amOpenTxt, 4.25, 0.35);
            fadeOut(amOpenTxt, 5.55, 0.55);
        }

        // Small IG top right
        var amIG = RC(comp, {p:[CX+420, CY-420], sz:[56, 56], rn:14, fc:false, sc:cText, sw:4, n:"AmIG_Box"});
        if (amIG) { amIG.inPoint = 3.5; amIG.outPoint = 6.05; fadeIn(amIG, 3.5, 0.35); fadeOut(amIG, 5.5, 0.55); }
        var amIGCirc = EL(comp, {p:[CX+420, CY-420], r:14, fc:false, sc:cText, sw:4, n:"AmIG_Circ"});
        if (amIGCirc) { amIGCirc.inPoint = 3.52; amIGCirc.outPoint = 6.05; fadeIn(amIGCirc, 3.52, 0.35); fadeOut(amIGCirc, 5.5, 0.55); }
        var amIGDot = EL(comp, {p:[CX+436, CY-438], r:3, fc:cText, n:"AmIG_Dot"});
        if (amIGDot) { amIGDot.inPoint = 3.54; amIGDot.outPoint = 6.05; fadeIn(amIGDot, 3.54, 0.35); fadeOut(amIGDot, 5.5, 0.55); }
        var amHandle = TX(comp, "@DNYXSTUDIOS", {p:[CX+420, CY-345], s:30, c:cText, f:fBold, al:"c", tr:60, n:"Am_Handle"});
        if (amHandle) { amHandle.inPoint = 3.6; amHandle.outPoint = 6.05; fadeIn(amHandle, 3.6, 0.35); fadeOut(amHandle, 5.5, 0.55); }

        // ═══════════════════════════════════════════════════
        // CENA 3: MUSIC ICON CLOSEUP (1.5s - 3.5s)
        // ═══════════════════════════════════════════════════
        // Larger centered icon with pink radial glow
        var bigGlow = EL(comp, {p:[CX, CY], r:420, fc:cPinkSoft, n:"Big_Glow"});
        if (bigGlow) {
            bigGlow.inPoint = 1.5;
            bigGlow.outPoint = 3.5;
            AE.sv(AE.opa(bigGlow), 70);
            addBlur(bigGlow, 220);
            var bgS = AE.scl(bigGlow);
            AE.sa(bgS, 1.5, [70,70]);
            AE.sa(bgS, 2.5, [115,115]);
            AE.sa(bgS, 3.4, [130,130]);
            AE.ease(bgS, 82);
            fadeIn(bigGlow, 1.5, 0.4);
            fadeOut(bigGlow, 3.25, 0.25);
        }

        var bigIcon = RC(comp, {p:[CX, CY], sz:[320, 320], rn:70, fc:cPink, n:"Big_Icon"});
        if (bigIcon) {
            bigIcon.inPoint = 1.5;
            bigIcon.outPoint = 3.55;
            bouncePop(bigIcon, 1.5, 0.95);
            addShadow(bigIcon, 45, 14, 40);
            addGlow(bigIcon, cPinkHi, 45, 65);
            // Morph to smaller/moved position at scene transition
            var biS = AE.scl(bigIcon);
            AE.sa(biS, 2.85, [100,100]);
            AE.sa(biS, 3.45, [60,60]);
            AE.ease(biS, 85);
            var biP = AE.pos(bigIcon);
            AE.sa(biP, 2.85, [CX, CY]);
            AE.sa(biP, 3.45, [CX-330, CY]);
            AE.ease(biP, 88);
            var biO = AE.opa(bigIcon);
            AE.sa(biO, 3.4, 100);
            AE.sa(biO, 3.55, 0);
            AE.ease(biO, 75);
        }

        var bigIconHi = RC(comp, {p:[CX, CY-35], sz:[320, 180], rn:70, fc:cPinkHi, n:"Big_IconHi"});
        if (bigIconHi) {
            bigIconHi.inPoint = 1.52;
            bigIconHi.outPoint = 3.55;
            if (bigIcon) { bigIconHi.parent = bigIcon; AE.sv(AE.pos(bigIconHi), [0, -35]); }
            AE.sv(AE.opa(bigIconHi), 55);
            var biHO = AE.opa(bigIconHi);
            AE.sa(biHO, 1.52, 0);
            AE.sa(biHO, 1.95, 55);
            AE.sa(biHO, 3.4, 55);
            AE.sa(biHO, 3.55, 0);
            AE.ease(biHO, 75);
        }

        // Big music note - children of bigIcon
        var bigN1 = EL(comp, {p:[CX-50, CY+50], r:28, fc:cWhite, n:"Big_N1"});
        if (bigN1) {
            bigN1.inPoint = 1.75;
            bigN1.outPoint = 3.55;
            if (bigIcon) { bigN1.parent = bigIcon; AE.sv(AE.pos(bigN1), [-50, 50]); }
            appleIn(bigN1, 1.75, 0.7);
            fadeOut(bigN1, 3.15, 0.35);
        }
        var bigN2 = EL(comp, {p:[CX+35, CY+72], r:28, fc:cWhite, n:"Big_N2"});
        if (bigN2) {
            bigN2.inPoint = 1.78;
            bigN2.outPoint = 3.55;
            if (bigIcon) { bigN2.parent = bigIcon; AE.sv(AE.pos(bigN2), [35, 72]); }
            appleIn(bigN2, 1.78, 0.7);
            fadeOut(bigN2, 3.15, 0.35);
        }
        var bigStm1 = RC(comp, {p:[CX-28, CY-5], sz:[10, 115], rn:2, fc:cWhite, n:"Big_Stm1"});
        if (bigStm1) {
            bigStm1.inPoint = 1.82;
            bigStm1.outPoint = 3.55;
            if (bigIcon) { bigStm1.parent = bigIcon; AE.sv(AE.pos(bigStm1), [-28, -5]); }
            fadeIn(bigStm1, 1.82, 0.4);
            fadeOut(bigStm1, 3.15, 0.35);
        }
        var bigStm2 = RC(comp, {p:[CX+57, CY+17], sz:[10, 115], rn:2, fc:cWhite, n:"Big_Stm2"});
        if (bigStm2) {
            bigStm2.inPoint = 1.85;
            bigStm2.outPoint = 3.55;
            if (bigIcon) { bigStm2.parent = bigIcon; AE.sv(AE.pos(bigStm2), [57, 17]); }
            fadeIn(bigStm2, 1.85, 0.4);
            fadeOut(bigStm2, 3.15, 0.35);
        }
        var bigStBar = RC(comp, {p:[CX+14, CY-63], sz:[108, 14], rn:4, fc:cWhite, n:"Big_Bar"});
        if (bigStBar) {
            bigStBar.inPoint = 1.9;
            bigStBar.outPoint = 3.55;
            if (bigIcon) { bigStBar.parent = bigIcon; AE.sv(AE.pos(bigStBar), [14, -63]); }
            fadeIn(bigStBar, 1.9, 0.4);
            var bigBR = AE.rot(bigStBar);
            AE.sa(bigBR, 1.9, -12);
            AE.sa(bigBR, 2.1, -12);
            fadeOut(bigStBar, 3.15, 0.35);
        }

        // Small IG top right corner icon
        var smBoxBig = RC(comp, {p:[CX+420, CY-420], sz:[56, 56], rn:14, fc:false, sc:cText, sw:4, n:"BigIG_Box"});
        if (smBoxBig) { smBoxBig.inPoint = 1.5; smBoxBig.outPoint = 3.55; fadeIn(smBoxBig, 1.5, 0.35); fadeOut(smBoxBig, 3.15, 0.4); }
        var smCircBig = EL(comp, {p:[CX+420, CY-420], r:14, fc:false, sc:cText, sw:4, n:"BigIG_Circ"});
        if (smCircBig) { smCircBig.inPoint = 1.52; smCircBig.outPoint = 3.55; fadeIn(smCircBig, 1.52, 0.35); fadeOut(smCircBig, 3.15, 0.4); }
        var smDotBig = EL(comp, {p:[CX+436, CY-438], r:3, fc:cText, n:"BigIG_Dot"});
        if (smDotBig) { smDotBig.inPoint = 1.54; smDotBig.outPoint = 3.55; fadeIn(smDotBig, 1.54, 0.35); fadeOut(smDotBig, 3.15, 0.4); }
        var bigHandle = TX(comp, "@DNYXSTUDIOS", {p:[CX+420, CY-345], s:30, c:cText, f:fBold, al:"c", tr:60, n:"Big_Handle"});
        if (bigHandle) { bigHandle.inPoint = 1.6; bigHandle.outPoint = 3.55; fadeIn(bigHandle, 1.6, 0.35); fadeOut(bigHandle, 3.15, 0.4); }

        // ═══════════════════════════════════════════════════
        // CENA 1+2: OPENER RADIAL (0.0s - 1.5s)
        // ═══════════════════════════════════════════════════
        // Pink radial reveal expanding from center
        var openGlow = EL(comp, {p:[CX, CY], r:300, fc:cPinkSoft, n:"Open_Glow"});
        if (openGlow) {
            openGlow.inPoint = 0.0;
            openGlow.outPoint = 1.6;
            AE.sv(AE.opa(openGlow), 0);
            addBlur(openGlow, 180);
            var ogS = AE.scl(openGlow);
            AE.sa(ogS, 0.0, [20,20]);
            AE.sa(ogS, 1.2, [130,130]);
            AE.ease(ogS, 85);
            var ogO = AE.opa(openGlow);
            AE.sa(ogO, 0.0, 0);
            AE.sa(ogO, 0.4, 75);
            AE.sa(ogO, 1.45, 0);
            AE.ease(ogO, 75);
        }

        // Opener small icon that bounces in then scales to big
        var openIcon = RC(comp, {p:[CX, CY], sz:[160, 160], rn:36, fc:cPink, n:"Open_Icon"});
        if (openIcon) {
            openIcon.inPoint = 0.15;
            openIcon.outPoint = 1.58;
            bouncePop(openIcon, 0.15, 1.0);
            addShadow(openIcon, 40, 10, 30);
            addGlow(openIcon, cPinkHi, 60, 45);
            var oiS = AE.scl(openIcon);
            AE.sa(oiS, 1.2, [100,100]);
            AE.sa(oiS, 1.5, [200,200]);
            AE.ease(oiS, 85);
            var oiO = AE.opa(openIcon);
            AE.sa(oiO, 1.45, 100);
            AE.sa(oiO, 1.58, 0);
            AE.ease(oiO, 70);
        }

        // Small notes on opener icon - children so they zoom with it
        var oN1 = EL(comp, {p:[CX-22, CY+28], r:14, fc:cWhite, n:"Open_N1"});
        if (oN1) {
            oN1.inPoint = 0.35; oN1.outPoint = 1.58;
            if (openIcon) { oN1.parent = openIcon; AE.sv(AE.pos(oN1), [-22, 28]); }
            appleIn(oN1, 0.35, 0.55);
            fadeOut(oN1, 1.35, 0.23);
        }
        var oN2 = EL(comp, {p:[CX+22, CY+40], r:14, fc:cWhite, n:"Open_N2"});
        if (oN2) {
            oN2.inPoint = 0.38; oN2.outPoint = 1.58;
            if (openIcon) { oN2.parent = openIcon; AE.sv(AE.pos(oN2), [22, 40]); }
            appleIn(oN2, 0.38, 0.55);
            fadeOut(oN2, 1.35, 0.23);
        }
        var oSt1 = RC(comp, {p:[CX-10, CY-8], sz:[5, 60], rn:2, fc:cWhite, n:"Open_St1"});
        if (oSt1) {
            oSt1.inPoint = 0.4; oSt1.outPoint = 1.58;
            if (openIcon) { oSt1.parent = openIcon; AE.sv(AE.pos(oSt1), [-10, -8]); }
            fadeIn(oSt1, 0.4, 0.3);
            fadeOut(oSt1, 1.35, 0.23);
        }
        var oSt2 = RC(comp, {p:[CX+34, CY+4], sz:[5, 60], rn:2, fc:cWhite, n:"Open_St2"});
        if (oSt2) {
            oSt2.inPoint = 0.42; oSt2.outPoint = 1.58;
            if (openIcon) { oSt2.parent = openIcon; AE.sv(AE.pos(oSt2), [34, 4]); }
            fadeIn(oSt2, 0.42, 0.3);
            fadeOut(oSt2, 1.35, 0.23);
        }
        var oBar = RC(comp, {p:[CX+12, CY-32], sz:[58, 7], rn:2, fc:cWhite, n:"Open_Bar"});
        if (oBar) {
            oBar.inPoint = 0.45;
            oBar.outPoint = 1.58;
            if (openIcon) { oBar.parent = openIcon; AE.sv(AE.pos(oBar), [12, -32]); }
            var obR = AE.rot(oBar);
            AE.sa(obR, 0.45, -12);
            AE.sa(obR, 0.55, -12);
            fadeIn(oBar, 0.45, 0.3);
            fadeOut(oBar, 1.35, 0.23);
        }

        alert("Apple Music DNYX recriado com sucesso!\n\nResolucao: 1080x1080\nDuracao: 24.0s\nCenas: 10 com motion Apple + bounce + morphing\n\nCopie o audio original por baixo para sincronia.");

    } catch(e) {
        alert("Erro: " + e.toString() + "\nLinha: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();
